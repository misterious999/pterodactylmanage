const fs = require("fs");
const path = require("path");

// ======================================================
// Lightweight .env loader
// Tidak perlu install dotenv.
// Format:
// KEY=value
// KEY="value"
// KEY='value'
// Baris # akan diabaikan.
// ======================================================
function loadEnvFile(filePath = path.join(__dirname, ".env")) {
  if (!fs.existsSync(filePath)) return;

  const content = fs.readFileSync(filePath, "utf8");

  for (const line of content.split(/\r?\n/)) {
    const trimmed = line.trim();

    if (!trimmed || trimmed.startsWith("#")) continue;

    const separatorIndex = trimmed.indexOf("=");
    if (separatorIndex === -1) continue;

    const key = trimmed.slice(0, separatorIndex).trim();
    if (!key) continue;

    let value = trimmed.slice(separatorIndex + 1).trim();

    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }

    // Environment Variables panel lebih diprioritaskan daripada file .env
    if (!Object.prototype.hasOwnProperty.call(process.env, key)) {
      process.env[key] = value;
    }
  }
}

loadEnvFile();

function cleanEnvValue(value = "") {
  if (value === undefined || value === null) return "";

  let result = String(value).trim();

  if (
    (result.startsWith('"') && result.endsWith('"')) ||
    (result.startsWith("'") && result.endsWith("'"))
  ) {
    result = result.slice(1, -1).trim();
  }

  return result;
}

function env(key, fallback = "") {
  const value = cleanEnvValue(process.env[key]);
  return value === "" ? fallback : value;
}

function envAny(keys = [], fallback = "") {
  for (const key of keys) {
    const value = env(key);
    if (value) return value;
  }

  return fallback;
}

function requiredEnv(key, fallback = "") {
  const value = env(key, fallback);

  if (!value) {
    console.warn(`[CONFIG] ${key} belum diisi. Isi di file .env / Environment Variables panel agar fitur terkait berjalan.`);
  }

  return value;
}

function requiredEnvAny(keys = [], fallback = "") {
  const value = envAny(keys, fallback);

  if (!value) {
    console.warn(`[CONFIG] ${keys.join(" / ")} belum diisi. Isi di file .env / Environment Variables panel agar fitur terkait berjalan.`);
  }

  return value;
}

function normalizeUrl(value = "") {
  return String(value || "").trim().replace(/\/$/, "");
}

function maskSecret(value = "") {
  const clean = cleanEnvValue(value);

  if (!clean) return "KOSONG";
  if (clean.length <= 12) return "TERBACA";

  return `${clean.slice(0, 6)}...${clean.slice(-4)}`;
}

// ======================================================
// Setting Bot
// ======================================================
global.owner = requiredEnv("OWNER_NUMBER");
global.ownername = env("OWNER_NAME", "Pstar");
global.pairingNumber = requiredEnv("PAIRING_NUMBER");

global.prefix = env("BOT_PREFIX", ".");
global.versibot = env("BOT_VERSION", "2.0");
global.botname = env("BOT_NAME", "Assistant X Project");

global.linkChannel = env("LINK_CHANNEL");
global.idChannel = env("ID_CHANNEL");
global.idChannelDaftar = env("ID_CHANNEL_DAFTAR");
global.linkGrup = env("LINK_GRUP");
global.thumbnail = env("THUMBNAIL_URL");

// ======================================================
// Setting REST API Utama - BOTCAHX
// ======================================================
global.botcahxBaseUrl = normalizeUrl(
  env("BOTCAHX_BASE_URL", "https://api.botcahx.eu.org")
);

global.btc = requiredEnv("BOTCAHX_APIKEY");
global.botcahxKey = global.btc;

global.APIs = {
  btc: global.botcahxBaseUrl
};

global.APIKeys = {
  [global.botcahxBaseUrl]: global.btc
};

global.botcahxUrl = function botcahxUrl(endpoint, params = {}, keyName = "apikey") {
  const url = new URL(
    endpoint.startsWith("http")
      ? endpoint
      : `${global.botcahxBaseUrl}${endpoint.startsWith("/") ? endpoint : `/${endpoint}`}`
  );

  for (const [key, value] of Object.entries(params || {})) {
    if (value !== undefined && value !== null && value !== "") {
      url.searchParams.set(key, String(value));
    }
  }

  if (keyName && global.btc) {
    url.searchParams.set(keyName, global.btc);
  }

  return url.toString();
};

// ======================================================
// Manage Vercel
// Dipakai fitur cweb / createweb
// ======================================================
global.vercelToken = env("VERCEL_TOKEN");

// ======================================================
// Manage GitHub - DIPISAH BIAR TIDAK BENTROK
// ======================================================

// Legacy fallback.
// Kalau masih ada GITHUB_TOKEN lama, tetap dibaca.
// Tapi untuk konfigurasi baru, pakai CWEB_GITHUB_TOKEN dan LICENSE_GITHUB_TOKEN.
const legacyGithubToken = envAny([
  "GITHUB_TOKEN",
  "GITHUB_PAT",
  "GITHUB_ACCESS_TOKEN",
  "GH_TOKEN"
]);

const legacyGithubUsername = envAny([
  "GITHUB_USERNAME",
  "GH_USERNAME"
]);

// ------------------------------------------------------
// GitHub khusus CWEB2 / GitHub Pages
// ------------------------------------------------------
global.cwebGithubToken = requiredEnvAny([
  "CWEB_GITHUB_TOKEN",
  "CWEB_GITHUB_PAT",
  "CWEB_GH_TOKEN"
], legacyGithubToken);

global.cwebGithubUsername = requiredEnvAny([
  "CWEB_GITHUB_USERNAME",
  "CWEB_GH_USERNAME"
], legacyGithubUsername);

global.cwebGithubBranch = envAny([
  "CWEB_GITHUB_BRANCH",
  "CWEB_GH_BRANCH"
], "main");

// ------------------------------------------------------
// GitHub khusus LICENSE / WHITELIST PAIRING
// Dipakai addlisensi, dellisensi, listlisensi, dan index.js
// ------------------------------------------------------
global.licenseGithubToken = requiredEnvAny([
  "LICENSE_GITHUB_TOKEN",
  "LICENSE_GH_TOKEN",
  "WHITELIST_GITHUB_TOKEN"
], legacyGithubToken);

global.licenseRepoOwner = requiredEnvAny([
  "LICENSE_REPO_OWNER",
  "WHITELIST_REPO_OWNER",
  "LICENSE_GITHUB_OWNER"
], legacyGithubUsername);

global.licenseRepoName = requiredEnvAny([
  "LICENSE_REPO_NAME",
  "WHITELIST_REPO_NAME",
  "LICENSE_GITHUB_REPO"
]);

global.licenseFilePath = envAny([
  "LICENSE_FILE_PATH",
  "WHITELIST_FILE_PATH"
], "whitelist.json");

global.licenseBranch = envAny([
  "LICENSE_BRANCH",
  "WHITELIST_BRANCH"
], "main");

// ------------------------------------------------------
// Backward compatibility
// Untuk plugin lama seperti cweb.js lama yang masih membaca:
// global.githubToken / global.githubUsername
// diarahkan ke akun GitHub CWEB, bukan lisensi.
// ------------------------------------------------------
global.githubToken = global.cwebGithubToken;
global.githubUsername = global.cwebGithubUsername;

// ------------------------------------------------------
// Debug aman. Tidak menampilkan token full.
// Aktifkan dengan DEBUG_GITHUB_CONFIG=true
// ------------------------------------------------------
global.debugGithubConfig = env("DEBUG_GITHUB_CONFIG", "false").toLowerCase() === "true";

if (global.debugGithubConfig) {
  console.log("[GITHUB CONFIG - CWEB]", {
    token: maskSecret(global.cwebGithubToken),
    username: global.cwebGithubUsername || "KOSONG",
    branch: global.cwebGithubBranch || "KOSONG"
  });

  console.log("[GITHUB CONFIG - LICENSE]", {
    token: maskSecret(global.licenseGithubToken),
    repoOwner: global.licenseRepoOwner || "KOSONG",
    repoName: global.licenseRepoName || "KOSONG",
    filePath: global.licenseFilePath || "KOSONG",
    branch: global.licenseBranch || "KOSONG"
  });
}

// ======================================================
// Setting Api Panel Pterodactyl
// ======================================================
global.egg = env("PANEL_EGG_ID", "15");
global.nestid = env("PANEL_NEST_ID", "5");
global.loc = env("PANEL_LOCATION_ID", "1");

global.domain = env("PANEL_DOMAIN");
global.apikey = requiredEnv("PTERODACTYL_ADMIN_API_KEY");
global.capikey = requiredEnv("PTERODACTYL_CLIENT_API_KEY");

// ======================================================
// Setting Payment
// ======================================================
global.dana = env("PAYMENT_DANA");
global.ovo = env("PAYMENT_OVO");
global.gopay = env("PAYMENT_GOPAY");
global.qris = env("PAYMENT_QRIS_URL");
global.qrisStaticPayload = env("QRIS_STATIC_PAYLOAD");

// ======================================================
// Konfigurasi Subdomain
// ======================================================
global.subdomain = {
  [env("SUBDOMAIN_1_DOMAIN", "bypstar7.online")]: {
    zone: env("SUBDOMAIN_1_ZONE"),
    apitoken: env("SUBDOMAIN_1_API_TOKEN")
  },
  [env("SUBDOMAIN_2_DOMAIN", "pterostore.my.id")]: {
    zone: env("SUBDOMAIN_2_ZONE"),
    apitoken: env("SUBDOMAIN_2_API_TOKEN")
  }
};

// ======================================================
// Helper Global Tambahan
// ======================================================
global.pickRandom = global.pickRandom || function pickRandom(list = []) {
  return list[Math.floor(Math.random() * list.length)];
};

global.delay = global.delay || function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
};

// ======================================================
// Auto Reload Config
// ======================================================
const file = require.resolve(__filename);

fs.watchFile(file, () => {
  fs.unwatchFile(file);
  delete require.cache[file];
  require(file);
});