const fs = require("fs");
const util = require("util");
const chalk = require("chalk");

// Fungsi Jeda Waktu (Delay) untuk Countdown
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

module.exports = async (sock, m) => {
  try {
    console.log(chalk.yellow("\n📍 [RADAR 1] Pesan masuk ditangkap Handler..."));
    
    let plugins = global.plugins;
    await global.loadDatabase(sock, m);

    // 1. Ekstrak teks chat biasa atau link terlebih dahulu
    let bodyText = m.text || m.body || m.message?.conversation || m.message?.extendedTextMessage?.text || m.message?.imageMessage?.caption || m.message?.videoMessage?.caption || "";

    // 🔥 2. TANGKAP ID TOMBOL SECARA SPESIFIK & AMAN (Tanpa merusak link/teks biasa)
    if (m.message?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson) {
        try {
            let params = JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson);
            if (params && params.id) {
                bodyText = params.id;
                console.log(chalk.green(`🔥 [TOMBOL DETECTED] Payload: "${bodyText}"`));
            }
        } catch (e) {}
    } else if (m.message?.templateButtonReplyMessage?.selectedId) {
        bodyText = m.message.templateButtonReplyMessage.selectedId;
    } else if (m.message?.listResponseMessage?.singleSelectReply?.selectedRowId) {
        bodyText = m.message.listResponseMessage.singleSelectReply.selectedRowId;
    }

    m.body = bodyText;
    m.text = bodyText;

    console.log(chalk.yellow(`📍 [RADAR 2] Teks sukses diekstrak: "${bodyText}"`));

    const prefixRegex = /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?#$%^&.©^]/;
    const isCmd = prefixRegex.test(bodyText);
    const prefix = isCmd ? bodyText.match(prefixRegex)[0] : "";
    const args = isCmd ? bodyText.slice(prefix.length).trim().split(/ +/) : [];
    const command = isCmd ? args.shift().toLowerCase() : "";
    const cmd = prefix + command;
    const text = args.join(" ");
    const q = text;

    console.log(chalk.yellow(`📍 [RADAR 3] Status: isCmd=${isCmd} | Command="${command}"`));

    const quoted = m.quoted ? m.quoted : m;
    const mime = quoted?.msg?.mimetype || quoted?.mimetype || null;
    const qmsg = (m.quoted || m);
    const botNumber = m.botNumber;
    
    // 🔐 Owner diambil dari global.owner/config .env, tidak hardcode nomor pribadi.
    const ownerNumbers = Array.isArray(global.owner)
        ? global.owner.map(String)
        : String(global.owner || "").split(/[,\s]+/).filter(Boolean);
    const isOwner = m.isOwner || ownerNumbers.some(num => m.sender.includes(num.replace(/@s\.whatsapp\.net$/, "")));

    m.prefix = prefix; 
    m.cmd = cmd;
    m.mime = mime;
    m.qmsg = qmsg;
    m.args = args;
    m.isGroup = m.chat?.endsWith("g.us") || false;
    m.metadata = {};
    m.isAdmin = false;
    m.isBotAdmin = false;

    // ============================================
    // 🛡️ [ SATPAM KEAMANAN ONLY GC & ONLY PC ]
    // ============================================
    let set = global.db.settings || {};

    // ⛔ 1. BLOKIR OTOMATIS JIKA ONLY GC AKTIF (TAPI CHAT DI PRIVATE)
    if (set.onlygc && !m.isGroup && !isOwner) {
        const ownerContact = ownerNumbers[0] || "";
        let teksPeringatan = `INI NOMOR BOT, JANGAN CHAT KESINI\n\nNomormu akan di blok otomatis oleh bot, dalam beberapa saat lagi,\n\n${ownerContact ? `Chat Owner wa.me/${ownerContact}` : "Hubungi owner bot."}\n\n`;
        
        let warnMsg = await sock.sendMessage(m.chat, { text: teksPeringatan + `⏳ *5 Detik...*` });

        // Hitungan Mundur 5 Detik (Edit Pesan)
        for (let i = 4; i >= 1; i--) {
            await delay(1000); 
            await sock.sendMessage(m.chat, { text: teksPeringatan + `⏳ *${i} Detik...*`, edit: warnMsg.key });
        }

        // Eksekusi Pesan Blokir Terakhir
        await delay(1000);
        await sock.sendMessage(m.chat, { text: `⛔ *AKUN ANDA TELAH DIBLOKIR OTOMATIS OLEH SISTEM.*`, edit: warnMsg.key });
        
        // 🔥 JURUS PAMUNGKAS: RAW XMPP QUERY (Tembus WA Bisnis)
        let targetBlock = m.chat.split(':')[0] + '@s.whatsapp.net';
        
        try {
            await sock.updateBlockStatus(targetBlock, 'block'); // Coba cara biasa dulu
        } catch(e) {}

        try {
            // Bypass sistem Baileys, tembak langsung ke server Meta
            await sock.query({
                tag: "iq",
                attrs: {
                    to: "@s.whatsapp.net",
                    type: "set",
                    xmlns: "blocklist"
                },
                content: [
                    {
                        tag: "item",
                        attrs: { action: "block", jid: targetBlock }
                    }
                ]
            });
        } catch (err) {
            console.error("Gagal Blokir Raw Query:", err);
        }
        
        return; 
    }

    // ⛔ 2. DIAM JIKA ONLY PC AKTIF (TAPI CHAT DI GRUP)
    if (set.onlypc && m.isGroup && !isOwner) {
        return; 
    }
    // ============================================

    if (global.db.settings?.autoread && m.chat !== 'status@broadcast') {
        await sock.readMessages([m.key]).catch(() => {});
    }
    
    m.react = async (emoji) => {
      try { return await sock.sendMessage(m.chat, { react: { text: emoji, key: m.key } }); } catch (e) {}
    }

    m.reply = async (teks) => sock.sendMessage(m.chat, { text: String(teks) }, { quoted: m });

    // ============================================
    // 👑 [ CUSTOM X-PROTOCOL REPLY DENGAN STATUS TAG ]
    // ============================================
    m.replyPremium = async (teks) => {
        // Objek Fake Status WhatsApp (Bingkai Verified)
        const fmetaStatus = {
            key: { participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {}) },
            message: {
                imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/f1/m233/up-video-nd-10... ",
                    mimetype: "image/jpeg",
                    caption: "PROTOCOL SYSTEM", // <-- Sudah diubah menjadi X - PROTOCOL
                    jpegThumbnail: null
                }
            }
        };

        try {
            return await sock.sendMessage(m.chat, { 
                text: `${teks}`, 
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: global.idChannel || "1203631@newsletter",
                        newsletterName: "Assistant X System",
                        serverId: 1
                    }
                }
            }, { quoted: fmetaStatus }); // Memanggil tag status di sini
        } catch (e) {
            return await sock.sendMessage(m.chat, { text: `${teks}` }, { quoted: fmetaStatus });
        }
    };

    if (m.isGroup) {
      let meta = global.groupMetadataCache?.get(m.chat);
      if (!meta) meta = await sock.groupMetadata(m.chat).catch(() => {});
      m.metadata = meta || {};
      const p = m.metadata?.participants || [];
      m.isAdmin = p.some((i) => (i.id === m.sender || i.jid === m.sender) && i.admin !== null);
      m.isBotAdmin = p.some((i) => (i.id === botNumber || i.jid === botNumber) && i.admin !== null);
    }

    for (let name in plugins) {
      let plugin = plugins[name];
      if (typeof plugin?.before !== "function") continue;
      let stop = await plugin.before(m, { sock, isOwner, isAdmin: m.isAdmin, isBotAdmin: m.isBotAdmin, metadata: m.metadata });
      if (stop) return;
    }

    for (let name in plugins) {
      let plugin = plugins[name];
      if (typeof plugin?.all !== "function") continue;
      await plugin.all(m, { sock, isOwner, isAdmin: m.isAdmin, isBotAdmin: m.isBotAdmin, metadata: m.metadata });
    }

    if (!isCmd) return;
    
    if (global.db.users[m.sender]?.banned) return; 
    if (m.isGroup && global.db.groups[m.chat]?.mute && command !== "unmute") return; 

    console.log(chalk.black.bgCyan("\n>> Executing Command\n"),chalk.cyan(`From: ${m?.pushName || m?.metadata?.subject || m.sender}\n`),chalk.cyan(`Command: ${cmd}`));

    let commandTereksekusi = false;

    for (let name in plugins) {
      let plugin = plugins[name];
      if (!plugin?.command) continue;
      if (![].concat(plugin.command).includes(command)) continue;

      commandTereksekusi = true;
      let isPremiumUser = isOwner || global.db.users[m.sender]?.premium || global.db.users[m.sender]?.premiumTime > 0;

      if (plugin.owner && !isOwner) { await m.react("⚠️"); return m.replyPremium("🔒 *Akses Ditolak!*\nHanya Developer / Owner yang dapat menggunakan fitur ini."); }
      if (plugin.group && !m.isGroup) { await m.react("⚠️"); return m.replyPremium("👥 *Akses Ditolak!*\nFitur ini hanya dapat digunakan di dalam obrolan Grup."); }
      if (plugin.admin && !m.isAdmin) { await m.react("⚠️"); return m.replyPremium("🛡️ *Akses Ditolak!*\nHanya Admin Grup yang dapat menggunakan fitur ini."); }
      if (plugin.botAdmin && !m.isBotAdmin) { await m.react("⚠️"); return m.replyPremium("🤖 *Akses Ditolak!*\nSistem membutuhkan hak akses Admin Grup untuk mengeksekusi perintah."); }
      
      if (plugin.premium && !isPremiumUser) {
          await m.react("🔒");
          let teksTolak = `❌ *AKSES DITOLAK*\n\nFitur *${cmd}* bersifat eksklusif.\nKamu memerlukan akses Premium untuk membukanya.\n\n_Ketik *.owner* untuk informasi lebih lanjut._`;
          return m.replyPremium(teksTolak);
      }

      global.db.settings.totalhit = (global.db.settings.totalhit || 0) + 1;
      
      let isRegistered = global.db.users[m.sender]?.registered || false;
      let isRegisterCommand = ["daftar", "autodaftar"].includes(command);

            if (!isRegistered && !isRegisterCommand && !isOwner) {
        await m.react("❌");
        
        let teksTolak = `🔒 *ID Tidak Terdaftar*\n\nSistem menolak akses karena Bosku belum terdaftar di database.\nSilakan pilih metode pendaftaran di bawah ini untuk memulai petualangan!`;
        
        const { generateWAMessageFromContent } = require('@whiskeysockets/baileys');
        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                    interactiveMessage: {
                        body: { text: teksTolak },
                        footer: { text: "© Assistant X Security System" },
                        nativeFlowMessage: {
                            buttons: [
                                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🤖 Daftar Otomatis", id: `${prefix}autodaftar` }) },
                                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "✍️ Daftar Manual", id: `${prefix}daftar` }) }
                            ]
                        }
                    }
                }
            }
        }, { quoted: m });

        return await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
      }

      if (plugin.limit && !isPremiumUser) { 
        let userLimit = global.db.users[m.sender]?.limit || 0;
        if (userLimit < 1) { 
            await m.react("🚫"); 
            return m.replyPremium(`❌ *LIMIT EXHAUSTED*\n\nBatas penggunaan harianmu telah habis.\nGunakan perintah \`${prefix}buylimit <jumlah>\` untuk mengisi ulang.`); 
        }
      }

      await plugin(m, { sock, args, text, q, quoted: m.quoted || m, mime, command, cmd, prefix, isOwner, isAdmin: m.isAdmin, isBotAdmin: m.isBotAdmin, metadata: m.metadata });
    }
    
    if (!commandTereksekusi && isCmd) {
        console.log(chalk.red(`🛑 Command ${cmd} tidak ditemukan!`));
    }

  } catch (err) {
    console.log(chalk.bgRed("❌ [HANDLER ERROR FATAL]:"), util.format(err));
  }
};
