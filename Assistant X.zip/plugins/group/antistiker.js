let handler = async (m, { sock, command, args, isOwner, isAdmin }) => {
    // 🎛️ SAKLAR KENDALI ANTI-STIKER (Native Reply)
    if (!m.isGroup) return sock.sendMessage(m.chat, { text: "❌ Fitur Anti-Stiker hanya dapat digunakan di dalam grup." }, { quoted: m });
    if (!isAdmin && !isOwner) return sock.sendMessage(m.chat, { text: "🛡️ Akses Ditolak! Hanya Admin Grup yang berhak memegang saklar ini." }, { quoted: m });
    
    // 🛡️ PROTOKOL PERTAHANAN DATABASE (Mencegah Undefined Crash)
    if (typeof global.db === 'undefined') global.db = {};
    if (typeof global.db.chats === 'undefined') global.db.chats = {};
    if (typeof global.db.chats[m.chat] === 'undefined') global.db.chats[m.chat] = {};
    
    let chat = global.db.chats[m.chat];
    
    if (args[0] === 'on') {
        chat.antistiker = true;
        return sock.sendMessage(m.chat, { text: "✅ *Radar Anti-Stiker Berhasil DIAKTIFKAN!*\n\nSetiap stiker yang dikirim oleh member biasa akan langsung **DIHAPUS** secara otomatis oleh sistem." }, { quoted: m });
    } else if (args[0] === 'off') {
        chat.antistiker = false;
        return sock.sendMessage(m.chat, { text: "❌ *Radar Anti-Stiker Berhasil DIMATIKAN!*\n\nMember bebas mengirim stiker kembali." }, { quoted: m });
    } else {
        return sock.sendMessage(m.chat, { text: `╭───┈ *「 🚫 PANEL ANTI-STIKER 」*\n│ ◈ *Status:* ${chat.antistiker ? 'AKTIF ✅' : 'MATI ❌'}\n│\n│ ⚙️ *Panduan Penggunaan:*\n│ Ketik \`.antistiker on\` untuk menyalakan.\n│ Ketik \`.antistiker off\` untuk mematikan.\n╰───────────────┈ ⳹` }, { quoted: m });
    }
}

// 📡 SENSOR PENANGKAP STIKER (Berjalan di latar belakang)
handler.before = async function (m, { sock, isOwner, isAdmin }) {
    if (!m.isGroup || m.isBaileys) return false; 

    // 🛡️ Validasi Database di Background
    if (typeof global.db === 'undefined' || typeof global.db.chats === 'undefined') return false;
    let chat = global.db.chats[m.chat];
    if (!chat || !chat.antistiker) return false; 

    let isSticker = m.message && m.message.stickerMessage;

    if (isSticker) {
        // 👑 PROTOKOL KEKEBALAN VIP
        if (isOwner) {
            await sock.sendMessage(m.chat, { react: { text: "👑", key: m.key } }).catch(() => {});
            return false; 
        }
        
        // 👨‍💻 PROTOKOL KEKEBALAN ADMIN
        if (isAdmin) {
            await sock.sendMessage(m.chat, { react: { text: "👨‍💻", key: m.key } }).catch(() => {});
            return false; 
        }

        // 🗑️ EKSEKUSI MEMBER BIASA
        await sock.sendMessage(m.chat, { delete: m.key }).catch(() => {
            console.log("[WARNING] Bot gagal menghapus stiker. Pastikan bot sudah menjadi Admin Grup!");
        });

        let warnMsg = `╭───┈ *「 🚫 PELANGGARAN STIKER 」*\n│ 👤 *Pelaku:* @${m.sender.split('@')[0]}\n│ 🚨 *Aturan:* Anti-Stiker Aktif!\n│ 🗑️ *Tindakan:* Stiker dimusnahkan.\n╰───────────────┈ ⳹\n\n_Mohon patuhi aturan grup dan jangan buang sampah stiker di sini!_`;
        
        await sock.sendMessage(m.chat, { text: warnMsg, mentions: [m.sender] });

        return true; 
    }
}

handler.command = ["antistiker"];
handler.tags = ["group"];
handler.help = ["antistiker <on/off>"];

module.exports = handler;
