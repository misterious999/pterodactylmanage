let handler = async (m, { sock, isAdmin, isBotAdmin, isOwner, prefix, command }) => {
    // 1. Validasi: Pastikan user me-reply pesan yang ingin dihapus
    if (!m.quoted) {
        await m.react("⚠️");
        return m.reply(`❌ Reply pesan yang ingin dihapus!\n*Contoh:* Reply pesan orang lalu ketik \`${prefix + command}\``);
    }

    // Cek apakah pesan yang di-reply adalah pesan dari Bot itu sendiri
    let isBotMsg = m.quoted.sender === sock.user.jid;

    // 2. Validasi Keamanan (Jika yang dihapus BUKAN pesan bot)
    if (!isBotMsg) {
        // Yang menyuruh harus Admin Grup atau Owner Bot
        if (!isAdmin && !isOwner) {
            await m.react("⚠️");
            return m.reply("❌ Woi! Cuma *Admin Grup* atau *Owner* yang punya wewenang menghapus pesan orang lain!");
        }
        // Bot juga harus jadi Admin Grup
        if (!isBotAdmin) {
            await m.react("⚠️");
            return m.reply("❌ Jadikan bot *Admin* dulu Bosku, biar bot punya kuasa buat menghapus pesan member!");
        }
    }

    await m.react("⏳");

    try {
        // 3. Merakit Kunci Target (Target Key) untuk dihancurkan server Baileys
        let key = {
            remoteJid: m.chat,
            fromMe: isBotMsg,
            id: m.quoted.id,
            participant: m.quoted.sender
        };

        // 4. Eksekusi Hapus Pesan (Delete for Everyone)
        await sock.sendMessage(m.chat, { delete: key });
        await m.react("✅");

    } catch (e) {
        console.error("[ERROR DELETE MESSAGE]", e);
        await m.react("❌");
        m.reply("❌ Gagal menghapus pesan. Pastikan pesannya belum terlalu lama (batas waktu WA).");
    }
}

handler.command = ["del", "d"];
handler.tags = ["group"];
handler.help = ["del <reply pesan>"];

module.exports = handler;
