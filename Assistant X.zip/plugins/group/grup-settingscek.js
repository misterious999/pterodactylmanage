// ==========================================
// ⚙️ SYSTEM CONTROL PANEL (VIP DASHBOARD)
// ==========================================

let handler = async (m, { sock, isOwner }) => {
  await m.react("⏳").catch(() => {});

  // Mengambil pangkalan data global
  let sett = global.db.settings || {};
  
  // Fungsi Helper untuk membuat status lebih elegan dan mencolok
  const statusIcon = (stat) => stat ? "🟢 *Aktif*" : "🔴 *Mati*";

  // Merakit Teks Dasbor Global
  let teks = `✨ *S Y S T E M   C O N T R O L* ✨\n\n`;
  teks += `╭───「 *GLOBAL SETTINGS* 」\n`;
  teks += `│ ◦ 🔄 Auto JPM: ${statusIcon(sett.autojpm?.status)}\n`;
  teks += `│ ◦ 🚀 Push Kontak: ${global.statusPushkontak ? "🟢 *Berjalan*" : "🔴 *Mati*"}\n`;
  teks += `│ ◦ 📖 Auto Read: ${statusIcon(sett.autoread)}\n`;
  teks += `│ ◦ 👤 Mode PC Only: ${statusIcon(sett.pconly)}\n`;
  teks += `│ ◦ 👥 Mode Group Only: ${statusIcon(sett.grouponly)}\n`;
  teks += `╰──────────────\n\n`;

  // Mengambil pangkalan data grup (hanya jika perintah dieksekusi di grup)
  if (m.isGroup) {
    let gc = global.db.groups[m.chat] || {};
    
    // Status Auto-Close Spesial dengan Jadwal Waktu
    let autocloseInfo = gc.autoclose?.status 
        ? `🟢 *Aktif* (${gc.autoclose.openTime} 🔓 - ${gc.autoclose.closeTime} 🔒)` 
        : "🔴 *Mati*";
    
    teks += `╭───「 *GROUP SECURITY & AI* 」\n`;
    teks += `│ ◦ 🤖 Auto AI: ${statusIcon(gc.autoai)}\n`;
    teks += `│ ◦ 🎙️ Anti VoiceChat: ${statusIcon(gc.antiobrol)}\n`;
    teks += `│ ◦ 🔗 Anti Link Group: ${statusIcon(gc.antilinkgc)}\n`;
    teks += `│ ◦ 📢 Anti Link Channel: ${statusIcon(gc.antilinkch)}\n`;
    teks += `│ ◦ 📱 Anti Tag SW: ${statusIcon(gc.antitagsw)}\n`;
    teks += `│ ◦ 👋 Welcome Message: ${statusIcon(gc.welcome)}\n`;
    teks += `│ ◦ 🛍️ Auto Promosi: ${statusIcon(gc.autopromosi)}\n`;
    teks += `│ ◦ ⏳ Auto Close/Open: ${autocloseInfo}\n`;
    teks += `╰──────────────\n\n`;
  } else {
    teks += `_💡 Eksekusi perintah ini di dalam Grup untuk melihat dasbor keamanan grup beserta fitur AI._\n\n`;
  }

  teks += `_© Assistant X Security Protocol_ 🛡️`;

  // Mengirimkan hasil dasbor ke pengguna dengan gaya mewah VVIP
  await sock.sendMessage(m.chat, { 
      text: teks,
      contextInfo: {
          mentionedJid: [m.sender],
          forwardingScore: 999,
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
              newsletterJid: global.idChannel || "1203631@newsletter",
              newsletterName: "⚙️ Assistant X System 📡",
              serverId: 1
          }
      }
  }, { quoted: m });

  await m.react("✅").catch(() => {});
}

// Tambahan alias untuk memudahkan pemanggilan
handler.command = ["settingscek"];
handler.tags = ["owner"];
handler.help = ["settingscek"];

module.exports = handler;
