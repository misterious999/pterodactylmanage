// ==========================================
// 🛡️ GROUP SECURITY (MANUAL OPEN/CLOSE)
// ==========================================

let handler = async (m, { sock, args, prefix, command, isAdmin, isOwner, isBotAdmin }) => {
    
    // 🔥 FUNGSI REPLY PENGUMUMAN RESMI
    const replyVIP = async (teks) => {
        return sock.sendMessage(m.chat, {
            text: teks,
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: global.idChannel || "1203631@newsletter",
                    newsletterName: "🛡️ Group Security Protocol",
                    serverId: 1
                }
            }
        }, { quoted: m });
    };

    // 1. Validasi Otoritas
    if (!m.isGroup) return replyVIP("❌ *Akses Ditolak!*\nFitur ini khusus untuk manajemen di dalam grup.");
    if (!isAdmin && !isOwner) return replyVIP("🛡️ *Akses Ditolak!*\nHanya jajaran Admin Group yang dapat mengubah gerbang komunikasi.");
    if (!isBotAdmin) return replyVIP("🤖 *Sistem Ditolak!*\nBot tidak bisa mengubah pengaturan grup karena belum menjadi Admin.");

    await m.react("⏳").catch(() => {});

    // 2. Deteksi Perintah Buka / Tutup
    let isClose = ['close', 'tutup'].includes(command) || ['close', 'tutup'].includes(args[0]?.toLowerCase());
    let isOpen = ['open', 'buka'].includes(command) || ['open', 'buka'].includes(args[0]?.toLowerCase());

    try {
        if (isClose) {
            // EKSEKUSI LOCKDOWN (Hanya Admin yang bisa chat)
            await sock.groupSettingUpdate(m.chat, 'announcement');
            
            let teksKeren = `🔒 *G R O U P   L O C K D O W N* 🔒\n\n`;
            teksKeren += `Gerbang komunikasi grup telah ditutup oleh Admin.\n`;
            teksKeren += `Sekarang hanya **Admin** yang dapat mengirim pesan di grup ini.\n\n`;
            teksKeren += `_Harap patuhi peraturan dan tunggu instruksi selanjutnya._ 🛑`;
            
            await replyVIP(teksKeren);
            
        } else if (isOpen) {
            // EKSEKUSI BUKA GERBANG (Semua bisa chat)
            await sock.groupSettingUpdate(m.chat, 'not_announcement');
            
            let teksKeren = `🔓 *G R O U P   U N L O C K E D* 🔓\n\n`;
            teksKeren += `Gerbang komunikasi grup telah dibuka kembali oleh Admin.\n`;
            teksKeren += `Sekarang **Seluruh Anggota** dapat kembali berinteraksi.\n\n`;
            teksKeren += `_Silakan berdiskusi dengan tertib dan sopan._ ✨`;
            
            await replyVIP(teksKeren);
            
        } else {
            // JIKA COMMAND TYPO ATAU KOSONG
            return replyVIP(`❌ *Format Salah!*\n\nSilakan gunakan perintah berikut:\n> \`${prefix}group open\` (Untuk membuka obrolan)\n> \`${prefix}group close\` (Untuk mengunci obrolan)`);
        }

        await m.react("✅").catch(() => {});

    } catch (e) {
        console.error("🔴 [ERROR GROUP SETTING]", e);
        await m.react("❌").catch(() => {});
        return replyVIP(`❌ *Sistem Gagal!*\nTerjadi kesalahan teknis saat mengubah pengaturan grup.`);
    }
}

// Mendukung berbagai gaya pemanggilan perintah
handler.command = ["group", "grup", "gc", "buka", "tutup", "open", "close"];
handler.tags = ["group"];
handler.help = ["group <open/close>"];

module.exports = handler;
