// ==========================================
// 🛡️ ANTI LINK GROUP & CHANNEL SYSTEM
// ==========================================

let handler = async (m, { sock, args, isAdmin, prefix, command }) => {
    // 1. Validasi Keamanan Hak Akses
    if (!m.isGroup) return m.reply("❌ *Akses Ditolak!*\nFitur ini hanya dapat digunakan di dalam grup.");
    if (!isAdmin && !m.isOwner) return m.reply("🛡️ *Akses Ditolak!*\nHanya Admin Grup yang dapat mengatur fitur ini.");

    // 2. Persiapan Database Grup
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
    let chat = global.db.groups[m.chat];
    
    // 3. Deteksi Tipe Perintah
    let isLinkGc = /antilinkgc|antilinkgroup/i.test(command);
    let type = isLinkGc ? 'antilinkgc' : 'antilinkch';
    let name = isLinkGc ? 'Anti Link Group' : 'Anti Link Channel';

    // 4. Eksekusi Saklar (On/Off)
    if (args[0] === 'on') {
        if (chat[type]) return m.reply(`⚠️ Mode *${name}* sudah dalam keadaan aktif di grup ini.`);
        chat[type] = true;
        m.reply(`✅ *${name} Berhasil Diaktifkan!*\nSistem Assistant X kini akan memantau dan memusnahkan setiap tautan ${isLinkGc ? "Grup" : "Channel"} yang dibagikan.`);
    } else if (args[0] === 'off') {
        if (!chat[type]) return m.reply(`⚠️ Mode *${name}* sudah dalam keadaan nonaktif.`);
        chat[type] = false;
        m.reply(`❌ *${name} Dimatikan!*\nAnggota grup kini dapat membagikan tautan ${isLinkGc ? "Grup" : "Channel"} kembali.`);
    } else {
        m.reply(`*Format Salah!*\n\nContoh Penggunaan:\n> ${prefix}${command} on\n> ${prefix}${command} off`);
    }
}

// ==========================================
// 📡 RADAR PENDETEKSI LINK (X-RAY SCANNER)
// ==========================================
handler.before = async (m, { sock, isAdmin, isBotAdmin }) => {
    if (!m.isGroup) return false; // Abaikan jika bukan di grup
    
    let chat = global.db.groups[m.chat] || {};
    
    // Berhenti jika kedua radar mati
    if (!chat.antilinkgc && !chat.antilinkch) return false; 
    
    // Pengecualian Otoritas
    if (isAdmin || m.isOwner) return false; // Admin & Developer bebas dari razia
    if (!isBotAdmin) return false; // Bot harus jadi admin untuk bisa mengeksekusi (menghapus)

    // Deteksi Teks di segala kondisi (Pesan biasa, caption foto, caption video)
    let bodyText = m.text || m.body || m.message?.conversation || m.message?.extendedTextMessage?.text || m.message?.imageMessage?.caption || m.message?.videoMessage?.caption || "";
    if (!bodyText) return false;

    // 🔥 Pola Radar Pendeteksi Link WA
    const isGroupLink = chat.antilinkgc && /chat\.whatsapp\.com\/(?:invite\/)?([0-9A-Za-z]{20,24})/i.test(bodyText);
    const isChannelLink = chat.antilinkch && /whatsapp\.com\/channel\/([0-9A-Za-z]{20,24})/i.test(bodyText);

    if (isGroupLink || isChannelLink) {
        try {
            let linkType = isGroupLink ? "Link WhatsApp Group" : "Link WhatsApp Channel";

            // 💥 Tembak mati (Hapus pesannya)
            await sock.sendMessage(m.chat, { delete: m.key });
            
            // 📝 Teguran Mewah Ala Assistant X
            let teksTeguran = `⚠️ *S Y S T E M   W A R N I N G* ⚠️\n\n`;
            teksTeguran += `Sistem keamanan mendeteksi pembagian tautan terlarang (*${linkType}*) di dalam markas ini.\n\n`;
            teksTeguran += `╭───「 *INFO PELANGGARAN* 」\n`;
            teksTeguran += `│ ◦ 👤 Pelaku: *@${m.sender.split('@')[0]}*\n`;
            teksTeguran += `│ ◦ 🛡️ Tindakan: *Pesan Dihapus*\n`;
            teksTeguran += `╰──────────────\n\n`;
            teksTeguran += `_Dilarang keras melakukan promosi atau membagikan tautan eksternal tanpa izin Admin!_ 🚫`;

            await sock.sendMessage(m.chat, { 
                text: teksTeguran, 
                mentions: [m.sender] 
            });
            
            return true; // Hentikan eksekusi plugin lain (Blokir total)
        } catch (error) {
            console.error("Gagal menghapus Link di grup:", error);
        }
    }
    
    return false;
}

handler.help = ['antilinkgc <on/off>', 'antilinkch <on/off>']
handler.tags = ['group']
handler.command = ['antilinkgc', 'antilinkch']

module.exports = handler;
