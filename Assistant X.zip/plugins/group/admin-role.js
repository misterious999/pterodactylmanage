// ==========================================
// 🛡️ ADMIN GROUP AUTHORITY (ULTIMATE MENTION FIX)
// ==========================================

let handler = async (m, { sock, text, prefix, command, isAdmin, isOwner, isBotAdmin }) => {
    
    // 🔥 FUNGSI REPLY ADMIN DENGAN SUNTIKAN MENTION KE JANTUNG CONTEXT INFO
    const replyAdmin = async (teks, targetJid) => {
        return sock.sendMessage(m.chat, {
            text: teks,
            // KITA MASUKKAN MENTIONNYA KE DALAM CONTEXT INFO LANGSUNG!
            contextInfo: {
                mentionedJid: [targetJid], // <--- INI DIA OBAT MUJARABNYA!
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: global.idChannel || "1203631@newsletter",
                    newsletterName: "🛡️ Admin Group Authority",
                    serverId: 1
                }
            }
        }, { quoted: m });
    };

    if (!m.isGroup) return replyAdmin("❌ *Akses Ditolak!*\nFitur ini khusus untuk manajemen Admin di dalam grup.", m.sender);
    if (!isAdmin && !isOwner) return replyAdmin("🛡️ *Akses Ditolak!*\nHanya jajaran Admin Group yang bisa menggunakan perintah ini.", m.sender);
    if (!isBotAdmin) return replyAdmin("🤖 *Bot Bukan Admin!*\nSistem tidak bisa mengubah jabatan karena bot belum diberikan hak Admin.", m.sender);

    // Radar Target
    let users = m.mentionedJid[0] ? m.mentionedJid : m.quoted ? [m.quoted.sender] : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
    let target = users[0];

    if (!target || target === '@s.whatsapp.net') {
        return replyAdmin(`❌ *Siapa yang mau diatur jabatannya?*\n\nContoh:\n> \`${prefix}${command} @user\``, m.sender);
    }

    let botJid = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    if (target === botJid) return replyAdmin("⚠️ Sistem utama tidak bisa diubah jabatannya sendiri.", target);

    await m.react("⏳");

    try {
        if (['promote', 'pm', 'admin'].includes(command)) {
            await sock.groupParticipantsUpdate(m.chat, [target], "promote");
            
            let teksKeren = `✨ *A D M I N   U P G R A D E* ✨\n\n`;
            teksKeren += `Selamat! @${target.split('@')[0]} telah resmi diangkat menjadi *Admin Group*.\n\n`;
            teksKeren += `_Jaga ketertiban grup dengan baik!_ ⚔️`;
            
            // Suntikkan targetJid agar menjadi biru
            await replyAdmin(teksKeren, target);
            
        } else if (['demote', 'dm', 'unadmin'].includes(command)) {
            const ownerNumbers = Array.isArray(global.owner)
                ? global.owner.map(String)
                : String(global.owner || "").split(/[,\s]+/).filter(Boolean);
            const ownerJids = ownerNumbers.map(num => num.includes("@") ? num : `${num}@s.whatsapp.net`);
            if (ownerJids.includes(target) && !isOwner) return replyAdmin("⚠️ *Otoritas Ditolak!*\nJabatan Owner tidak bisa dicabut oleh Admin biasa.", target);

            await sock.groupParticipantsUpdate(m.chat, [target], "demote");
            
            let teksKeren = `🔻 *A D M I N   D O W N G R A D E* 🔻\n\n`;
            teksKeren += `Jabatan Admin milik @${target.split('@')[0]} telah dicabut.\n\n`;
            teksKeren += `_Status kembali menjadi anggota biasa._ 🚶‍♂️`;
            
            // Suntikkan targetJid agar menjadi biru
            await replyAdmin(teksKeren, target);
        }

        await m.react("✅");

    } catch (e) {
        await m.react("❌");
        return replyAdmin(`❌ *Gagal!*\nTerjadi kesalahan teknis pada sistem Admin Group.`, target);
    }
}

handler.command = ["promote", "admin", "demote", "unadmin"];
handler.tags = ["group"];
handler.help = ["promote @tag", "demote @tag"];

module.exports = handler;
