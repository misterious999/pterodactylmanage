const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

// ==========================================
// 🚀 MAIN HANDLER (TOMBOL CONTROLLER)
// ==========================================
let handler = async (m, { sock, args, prefix, command, isAdmin, isOwner }) => {
    if (!m.isGroup) return m.reply("❌ Fitur ini hanya khusus digunakan di dalam grup!");
    if (!isAdmin && !isOwner) return m.reply("❌ *Akses Ditolak!*\nHanya Admin Grup yang bisa mengatur sistem keamanan ini.");

    // Pengaman Database (Anti-Crash)
    global.db = global.db || { data: { chats: {}, users: {} } };
    global.db.data = global.db.data || { chats: {}, users: {} };
    global.db.data.chats = global.db.data.chats || {};

    global.db.data.chats[m.chat] = global.db.data.chats[m.chat] || {};
    let chat = global.db.data.chats[m.chat];

    if (args[0] === 'on') {
        if (chat.antiswgc) return m.reply("⚠️ Fitur *Anti-SWGC* sudah aktif di grup ini.");
        chat.antiswgc = true;
        return m.reply("✅ *Anti-SWGC Berhasil Diaktifkan!*\nAturan Mutlak: HANYA OWNER yang boleh membuat Status Grup. Pelanggar (termasuk bot lain & admin) akan ditindak tegas!");
    } else if (args[0] === 'off') {
        if (!chat.antiswgc) return m.reply("⚠️ Fitur *Anti-SWGC* sudah nonaktif di grup ini.");
        chat.antiswgc = false;
        return m.reply("✅ *Anti-SWGC Berhasil Dinonaktifkan!*\nGrup kembali terbuka untuk fitur Status Grup.");
    }

    let teks = `🛡️ *ANTI SWGC (ABSOLUTE DICTATOR)* 🛡️\n\n`;
    teks += `Sistem Keamanan tingkat tinggi yang akan melenyapkan fitur "Buat Status Grup" dari tangan member biasa, admin, maupun bot lain.\n`;
    teks += `⚠️ *Aturan:* Pelanggar akan mendapat peringatan. Jika mencapai *3x pelanggaran*, otomatis di-kick.\n\n`;
    teks += `Status Sistem: *${chat.antiswgc ? "AKTIF 🟢" : "NONAKTIF 🔴"}*\n\n`;
    teks += `_Silakan pilih tombol di bawah untuk mengatur sistem:_`;

    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
                    footer: proto.Message.InteractiveMessage.Footer.create({ text: "© Assistant X Security System" }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
                            {
                                name: "quick_reply",
                                buttonParamsJson: JSON.stringify({ display_text: "🟢 Aktifkan", id: `${prefix}${command} on` })
                            },
                            {
                                name: "quick_reply",
                                buttonParamsJson: JSON.stringify({ display_text: "🔴 Matikan", id: `${prefix}${command} off` })
                            }
                        ]
                    })
                })
            }
        }
    }, { quoted: m });

    await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}

// ==========================================
// 📡 RADAR DETEKTOR (ALGOJO STATUS GRUP)
// ==========================================
handler.before = async (m, { sock, isBotAdmin, isOwner }) => {
    if (!m.isGroup) return;
    
    // Pengaman Ekstra Handler Background (Anti-Crash)
    if (!global.db || !global.db.data) return;
    global.db.data.chats = global.db.data.chats || {};
    global.db.data.users = global.db.data.users || {};

    global.db.data.chats[m.chat] = global.db.data.chats[m.chat] || {};
    let chat = global.db.data.chats[m.chat];

    // Jika Anti-SWGC Aktif
    if (chat.antiswgc) {
        // Mendeteksi Tipe Pesan "Buat Status Grup" dari Server WhatsApp
        let isGroupStatus = m.mtype === 'groupStatusMessage' || m.mtype === 'groupStatusMessageV2';
        
        if (!isGroupStatus && m.message) {
            if (m.message.groupStatusMessage || m.message.groupStatusMessageV2) {
                isGroupStatus = true;
            }
        }

        // Eksekusi Jika Radar Menangkap Status Grup
        if (isGroupStatus) {
            // 🔥 HANYA OWNER YANG KEBAL! (Bebas bikin status grup)
            if (isOwner) return;
            
            // Bot harus jadi admin untuk bisa menghapus dan kick
            if (!isBotAdmin) return; 

            // 1. Langsung hapus Status Grup tersebut sampai lenyap
            await sock.sendMessage(m.chat, { delete: m.key }).catch(() => {});

            // 2. PENCEGAHAN BUNUH DIRI (Jika bot disuruh owner/admin tapi lewat fitur lain)
            if (m.fromMe) {
                return sock.sendMessage(m.chat, { 
                    text: "🤖 *Sistem Mutlak:* Assistant X terdeteksi membuat Status Grup. Pesan kutebas sendirian karena HANYA OWNER yang berhak! 🗿" 
                }).catch(() => {});
            }

            // 3. Eksekusi Pelanggar (Bot Lain, Admin, atau Member)
            global.db.data.users[m.sender] = global.db.data.users[m.sender] || {};
            let user = global.db.data.users[m.sender];
            
            // Tambahkan point pelanggaran
            user.warn_swgc = (user.warn_swgc || 0) + 1;

            // Cek apakah sudah 3x melanggar
            if (user.warn_swgc >= 3) {
                // Reset point pelanggaran
                user.warn_swgc = 0;
                
                // Kirim notifikasi eliminasi
                await sock.sendMessage(m.chat, { 
                    text: `🚨 *ELIMINASI SYSTEM* 🚨\n\nSelamat tinggal @${m.sender.split('@')[0]}! 👋\nKamu telah ngeyel membuat Status Grup ilegal sebanyak 3 kali.\n\n_Eksekusi Kick otomatis dijalankan..._`, 
                    mentions: [m.sender] 
                }).catch(() => {});
                
                // Tendang (Kick) akun tersebut dari grup
                await sock.groupParticipantsUpdate(m.chat, [m.sender], "remove").catch(() => {});
                
            } else {
                // Kirim surat peringatan (SP)
                await sock.sendMessage(m.chat, { 
                    text: `🛡️ *SYSTEM WARNING (${user.warn_swgc}/3)* 🛡️\n\nKetahuan lu ya @${m.sender.split('@')[0]}! 🗿\nDi grup ini HANYA OWNER yang boleh membuat Status Grup!\n\n_Peringatan ke-${user.warn_swgc} dari 3. Sekali lagi bikin Status Grup, otomatis di-kick!_`, 
                    mentions: [m.sender] 
                }).catch(() => {});
            }
        }
    }
}

handler.help = ['antiswgc'];
handler.tags = ['group'];
handler.command = ['antiswgc'];
handler.group = true;

module.exports = handler;
