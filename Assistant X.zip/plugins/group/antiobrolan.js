// ==========================================
// 🛡️ ANTI OBROLAN SUARA (VOICE CHAT) SYSTEM
// ==========================================

let handler = async (m, { sock, args, isAdmin, prefix, command }) => {
    // 1. Validasi Keamanan Hak Akses
    if (!m.isGroup) return m.reply("❌ *Akses Ditolak!*\nFitur ini hanya dapat digunakan di dalam grup.");
    if (!isAdmin && !m.isOwner) return m.reply("🛡️ *Akses Ditolak!*\nHanya Admin Grup yang dapat mengatur fitur ini.");

    // 2. Persiapan Database Grup
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
    let chat = global.db.groups[m.chat];
    
    // 3. Eksekusi Saklar (On/Off)
    if (args[0] === 'on') {
        if (chat.antiobrol) return m.reply("⚠️ Mode *Anti Obrolan Suara* sudah dalam keadaan aktif di grup ini.");
        chat.antiobrol = true;
        m.reply("✅ *Anti Obrolan Suara Berhasil Diaktifkan!*\nSistem Assistant X kini akan memantau dan memusnahkan otomatis setiap upaya pembukaan sesi Obrolan Suara (Voice Chat).");
    } else if (args[0] === 'off') {
        if (!chat.antiobrol) return m.reply("⚠️ Mode *Anti Obrolan Suara* sudah dalam keadaan nonaktif.");
        chat.antiobrol = false;
        m.reply("❌ *Anti Obrolan Suara Dimatikan!*\nAnggota grup kini dapat menggunakan fitur Obrolan Suara kembali.");
    } else {
        m.reply(`*Format Salah!*\n\nContoh Penggunaan:\n> ${prefix}${command} on\n> ${prefix}${command} off`);
    }
}

// ==========================================
// 📡 RADAR PENDETEKSI OBROLAN SUARA
// ==========================================
handler.before = async (m, { sock, isAdmin, isBotAdmin }) => {
    if (!m.isGroup) return false; // Abaikan jika bukan di grup
    
    let chat = global.db.groups[m.chat] || {};
    if (!chat.antiobrol) return false; // Berhenti jika fitur mati
    
    // Pengecualian Otoritas
    if (isAdmin || m.isOwner) return false; // Admin & Developer bebas bikin obrolan
    if (!isBotAdmin) return false; // Bot harus jadi admin untuk bisa mengeksekusi (menghapus)

    // 🔥 Variabel Radar
    let isVoiceChat = false;

    // 1. Deteksi lewat tipe pesan (Scheduled Call / Voice Chat)
    if (m.message?.scheduledCallCreationMessage) isVoiceChat = true;

    // 2. Deteksi lewat StubType (Sistem bawaan Baileys untuk event grup)
    // Tipe 115, 116, 144, 145 biasanya berkaitan dengan inisiasi panggilan/obrolan suara grup
    if (m.messageStubType && [115, 116, 144, 145, 146].includes(m.messageStubType)) {
        isVoiceChat = true;
    }

    // 3. X-Ray Paksa lewat Raw JSON (Anti By-pass)
    let rawJson = JSON.stringify(m.message || {}).toLowerCase();
    if (rawJson.includes("scheduledcall") || rawJson.includes("groupcall") || rawJson.includes("voicechat")) {
        isVoiceChat = true;
    }

    // 💥 EKSEKUSI JIKA TERDETEKSI
    if (isVoiceChat) {
        try {
            // Tembak mati (Hapus notifikasi obrolannya)
            await sock.sendMessage(m.chat, { delete: m.key });
            
            // 📝 Teguran Mewah Ala Assistant X
            let teksTeguran = `⚠️ *S Y S T E M   W A R N I N G* ⚠️\n\n`;
            teksTeguran += `Sistem keamanan mendeteksi aktivitas pembukaan **Obrolan Suara (Voice Chat)**.\n\n`;
            teksTeguran += `╭───「 *INFO PELANGGARAN* 」\n`;
            teksTeguran += `│ ◦ 👤 Pelaku: *@${m.sender.split('@')[0]}*\n`;
            teksTeguran += `│ ◦ 🛡️ Tindakan: *Sesi Dihapus*\n`;
            teksTeguran += `╰──────────────\n\n`;
            teksTeguran += `_Dilarang keras melakukan spam Obrolan Suara di grup ini!_ 🚫`;

            await sock.sendMessage(m.chat, { 
                text: teksTeguran, 
                mentions: [m.sender] 
            });
            
            return true; // Hentikan eksekusi plugin lain agar fokus ke pelanggaran ini
        } catch (error) {
            console.error("Gagal menghapus Obrolan Suara di grup:", error);
        }
    }
    
    return false;
}

handler.help = ['antiobrol <on/off>']
handler.tags = ['group']
// Mendukung beberapa alias perintah agar mudah diingat
handler.command = ['antiobrol']

module.exports = handler;
