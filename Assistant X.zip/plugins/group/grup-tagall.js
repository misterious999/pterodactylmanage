let handler = async (m, { sock, text, prefix, command }) => {
  if (!m.isOwner && !m.isAdmin) return m.reply("❌ Khusus admin grup!");

  if (!text) {
    let usedPrefix = prefix || '.';
    return m.reply(`Contoh: \`${usedPrefix + command}\` hai semuanya`);
  }

  try {
    // 1. Ambil data peserta grup
    let meta = m.metadata || await sock.groupMetadata(m.chat).catch(() => {});
    if (!meta) return m.reply("❌ Gagal mengambil data peserta grup.");

    let participants = meta.participants.map(v => v.id);
    
    // 2. Merakit tag satu per satu, dempet menggunakan 1 spasi agar WA tetap membacanya
    let tagString = participants.map(v => '@' + v.split('@')[0]).join(' ');

    // 3. Trik Ajaib: Karakter invisible (Read More) sebanyak 4001 kali untuk menyembunyikan tag
    const readmore = String.fromCharCode(8206).repeat(4001);

    // 4. Merakit teks final: Pesan Utama -> Read More -> Kumpulan Tag Dempet
    let finalTeks = `${text}\n\n${readmore}${tagString}`;

    // 5. Eksekusi pengiriman
    await sock.sendMessage(
      m.chat,
      {
        text: finalTeks,
        mentions: participants // Parameter sakti penarik notifikasi
      },
      { quoted: m }
    );

  } catch (err) {
    console.error("Tagall error:", err);
    m.reply("❌ Terjadi kesalahan saat memproses tagall.");
  }
}

handler.command = ["tagall"];
handler.tags = ["group"];
handler.help = ["tagall <teks>"];
handler.group = true;

module.exports = handler;
