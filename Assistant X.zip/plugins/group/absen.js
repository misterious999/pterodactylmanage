const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

// ==========================================
// 📝 SMART GROUP ATTENDANCE (HIDETAG)
// ⚙️ Ciptaan Pstar7 | Interactive & Auto List
// ==========================================

let handler = async (m, { sock, conn, text, prefix, command, isAdmin, isOwner }) => {
    let client = sock || conn;
    
    // Inisialisasi database absen sementara di memori bot
    client.absen = client.absen ? client.absen : {};

    // Validasi: Fitur ini cuma bisa dipakai di dalam Grup
    let isGroup = m.chat.endsWith('@g.us');
    if (!isGroup) return m.reply("❌ *Fitur ini khusus untuk di dalam grup!*");

    let id = m.chat;

    switch (command) {
        // 🟢 1. MEMULAI ABSEN (KHUSUS ADMIN)
        case 'mulaiabsen':
        case 'absenstart': {
            if (!isAdmin && !isOwner) return m.reply("❌ *Akses Ditolak!* Hanya Admin grup yang bisa memulai absen.");
            if (id in client.absen) return m.reply(`❗ *Absen masih berjalan!*\nKetik \`${prefix}tutupabsen\` untuk mengakhiri absen sebelumnya.`);

            let topik = text ? text : 'Absensi Rutin Grup';
            let date = new Date().toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });

            // 🚀 FITUR HIDETAG: Tarik semua nomor member di grup
            let groupMetadata = await client.groupMetadata(m.chat);
            let participants = groupMetadata.participants;
            let hidetag = participants.map(a => a.id);

            // Simpan data absen ke memori
            client.absen[id] = {
                topik: topik,
                tanggal: date,
                list: [] // Array untuk nyimpen nomor yang udah hadir
            };

            // Kirim pesan interaktif dengan tombol HADIR + HIDETAG
            let msg = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: {
                    message: {
                        "messageContextInfo": { "deviceListMetadata": {}, "deviceListMetadataVersion": 2 },
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            // 👇 Ini kunci Hidetag di dalam pesan tombol
                            contextInfo: {
                                mentionedJid: hidetag 
                            },
                            body: proto.Message.InteractiveMessage.Body.create({
                                text: `╭──「 *📝 ABSENSI DIBUKA* 」\n│\n│ 📅 *Tanggal:* ${date}\n│ 📌 *Topik:* ${topik}\n│\n╰────────────🚀\n\n📢 _Panggilan kepada seluruh member grup!_\n\nSilakan klik tombol *HADIR* di bawah ini atau ketik \`.absen\` untuk mencatat kehadiranmu!`
                            }),
                            footer: proto.Message.InteractiveMessage.Footer.create({ text: "© ZeroixDark Marketplace" }),
                            header: proto.Message.InteractiveMessage.Header.create({ title: "", subtitle: "", hasMediaAttachment: false }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                buttons: [
                                    {
                                        "name": "quick_reply",
                                        "buttonParamsJson": `{"display_text":"🙋‍♂️ HADIR","id":".absen"}`
                                    }
                                ]
                            })
                        })
                    }
                }
            }, { quoted: m });

            await client.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
            break;
        }

        // 🟢 2. MENGISI ABSEN (MEMBER)
        case 'absen':
        case 'hadir': {
            if (!(id in client.absen)) return m.reply(`❗ *Belum ada absen yang dibuka!*\nAdmin bisa mengetik \`${prefix}mulaiabsen <topik>\`.`);

            let absenData = client.absen[id];
            let sender = m.sender;

            // Cek apakah user sudah absen
            if (absenData.list.includes(sender)) return m.reply("✅ *Kamu sudah absen!* Tidak perlu absen dua kali.");

            // Tambahkan user ke daftar hadir
            absenData.list.push(sender);

            // Format list untuk ditampilkan
            let teks = `╭──「 *📝 DAFTAR HADIR* 」\n`;
            teks += `│ 📅 *Tanggal:* ${absenData.tanggal}\n`;
            teks += `│ 📌 *Topik:* ${absenData.topik}\n`;
            teks += `│ 👥 *Total Hadir:* ${absenData.list.length}\n`;
            teks += `│\n`;
            
            absenData.list.forEach((v, i) => {
                teks += `│ ${i + 1}. @${v.split('@')[0]}\n`;
            });
            teks += `╰────────────🚀\n\n_Klik tombol HADIR di atas untuk ikut absen!_`;

            // Update pesan list di grup
            await client.sendMessage(m.chat, { text: teks, mentions: absenData.list }, { quoted: m });
            break;
        }

        // 🟢 3. MENGECEK ABSEN (TANPA MENGISI)
        case 'cekabsen':
        case 'listabsen': {
            if (!(id in client.absen)) return m.reply("❗ *Tidak ada sesi absen yang sedang berjalan.*");

            let absenData = client.absen[id];
            let teks = `╭──「 *📝 CEK ABSENSI* 」\n`;
            teks += `│ 📅 *Tanggal:* ${absenData.tanggal}\n`;
            teks += `│ 📌 *Topik:* ${absenData.topik}\n`;
            teks += `│ 👥 *Total Hadir:* ${absenData.list.length}\n`;
            teks += `│\n`;
            
            if (absenData.list.length === 0) {
                teks += `│ _Belum ada yang hadir._\n`;
            } else {
                absenData.list.forEach((v, i) => {
                    teks += `│ ${i + 1}. @${v.split('@')[0]}\n`;
                });
            }
            teks += `╰────────────🚀`;

            await client.sendMessage(m.chat, { text: teks, mentions: absenData.list }, { quoted: m });
            break;
        }

        // 🟢 4. MENUTUP ABSEN (KHUSUS ADMIN)
        case 'tutupabsen':
        case 'absenstop': {
            if (!isAdmin && !isOwner) return m.reply("❌ *Akses Ditolak!* Hanya Admin yang bisa menutup absen.");
            if (!(id in client.absen)) return m.reply("❗ *Tidak ada sesi absen yang bisa ditutup.*");

            let absenData = client.absen[id];
            let teks = `╭──「 *🛑 ABSENSI DITUTUP* 」\n`;
            teks += `│ 📅 *Tanggal:* ${absenData.tanggal}\n`;
            teks += `│ 📌 *Topik:* ${absenData.topik}\n`;
            teks += `│ 👥 *Total Hadir:* ${absenData.list.length} Orang\n`;
            teks += `│\n`;
            
            if (absenData.list.length === 0) {
                teks += `│ _Tidak ada yang hadir hari ini._\n`;
            } else {
                absenData.list.forEach((v, i) => {
                    teks += `│ ${i + 1}. @${v.split('@')[0]}\n`;
                });
            }
            teks += `╰────────────🚀\n\n_Terima kasih atas partisipasinya!_`;

            // Kirim rekap terakhir
            await client.sendMessage(m.chat, { text: teks, mentions: absenData.list }, { quoted: m });

            // Hapus sesi absen dari memori
            delete client.absen[id];
            break;
        }
    }
}

/// Mendaftarkan command inti ke bot (Biar menu kelihatan bersih & pro)
handler.command = ['mulaiabsen', 'absen', 'cekabsen', 'tutupabsen'];
handler.tags = ['group'];
handler.help = ['mulaiabsen <topik>', 'absen', 'cekabsen', 'tutupabsen'];
handler.group = true; 

module.exports = handler;