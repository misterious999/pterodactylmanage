// ==========================================
// 📢 VIP HIDETAG SYSTEM (REPLY, TAG FIX & NATIVE REACT)
// ==========================================

let handler = async (m, { sock, text, prefix, command, isAdmin, isOwner }) => {
    // Validasi Keamanan VIP
    if (!isOwner && !isAdmin) {
        await sock.sendMessage(m.chat, { react: { text: "⚠️", key: m.key } }).catch(() => {});
        return m.reply("❌ *Akses Ditolak!*\nFitur ini khusus untuk Admin Group.");
    }

    // 1. LOGIKA MENANGKAP TEKS 
    let teks = text ? text : (m.quoted && (m.quoted.text || m.quoted.caption || m.quoted.body)) ? (m.quoted.text || m.quoted.caption || m.quoted.body) : "";
    
    if (!teks) {
        await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } }).catch(() => {});
        return m.reply(`❌ *Teks Kosong!*\n\nContoh Penggunaan:\n> \`${prefix + command} Pengumuman besok libur!\`\n\n_Atau Bosku bisa *reply* pesan orang lalu ketik_ \`${prefix + command}\``);
    }

    // 📢 REAKSI TOA INSTAN KE PESAN COMMAND BOSKU
    await sock.sendMessage(m.chat, { react: { text: "📢", key: m.key } }).catch(() => {});

    try {
        if (!m.metadata || !m.metadata.participants) {
            return m.reply("❌ Gagal mendapatkan daftar anggota grup.");
        }

        // 2. Mengambil seluruh JID anggota grup yang sah
        const members = m.metadata.participants.map(v => v.id || v.jid).filter(v => v);

        // 3. 💉 OBAT ANTI-TAG PATAH (Suntikan Paksa)
        let extraMentions = [...teks.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net');
        let allMentions = [...new Set([...members, ...extraMentions])];

        // 4. Eksekusi Hidetag Murni
        await sock.sendMessage(
            m.chat,
            {
                text: teks,
                mentions: allMentions
            },
            { quoted: null } 
        );

    } catch (err) {
        console.error("🔴 [HIDETAG ERROR]:", err);
        await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } }).catch(() => {});
        m.reply("❌ Terjadi kesalahan teknis saat memproses Hidetag.");
    }
}

handler.command = ["ht", "hidetag", "h"];
handler.tags = ["group"];
handler.help = ["hidetag <teks/reply>"];
handler.group = true;
handler.admin = true;
handler.owner = true;

module.exports = handler;
