const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

// ==========================================
// 🌟 VIP WELCOME & GOODBYE SYSTEM (GHOST BUSTER FIX)
// ==========================================

let handler = async (m, { sock, args, command, prefix }) => {
    const isGroupChat = m.chat.endsWith('@g.us');
    if (!isGroupChat) {
        await m.react("⚠️").catch(() => {});
        return sock.sendMessage(m.chat, { text: "❌ *Akses Ditolak!*\nFitur ini hanya bisa digunakan di dalam grup!" }, { quoted: m });
    }

    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = { welcome: false };
    let chat = global.db.groups[m.chat];

    if (!args[0]) {
        return sock.sendMessage(m.chat, { text: `❌ *Format salah!*\n\n*Contoh Penggunaan:*\n> \`${prefix + command} on\` (Menyalakan)\n> \`${prefix + command} off\` (Mematikan)` }, { quoted: m });
    }

    let namaGrup = m.metadata?.subject || "Grup Ini";

    if (args[0].toLowerCase() === 'on') {
        if (chat.welcome) return sock.sendMessage(m.chat, { text: "⚠️ Fitur Welcome & Goodbye sudah aktif sebelumnya!" }, { quoted: m });
        chat.welcome = true;
        await m.react("✅").catch(() => {});
        
        let teks = `╭───「 *⚙️ SYSTEM NOTIFICATION* 」\n│ 🔘 *Fitur:* Welcome & Leave\n│ 🟢 *Status:* AKTIF\n│ 🏢 *Grup:* ${namaGrup}\n│ 👤 *Oleh:* @${m.sender.split('@')[0]}\n╰──────────────\n\n_Radar Inti Baileys telah diaktifkan._ 🛡️`;
        
        await sock.sendMessage(m.chat, { text: teks, contextInfo: { mentionedJid: [m.sender] } }, { quoted: m });

    } else if (args[0].toLowerCase() === 'off') {
        if (!chat.welcome) return sock.sendMessage(m.chat, { text: "⚠️ Fitur Welcome memang sudah mati!" }, { quoted: m });
        chat.welcome = false;
        await m.react("✅").catch(() => {});
        
        let teks = `╭───「 *⚙️ SYSTEM NOTIFICATION* 」\n│ 🔘 *Fitur:* Welcome & Leave\n│ 🔴 *Status:* NONAKTIF\n│ 🏢 *Grup:* ${namaGrup}\n│ 👤 *Oleh:* @${m.sender.split('@')[0]}\n╰──────────────\n\n_Sistem pemantauan dimatikan._ 🛑`;
        
        await sock.sendMessage(m.chat, { text: teks, contextInfo: { mentionedJid: [m.sender] } }, { quoted: m });
    } else {
        await sock.sendMessage(m.chat, { text: `❌ Argumen tidak dikenal!\nGunakan *on* atau *off*.` }, { quoted: m });
    }
}

// ==========================================
// 📡 CHIP PENYADAP DENGAN PEMBASMI GHOST LISTENER
// ==========================================
handler.before = async (m, { sock }) => {
    // Kita gunakan nama variabel baru untuk memaksa pembaruan sistem
    if (!sock.welcomeRadarUltimateFixed) {
        sock.welcomeRadarUltimateFixed = true;
        
        // 🧹 SAPU BERSIH SEMUA RADAR LAMA YANG NYANGKUT DI MEMORI!
        sock.ev.removeAllListeners('group-participants.update');
        
        console.log("🟢 [SYSTEM] Menanamkan Radar Welcome VIP (Custom Text Support)...");

        sock.ev.on('group-participants.update', async (update) => {
            const { id, participants, action } = update;
            
            let chat = global.db.groups[id] || {};
            if (!chat.welcome) return;

            try {
                let metadata = await sock.groupMetadata(id).catch(() => ({}));
                let groupName = metadata.subject || "Grup Executive";

                for (let target of participants) {
                    if (action === 'add') {
                        
                        // 🧠 LOGIKA CUSTOM TEXT WELCOME (Dengan Regex /g)
                        let welcomeTeks = "";
                        if (chat.sWelcome) {
                            welcomeTeks = chat.sWelcome.replace(/@user/g, `@${target.split('@')[0]}`).replace(/@subject/g, groupName);
                        } else {
                            welcomeTeks = `✨ *W E L C O M E   V I P* ✨\n\nSelamat datang @${target.split('@')[0]} di markas **${groupName}**! 🎉\n\n_Silakan perkenalkan diri dan jangan lupa patuhi rules yang ada di sini ya!_ ☕`;
                        }

                        let msgWelcome = generateWAMessageFromContent(id, {
                            viewOnceMessage: {
                                message: {
                                    messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                                    interactiveMessage: proto.Message.InteractiveMessage.create({
                                        body: proto.Message.InteractiveMessage.Body.create({ text: welcomeTeks }),
                                        footer: proto.Message.InteractiveMessage.Footer.create({ text: `© Assistant X Project 📡` }),
                                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                            buttons: [{
                                                name: "quick_reply",
                                                buttonParamsJson: JSON.stringify({ display_text: "🚀 Klik untuk memulai bot", id: ".menu" })
                                            }]
                                        }),
                                        contextInfo: {
                                            mentionedJid: [target],
                                            forwardingScore: 999,
                                            isForwarded: true,
                                            forwardedNewsletterMessageInfo: {
                                                newsletterJid: global.idChannel || "1203631@newsletter",
                                                newsletterName: "🎉 Assistant X Welcome",
                                                serverId: 1
                                            }
                                        }
                                    })
                                }
                            }
                        }, {});

                        await sock.relayMessage(id, msgWelcome.message, { messageId: msgWelcome.key.id });

                    } else if (action === 'remove') {
                        // 🧠 TEKS GOODBYE
                        let goodbyeTeks = `👋 *G O O D B Y E* 👋\n\nSayonara @${target.split('@')[0]}... 🍂\n\n_Terima kasih sudah pernah meramaikan **${groupName}**._`;

                        let msgGoodbye = generateWAMessageFromContent(id, {
                            viewOnceMessage: {
                                message: {
                                    messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                                    interactiveMessage: proto.Message.InteractiveMessage.create({
                                        body: proto.Message.InteractiveMessage.Body.create({ text: goodbyeTeks }),
                                        footer: proto.Message.InteractiveMessage.Footer.create({ text: `© Assistant X Project 📡` }),
                                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                            buttons: [{
                                                name: "quick_reply",
                                                buttonParamsJson: JSON.stringify({ display_text: "🔙 Kembali ke Menu", id: ".menu" })
                                            }]
                                        }),
                                        contextInfo: {
                                            mentionedJid: [target],
                                            forwardingScore: 999,
                                            isForwarded: true,
                                            forwardedNewsletterMessageInfo: {
                                                newsletterJid: global.idChannel || "1203631@newsletter",
                                                newsletterName: "🍂 Assistant X Departure",
                                                serverId: 1
                                            }
                                        }
                                    })
                                }
                            }
                        }, {});

                        await sock.relayMessage(id, msgGoodbye.message, { messageId: msgGoodbye.key.id });
                    }
                }
            } catch (err) {
                console.error("🔴 [ERROR CHIP PENYADAP]", err);
            }
        });
    }
}

handler.command = ["welcome"];
handler.tags = ["group"];
handler.help = ["welcome on/off"];
handler.group = true;
handler.admin = true;

module.exports = handler;
