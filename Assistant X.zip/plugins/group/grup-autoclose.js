const moment = require('moment-timezone');

// ==========================================
// ⏳ VIP AUTO CLOSE/OPEN GROUP (BACKGROUND ENGINE)
// ==========================================

let handler = async (m, { sock, args, command, prefix, isAdmin, isOwner }) => {
    // 1. Validasi Keamanan VIP
    if (!m.isGroup) return m.reply("❌ *Akses Ditolak!*\nFitur ini khusus untuk pengaturan di dalam grup.");
    if (!isAdmin && !isOwner) return m.reply("🛡️ *Akses Ditolak!*\nHanya Admin Group yang dapat mengatur jadwal gerbang.");

    let chat = global.db.groups[m.chat];
    if (!chat) global.db.groups[m.chat] = {};

    // 2. Fungsi Reply VIP
    const replyVIP = async (teks) => {
        return sock.sendMessage(m.chat, {
            text: teks,
            contextInfo: {
                forwardingScore: 999, isForwarded: true,
                forwardedNewsletterMessageInfo: { newsletterJid: global.idChannel || "1203631@newsletter", newsletterName: "⚙️ Group Scheduler", serverId: 1 }
            }
        }, { quoted: m });
    };

    // 3. Logika Menyalakan (ON)
    if (args[0] === 'on' || args[0] === 'aktif') {
        if (!args[1] || !args[1].includes('|')) {
            return replyVIP(`❌ *Format Salah!*\n\nContoh Penggunaan:\n> \`${prefix + command} on 22:00|05:30\`\n_(Artinya tutup jam 22:00, buka jam 05:30)_`);
        }

        let [closeTime, openTime] = args[1].split('|').map(v => v.trim());
        const timeRegex = /^([01]\d|2[0-3]):([0-5]\d)$/; // Format wajib HH:mm

        if (!timeRegex.test(closeTime) || !timeRegex.test(openTime)) {
            return replyVIP('❌ *Format Waktu Tidak Sah!*\nPastikan menggunakan format 24 Jam, contoh: *07:15* atau *23:00*.');
        }

        // Menyimpan ke database (Sesuai dengan settingscek.js)
        chat.autoclose = { 
            status: true, 
            closeTime: closeTime, 
            openTime: openTime, 
            lastTrigger: '' 
        };

        await m.react("✅").catch(() => {});
        
        let teksSukses = `✅ *A U T O   S C H E D U L E R   A K T I F*\n\n`;
        teksSukses += `🌙 *Gerbang Ditutup:* ${closeTime} WIB\n`;
        teksSukses += `☀️ *Gerbang Dibuka:* ${openTime} WIB\n\n`;
        teksSukses += `_Sistem Background Timer telah mengambil alih jadwal grup ini._ ⏳`;
        
        return replyVIP(teksSukses);
    } 
    
    // 4. Logika Mematikan (OFF)
    else if (args[0] === 'off' || args[0] === 'mati') {
        if (!chat.autoclose || !chat.autoclose.status) return replyVIP('⚠️ *Peringatan:*\nJadwal otomatis memang belum aktif di grup ini.');
        
        chat.autoclose.status = false;
        await m.react("✅").catch(() => {});
        return replyVIP('🛑 *A U T O   S C H E D U L E R   M A T I*\n\n_Pengaturan gerbang dikembalikan ke mode manual._');
    } 
    
    else {
        return replyVIP(`❌ *Argumen Tidak Dikenal!*\nSilakan gunakan opsi *on* atau *off*.\n\nContoh: \`${prefix + command} on 22:00|06:00\``);
    }
};

// ==========================================
// 📡 CHIP PENYADAP WAKTU (BACKGROUND TIMER)
// ==========================================
handler.before = async (m, { sock }) => {
    // Tanam interval 1x saja agar tidak spam di memori VPS
    if (!sock.autoGcIntervalInjected) {
        sock.autoGcIntervalInjected = true;
        console.log("🟢 [SYSTEM] Menyalakan Mesin Waktu Auto-Close Group...");

        setInterval(async () => {
            let currentTime = moment().tz('Asia/Jakarta').format('HH:mm');
            
            // Cegah pengiriman dobel di menit yang sama
            if (sock.lastCronCheck === currentTime) return;
            let triggered = false;

            // Looping semua grup yang ada di database
            for (let jid of Object.keys(global.db.groups)) {
                let chat = global.db.groups[jid];
                
                // Lewati jika fitur tidak aktif
                if (!chat || !chat.autoclose || !chat.autoclose.status) continue;

                let { closeTime, openTime, lastTrigger } = chat.autoclose;

                // --- EKSEKUSI LOCKDOWN (TUTUP) ---
                if (currentTime === closeTime && lastTrigger !== 'closed') {
                    try {
                        await sock.groupSettingUpdate(jid, 'announcement');
                        
                        let teksLock = `🔒 *G R O U P   L O C K D O W N* 🔒\n\n`;
                        teksLock += `Waktu menunjukkan pukul *${currentTime} WIB*.\n`;
                        teksLock += `Gerbang komunikasi grup telah ditutup otomatis oleh sistem.\n\n`;
                        teksLock += `_Grup akan dibuka kembali pada pukul ${openTime} WIB._ 🛑`;

                        await sock.sendMessage(jid, { 
                            text: teksLock,
                            contextInfo: { forwardingScore: 999, isForwarded: true, forwardedNewsletterMessageInfo: { newsletterJid: global.idChannel || "1203631@newsletter", newsletterName: "⚙️ Group Scheduler", serverId: 1 } }
                        });
                        
                        chat.autoclose.lastTrigger = 'closed';
                        triggered = true;
                    } catch (e) {
                        console.error(`🔴 [ERROR AUTOGC] Gagal menutup grup ${jid}. Bot bukan admin?`);
                    }
                } 
                
                // --- EKSEKUSI UNLOCK (BUKA) ---
                else if (currentTime === openTime && lastTrigger !== 'opened') {
                    try {
                        await sock.groupSettingUpdate(jid, 'not_announcement');
                        
                        let teksUnlock = `🔓 *G R O U P   U N L O C K E D* 🔓\n\n`;
                        teksUnlock += `Waktu menunjukkan pukul *${currentTime} WIB*.\n`;
                        teksUnlock += `Gerbang komunikasi grup telah dibuka otomatis oleh sistem.\n\n`;
                        teksUnlock += `_Silakan berdiskusi dengan tertib dan sopan._ ✨`;

                        await sock.sendMessage(jid, { 
                            text: teksUnlock,
                            contextInfo: { forwardingScore: 999, isForwarded: true, forwardedNewsletterMessageInfo: { newsletterJid: global.idChannel || "1203631@newsletter", newsletterName: "⚙️ Group Scheduler", serverId: 1 } }
                        });

                        chat.autoclose.lastTrigger = 'opened';
                        triggered = true;
                    } catch (e) {
                        console.error(`🔴 [ERROR AUTOGC] Gagal membuka grup ${jid}. Bot bukan admin?`);
                    }
                }

                // --- RESET TRIGGER ---
                // Jika jam saat ini bukan jam buka dan bukan jam tutup, reset status trigger
                if (currentTime !== closeTime && currentTime !== openTime) {
                    if (chat.autoclose.lastTrigger) chat.autoclose.lastTrigger = ''; 
                }
            }
            
            // Catat waktu terakhir agar tidak mengulang
            if (triggered) {
                sock.lastCronCheck = currentTime;
            }
            
        }, 30000); // Mengecek setiap 30 detik!
    }
    
    // Jangan menghalangi plugin lain
    return false;
}

handler.command = ["autogc", "autoclose", "jadwalgc"];
handler.tags = ["group"];
handler.help = ["autogc on/off"];
handler.admin = true;
handler.group = true;

module.exports = handler;
