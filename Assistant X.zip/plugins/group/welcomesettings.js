// ==========================================
// ⚙️ CUSTOM WELCOME TEXT (VIP SETTINGS)
// ==========================================

let handler = async (m, { sock, text, prefix, command, isAdmin, isOwner }) => {
    
    // 🔥 Fungsi Reply VIP dengan Suntikan Tag Biru
    const replyVIP = async (teks, targets = []) => {
        return sock.sendMessage(m.chat, {
            text: teks,
            contextInfo: {
                mentionedJid: targets, // INI OBAT TAG BIRUNYA
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: global.idChannel || "1203631@newsletter",
                    newsletterName: "⚙️ System Configuration",
                    serverId: 1
                }
            }
        }, { quoted: m });
    };

    if (!m.isGroup) return replyVIP("❌ *Akses Ditolak!*\nFitur ini khusus untuk pengaturan di dalam grup.");
    if (!isAdmin && !isOwner) return replyVIP("🛡️ *Akses Ditolak!*\nHanya Admin Group yang berwenang mengubah teks sambutan.");

    let chat = global.db.groups[m.chat];
    if (!chat) global.db.groups[m.chat] = {};

    await m.react("⏳").catch(() => {});

    // LOGIKA MENGHAPUS CUSTOM WELCOME
    if (['delwelcome', 'hapuswelcome'].includes(command)) {
        delete chat.sWelcome;
        await m.react("✅").catch(() => {});
        return replyVIP("🗑️ *Custom Welcome Dihapus!*\nSistem akan kembali menggunakan teks sambutan *Default* Assistant X.");
    }

    // LOGIKA JIKA TEKS KOSONG (MENAMPILKAN PANDUAN)
    if (!text) {
        await m.react("❌").catch(() => {});
        let usage = `✨ *C U S T O M   W E L C O M E* ✨\n\n`;
        usage += `Gunakan fitur ini untuk merubah teks sambutan member baru secara spesifik untuk grup ini.\n\n`;
        usage += `*Variabel Ajaib yang bisa digunakan:*\n`;
        usage += `> \`@user\` : Untuk men-tag member yang baru masuk\n`;
        usage += `> \`@subject\` : Untuk memanggil nama grup ini\n\n`;
        usage += `*Contoh Penggunaan:*\n`;
        usage += `> \`${prefix + command} Halo @user, selamat bergabung di keluarga besar @subject! Jangan lupa baca deskripsi grup ya!\``;
        
        return replyVIP(usage);
    }

    // LOGIKA MENYIMPAN TEKS
    chat.sWelcome = text;
    
    let teksSukses = `✅ *Custom Welcome Berhasil Disimpan!*\n\n`;
    teksSukses += `*Preview Tampilan:*\n`;
    // Me-replace variabel agar terlihat cantik di preview
    teksSukses += `"${text.replace('@user', '@' + m.sender.split('@')[0]).replace('@subject', m.metadata?.subject || "Grup Ini")}"\n\n`;
    teksSukses += `_Setiap member baru akan disapa dengan teks ini._ 🛡️`;

    await m.react("✅").catch(() => {});
    // Memasukkan m.sender agar nomor di preview berubah jadi tag biru
    return replyVIP(teksSukses, [m.sender]);
}

handler.command = ["setwelcome", "delwelcome"];
handler.tags = ["group"];
handler.help = ["setwelcome <teks>", "delwelcome"];

module.exports = handler;
