const { generateWAMessageContent, proto, generateWAMessageFromContent, downloadContentFromMessage } = require('@whiskeysockets/baileys');
const crypto = require('crypto');

// Jeda aman anti-banned
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// ==========================================
// 📡 HELPER FUNGSI CORE
// ==========================================

// 🔥 Helper 1: Download Media Murni (Native Baileys Engine - Anti Error)
async function downloadMedia(q) {
    try {
        // Jalur 1: Cek jika base script bot memiliki fungsi download bawaan
        if (typeof q.download === 'function') {
            const buffer = await q.download();
            if (Buffer.isBuffer(buffer) && buffer.length) return buffer;
        }

        // 🔥 Jalur 2 (VVIP): Gunakan Ekstraktor Murni Baileys jika Jalur 1 gagal/tidak didukung!
        let msg = q.msg || q;
        let mime = msg.mimetype || q.mediaType || '';
        let mediaType = mime.split('/')[0];
        
        if (mediaType === 'audio') mediaType = 'audio';
        else if (mediaType === 'video') mediaType = 'video';
        else if (mediaType === 'image') mediaType = 'image';
        else mediaType = 'document';

        const stream = await downloadContentFromMessage(msg, mediaType);
        let buffer = Buffer.from([]);
        
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        
        if (buffer.length > 0) return buffer;
        throw new Error('Buffer hasil ekstraksi kosong.');

    } catch (e) {
        throw new Error(`Gagal menyedot media dari server WhatsApp. Log: ${e.message}`);
    }
}

// Helper 2: Mesin Pengirim Status Grup V2 (Anti Error)
async function sendGroupStatus(sock, groupJid, content = {}) {
    let inside = await generateWAMessageContent(content, { upload: sock.waUploadToServer });
    
    // Perbaikan format teks agar bisa masuk ke dalam status V2
    if (inside.conversation) {
        inside = { extendedTextMessage: { text: inside.conversation, font: 3 } };
    } else if (inside.extendedTextMessage) {
        inside.extendedTextMessage.font = 3;
    }

    const message = proto.Message.fromObject({
        groupStatusMessageV2: {
            message: inside,
            groupJid
        }
    });

    await sock.relayMessage(groupJid, message, {
        messageId: crypto.randomBytes(6).toString('hex')
    });
}

// ==========================================
// 🚀 MAIN HANDLER (SWGC CONTROLLER)
// ==========================================

let handler = async (m, { sock, args, text, prefix, command, isAdmin, isOwner }) => {
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || q.mimetype || q.mediaType || '';
    const captionText = m.text.replace(new RegExp(`^${prefix}${command}\\s*`, 'i'), '').trim();

    switch (command) {
        
        // ----------------------------------------------------
        // 1. FITUR: .swgc (Upload status ke grup saat ini)
        // ----------------------------------------------------
        case 'swgc': {
            if (!isOwner && !isAdmin) return m.reply("❌ *Akses Ditolak!*\nFitur ini hanya untuk Admin Grup dan Owner bot.");
            if (!mime && !captionText) return m.reply(`⚠️ *Format Salah!*\n\n*Contoh:*\n${prefix}swgc Halo warga!\n${prefix}swgc (sambil reply gambar/video)`);

            await m.react('⏳');
            try {
                let payload = {};
                if (/image/.test(mime)) payload = { image: await downloadMedia(q), caption: captionText };
                else if (/video/.test(mime)) payload = { video: await downloadMedia(q), caption: captionText };
                else if (/audio/.test(mime)) payload = { audio: await downloadMedia(q), mimetype: 'audio/mp4' };
                else payload = { text: captionText };

                await sendGroupStatus(sock, m.chat, payload);
                await m.react('✅');
                m.reply("✅ *Status berhasil diunggah ke grup ini!*");
            } catch (e) {
                console.error('[SWGC ERROR]', e);
                await m.react('❌');
                m.reply(`❌ Terjadi kesalahan saat mengunggah status grup.\n\n📝 _Log:_ ${e.message}`);
            }
            break;
        }

        // ----------------------------------------------------
        // 2. FITUR: .swgcall (Dashboard Kontrol Multi-Grup)
        // ----------------------------------------------------
        case 'swgcall': {
            if (!isOwner) return m.reply("❌ *Akses Ditolak!*\nFitur dashboard SWGC hanya khusus Owner bot.");
            
            try {
                let buffer = null;
                let type = "text";
                
                if (/image|video|audio/.test(mime)) {
                    buffer = await downloadMedia(q);
                    type = /image/.test(mime) ? 'image' : /video/.test(mime) ? 'video' : 'audio';
                } else if (!captionText) {
                    return m.reply(`⚠️ _Kirim/Balas gambar/video dengan caption *${prefix}swgcall*_`);
                }

                // Simpan cache ke memori Global
                global.swgcBuffer = global.swgcBuffer || {};
                global.swgcBuffer[m.sender] = { buffer, type, caption: captionText };

                await m.react('⏳');
                let { key } = await sock.sendMessage(m.chat, { text: "🔍 _Mengambil daftar grup..._" }, { quoted: m });

                const allGroups = await sock.groupFetchAllParticipating();
                const groupList = Object.values(allGroups);

                if (groupList.length === 0) return m.reply("❌ Bot tidak berada di dalam grup manapun.");

                // Rakit List Interaktif VVIP
                const rows = groupList.map(g => ({
                    header: "",
                    title: g.subject,
                    description: `👥 Anggota: ${g.participants.length} | ⚙️ Status: ${g.announce ? "Hanya Admin" : "Terbuka"}`,
                    id: `${prefix}swgcprocess ${g.id}`
                }));

                let teksBuka = `✨ *SWGC - CONTROLLER* ✨\n\n`;
                teksBuka += `📊 *Total Grup:* ${groupList.length}\n\n`;
                teksBuka += `_Pilih opsi di bawah untuk mengirim media/teks yang sudah tersimpan ke grup tujuan._`;

                const msg = generateWAMessageFromContent(m.chat, {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                            interactiveMessage: proto.Message.InteractiveMessage.create({
                                body: proto.Message.InteractiveMessage.Body.create({ text: teksBuka }),
                                footer: proto.Message.InteractiveMessage.Footer.create({ text: `© Assistant X Group Status Engine 📡` }),
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                    buttons: [
                                        {
                                            name: "single_select",
                                            buttonParamsJson: JSON.stringify({
                                                title: "📥 Pilih Grup Tujuan",
                                                sections: [{ title: "Daftar Grup Bot", rows: rows }]
                                            })
                                        },
                                        {
                                            name: "quick_reply",
                                            buttonParamsJson: JSON.stringify({
                                                display_text: "🚀 Kirim Ke Semua Grup",
                                                id: `${prefix}swgcallprocess`
                                            })
                                        }
                                    ]
                                }),
                                contextInfo: { mentionedJid: [m.sender], forwardingScore: 999, isForwarded: true }
                            })
                        }
                    }
                }, { quoted: m });

                await sock.sendMessage(m.chat, { delete: key }); // Hapus pesan loading
                await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

            } catch (error) {
                console.error('[SWGCALL ERROR]', error);
                m.reply(`❌ Gagal menampilkan daftar grup.\n📝 _Log:_ ${error.message}`);
            }
            break;
        }

        // ----------------------------------------------------
        // 3. FITUR: .swgcprocess (Proses per-Grup dari Tombol)
        // ----------------------------------------------------
        case 'swgcprocess': {
            if (!isOwner) return;
            const groupId = args[0];
            if (!groupId) return m.reply("❌ ID Grup tidak ditemukan.");

            const data = global.swgcBuffer ? global.swgcBuffer[m.sender] : null;
            if (!data) return m.reply(`❌ Media tidak tersedia atau kadaluarsa!\nSilakan reply media yang mau dikirim dengan *${prefix}swgcall* terlebih dahulu.`);

            await m.react('🚀');
            try {
                let payload = {};
                if (data.type === 'image') payload = { image: data.buffer, caption: data.caption };
                else if (data.type === 'video') payload = { video: data.buffer, caption: data.caption };
                else if (data.type === 'audio') payload = { audio: data.buffer, mimetype: 'audio/mp4' };
                else payload = { text: data.caption };

                await sendGroupStatus(sock, groupId, payload);
                delete global.swgcBuffer[m.sender]; // Bersihkan cache memori
                
                m.reply(`✅ *Sukses!*\nStatus berhasil dikirim ke grup: ${groupId}`);
            } catch (error) {
                console.error('[SWGC PROCESS ERROR]', error);
                m.reply("❌ Gagal mengirim status ke grup tersebut.");
            }
            break;
        }

        // ----------------------------------------------------
        // 4. FITUR: .swgcallprocess (Proses All Grup)
        // ----------------------------------------------------
        case 'swgcallprocess': {
            if (!isOwner) return;
            const data = global.swgcBuffer ? global.swgcBuffer[m.sender] : null;
            if (!data) return m.reply(`❌ Media tidak tersedia!\nSilakan reply media yang mau dikirim dengan *${prefix}swgcall* terlebih dahulu.`);
            
            try {
                let { key } = await sock.sendMessage(m.chat, { text: "⏳ *Memproses upload massal ke seluruh grup...*" }, { quoted: m });
                
                const allGroups = await sock.groupFetchAllParticipating();
                const groupList = Object.values(allGroups);
                
                if (groupList.length === 0) return m.reply("❌ Bot tidak ada di grup manapun!");
                
                let success = 0;
                let failed = 0;
                
                let payload = {};
                if (data.type === 'image') payload = { image: data.buffer, caption: data.caption };
                else if (data.type === 'video') payload = { video: data.buffer, caption: data.caption };
                else if (data.type === 'audio') payload = { audio: data.buffer, mimetype: 'audio/mp4' };
                else payload = { text: data.caption };
                
                // Looping Pengiriman dengan Jeda Waktu
                for (const group of groupList) {
                    try {
                        await sendGroupStatus(sock, group.id, payload);
                        success++;
                        await sleep(8000); 
                    } catch (e) {
                        failed++;
                        console.error(`Gagal kirim ke ${group.id}:`, e.message);
                    }
                }
                
                delete global.swgcBuffer[m.sender];
                
                let resultTeks = `✅ *EKSEKUSI SELESAI!*\n\n`;
                resultTeks += `📊 *Ringkasan Pengiriman:*\n`;
                resultTeks += `• Total Target: ${groupList.length} Grup\n`;
                resultTeks += `• Berhasil: ${success} Grup\n`;
                resultTeks += `• Gagal/Ditolak: ${failed} Grup`;
                
                await sock.sendMessage(m.chat, { text: resultTeks, edit: key });
                
            } catch (e) {
                console.error('[SWGC ALLPROCESS ERROR]', e);
                m.reply("❌ Terjadi kesalahan fatal saat mengunggah status ke semua grup.");
            }
            break;
        }
    }
}

handler.help = ['swgc', 'swgcall'];
handler.tags = ['group'];
handler.command = ['swgc', 'swgcall', 'swgcprocess', 'swgcallprocess']; 
handler.group = false; 

module.exports = handler;
