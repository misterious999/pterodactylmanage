const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

// ==========================================
// 🚀 MAIN HANDLER (TOMBOL CONTROLLER)
// ==========================================
let handler = async (m, { sock, args, prefix, command, isAdmin, isOwner }) => {
    if (!m.isGroup) return m.reply("❌ Fitur ini hanya khusus digunakan di dalam grup!");
    if (!isAdmin && !isOwner) return m.reply("❌ *Akses Ditolak!*\nHanya Admin Grup yang bisa mengatur sistem keamanan ini.");

    // Pengaman Database (Anti-Crash)
    global.db = global.db || { data: { chats: {}, users: {} } };
    global.db.data = global.db.data || { chats: {}, users: {} };
    global.db.data.chats = global.db.data.chats || {};

    global.db.data.chats[m.chat] = global.db.data.chats[m.chat] || {};
    let chat = global.db.data.chats[m.chat];

    if (args[0] === 'on') {
        if (chat.antiswgc) return m.reply("⚠️ Fitur *Anti-SWGC* sudah aktif di grup ini.");
        chat.antiswgc = true;
        return m.reply("✅ *Anti-SWGC Berhasil Diaktifkan!*\nAturan Mutlak: HANYA OWNER yang boleh membuat Status Grup. Pelanggar (termasuk bot lain & admin) akan ditindak tegas!");
    } else if (args[0] === 'off') {
        if (!chat.antiswgc) return m.reply("⚠️ Fitur *Anti-SWGC* memang sudah nonaktif.");
        chat.antiswgc = false;
        return m.reply("✅ *Anti-SWGC Berhasil Dinonaktifkan!*\nSemua anggota kini bebas berkreasi.");
    } else {
        return m.reply(`❓ *Format Salah!*\n\nGunakan perintah:\n◦ \`${prefix + command} on\` (Aktifkan)\n◦ \`${prefix + command} off\` (Matikan)`);
    }
}

// ==========================================
// 🛡️ AUTO-DETECTION SYSTEM (BEFORE HOOK)
// ==========================================
handler.before = async (m, { sock, isOwner, isBotAdmin }) => {
    if (!m.isGroup) return false; // Hanya berjalan di grup

    // Load Data
    global.db = global.db || { data: { chats: {}, users: {} } };
    global.db.data = global.db.data || { chats: {}, users: {} };
    global.db.data.chats = global.db.data.chats || {};
    global.db.data.users = global.db.data.users || {};

    global.db.data.chats[m.chat] = global.db.data.chats[m.chat] || {};
    let chat = global.db.data.chats[m.chat];

    // Eksekusi jika fitur aktif dan pelakunya BUKAN owner
    if (chat.antiswgc && !isOwner) {
        let isStatusGrup = false;

        // 🔍 DETEKSI PESAN STATUS GRUP (SWGC) SUPER AKURAT
        if (m.message) {
            // Ekstrak pesan sesungguhnya (Bypass lapisan ephemeral/viewOnce)
            let msg = m.message;
            if (msg.ephemeralMessage) msg = msg.ephemeralMessage.message;
            if (msg.viewOnceMessage) msg = msg.viewOnceMessage.message;
            if (msg.viewOnceMessageV2) msg = msg.viewOnceMessageV2.message;
            if (msg.viewOnceMessageV2Extension) msg = msg.viewOnceMessageV2Extension.message;

            let keys = Object.keys(msg || {});

            // Mengecek keberadaan object Group Status bawaan WhatsApp/Baileys API terbaru
            if (
                keys.includes('groupStatusMessage') || 
                keys.includes('groupStatusMentionMessage') || 
                keys.includes('statusMentionMessage') ||
                m.mtype === 'groupStatusMessage' ||
                m.mtype === 'groupStatusMentionMessage'
            ) {
                isStatusGrup = true;
            }
        }

        // 🚨 JIKA TERDETEKSI SEBAGAI STATUS GRUP ILEGAL
        if (isStatusGrup) {
            
            // Hapus pesan status grup tersebut (Harus Bot Admin)
            if (isBotAdmin) {
                await sock.sendMessage(m.chat, { delete: m.key }).catch(() => {});
            }

            global.db.data.users[m.sender] = global.db.data.users[m.sender] || {};
            let user = global.db.data.users[m.sender];
            
            // Tambahkan point pelanggaran
            user.warn_swgc = (user.warn_swgc || 0) + 1;

            // Cek apakah sudah 3x melanggar
            if (user.warn_swgc >= 3) {
                // Reset point pelanggaran
                user.warn_swgc = 0;
                
                // Kirim notifikasi eliminasi
                await sock.sendMessage(m.chat, { 
                    text: `🚨 *ELIMINASI SYSTEM* 🚨\n\nSelamat tinggal @${m.sender.split('@')[0]}! 👋\nKamu telah ngeyel membuat Status Grup ilegal sebanyak 3 kali.\n\n_Eksekusi Kick otomatis dijalankan..._`, 
                    mentions: [m.sender] 
                }).catch(() => {});
                
                // Tendang (Kick) akun tersebut dari grup
                if (isBotAdmin) {
                    await sock.groupParticipantsUpdate(m.chat, [m.sender], "remove").catch(() => {});
                }
                
            } else {
                // Kirim surat peringatan (SP)
                await sock.sendMessage(m.chat, { 
                    text: `🛡️ *SYSTEM WARNING (${user.warn_swgc}/3)* 🛡️\n\nKetahuan lu ya @${m.sender.split('@')[0]}! 🗿\nDi grup ini HANYA OWNER yang boleh membuat Status Grup!\n\n_Peringatan ke-${user.warn_swgc} dari 3. Sekali lagi bikin Status Grup, otomatis di-kick!_`, 
                    mentions: [m.sender] 
                }).catch(() => {});
            }
            return true; // Stop eksekusi plugin lain agar fokus menindak pelanggar
        }
    }
    return false;
}

handler.command = ['antiswgc'];
handler.tags = ['grup'];
handler.help = ['antiswgc'];

module.exports = handler;
