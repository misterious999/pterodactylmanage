let handler = async (m, { sock, args, command, prefix }) => {
  // Pastikan database settings sudah ada
  if (!global.db.settings) global.db.settings = {};
  if (global.db.settings.autoread === undefined) global.db.settings.autoread = false;

  let setting = global.db.settings;

  if (args[0] === 'on') {
    if (setting.autoread) return m.replyPremium("⚠️ Fitur Auto-Read sudah aktif sebelumnya!");
    setting.autoread = true;
    await m.react("✅");
    m.replyPremium("✅ *Auto-Read AKTIF!*\nBot sekarang akan otomatis membaca (centang biru) semua pesan masuk.");
  } 
  else if (args[0] === 'off') {
    if (!setting.autoread) return m.replyPremium("⚠️ Fitur Auto-Read memang sudah mati!");
    setting.autoread = false;
    await m.react("✅");
    m.replyPremium("❌ *Auto-Read DIMATIKAN!*\nBot tidak akan lagi mengirimkan laporan dibaca (centang abu-abu).");
  } 
  else {
    m.replyPremium(`❌ Format salah!\n\n*Contoh Penggunaan:*\n\`${prefix + command} on\`\n\`${prefix + command} off\``);
  }
}

handler.command = ["autoread", "autobaca"];
handler.tags = ["owner"];
handler.help = ["autoread on/off"];
handler.owner = true; // Khusus Owner saja!

module.exports = handler;
