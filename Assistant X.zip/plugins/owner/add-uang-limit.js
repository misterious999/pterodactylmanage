// ==========================================
// 💰 FITUR TOP UP SALDO & LIMIT (DEVELOPER ONLY)
// ⚙️ FIXED: SINKRONISASI 'BALANCE' & ANTI DOUBLE RP
// ==========================================

let handler = async (m, { sock, args, text, command, prefix }) => {
  // 1. Validasi Input Dasar
  if (!text) {
    await m.react("⚠️")
    return m.reply(`❌ Format salah!\n\n*Cara Penggunaan:*\n\`${prefix + command} @tag/reply/nomor jumlah\`\n\n*Contoh:*\n\`${prefix + command} @628xxxxxx 2000000\``)
  }

  // 2. Deteksi Target (Bisa dari Reply, Tag/Mention, atau ketik nomor manual)
  let target = m.mentionedJid && m.mentionedJid[0] 
               ? m.mentionedJid[0] 
               : m.quoted 
                 ? m.quoted.sender 
                 : args[0] ? args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : ""

  if (!target || target === '@s.whatsapp.net') {
     return m.reply("❌ Harap tag (mention), reply pesan, atau masukkan nomor targetnya!")
  }

  // 3. Pengecekan Database
  let user = global.db.users[target]
  if (!user) {
    return m.reply(`❌ Pengguna tersebut belum terdaftar di database bot!`)
  }

  // 4. Ekstrak Nominal Angka (Lebih Akurat)
  // Kita bersihkan teks dari tag '@nomor' biar yang tersisa murni cuma angkanya saja!
  let cleanText = text.replace(/@\d+/g, '').trim();
  let amount = parseInt(cleanText);

  if (isNaN(amount) || amount <= 0) {
    await m.react("⚠️")
    return m.reply(`❌ Masukkan jumlah angka yang valid!\n*Contoh:* \`${prefix + command} @tag 50\``)
  }

  // 5. Eksekusi Penambahan
  await m.react("⏳")
  
  // ==========================================
  // 🎟️ LOGIKA TOP UP LIMIT
  // ==========================================
  if (command === 'addlimit') {
    user.limit = (user.limit || 0) + amount
    await m.react("✅")
    return sock.sendMessage(m.chat, { 
        text: `╭───┈ *「 TOP UP LIMIT 」*\n│ ✅ Berhasil menambahkan *${amount} Limit*\n│ 👤 Kepada: @${target.split('@')[0]}\n│ 🎟️ Limit Sekarang: *${user.limit}*\n╰───────────────┈ ⳹`, 
        mentions: [target] 
    }, { quoted: m })
  } 
  
  // ==========================================
  // 💰 LOGIKA TOP UP SALDO
  // ==========================================
  if (command === 'adduang' || command === 'addmoney' || command === 'addbalance') {
    // 🔥 FIX UTAMA 1: Paksa masuk ke dompet asli (user.balance)
    user.balance = (user.balance || 0) + amount
    
    // 🔥 FIX UTAMA 2: Format Rupiah rapi, cegah double "Rp Rp"
    let currentBalance = typeof global.toRupiah === 'function' ? global.toRupiah(user.balance) : `Rp ${user.balance.toLocaleString('id-ID')}`
    let addedAmount = typeof global.toRupiah === 'function' ? global.toRupiah(amount) : `Rp ${amount.toLocaleString('id-ID')}`
    
    await m.react("✅")
    return sock.sendMessage(m.chat, { 
        text: `╭───┈ *「 TOP UP SALDO 」*\n│ ✅ Berhasil menambahkan *${addedAmount}*\n│ 👤 Kepada: @${target.split('@')[0]}\n│ 💳 Saldo Sekarang: *${currentBalance}*\n╰───────────────┈ ⳹`, 
        mentions: [target] 
    }, { quoted: m })
  }
}

handler.command = ["addlimit", "adduang", "addmoney", "addbalance"]
handler.tags = ["owner"]
handler.help = ["addlimit @tag jumlah", "adduang @tag jumlah"]
handler.owner = true // 🛡️ GLOBAL SECURITY: HANYA OWNER YANG BISA PAKAI INI!

module.exports = handler
