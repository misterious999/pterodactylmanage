// ==========================================
// 👨‍💻 ROOT TERMINAL (SISTEM MANAJEMEN OWNER)
// ==========================================

let handler = async (m, { sock, text, command, prefix }) => {
  let usedPrefix = prefix || '.';

  // 1. Pastikan seluruh struktur object database aman
  global.db = global.db || {};
  global.db.settings = global.db.settings || {};
  global.db.settings.owner = global.db.settings.owner || [];
  
  let dbOwner = global.db.settings.owner;

  // 2. Identifikasi target dari reply, tag, atau teks manual
  let target = m.quoted?.sender 
    ? m.quoted.sender 
    : m.mentionedJid?.[0] 
    ? m.mentionedJid[0] 
    : text 
    ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" 
    : null;

  let ownerNumber = target ? target.split('@')[0] : null;

  switch (command) {

    // ➕ FITUR TAMBAH OWNER
    case "addowner": {
      if (!target || !ownerNumber) return m.reply(`╭──「 *⚠️ PILIH TARGET* 」\n│ Masukkan nomor atau tag orangnya!\n│\n│ *Contoh:*\n│ ◦ \`${usedPrefix + command} @tag\`\n│ ◦ \`${usedPrefix + command} 628xxx\`\n╰────────────`);

      if (dbOwner.includes(target)) {
        return m.reply("⚠️ Target tersebut sudah terdaftar sebagai Owner di database!");
      }

      // Simpan ke database persisten
      dbOwner.push(target);
      
      // 🔥 FIX: Pengecekan tipe data global.owner agar terhindar dari TypeError
      if (global.owner) {
         if (Array.isArray(global.owner)) {
             global.owner.push(ownerNumber); 
         } else if (typeof global.owner === 'string') {
             // Jika awalnya string, ubah menjadi array untuk menampung owner baru
             global.owner = [global.owner, ownerNumber];
         }
      }

      return sock.sendMessage(m.chat, {
        text: `╭──「 *✅ NEW OWNER ADDED* 」\n│ 👤 Target: @${ownerNumber}\n│ ⚡ Hak Akses: *VVIP/Creator*\n╰────────────\n\n_Berhasil diangkat menjadi Owner AUTOMATIC BOT!_`,
        mentions: [target]
      }, { quoted: m });
    }

    // ➖ FITUR HAPUS OWNER
    case "delowner": {
      if (!target || !ownerNumber) return m.reply(`╭──「 *⚠️ PILIH TARGET* 」\n│ Masukkan nomor atau tag orangnya!\n│\n│ *Contoh:*\n│ ◦ \`${usedPrefix + command} @tag\`\n│ ◦ \`${usedPrefix + command} 628xxx\`\n╰────────────`);

      if (!dbOwner.includes(target)) {
        return m.reply("⚠️ Target tersebut bukan seorang Owner!");
      }

      // Hapus dari database persisten
      global.db.settings.owner = dbOwner.filter(v => v !== target);
      
      // 🔥 FIX: Hapus dari memori runtime dengan pengecekan aman
      if (global.owner && Array.isArray(global.owner)) {
         let index = global.owner.findIndex(o => o === ownerNumber || (Array.isArray(o) && o[0] === ownerNumber));
         if (index !== -1) global.owner.splice(index, 1);
      }

      return sock.sendMessage(m.chat, {
        text: `╭──「 *🛑 OWNER REVOKED* 」\n│ 👤 Target: @${ownerNumber}\n│ ⚡ Hak Akses: *Dicabut*\n╰────────────\n\n_Berhasil diturunkan pangkatnya menjadi user biasa!_`,
        mentions: [target]
      }, { quoted: m });
    }

    // 📋 FITUR LIHAT DAFTAR OWNER
    case "listowner": {
      let allOwners = new Set([...dbOwner]);
      
      // Menggabungkan data dengan aman berdasarkan tipe datanya
      if (global.owner) {
         if (Array.isArray(global.owner)) {
             global.owner.forEach(o => {
                 let num = Array.isArray(o) ? o[0] : o;
                 allOwners.add(num + "@s.whatsapp.net");
             });
         } else if (typeof global.owner === 'string') {
             allOwners.add(global.owner + "@s.whatsapp.net");
         }
      }

      let data = Array.from(allOwners);

      if (data.length < 1) return m.reply("📝 Belum ada Owner yang terdaftar.");

      let teks = `╭──「 *👨‍💻 ROOT TERMINAL (OWNER)* 」\n`;
      teks += `│ Total: *${data.length} Orang*\n`;
      teks += `╰────────────\n\n`;

      for (let i = 0; i < data.length; i++) {
        teks += `*${i + 1}.* 👤 @${data[i].split("@")[0]}\n`;
      }
      
      teks += `\n_© Executive Database Manager - AUTOMATIC BOT_`;

      return sock.sendMessage(m.chat, {
        text: teks,
        mentions: data
      }, { quoted: m });
    }
  }
}

handler.owner = true; 
handler.tags = ["owner"];
handler.help = ["addowner", "delowner", "listowner"];
handler.command = ["addowner", "delowner", "listowner"];

module.exports = handler;
