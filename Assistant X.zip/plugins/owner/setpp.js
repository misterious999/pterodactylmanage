let handler = async (m, { sock, command, isOwner }) => {
  if (!isOwner) return m.reply("❌ Hanya owner yang bisa menggunakan fitur ini.");

  await m.react("⏳");

  try {
    if (command === "setpp") {
      // ==================== UBAH FOTO PROFIL ====================
      let quotedMsg = m.quoted ? m.quoted : m;

      // Cek apakah ada gambar
      if (!quotedMsg || (!quotedMsg.mimetype && !quotedMsg.msg?.mimetype)) {
        await m.react("❌");
        return m.reply(
          `❌ Kirim atau reply gambar dengan caption:\n\`.setpp\``
        );
      }

      // Download gambar
      const { downloadContentFromMessage } = require("@whiskeysockets/baileys");
      let messageType = quotedMsg.mtype?.replace(/Message/gi, "") || "image";
      
      let stream = await downloadContentFromMessage(
        quotedMsg.msg || quotedMsg, 
        messageType
      );

      let buffer = Buffer.from([]);
      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
      }

      // Ubah foto profil
      await sock.updateProfilePicture(sock.user.id, buffer);

      await m.react("✅");
      m.reply("✅ *Foto profil berhasil diubah!*");

    } else if (command === "delpp") {
      // ==================== HAPUS FOTO PROFIL ====================
      await sock.removeProfilePicture(sock.user.id);

      await m.react("✅");
      m.reply("✅ *Foto profil berhasil dihapus!*");
    }

  } catch (e) {
    console.error("[SETPP ERROR]", e);
    await m.react("❌");
    m.reply("❌ Gagal memproses perintah. Pastikan kamu mengirim/reply gambar yang valid.");
  }
};

handler.command = ["setpp", "delpp"];
handler.tags = ["owner"];
handler.owner = true;

module.exports = handler;