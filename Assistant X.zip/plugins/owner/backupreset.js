const fs = require('fs');
const path = require('path');

let handler = async (m, { sock, prefix, command }) => {
  await m.react("⏳");
  console.log("\n[📦 BACKUP] Memulai proses backup...");

  try {
    require.resolve('archiver');
  } catch (e) {
    await m.react("❌");
    return m.reply(`❌ *SYSTEM HALTED*\nModul kompresi belum terinstal!\nBuka tab Console Pterodactyl, ketik: \`npm install archiver\` lalu restart bot.`);
  }

  const archiver = require('archiver');
  const rootDir = process.cwd(); 
  const botVersion = global.versibot || '1.0'; 
  const zipFileName = `AssistantXProjectV${botVersion}.zip`;
  
  const backupDir = path.join(rootDir, '.temp_backup_mini');
  const zipPath = path.join(rootDir, zipFileName);

  const ignoreList = [
    'node_modules', '.git', 'session', 'auth_info_baileys', 
    '.temp_backup_mini', zipFileName, 'AssistantX_Scrubbed.zip', 
    'package-lock.json', 'database.json', 'db.json', 'database',
    '.cache', '.npm', 'tmp', 'temp'
  ];

  try {
    m.reply("⏳ Proses backup aman sedang dimulai... Cek Console Panel untuk melihat progress!");

    if (fs.existsSync(backupDir)) fs.rmSync(backupDir, { recursive: true, force: true });
    if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath);

    console.log("[📦 BACKUP] TAHAP 1: Mengcopy file...");
    function copyDirSync(src, dest) {
      fs.mkdirSync(dest, { recursive: true });
      let entries = fs.readdirSync(src, { withFileTypes: true });

      for (let entry of entries) {
        if (ignoreList.includes(entry.name)) continue;
        
        let srcPath = path.join(src, entry.name);
        let destPath = path.join(dest, entry.name);

        if (entry.isDirectory()) copyDirSync(srcPath, destPath);
        else fs.copyFileSync(srcPath, destPath);
      }
    }
    copyDirSync(rootDir, backupDir);

    console.log("[📦 BACKUP] TAHAP 2: Membersihkan API Key...");
    function sanitizeFile(fileName) {
      let filePath = path.join(backupDir, fileName);
      if (!fs.existsSync(filePath)) return;
      let content = fs.readFileSync(filePath, 'utf8');
      content = content.replace(/(BOTCAHX_APIKEY\s*=\s*)(.*)/gi, '$1HIDDEN_BY_MINI');
      content = content.replace(/(apikey\s*[:=]\s*['"])(.*?)(['"])/gi, '$1HIDDEN_BY_MINI$3');
      fs.writeFileSync(filePath, content);
    }
    ['config.js', 'config.json', 'settings.js'].forEach(sanitizeFile);

    console.log("[📦 BACKUP] TAHAP 3: Membuat file ZIP...");
    await new Promise((resolve, reject) => {
      const output = fs.createWriteStream(zipPath);
      const archive = archiver('zip', { zlib: { level: 9 } }); 

      output.on('close', resolve);
      archive.on('error', reject);

      archive.pipe(output);
      archive.directory(backupDir, false); 
      archive.finalize();
    });

    let zipStat = fs.statSync(zipPath);
    let fileSizeMB = (zipStat.size / (1024 * 1024)).toFixed(2);
    console.log(`[📦 BACKUP] ZIP Selesai! Ukuran: ${fileSizeMB} MB`);

    // ==========================================
    // 🔒 ULTIMATE FIX: BYPASS CONFIG, LANGSUNG KE PENGIRIM!
    // ==========================================
    let primaryOwner = m.sender; // <-- INI KUNCI JAWABANNYA! (Nomor orang yang ngetik perintah)
    console.log(`[📦 BACKUP] Mengirim ke Owner Asli: ${primaryOwner}`); 

    await sock.sendMessage(primaryOwner, {
      document: fs.readFileSync(zipPath),
      mimetype: 'application/zip',
      fileName: zipFileName,
      caption: `╭───┈ *「 📦 BACKUP SUCCESS 」*\n│ ✅ Script berhasil diamankan!\n│ 🗂️ Nama File: *${zipFileName}*\n│ 📊 Ukuran: *${fileSizeMB} MB*\n╰───────────────┈ ⳹`
    });

    console.log("[📦 BACKUP] BERHASIL DIKIRIM KE PC OWNER!");

    // Kasih info ke grup jika diketik di grup
    if (m.chat !== primaryOwner) {
        await m.reply(`✅ *BACKUP SELESAI!*\n\nFile *${zipFileName}* berhasil dikirim ke Chat Pribadi (PC) milikmu, Bosku! Cek pesan masuk! 🛡️`);
    }

    await m.react("✅");

    // Bersihkan
    fs.rmSync(backupDir, { recursive: true, force: true });
    fs.unlinkSync(zipPath);

  } catch (error) {
    console.error("\n[❌ BACKUP ERROR]\n", error);
    await m.react("❌");
    m.reply(`❌ Terjadi kesalahan saat membackup script.\n*Error:* ${error.message}`);
    
    if (fs.existsSync(backupDir)) fs.rmSync(backupDir, { recursive: true, force: true });
    if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath);
  }
}

handler.command = ["backupreset"];
handler.tags = ["owner"];
handler.help = ["backupreset"];
handler.owner = true; 

module.exports = handler;
