let handler = async (m, { sock }) => {
  let groups = global.db.groups
  let mutedGroups = []

  // Memindai grup yang status mutenya aktif
  for (let jid in groups) {
    if (groups[jid]?.mute) {
      mutedGroups.push(jid)
    }
  }

  if (mutedGroups.length === 0) return m.reply("🔊 Tidak ada grup yang sedang di-mute saat ini.")

  let teks = `╭───┈ *「 DAFTAR GRUP MUTE 」*\n`
  teks += `│ 🔇 *Total:* ${mutedGroups.length} Grup\n`
  teks += `╰───────────────┈ ⳹\n\n`

  for (let i = 0; i < mutedGroups.length; i++) {
    let jid = mutedGroups[i]
    let name = "Grup " + (i + 1)
    
    // Mencoba mengambil nama grup secara langsung
    try {
      let meta = await sock.groupMetadata(jid)
      name = meta.subject
    } catch (e) {}
    
    teks += `▧ *${name}*\n> ID: ${jid}\n\n`
  }

  teks += `_Gunakan perintah .unmute atau .mute (untuk membuka list tombol) jika ingin mengaktifkan bot kembali._`
  
  await m.reply(teks)
}

handler.command = ["listmute", "mutelist"]
handler.tags = ["owner"]
handler.help = ["listmute"]
handler.owner = true // Khusus Owner

module.exports = handler
