// ==========================================
// 🧹 VIP DATABASE CLEANER (GARBAGE COLLECTOR)
// ==========================================

let handler = async (m, { sock, isOwner }) => {
    // 🔒 Keamanan Ekstra: Hanya Owner yang bisa mengeksekusi
    if (!isOwner) {
        await m.react("🚫").catch(() => {});
        return m.reply("🔒 *Akses Ditolak!*\nFitur tingkat tinggi ini hanya dapat diakses oleh Developer (Pstar7).");
    }

    await m.react("⏳").catch(() => {});

    let users = global.db.users;
    let ghostCount = 0;
    let totalAwal = Object.keys(users).length;

    // 🔍 Memindai seluruh data di dalam database users
    for (let jid in users) {
        // Syarat Data Sampah: Jika ID tidak berakhiran @s.whatsapp.net (Bukan nomor pribadi / manusia asli)
        if (!jid.endsWith('@s.whatsapp.net')) {
            delete users[jid]; // 💥 Eksekusi pemusnahan data
            ghostCount++;
        }
        // Opsi Tambahan: Jika ingin menghapus user asli yang saldonya 0 dan limitnya 0 (Bisa diaktifkan jika perlu)
        // else if (users[jid].balance === 0 && users[jid].limit === 0 && !users[jid].registered) {
        //     delete users[jid];
        //     ghostCount++;
        // }
    }

    let totalAkhir = Object.keys(users).length;

    // 🎨 RAKIT UI VVIP REPORT
    let teks = `╭───┈ *「 🧹 DATABASE CLEANER 」*\n`;
    teks += `│ 🛡️ *Status:* Pembersihan Selesai\n`;
    teks += `╰───────────────┈ ⳹\n\n`;

    if (ghostCount === 0) {
        teks += `_Database sudah sangat bersih! Tidak ada akun hantu atau data sampah yang ditemukan._ ✨\n\n`;
        teks += `📊 *Total Pengguna Aktif:* ${totalAkhir} User`;
    } else {
        teks += `✅ Berhasil memusnahkan *${ghostCount} Data Sampah* (Akun Hantu/Grup/Log) dari sistem!\n\n`;
        teks += `📉 *Data Awal:* ${totalAwal}\n`;
        teks += `📈 *Data Bersih:* ${totalAkhir}\n\n`;
        teks += `_Sistem Leaderboard dan Dompet sekarang 100% presisi, server makin ngebut!_ 🚀`;
    }

    await m.react("✅").catch(() => {});
    
    // Kirim laporan menggunakan UI Premium
    return sock.sendMessage(m.chat, { 
        text: teks,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idChannel || "1203631@newsletter",
                newsletterName: "🛡️ Pstar7 Security System",
                serverId: 1
            }
        }
    }, { quoted: m });
}

handler.command = ["cleandb", "bersihdb", "hapussampah", "cleardb"];
handler.tags = ["owner"];
handler.help = ["cleandb"];
handler.owner = true; // Pastikan hanya owner yang bisa akses dari sistem core

module.exports = handler;
