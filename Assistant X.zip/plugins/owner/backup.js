const fs = require("fs")
const archiver = require("archiver")
const path = require("path")

let handler = async (m, { sock, command, prefix }) => {

  // ==========================================
  // 💾 1. BACKUP DATABASE RPG (XENORIA DB)
  // ==========================================
  if (command === "backupdb" || command === "tarikdb") {
      let dbPath = './database/database.json'; 

      if (!fs.existsSync(dbPath)) return m.reply(`❌ *GAWAT!* File database tidak ditemukan di server!`);

      await m.reply(`⏳ Mengkompresi dunia Xenoria... Mempersiapkan file backup database...`);

      try {
          let time = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
          
          let captionText = `╭───┈ *「 📦 MANUAL DB BACKUP 」*\n`;
          captionText += `│ ⏰ *Ditarik Pada:* ${time}\n`;
          captionText += `│ 💾 *Ukuran:* ${(fs.statSync(dbPath).size / 1024).toFixed(2)} KB\n`;
          captionText += `╰───────────────┈ ⳹\n\n`;
          captionText += `_Backup database berhasil dieksekusi bosku!_ 🛡️`;

          await sock.sendMessage(m.chat, {
              document: fs.readFileSync(dbPath),
              mimetype: 'application/json',
              fileName: `Xenoria_DB_Backup.json`,
              caption: captionText
          }, { quoted: m });

          return; // Berhenti di sini biar gak ngejalanin backup script di bawah
      } catch (error) {
          console.error("Backup DB Error:", error);
          return m.reply(`❌ *ERROR!* Gagal mengirim file backup database.`);
      }
  }

  // ==========================================
  // 📂 2. BACKUP SELURUH SCRIPT BOT (ZIP)
  // ==========================================
  try {
    await m.reply("📦 Backup Script Bot sedang diproses, Tunggu sebentar...")

    // Format tanggal dd-mm-yy
    const today = new Date()
    const dd = String(today.getDate()).padStart(2, "0")
    const mm = String(today.getMonth() + 1).padStart(2, "0")
    const yy = String(today.getFullYear()).slice(-2)
    const date = `${dd}-${mm}-${yy}`

    // Nama bot + tanggal
    const baseName = global.botname ? (global.botname.includes(" ") ? global.botname.split(" ").join("-") : global.botname) : "AssistantX";

    const name = `${baseName}-${date}.zip`

    const output = fs.createWriteStream(name)
    const archive = archiver("zip", { zlib: { level: 9 } })

    const exclude = [
      "node_modules",
      "session",
      "package-lock.json",
      "yarn.lock",
      ".npm",
      ".cache"
    ]

    archive.pipe(output)

    const addDir = (dir) => {
      const files = fs.readdirSync(dir)
      for (let file of files) {
        const fullPath = path.join(dir, file)

        if (exclude.some(e => fullPath.includes(e))) continue

        if (fs.statSync(fullPath).isDirectory()) {
          addDir(fullPath)
        } else {
          archive.file(fullPath, { name: fullPath })
        }
      }
    }

    addDir(".")

    await archive.finalize()

    output.on("close", async () => {
      await sock.sendMessage(m.sender, {
        document: fs.readFileSync(name),
        fileName: name,
        mimetype: "application/zip",
        caption: "✅ *BACKUP SCRIPT SELESAI*\nSilakan simpan file .zip ini di tempat yang aman bosku!"
      }, { quoted: m })

      fs.unlinkSync(name)

      if (m.chat !== m.sender) {
        m.reply("📂 File Backup Script Bot berhasil dikirim ke Private Chat Bosku.")
      }
    })

  } catch (err) {
    console.error("Backup SC Error:", err)
    m.reply("❌ Terjadi kesalahan saat melakukan backup script.")
  }
}

handler.command = ["backupsc", "backup", "bck", "backupdb", "tarikdb"]
handler.tags = ["owner"]
handler.help = ["backup", "backupdb"]
handler.owner = true

module.exports = handler
