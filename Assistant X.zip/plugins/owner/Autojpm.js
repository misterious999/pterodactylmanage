// ==========================================
// 🌸 AUTO JPM (PROMOSI OTOMATIS)
// Support: Teks, Tombol, Image, Custom Interval & Target (Grup/Custom Channel)
// Anti-Overlap, Strict Targeting & Channel Format Bypass Included
// ==========================================

const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
let isBroadcasting = false; 

// ⚙️ MESIN EKSEKUTOR BACKGROUND
async function executeJPM(sock, setting, m) {
    if (isBroadcasting) return; 
    isBroadcasting = true;
    
    try {
        let targets = [];
        
        // PERBAIKAN MUTLAK: Jaring Pengaman (Safety Fallback) agar tidak crash jika db.chats kosong/berbeda struktur
        let chatsData = global.db?.data?.chats || global.db?.chats || {};
        let allChats = Object.entries(chatsData);

        // STRUKTUR FILTER MUTLAK (STRICT SWITCH-CASE)
        switch (setting.target) {
            case 'channel':
                if (setting.customChannels && setting.customChannels.length > 0) {
                    targets.push(...setting.customChannels);
                } else {
                    targets.push(...allChats.filter(([jid, chat]) => jid.endsWith('@newsletter') && !chat?.isBanned).map(v => v[0]));
                }
                break;
                
            case 'grup':
                targets.push(...allChats.filter(([jid, chat]) => jid.endsWith('@g.us') && !chat?.isBanned).map(v => v[0]));
                break;
                
            case 'all':
                targets.push(...allChats.filter(([jid, chat]) => jid.endsWith('@g.us') && !chat?.isBanned).map(v => v[0]));
                if (setting.customChannels && setting.customChannels.length > 0) {
                    targets.push(...setting.customChannels);
                } else {
                    targets.push(...allChats.filter(([jid, chat]) => jid.endsWith('@newsletter') && !chat?.isBanned).map(v => v[0]));
                }
                break;
        }

        // Hapus duplikat ID jika ada
        targets = [...new Set(targets)];

        if (targets.length === 0) {
            if (m) m.reply(`⚠️ Gagal mengeksekusi! Tidak ada satupun ID ${setting.target.toUpperCase()} yang ditemukan di database bot.`);
            return;
        }

        // Laporan Eksekusi Langsung ke Owner
        if (m) m.reply(`🚀 Memulai penyebaran promosi ke *${targets.length} Target (${setting.target.toUpperCase()})* secara bertahap di latar belakang...`);

        // Proses Broadcast dengan Delay 30 Detik
        for (let jid of targets) {
            try {
                let isChannel = jid.endsWith('@newsletter');
                
                if (setting.buttons && setting.buttons.length > 0 && !isChannel) {
                    let buttons = setting.buttons.map((btn, index) => ({
                        buttonId: `btn_jpm_${index}`,
                        buttonText: { displayText: btn },
                        type: 1
                    }));

                    let buttonMessage = {
                        text: setting.text,
                        footer: "📢 Auto Broadcast",
                        buttons: buttons,
                        headerType: 1
                    };

                    if (setting.image) {
                        buttonMessage.image = Buffer.from(setting.image, 'base64');
                        buttonMessage.headerType = 4;
                    }

                    await sock.sendMessage(jid, buttonMessage);
                } else {
                    let textMessage = { text: setting.text };
                    if (setting.image) {
                        textMessage = { image: Buffer.from(setting.image, 'base64'), caption: setting.text };
                    }
                    await sock.sendMessage(jid, textMessage);
                }
                
                await delay(30000); 
                
            } catch (e) {
                console.error(`[SYSTEM] Gagal mengirim JPM ke target ${jid}`);
            }
        }
    } finally {
        isBroadcasting = false;
        setting.last = Date.now(); 
    }
}

let handler = async (m, { sock, text, command, prefix }) => {
    if (!global.db.settings) global.db.settings = {};
    if (!global.db.settings.autojpm) {
        global.db.settings.autojpm = {
            status: false,
            text: "",
            buttons: [], 
            image: null,
            interval: 60000,
            last: 0,
            target: 'grup',
            customChannels: [] 
        };
    }

    const setting = global.db.settings.autojpm;
    if (!setting.target) setting.target = 'grup'; 
    if (!setting.customChannels) setting.customChannels = []; 

    function parseTime(input) {
        let match = input.match(/^(\d+)([mjh])$/);
        if (!match) return null;

        let value = Number(match[1]);
        let type = match[2];

        switch (type) {
            case "m": return value * 60 * 1000;      
            case "j": return value * 60 * 60 * 1000; 
            case "h": return value * 24 * 60 * 60 * 1000; 
            default: return null;
        }
    }

    if (command === "autojpm") {
        if (!text) {
            let msg = `🎀 *KONTROL AUTO JPM* 🎀\n\n`;
            msg += `▶️ *${prefix}autojpm on* (Menyalakan)\n`;
            msg += `⏹️ *${prefix}autojpm off* (Mematikan)\n\n`;
            msg += `🎯 *SETTING TARGET PROMOSI:*\n`;
            msg += `◦ *${prefix}autojpm target grup* (Grup Saja)\n`;
            msg += `◦ *${prefix}autojpm target channel* (Saluran Saja)\n`;
            msg += `◦ *${prefix}autojpm target all* (Grup & Saluran)\n\n`;
            msg += `📡 *CUSTOM SALURAN (CHANNEL):*\n`;
            msg += `◦ *${prefix}autojpm getid* (Reply chat dari saluran)\n`;
            msg += `◦ *${prefix}autojpm addchannel <ID>*\n`;
            msg += `◦ *${prefix}autojpm delchannel <ID>*\n`;
            msg += `◦ *${prefix}autojpm clearchannel*\n`;
            msg += `◦ *${prefix}autojpm listchannel*\n\n`;
            msg += `_Status: ${setting.status ? '✅ ON' : '❌ OFF'}_\n`;
            msg += `_Target: ${setting.target.toUpperCase()}_\n`;
            msg += `_Total Saluran Custom: ${setting.customChannels.length}_`;
            return m.reply(msg);
        }

        let input = text.toLowerCase().trim();
        let args = text.trim().split(" ");

        if (input === "on") {
            // Validasi darurat jika target belum diset
            if (!['grup', 'channel', 'all'].includes(setting.target)) setting.target = 'grup';

            setting.status = true;
            setting.last = 0; 
            
            // Langsung eksekusi dengan melampirkan context 'm' agar notifikasinya muncul
            executeJPM(sock, setting, m).catch(console.error);
            
        } else if (input === "off") {
            setting.status = false;
            m.reply("❌ AutoJPM dimatikan. Mini istirahat dulu yaa.");
        } else if (input.startsWith("target")) {
            let t = args[1];
            if (['grup', 'channel', 'all'].includes(t)) {
                setting.target = t;
                m.reply(`✅ Target AutoJPM berhasil dikunci ke: *${t.toUpperCase()}*`);
            } else {
                m.reply(`❌ Pilihan target tidak valid!\nKetik: *${prefix}autojpm target grup/channel/all*`);
            }
        } else if (input === "getid") {
            let contextInfo = m.quoted?.contextInfo || m.msg?.contextInfo || m.message?.extendedTextMessage?.contextInfo;
            let fwdInfo = contextInfo?.forwardedNewsletterMessageInfo;
            
            if (fwdInfo) {
                let id = fwdInfo.newsletterJid;
                let name = fwdInfo.newsletterName;
                return m.reply(`✅ *ID SALURAN DITEMUKAN!*\n\n📝 Nama: ${name}\n🆔 ID: ${id}\n\nKetik *${prefix}autojpm addchannel ${id}* untuk mendaftarkannya.`);
            } else {
                return m.reply("❌ Reply pesan yang diforward (diteruskan) dari Saluran WhatsApp dulu ya, biar Mini bisa ekstrak ID-nya!");
            }
        } else if (input.startsWith("addchannel")) {
            let id = args[1];
            if (!id) return m.reply(`❌ Masukkan ID-nya!\nContoh: *${prefix}autojpm addchannel 12345@newsletter*`);
            if (!id.endsWith("@newsletter")) id += "@newsletter";
            
            if (!setting.customChannels.includes(id)) {
                setting.customChannels.push(id);
                m.reply(`✅ Saluran ${id} berhasil ditambahkan! Mini akan memprioritaskan promosi ke daftar ini.`);
            } else {
                m.reply("⚠️ Saluran ini sudah ada di dalam daftar.");
            }
        } else if (input.startsWith("delchannel")) {
            let id = args[1];
            if (!id) return m.reply(`❌ Masukkan ID-nya!\nContoh: *${prefix}autojpm delchannel 12345@newsletter*`);
            if (!id.endsWith("@newsletter")) id += "@newsletter";
            
            let idx = setting.customChannels.indexOf(id);
            if (idx !== -1) {
                setting.customChannels.splice(idx, 1);
                m.reply(`✅ Saluran ${id} berhasil dihapus dari daftar target!`);
            } else {
                m.reply("⚠️ Saluran tersebut tidak ditemukan di dalam daftar.");
            }
        } else if (input === "clearchannel") {
            setting.customChannels = [];
            m.reply("✅ Semua Saluran Custom berhasil dihapus. AutoJPM akan kembali mempromosikan ke *Semua Saluran*.");
        } else if (input === "listchannel") {
            if (setting.customChannels.length === 0) return m.reply("📂 Daftar Saluran Custom masih kosong.");
            let list = setting.customChannels.map((v, i) => `${i + 1}. ${v}`).join("\n");
            m.reply(`📂 *DAFTAR SALURAN CUSTOM*\n\n${list}`);
        }
    }

    if (command === "setjpm") {
        if (!text) {
            let usage = `🎀 *PANDUAN SET AUTO JPM* 🎀\n\n`;
            usage += `Gunakan simbol | untuk memisahkan bagian.\n\n`;
            usage += `📝 *Teks Saja:*\n${prefix}setjpm Halo semua, diskon hari ini!|1j\n\n`;
            usage += `🔘 *Teks + Tombol (Pisahkan tombol dgn koma):*\n${prefix}setjpm Halo semua diskon nih|Beli,Katalog|2j\n\n`;
            usage += `Keterangan Waktu:\nm = Menit, j = Jam, h = Hari\n\n`;
            usage += `_Kirim perintah ini sambil membalas (reply) gambar jika ingin memakai foto._`;
            return m.reply(usage);
        }

        let parts = text.split("|");
        if (parts.length < 2) return m.reply(`Formatnya kurang tepat sayang~ Cek panduan pakai *${prefix}setjpm* ya!`);

        let teks, buttonsRaw, intervalRaw;
        
        if (parts.length === 2) {
            teks = parts[0];
            buttonsRaw = "";
            intervalRaw = parts[1];
        } else {
            teks = parts[0];
            buttonsRaw = parts[1];
            intervalRaw = parts[2];
        }

        let interval = parseTime(intervalRaw.trim());
        if (!interval) return m.reply("Format waktu salah nih! Pake 1m (menit), 1j (jam), atau 1h (hari) yaa.");

        setting.text = teks.trim();
        setting.interval = interval;
        
        if (buttonsRaw) {
            setting.buttons = buttonsRaw.split(",").map(v => v.trim()).filter(v => v !== "");
        } else {
            setting.buttons = [];
        }

        if (m.quoted && /image/.test(m.mime)) {
            let media = await m.quoted.download();
            setting.image = media.toString("base64");
        } else {
            setting.image = null;
        }

        setting.last = setting.status ? 0 : Date.now(); 

        let btnMsg = setting.buttons.length > 0 ? `Aktif (${setting.buttons.join(", ")})` : "Tidak ada";
        m.reply(`✅ *AutoJPM Berhasil Disimpan!*\n\n💬 *Teks:* ${setting.text}\n🔘 *Tombol:* ${btnMsg}\n⏱️ *Interval:* ${intervalRaw}\n🎯 *Target:* ${setting.target.toUpperCase()}\n\nJangan lupa ketik *${prefix}autojpm on* buat menjalankannya yaa! 💕`);
    }
}

handler.before = async (m, { sock }) => {
    const setting = global.db.settings?.autojpm;
    if (!setting || !setting.status) return; 

    if (Date.now() - setting.last < setting.interval) return;
    
    executeJPM(sock, setting, null).catch(console.error);
};

handler.tags = ["owner"];
handler.command = ["autojpm", "setjpm"];
handler.owner = true;

module.exports = handler;
