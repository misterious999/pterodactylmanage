// ==========================================
// 🏢 VIP RENT MANAGER (SISTEM SEWA GRUP V3)
// ⚙️ Fix Custom Owner Checker for Axis
// ==========================================

function formatWaktuVIP(ms) {
    let d = new Date(ms);
    let options = { timeZone: 'Asia/Jakarta', day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' };
    return d.toLocaleString('id-ID', options).replace(/\./g, ':') + ' WIB';
}

let handler = async (m, { sock, args, command, prefix, isOwner }) => {
    
    // 🔐 Lapis Pengaman Tambahan (Custom Owner & Developer Check)
    let senderNumber = m.sender.replace(/@s\.whatsapp\.net$/, "");
    
    // Ambil daftar owner dari global.owner (bisa berupa array string/nomor)
    let ownerNumbers = Array.isArray(global.owner)
        ? global.owner.map(num => String(num).replace(/[^0-9]/g, ""))
        : String(global.owner || "").split(/[,\s]+/).map(num => String(num).replace(/[^0-9]/g, "")).filter(Boolean);

    // Tambahkan nomor spesifik atau cek database owner jika ada
    let dbOwners = global.db && global.db.users ? Object.keys(global.db.users).filter(jid => global.db.users[jid].owner) : [];
    let allOwners = [...ownerNumbers, ...dbOwners.map(jid => jid.replace(/[^0-9]/g, ""))];

    // Cek apakah pengirim adalah owner (berdasarkan parameter luar atau cocok dengan list nomor)
    let isReallyOwner = isOwner || allOwners.some(num => senderNumber.includes(num));

    if (!global.db.groups) global.db.groups = {};
    if (m.isGroup && !global.db.groups[m.chat]) global.db.groups[m.chat] = {};

    let sekarang = Date.now();

    // ➕ FITUR 1: MENAMBAHKAN SEWA (.setsewa 30)
    if (['addsewa', 'setsewa'].includes(command)) {
        if (!isReallyOwner) {
            await m.react("🚫").catch(() => {});
            return m.reply("🔒 *Akses Ditolak!*\nHanya Owner yang berhak mengatur masa sewa grup.");
        }
        if (!m.isGroup) {
            await m.react("⚠️").catch(() => {});
            return m.reply("👥 Gunakan perintah ini di dalam Grup yang ingin disewakan!");
        }
        
        // Menangani format input angka (misal: ".setsewa 3h" atau ".setsewa 30")
        let rawArg = args[0] ? args[0].replace(/[^0-9]/g, "") : "";
        if (!rawArg || isNaN(rawArg)) {
            await m.react("❓").catch(() => {});
            return m.reply(`❌ *Format Salah Bosku!*\nKamu belum memasukkan jumlah hari dengan benar.\n\nContoh ketik: *${prefix + command} 30*`);
        }
        
        let jumlahHari = parseInt(rawArg);
        let masaSewaMs = 86400000 * jumlahHari; 

        if (global.db.groups[m.chat].expired > sekarang) {
            global.db.groups[m.chat].expired += masaSewaMs;
        } else {
            global.db.groups[m.chat].expired = sekarang + masaSewaMs;
        }

        let tglExpired = formatWaktuVIP(global.db.groups[m.chat].expired);
        
        await m.react("✅").catch(() => {});
        return m.reply(`╭───「 *🏢 SEWA DIAKTIFKAN* 」\n│\n│ Bot Assistant X telah resmi\n│ disewakan di grup ini!\n│\n│ ⏳ Tambahan: *${jumlahHari} Hari*\n│ 🗓️ Expired: *${tglExpired}*\n│\n╰───────────────⳹\n\n_Terima kasih telah menyewa layanan VVIP kami! ✨_`);
    }

    // 🗑️ FITUR 2: MENGHAPUS SEWA & KELUAR OTOMATIS
    if (['delsewa'].includes(command)) {
        if (!isReallyOwner) return m.reply("🔒 *Akses Ditolak!*");
        
        let targetJid = m.chat; 

        if (args[0]) {
            let listSewa = [];
            for (let jid in global.db.groups) {
                if (global.db.groups[jid].expired && global.db.groups[jid].expired > sekarang) {
                    listSewa.push(jid); 
                }
            }

            if (!isNaN(args[0])) {
                let index = parseInt(args[0]) - 1; 
                if (index >= 0 && index < listSewa.length) {
                    targetJid = listSewa[index]; 
                } else {
                    return m.reply(`❌ Nomor urut tidak valid! Cek angka yang benar di \`${prefix}listsewa\``);
                }
            } else if (args[0].includes('@g.us')) {
                targetJid = args[0]; 
            }
        } else if (!m.isGroup) {
            return m.reply(`👥 Masukkan nomor urut dari daftar sewa jika kamu berada di Private Chat!\nContoh: \`${prefix}delsewa 1\``);
        }

        if (!global.db.groups[targetJid] || !global.db.groups[targetJid].expired || global.db.groups[targetJid].expired < sekarang) {
            return m.reply("⚠️ Grup tersebut tidak sedang menyewa bot atau masa sewanya sudah habis.");
        }

        global.db.groups[targetJid].expired = 0;
        await m.react("🗑️").catch(() => {});

        let teksPamit = `🛑 *SEWA DIHENTIKAN*\n\nMasa sewa bot di grup ini telah dicabut secara paksa oleh sistem pusat.\n\n_Bot akan keluar otomatis dalam 3 detik..._`;
        try {
            await sock.sendMessage(targetJid, { text: teksPamit });
            await new Promise(resolve => setTimeout(resolve, 3000));
            await sock.groupLeave(targetJid);
        } catch (e) {
            console.log("Bot sudah dikeluarkan dari grup sebelum bisa pamit.");
        }

        if (m.chat !== targetJid) {
            let targetName = "Grup Tidak Diketahui";
            try {
                let meta = await sock.groupMetadata(targetJid);
                targetName = meta.subject;
            } catch (e) {}

            return m.reply(`✅ *EKSEKUSI BERHASIL!*\n\nBot telah menghentikan sewa dan keluar dari grup:\n🏷️ *${targetName}*\n🆔 \`${targetJid}\``);
        }
        return;
    }

    // 📋 FITUR 3: MELIHAT DAFTAR GRUP YANG MENYEWA (.listsewa)
    if (['listsewa'].includes(command)) {
        if (!isReallyOwner) return m.reply("🔒 *Akses Ditolak!*");
        
        let groups = global.db.groups;
        let listSewa = [];

        for (let jid in groups) {
            if (groups[jid].expired && groups[jid].expired > sekarang) {
                listSewa.push({ jid, expired: groups[jid].expired });
            }
        }

        if (listSewa.length === 0) {
            await m.react("🤷‍♂️").catch(() => {});
            return m.reply(`📝 *DAFTAR SEWA KOSONG*\n\nBelum ada grup yang menyewa bot saat ini. Waktunya promosi Bosku! 🚀`);
        }

        await m.react("⏳").catch(() => {}); 
        
        let teks = `╭───「 *📋 DAFTAR GRUP SEWA* 」\n│\n`;
        for (let i = 0; i < listSewa.length; i++) {
            let sisaHari = Math.ceil((listSewa[i].expired - sekarang) / 86400000);
            let tglExpired = formatWaktuVIP(listSewa[i].expired);
            
            let namaGrup = "Grup Invalid / Bot Di-kick";
            try {
                let meta = await sock.groupMetadata(listSewa[i].jid);
                namaGrup = meta.subject; 
            } catch (e) {}
            
            teks += `│ ${i + 1}. 🏷️ *${namaGrup}*\n`;
            teks += `│ 🆔 ID: ${listSewa[i].jid.split('@')[0]}\n`;
            teks += `│ ⏳ Sisa: ${sisaHari} Hari\n`;
            teks += `│ 🗓️ ${tglExpired}\n`;
            teks += `│\n`;
        }
        teks += `╰───────────────⳹\n\n_Total: ${listSewa.length} Grup Pelanggan VIP_`;
        
        await m.react("📋").catch(() => {});
        return m.reply(teks);
    }

    // 🔍 FITUR BONUS: CEK SISA SEWA UNTUK MEMBER GRUP (.ceksewa)
    if (['ceksewa'].includes(command)) {
        if (!m.isGroup) return m.reply("👥 Perintah ini hanya untuk di dalam Grup!");
        
        let expired = global.db.groups[m.chat]?.expired || 0;

        if (expired < sekarang) {
            await m.react("⚠️").catch(() => {});
            return m.reply(`⚠️ *STATUS: TIDAK MENYEWA*\n\nGrup ini menggunakan bot secara gratis/trial atau masa sewanya telah habis.`);
        } else {
            let sisaHari = Math.ceil((expired - sekarang) / 86400000);
            let tglExpired = formatWaktuVIP(expired);
            
            await m.react("💎").catch(() => {});
            return m.reply(`╭───「 *💎 STATUS SEWA GRUP* 」\n│\n│ Bot Assistant X terikat\n│ kontrak VVIP di grup ini!\n│\n│ ⏳ Sisa Waktu: *${sisaHari} Hari lagi*\n│ 🗓️ Expired: *${tglExpired}*\n│\n╰───────────────⳹`);
        }
    }
};

handler.command = ['addsewa', 'setsewa', 'delsewa', 'listsewa', 'ceksewa'];
handler.tags = ['owner'];
handler.help = ['addsewa <hari>', 'delsewa', 'listsewa', 'ceksewa'];

module.exports = handler;
