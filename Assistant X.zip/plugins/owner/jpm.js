const {
    generateWAMessageFromContent,
    prepareWAMessageMedia,
    proto
} = require("@whiskeysockets/baileys");

// 🔥 CONFIGURATION: Delay 20 detik per grup & Kunci Mutex JPM
const JPM_DELAY = 20 * 1000; 
global.isJpmRunning = global.isJpmRunning || false;

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function ensureJpmDatabase() {
    if (!global.db) global.db = {};
    if (!global.db.settings) global.db.settings = {};
    if (!Array.isArray(global.db.settings.bljpm)) {
        global.db.settings.bljpm = [];
    }
}

function isBlacklisted(groupId) {
    ensureJpmDatabase();
    return global.db.settings.bljpm.some(group => group.id === groupId);
}

function formatDuration(ms) {
    const seconds = Math.ceil(ms / 1000);

    if (seconds < 60) return `${seconds} detik`;

    const minutes = Math.floor(seconds / 60);
    const rest = seconds % 60;

    if (rest === 0) return `${minutes} menit`;

    return `${minutes} menit ${rest} detik`;
}

async function getTargetGroups(sock) {
    const allGroups = await sock.groupFetchAllParticipating();

    return Object.values(allGroups)
        .filter(group => {
            if (!group || !group.id) return false;
            if (group.isCommunity) return false;
            if (group.isCommunityAnnounce) return false;
            if (group.announce) return false;
            if (isBlacklisted(group.id)) return false;

            return true;
        })
        .map(group => ({
            id: group.id,
            subject: group.subject || "Tanpa Nama"
        }));
}

async function getAllNormalGroups(sock) {
    const allGroups = await sock.groupFetchAllParticipating();

    return Object.values(allGroups)
        .filter(group => {
            if (!group || !group.id) return false;
            if (group.isCommunity) return false;
            if (group.isCommunityAnnounce) return false;

            return true;
        })
        .map(group => ({
            id: group.id,
            subject: group.subject || "Tanpa Nama",
            announce: !!group.announce
        }));
}

function pickFirstText(...values) {
    for (const value of values) {
        if (typeof value === "string" && value.trim()) return value.trim();
    }
    return "";
}

function getWebMessageInfo(quoted) {
    if (!quoted) return null;
    if (quoted.fakeObj && quoted.fakeObj.message) return quoted.fakeObj;
    if (quoted.message) return quoted;
    return null;
}

function getMessageContentObject(quoted) {
    const webMsg = getWebMessageInfo(quoted);
    return webMsg?.message || quoted?.message || null;
}

function extractTextFromMessageObject(message) {
    if (!message) return "";

    return pickFirstText(
        message.conversation,
        message.extendedTextMessage?.text,
        message.imageMessage?.caption,
        message.videoMessage?.caption,
        message.documentMessage?.caption,
        message.buttonsResponseMessage?.selectedDisplayText,
        message.listResponseMessage?.title,
        message.templateButtonReplyMessage?.selectedDisplayText
    );
}

function extractQuotedText(quoted) {
    if (!quoted) return "";

    return pickFirstText(
        quoted.text,
        quoted.caption,
        quoted.body,
        quoted.message?.conversation,
        quoted.message?.extendedTextMessage?.text,
        quoted.msg?.text,
        quoted.msg?.caption,
        extractTextFromMessageObject(getMessageContentObject(quoted))
    );
}

function detectQuotedType(quoted) {
    if (!quoted) return "";
    return quoted.mtype || quoted.type || quoted.mediaType || "";
}

async function downloadQuotedMedia(quoted) {
    if (!quoted) return null;

    if (typeof quoted.download === "function") {
        return quoted.download();
    }

    if (quoted.msg && typeof quoted.msg.download === "function") {
        return quoted.msg.download();
    }

    return null;
}

function normalizeUrl(url = "") {
    const clean = String(url || "").trim();

    if (!clean) return "";
    if (/^https?:\/\//i.test(clean)) return clean;

    return `https://${clean}`;
}

function normalizeOwnerNumber() {
    let owner = global.owner || global.ownerNumber || process.env.OWNER_NUMBER || "";

    if (Array.isArray(owner)) {
        owner = owner[0] || "";
    }

    owner = String(owner)
        .split(/[,\s|]+/)[0]
        .replace(/@s\.whatsapp\.net/gi, "")
        .replace(/[^0-9]/g, "")
        .trim();

    if (owner.startsWith("0")) {
        owner = `62${owner.slice(1)}`;
    }

    return owner;
}

function makeWaMeUrl(number) {
    const message = "hallo, aku ingin menanyakan perihal script Asssistant X yang mimin jual";
    return `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
}

function getScHeaderImage() {
    return (
        global.scHeaderImage ||
        process.env.SC_HEADER_IMAGE ||
        global.thumbnail ||
        global.logo ||
        ""
    );
}

function makeScPromoText(ownerNumber) {
    return `*SCRIPT ASSISTANT X*
Bot WhatsApp modern, ringan, dan siap pakai untuk kebutuhan pribadi, komunitas, promosi, hingga sewa bot grup.

*Kenapa pilih Assistant X?*
✨ Menu rapi dan interaktif
📥 Downloader multi-platform
🧠 Fitur AI untuk kebutuhan kreatif
🏢 Manajemen grup lebih fleksibel
📢 JPM/Broadcast lebih terkontrol
🤝 Cocok untuk sewa bot di grup
🛠️ Struktur plugin mudah dikembangkan

*Paket Harga*
📦 Script Tanpa Update
Harga: *Rp 35.000*

🚀 Script Full Update
Harga: *Rp 50.000*

🧾 Tambah Nomor Database
Harga: *Rp 20.000 / nomor*
Khusus pembeli script atau reseller.

*Catatan*
Tambah nomor database hanya untuk user yang sudah membeli script.

Punya bot WhatsApp sendiri tidak perlu ribet. Tinggal pakai, jalankan, dan kembangkan sesuai kebutuhan.

Klik tombol di bawah untuk konsultasi atau membeli.

Owner: wa.me/${ownerNumber}`;
}

function createUrlButtonPayload(text, buttonText, url, imageUrl = "") {
    return {
        mode: "interactive_url",
        text,
        buttonText,
        url: normalizeUrl(url),
        imageUrl
    };
}

function parseButtonBroadcastInput(m, input) {
    const raw = String(input || "").trim();
    const quotedText = extractQuotedText(m.quoted);

    if (raw.includes("|")) {
        const parts = raw.split("|").map(v => v.trim());

        if (parts.length >= 3) {
            const text = parts[0];
            const buttonText = parts[1];
            const url = parts.slice(2).join("|").trim();

            return { text, buttonText, url };
        }

        if (parts.length >= 2 && quotedText) {
            const buttonText = parts[0];
            const url = parts.slice(1).join("|").trim();

            return {
                text: quotedText,
                buttonText,
                url
            };
        }
    }

    throw new Error("Format tombol tidak valid.");
}

async function createBroadcastPayload(m, input) {
    if (input) {
        return {
            mode: "content",
            content: { text: input }
        };
    }

    const quoted = m.quoted;
    if (!quoted) {
        throw new Error("Pesan JPM kosong. Ketik .jpm teks atau reply pesan yang ingin dibroadcast.");
    }

    const quotedText = extractQuotedText(quoted);
    const mime = quoted.mimetype || quoted.msg?.mimetype || "";
    const qType = detectQuotedType(quoted);
    const webMsg = getWebMessageInfo(quoted);

    if (quotedText && !mime) {
        return {
            mode: "content",
            content: { text: quotedText }
        };
    }

    if (mime || /image|video|audio|sticker|document/i.test(qType)) {
        const mediaBuffer = await downloadQuotedMedia(quoted);

        if (!mediaBuffer) {
            throw new Error("Media reply tidak bisa diunduh. Coba kirim ulang media tersebut, lalu reply .jpm.");
        }

        const caption = quotedText || quoted.caption || "";
        const fileName = quoted.fileName || quoted.msg?.fileName || "file";

        if (/image/i.test(mime) || qType === "imageMessage") {
            return {
                mode: "content",
                content: { image: mediaBuffer, caption }
            };
        }

        if (/video/i.test(mime) || qType === "videoMessage") {
            return {
                mode: "content",
                content: { video: mediaBuffer, caption, mimetype: mime || "video/mp4" }
            };
        }

        if (/audio/i.test(mime) || qType === "audioMessage") {
            return {
                mode: "content",
                content: { audio: mediaBuffer, mimetype: mime || "audio/mpeg", ptt: !!quoted.ptt }
            };
        }

        if (/webp/i.test(mime) || qType === "stickerMessage") {
            return {
                mode: "content",
                content: { sticker: mediaBuffer }
            };
        }

        return {
            mode: "content",
            content: {
                document: mediaBuffer,
                mimetype: mime || "application/octet-stream",
                fileName,
                caption
            }
        };
    }

    if (webMsg?.message && Object.keys(webMsg.message).length) {
        return {
            mode: "forward",
            message: webMsg
        };
    }

    throw new Error("Tidak ada konten valid untuk dikirim. Gunakan .jpm teks atau reply pesan teks/media biasa.");
}

async function prepareHeaderImage(sock, imageUrl) {
    if (!imageUrl) return null;

    try {
        const media = await prepareWAMessageMedia(
            { image: { url: imageUrl } },
            { upload: sock.waUploadToServer }
        );

        return media.imageMessage || null;
    } catch (error) {
        console.error("[JPM HEADER IMAGE ERROR]", error.message || error);
        return null;
    }
}

async function sendInteractiveUrlButton(sock, jid, payload) {
    const buttons = [
        {
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
                display_text: payload.buttonText,
                url: payload.url,
                merchant_url: payload.url
            })
        }
    ];

    const imageMessage = await prepareHeaderImage(sock, payload.imageUrl);

    const msg = generateWAMessageFromContent(jid, {
        viewOnceMessage: {
            message: {
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    header: proto.Message.InteractiveMessage.Header.create({
                        title: "",
                        hasMediaAttachment: !!imageMessage,
                        ...(imageMessage ? { imageMessage } : {})
                    }),
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: payload.text
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: `© ${global.botname || "Assistant X Project"}`
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons
                    }),
                    contextInfo: {
                        forwardingScore: 999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: global.idChannelDaftar || global.idChannel || "1203631@newsletter",
                            newsletterName: "Assistant X Project",
                            serverId: 1
                        }
                    }
                })
            }
        }
    }, {});

    return sock.relayMessage(jid, msg.message, {
        messageId: msg.key.id
    });
}

async function sendBroadcast(sock, jid, payload) {
    if (!payload) throw new Error("Payload broadcast kosong.");

    if (payload.mode === "content") {
        if (!payload.content || !Object.keys(payload.content).length) {
            throw new Error("Konten broadcast kosong.");
        }

        return sock.sendMessage(jid, payload.content);
    }

    if (payload.mode === "interactive_url") {
        try {
            return await sendInteractiveUrlButton(sock, jid, payload);
        } catch (error) {
            console.error("[JPM BUTTON FAILED]", error);

            return sock.sendMessage(jid, {
                text: `${payload.text}\n\n${payload.buttonText}:\n${payload.url}`
            });
        }
    }

    if (payload.mode === "forward") {
        if (typeof sock.copyNForward === "function") {
            return sock.copyNForward(jid, payload.message, true);
        }

        return sock.sendMessage(jid, {
            forward: payload.message,
            force: true
        });
    }

    throw new Error("Mode broadcast tidak dikenal.");
}

async function sendListButton(sock, m, text, title, rows) {
    if (!rows.length) {
        return m.reply("❌ Tidak ada data yang bisa ditampilkan.");
    }

    return sock.sendMessage(m.chat, {
        text,
        viewOnce: true,
        buttons: [
            {
                buttonId: "select_gc",
                buttonText: {
                    displayText: "Pilih Grup"
                },
                type: 4,
                nativeFlowInfo: {
                    name: "single_select",
                    paramsJson: JSON.stringify({
                        title,
                        sections: [
                            {
                                title: "Daftar Grup",
                                rows
                            }
                        ]
                    })
                }
            }
        ]
    }, {
        quoted: m
    });
}

// ==================== CORE BROADCAST RUNNER ====================
async function runJpmBroadcast(sock, m, payload, options = {}) {
    // 🔥 Proteksi Loop: Blokir eksekusi ganda
    if (global.isJpmRunning) {
        return m.reply("⚠️ *Tunggu sebentar!* JPM sebelumnya masih berjalan. Jangan gunakan perintah secara beruntun.");
    }

    global.isJpmRunning = true; // Kunci sistem JPM

    const titleStart = options.titleStart || "🚀 JPM DIMULAI";
    const titleDone = options.titleDone || "✅ JPM SELESAI";

    await m.react("⏳").catch(() => {});

    let allGroups = [];
    let targetGroups = [];

    try {
        allGroups = await getAllNormalGroups(sock);
        targetGroups = await getTargetGroups(sock);
    } catch (error) {
        console.error("[JPM FETCH GROUP ERROR]", error);
        global.isJpmRunning = false; // Buka kunci jika gagal fetch group
        await m.react("❌").catch(() => {});

        return m.reply(`❌ Gagal mengambil daftar grup.\n\nDetail:\n${error.message || error}`);
    }

    const totalGroups = allGroups.length;
    const blacklistCount = allGroups.filter(group => isBlacklisted(group.id)).length;
    const adminOnlyCount = allGroups.filter(group => group.announce && !isBlacklisted(group.id)).length;
    const targetCount = targetGroups.length;
    const estimatedTime = targetCount > 0
        ? formatDuration((targetCount - 1) * JPM_DELAY)
        : "0 detik";

    if (!targetCount) {
        global.isJpmRunning = false; // Buka kunci
        await m.react("❌").catch(() => {});
        return m.reply(`❌ Tidak ada grup target.\n\nTotal Grup: ${totalGroups}\nBlacklist: ${blacklistCount}\nAdmin Only: ${adminOnlyCount}\nTarget Kirim: 0`);
    }

    await m.reply(`╭──「 *${titleStart}* 」
│ 📦 Total Grup: ${totalGroups}
│ 🎯 Target Kirim: ${targetCount}
│ 🚫 Blacklist: ${blacklistCount}
│ 🔒 Admin Only Dilewati: ${adminOnlyCount}
│ ⏱️ Delay: 20 detik / grup
│ 🕒 Estimasi: ${estimatedTime}
╰────────────

_Broadcast berjalan. Jangan restart bot sebelum selesai._`);

    let success = 0;
    let fail = 0;
    const failedGroups = [];

    try {
        for (let i = 0; i < targetGroups.length; i++) {
            const group = targetGroups[i];
            const current = i + 1;

            try {
                await sendBroadcast(sock, group.id, payload);
                success++;

                console.log(`[JPM SUCCESS] ${current}/${targetCount} => ${group.subject} (${group.id})`);
            } catch (error) {
                fail++;

                failedGroups.push({
                    id: group.id,
                    subject: group.subject,
                    error: error.message || String(error)
                });

                console.error(`[JPM FAILED] ${group.subject} (${group.id})`, error);
            }

            if (current < targetCount) {
                await sleep(JPM_DELAY); // Delay aman 20 detik
            }
        }

        let resultText = `╭──「 *${titleDone}* 」
│ 📦 Total Grup: ${totalGroups}
│ 🎯 Target Kirim: ${targetCount}
│ ✅ Berhasil: ${success}
│ ❌ Gagal: ${fail}
│ 🚫 Blacklist: ${blacklistCount}
│ 🔒 Admin Only Dilewati: ${adminOnlyCount}
│ ⏱️ Delay: 20 detik / grup
╰────────────`;

        if (failedGroups.length) {
            resultText += `\n\n*Grup gagal:*\n`;

            failedGroups.slice(0, 10).forEach((group, index) => {
                resultText += `${index + 1}. ${group.subject}\n   _${group.error}_\n`;
            });

            if (failedGroups.length > 10) {
                resultText += `...dan ${failedGroups.length - 10} grup lainnya.`;
            }
        }

        await m.react("✅").catch(() => {});
        await m.reply(resultText);

    } catch (e) {
        console.error("[JPM INTERNAL PROCESS ERROR]", e);
    } finally {
        // 🔥 MUTEX RELEASE: Kunci wajib dibuka di akhir
        global.isJpmRunning = false;
        console.log("🔓 JPM Selesai. Pengunci global dibuka kembali.");
    }
}

// ==================== COMMAND HANDLER ====================
let handler = async (m, { sock, text, args, command, prefix }) => {
    ensureJpmDatabase();

    const cmd = String(command || "").toLowerCase();
    const usedPrefix = prefix || ".";
    const input = String(text || (args || []).join(" ") || "").trim();

    switch (cmd) {
        case "jpm":
        case "jasher":
        case "jaser": {
            let payload;

            try {
                payload = await createBroadcastPayload(m, input);
            } catch (error) {
                return m.reply(`❌ *Pesan broadcast tidak valid.*\n\nGunakan salah satu format:\n\n1. ${usedPrefix}${cmd} teks broadcast\n2. Reply pesan teks/media lalu ketik ${usedPrefix}${cmd}\n\nDetail:\n${error.message || error}`);
            }

            return runJpmBroadcast(sock, m, payload, {
                titleStart: "🚀 JPM DIMULAI",
                titleDone: "✅ JPM SELESAI"
            });
        }

        case "jpmbutton":
        case "jpmtombol": {
            let parsed;

            try {
                parsed = parseButtonBroadcastInput(m, input);
            } catch (error) {
                return m.reply(`❌ *Format JPM tombol salah.*\n\nFormat 1:\n${usedPrefix}${cmd} teks promosi | Nama Tombol | https://linktujuan.com\n\nFormat 2:\nReply teks promosi lalu:\n${usedPrefix}${cmd} Nama Tombol | https://linktujuan.com\n\nContoh:\n${usedPrefix}${cmd} Promo Script Assistant X | 🛒 Beli Sekarang | https://wa.me/628xxxx\n\nDetail:\n${error.message || error}`);
            }

            if (!parsed.text || parsed.text.length < 3) {
                return m.reply("❌ Teks broadcast tidak boleh kosong.");
            }

            if (!parsed.buttonText || parsed.buttonText.length < 2) {
                return m.reply("❌ Nama tombol tidak boleh kosong.");
            }

            if (!parsed.url || !/^https?:\/\//i.test(normalizeUrl(parsed.url))) {
                return m.reply("❌ URL tombol tidak valid. Gunakan link seperti https://wa.me/628xxx");
            }

            const payload = createUrlButtonPayload(
                parsed.text,
                parsed.buttonText,
                parsed.url,
                getScHeaderImage()
            );

            return runJpmBroadcast(sock, m, payload, {
                titleStart: "🚀 JPM BUTTON DIMULAI",
                titleDone: "✅ JPM BUTTON SELESAI"
            });
        }

        case "jpmsc": {
            const ownerNumber = normalizeOwnerNumber();

            if (!ownerNumber || ownerNumber.length < 8) {
                return m.reply("❌ Nomor owner belum valid. Cek OWNER_NUMBER di config/.env.");
            }

            const url = makeWaMeUrl(ownerNumber);
            const promoText = makeScPromoText(ownerNumber);

            const payload = createUrlButtonPayload(
                promoText,
                "🛒 Tekan Untuk Membeli",
                url,
                getScHeaderImage()
            );

            return runJpmBroadcast(sock, m, payload, {
                titleStart: "🚀 JPM SCRIPT DIMULAI",
                titleDone: "✅ JPM SCRIPT SELESAI"
            });
        }

        case "bljpm": {
            await m.react("⏳").catch(() => {});

            let groups = [];

            try {
                groups = await getAllNormalGroups(sock);
            } catch (error) {
                await m.react("❌").catch(() => {});
                return m.reply(`❌ Gagal mengambil daftar grup.\n\nDetail:\n${error.message || error}`);
            }

            const rows = groups
                .filter(group => !isBlacklisted(group.id))
                .map(group => ({
                    title: group.subject.slice(0, 60),
                    description: group.announce
                        ? "Tambah ke blacklist JPM • Grup admin only"
                        : "Tambah ke blacklist JPM",
                    id: `${usedPrefix}addbljpm ${group.id}`
                }));

            if (!rows.length) {
                await m.react("❌").catch(() => {});
                return m.reply("⚠️ Semua grup sudah masuk blacklist JPM atau tidak ada grup tersedia.");
            }

            await m.react("✅").catch(() => {});

            return sendListButton(
                sock,
                m,
                "Pilih grup yang ingin dimasukkan ke blacklist JPM.",
                "BLACKLIST JPM",
                rows
            );
        }

        case "addbljpm": {
            const groupId = input;

            if (!groupId || !groupId.endsWith("@g.us")) {
                return m.reply(`❌ ID grup tidak valid.\n\nContoh:\n${usedPrefix}${cmd} 120363xxxxxxxx@g.us`);
            }

            if (isBlacklisted(groupId)) {
                return m.reply("⚠️ Grup tersebut sudah ada di blacklist JPM.");
            }

            await m.react("⏳").catch(() => {});

            try {
                const meta = await sock.groupMetadata(groupId);

                global.db.settings.bljpm.push({
                    groupName: meta.subject || "Tanpa Nama",
                    id: groupId,
                    addedAt: Date.now()
                });

                await m.react("✅").catch(() => {});
                return m.reply(`✅ Grup *${meta.subject || "Tanpa Nama"}* berhasil masuk blacklist JPM.`);
            } catch (error) {
                await m.react("❌").catch(() => {});
                return m.reply(`❌ Gagal menambahkan blacklist.\n\nDetail:\n${error.message || error}`);
            }
        }

        case "delbljpm": {
            if (!global.db.settings.bljpm.length) {
                return m.reply("⚠️ Blacklist JPM masih kosong.");
            }

            const rows = global.db.settings.bljpm.map(group => ({
                title: String(group.groupName || "Tanpa Nama").slice(0, 60),
                description: group.id,
                id: `${usedPrefix}delbljpm-confirm ${group.id}`
            }));

            return sendListButton(
                sock,
                m,
                "Pilih grup yang ingin dihapus dari blacklist JPM.",
                "HAPUS BLACKLIST JPM",
                rows
            );
        }

        case "delbljpm-confirm": {
            const groupId = input;

            if (!groupId || !groupId.endsWith("@g.us")) {
                return m.reply("❌ ID grup tidak valid.");
            }

            const before = global.db.settings.bljpm.length;

            global.db.settings.bljpm = global.db.settings.bljpm.filter(group => group.id !== groupId);

            const after = global.db.settings.bljpm.length;

            if (before === after) {
                return m.reply("⚠️ Grup tersebut tidak ada di blacklist JPM.");
            }

            await m.react("✅").catch(() => {});
            return m.reply("✅ Grup berhasil dihapus dari blacklist JPM.");
        }

        case "listbljpm": {
            if (!global.db.settings.bljpm.length) {
                return m.reply("⚠️ Blacklist JPM masih kosong.");
            }

            let teks = `╭──「 *🚫 LIST BLACKLIST JPM* 」\n`;
            teks += `│ 📊 *Total:* ${global.db.settings.bljpm.length} grup\n│\n`;

            global.db.settings.bljpm.forEach((group, index) => {
                teks += `│ ${index + 1}. ${group.groupName || "Tanpa Nama"}\n`;
                teks += `│    ${group.id}\n`;
            });

            teks += `╰────────────`;

            return m.reply(teks);
        }

        default:
            return m.reply("❌ Command tidak dikenal.");
    }
};

handler.command = [
    "jpm",
    "jasher",
    "jaser",
    "jpmbutton",
    "jpmtombol",
    "jpmsc",
    "bljpm",
    "addbljpm",
    "delbljpm",
    "delbljpm-confirm",
    "listbljpm"
];

handler.tags = ["owner"];

handler.help = [
    "jpm teks",
    "jpm (reply pesan)",
    "jpmbutton teks | tombol | url",
    "jpmtombol teks | tombol | url",
    "jpmsc",
    "bljpm",
    "delbljpm",
    "listbljpm"
];

handler.owner = true;

module.exports = handler;
