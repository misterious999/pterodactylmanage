let handler = async (m, { sock, text }) => {
  let teksBalasan = text || "Berhasil mengganti ke mode premium ✅"

  // 1. Membuat Fake Quote dari WhatsApp Business (Centang Biru)
  let fakeWA = {
    key: {
      fromMe: false,
      participant: `0@s.whatsapp.net`, // ID resmi WhatsApp
      ...(m.chat ? { remoteJid: "status@broadcast" } : {})
    },
    message: {
      conversation: global.botname // Teks yang muncul di bawah tulisan "WhatsApp"
    }
  }

  // 2. Merakit ContextInfo Premium
  let premiumContext = {
    isForwarded: true,
    forwardingScore: 999, // Memunculkan ikon "Diteruskan berkali-kali"
    forwardedNewsletterMessageInfo: {
      newsletterJid: global.idChannel,
      newsletterName: `💖 Assistant X Information || WhatsApp Bot 💖`,
      serverId: 1
    },
    externalAdReply: {
      title: `💢 — ${global.botname} v${global.versibot}`,
      body: `© Powered by ${global.ownername}`,
      thumbnailUrl: global.thumbnail, // Mengambil thumbnail dari config
      sourceUrl: global.linkGrup,
      mediaType: 1,
      renderLargerThumbnail: false // Disetel false agar gambarnya kotak kecil di kiri
    }
  }

  // 3. Mengeksekusi Pesan Gabungan
  await sock.sendMessage(m.chat, {
    text: teksBalasan,
    contextInfo: premiumContext
  }, { quoted: fakeWA }) // Membalas fake quote centang biru
}

handler.command = ["tesrespon", "teslayout"]
handler.tags = ["owner"]
handler.help = ["tesrespon <teks>"]
handler.owner = true

module.exports = handler
