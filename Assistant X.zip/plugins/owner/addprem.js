const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

function msToDate(ms) {
    let days = Math.floor(ms / (24 * 60 * 60 * 1000));
    let hours = Math.floor((ms % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
    let minutes = Math.floor((ms % (60 * 60 * 1000)) / (60 * 1000));
    return `${days} Hari ${hours} Jam ${minutes} Menit`;
}

let handler = async (m, { sock, args, prefix, command, isOwner }) => {
    if (!isOwner) return m.reply(`❌ *Akses Ditolak!*`);

    let users = global.db.users;

    // FUNGSI UTAMA: MENCARI NOMOR TARGET DENGAN CERDAS
    let who = m.quoted ? m.quoted.sender : (m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : (args[0] ? args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : ''));

    // 👑 1. MENU UTAMA PREMIUM
    if (['premium', 'vip'].includes(command)) {
        let menu = `╭──「 *👑 VVIP CONTROL PANEL* 」\n`;
        menu += `│ Kelola akses sultan bot:\n╰────────────`;
        return sock.sendMessage(m.chat, {
            text: menu,
            footer: "© Executive Manager 👑",
            buttons: [
                { buttonId: `${prefix}addprem`, buttonText: { displayText: "➕ Tambah VVIP" }, type: 1 },
                { buttonId: `${prefix}delprem`, buttonText: { displayText: "➖ Cabut VVIP" }, type: 1 },
                { buttonId: `${prefix}listprem`, buttonText: { displayText: "📋 Daftar Sultan" }, type: 1 }
            ],
            headerType: 1
        }, { quoted: m });
    }

    // ➕ 2. TAMBAH PREMIUM
    if (command === 'addprem') {
        if (!who) return m.reply(`⚠️ Balas pesan atau tag orangnya!\nContoh: \`.addprem @tag 30\``);
        let days = parseInt(args[args.length - 1]);
        if (isNaN(days)) return m.reply(`⚠️ Masukkan durasi hari!\nContoh: \`.addprem @tag 30\``);

        if (!users[who]) users[who] = {};
        let now = Date.now();
        users[who].premium = true;
        users[who].premiumTime = (users[who].premiumTime > now ? users[who].premiumTime : now) + (days * 86400000);

        m.reply(`✅ Berhasil! @${who.split('@')[0]} jadi VVIP selama ${days} hari.`);
    }

    // ➖ 3. CABUT PREMIUM
    if (command === 'delprem') {
        if (!who) return m.reply(`⚠️ Balas pesan atau tag orangnya!\nContoh: \`.delprem @tag\``);
        if (!users[who] || !users[who].premium) return m.reply(`⚠️ User tersebut bukan anggota Premium!`);
        
        users[who].premium = false;
        users[who].premiumTime = 0;
        m.reply(`✅ Akses VVIP @${who.split('@')[0]} berhasil dicabut.`);
    }

    // 📋 4. DAFTAR SULTAN (DENGAN AUTO-CLEAN)
    if (command === 'listprem') {
        let now = Date.now();
        let premList = [];
        for (let jid in users) {
            if (users[jid].premium) {
                if (users[jid].premiumTime > now) {
                    premList.push({ jid, sisa: users[jid].premiumTime - now });
                } else {
                    users[jid].premium = false; // Auto bersihkan yang expired
                }
            }
        }
        if (premList.length === 0) return m.reply(`📭 Belum ada User VVIP.`);
        
        let teks = `╭──「 *✨ DAFTAR USER VVIP* 」\n│ Total: ${premList.length} User\n╰────────────\n\n`;
        premList.forEach((v, i) => {
            teks += `*${i + 1}.* @${v.jid.split('@')[0]}\n   └ ⏳ ${msToDate(v.sisa)}\n\n`;
        });
        sock.sendMessage(m.chat, { text: teks, mentions: premList.map(v => v.jid) }, { quoted: m });
    }
}

handler.command = ['addprem', 'delprem', 'listprem'];
handler.rowner = true;
module.exports = handler;
