let handler = async (m, { sock, command }) => {
    // 1. Deteksi ID Bot secara akurat
    let botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    
    // 2. Pastikan objek database settings tersedia
    global.db.settings = global.db.settings || {};
    global.db.settings[botId] = global.db.settings[botId] || { public: true }; // Default public

    // 3. Tentukan status berdasarkan command
    let isPublic = command === "public";

    // 4. EKSEKUSI GANDA (Efek Instan + Simpan Permanen)
    sock.public = isPublic;                  // Ubah di memori (berlaku detik ini juga)
    global.db.settings[botId].public = isPublic; // Simpan di database (kebal restart)

    // 5. Output UI yang rapi
    let modeText = isPublic ? "🌐 *PUBLIC* (Semua Orang)" : "🔒 *SELF* (Hanya Owner)";
    
    let teks = `╭──「 *SYSTEM OVERRIDE* 」\n`;
    teks += `│ 🔄 Mode berhasil dialihkan!\n`;
    teks += `│ 🔰 Status: ${modeText}\n`;
    teks += `│ 💾 Database: Tersimpan Permanen\n`;
    teks += `╰────────────`;

    return m.reply(teks);
}

handler.tags = ["owner"];
handler.help = ["self", "public"];
handler.command = ["self", "public"];
handler.owner = true;

module.exports = handler;
