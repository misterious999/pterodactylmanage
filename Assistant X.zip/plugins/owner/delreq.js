let handler = async (m, { sock, args, command, prefix }) => {
    // Memastikan array requests ada di database agar tidak error
    global.db.settings.requests = global.db.settings.requests || [];
    let requests = global.db.settings.requests;

    // Jika daftar kosong
    if (requests.length === 0) {
        return m.replyPremium("📭 *Daftar Request Kosong!*\n\nSaat ini tidak ada antrean request fitur dari user. Database bersih!");
    }

    // Jika Bosku hanya mengetik command tanpa angka, tampilkan daftarnya
    if (!args[0]) {
        let listTxt = `╭───┈ *「 📋 DAFTAR REQUEST FITUR 」*\n`;
        let mentions = [];
        
        requests.forEach((req, i) => {
            // Asumsi struktur data request: { text: "Isi request", sender: "nomor@s.whatsapp.net" }
            let senderNum = req.sender ? req.sender.split('@')[0] : "Unknown";
            let reqText = req.text ? req.text : req; 
            
            listTxt += `│ *${i + 1}.* ${reqText} (Dari: @${senderNum})\n`;
            if (req.sender) mentions.push(req.sender);
        });
        
        listTxt += `╰───────────────┈ ⳹\n\n_⚙️ *Cara Menghapus:*_\n_Ketik \`${prefix}${command} <nomor>\`_\n_Contoh: \`${prefix}${command} 1\`_`;
        
        return sock.sendMessage(m.chat, { text: listTxt, mentions: mentions }, { quoted: m });
    }

    // Eksekusi Penghapusan berdasarkan Nomor Urut
    let index = parseInt(args[0]) - 1;
    
    // Validasi Angka
    if (isNaN(index) || index < 0 || index >= requests.length) {
        return m.replyPremium(`❌ *Nomor Urut Tidak Valid!*\n\nPastikan angka yang dimasukkan sesuai dengan daftar. Ketik \`${prefix}${command}\` untuk melihat daftar.`);
    }

    // Ekstrak data yang akan dihapus untuk dilaporkan
    let deletedReq = requests[index];
    let deletedText = deletedReq.text ? deletedReq.text : deletedReq;

    // 🗑️ EKSEKUSI PEMUSNAHAN
    requests.splice(index, 1);
    global.db.settings.requests = requests; // Update langsung ke database

    return m.replyPremium(`✅ *Request Berhasil Dimusnahkan!*\n\n🗑️ *Item Dihapus:* "${deletedText}"\n\n_Database telah diperbarui!_`);
}

// Bisa dipanggil pakai 3 kata kunci ini
handler.command = ['deletelistrequest', 'delreq', 'deletereq'];
handler.tags = ['owner'];
handler.help = ['delreq <nomor>'];
handler.owner = true; // 👑 MUTLAK HANYA OWNER

module.exports = handler;
