let handler = async (m, { sock, args, command, prefix, isOwner }) => {
    // 1. Validasi Akses Eksekutif
    if (!isOwner) return m.replyPremium("🛡️ *Akses Ditolak*\nFitur ini mutlak hanya untuk Owner.");

    // 2. Menu Panduan
    if (!args[0]) {
        return m.replyPremium(`╭───┈ *「 🚫 PANEL BLACKLIST 」*\n│ ◈ *Panduan Penggunaan:*\n│ \`${prefix + command} add <nomor/reply>\` - Memasukkan ke daftar hitam.\n│ \`${prefix + command} del <nomor/reply>\` - Membuka blokir.\n│ \`${prefix + command} list\` - Melihat daftar blacklist.\n╰───────────────┈ ⳹`);
    }

    let action = args[0].toLowerCase();
    
    // 3. Menangkap Target (Bisa lewat Tag, Reply Pesan, atau Ketik Nomor)
    let target = m.mentionedJid[0] ? m.mentionedJid[0] : 
                 m.quoted ? m.quoted.sender : 
                 args[1] ? args[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null;

    // 4. Fitur List: Melihat Daftar Tahanan
    if (action === 'list') {
        let users = global.db.users || {};
        let bannedList = Object.entries(users).filter(([jid, data]) => data.banned);
        
        if (bannedList.length === 0) return m.replyPremium("📭 *Daftar Blacklist Kosong!*\nTidak ada user yang diblokir saat ini.");
        
        let txt = `╭───┈ *「 📜 DAFTAR BLACKLIST 」*\n`;
        let mentions = [];
        bannedList.forEach(([jid, data], i) => {
            txt += `│ *${i + 1}.* @${jid.split('@')[0]}\n`;
            mentions.push(jid);
        });
        txt += `╰───────────────┈ ⳹`;
        
        return sock.sendMessage(m.chat, { text: txt, mentions: mentions }, { quoted: m });
    }

    // Validasi Target untuk Add/Del
    if (!target) return m.replyPremium("❌ *Target Tidak Valid!*\nSilakan tag orangnya, balas (reply) pesannya, atau ketik nomornya.");

    // Mencegah Owner bunuh diri (nge-ban diri sendiri)
    if (target === m.sender || target === sock.user.jid) return m.replyPremium("⚠️ *Peringatan Sistem!*\nAnda tidak bisa mem-blacklist nomor Owner atau nomor Bot itu sendiri!");

    // Inisialisasi Database User
    if (!global.db.users[target]) global.db.users[target] = {};
    let userDb = global.db.users[target];

    // 5. Eksekusi Hukuman
    if (action === 'add') {
        if (userDb.banned) return m.replyPremium("⚠️ Target tersebut sudah berada di dalam daftar Blacklist.");
        userDb.banned = true;
        global.db.users[target] = userDb; // Update Database
        return m.replyPremium(`✅ *Target Berhasil Dimusnahkan!*\n\nAkses @${target.split('@')[0]} ke dalam sistem bot telah dicabut secara permanen.`, target);
    } 
    
    // 6. Eksekusi Pembebasan
    else if (action === 'del') {
        if (!userDb.banned) return m.replyPremium("⚠️ Target tersebut tidak ada di dalam daftar Blacklist.");
        userDb.banned = false;
        global.db.users[target] = userDb; // Update Database
        return m.replyPremium(`✅ *Target Berhasil Dibebaskan!*\n\nAkses @${target.split('@')[0]} telah dipulihkan.`, target);
    }
}

handler.command = ['blacklist', 'ban', 'banned'];
handler.tags = ['owner'];
handler.help = ['blacklist <add/del/list>'];
handler.owner = true;

module.exports = handler;
