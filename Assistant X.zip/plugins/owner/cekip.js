const axios = require('axios');

let handler = async (m, { sock }) => {
    await m.reply('⏳ _Sedang melacak IP Publik server..._');
    try {
        // Meminta IP Publik dari layanan ipify
        const { data } = await axios.get('https://api.ipify.org?format=json');
        
        let teks = `╭───┈ *「 🌐 RADAR IP SERVER 」*\n`;
        teks += `│\n`;
        teks += `│ 💻 *IP Publik:* \`${data.ip}\`\n`;
        teks += `│\n`;
        teks += `╰───────────────┈ ⳹\n\n`;
        teks += `📌 *Silakan copy angka IP di atas dan masukkan ke menu Whitelist IP*`;

        await sock.sendMessage(m.chat, { text: teks }, { quoted: m });
    } catch (err) {
        m.reply('❌ Gagal melacak IP. Coba cek koneksi server.');
    }
}

handler.tags = ['owner'];
handler.help = ['cekip'];
handler.command = ['cekip'];
handler.owner = true; // Hanya bosku yang bisa pakai fitur ini

module.exports = handler;
