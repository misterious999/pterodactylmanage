const { generateWAMessageFromContent } = require("@whiskeysockets/baileys")

let handler = async (m, { sock, text, command }) => {

  // 1. Logika Eksekusi (Background Action dari Tombol)
  if (command === "setmute") {
    let [jid, action] = text.split(" ")
    if (!jid || !action) return m.reply("❌ Format tidak valid dari sistem tombol.")
    
    if (!global.db.groups[jid]) global.db.groups[jid] = {}
    
    let gcName = "Grup"
    try {
      let meta = await sock.groupMetadata(jid)
      gcName = meta.subject
    } catch (e) {}

    if (action === "on") {
      global.db.groups[jid].mute = true
      return m.reply(`🔇 *Bot Mute Aktif!*\nBot sekarang membisu dan tidak akan merespon perintah di grup *${gcName}*.`)
    } else {
      global.db.groups[jid].mute = false
      return m.reply(`🔊 *Bot Unmute Aktif!*\nBot kembali merespon perintah di grup *${gcName}*.`)
    }
  }

  // 2. Logika Menampilkan List Tombol Interaktif (.mute / .unmute)
  let allGroups = await sock.groupFetchAllParticipating()
  let groups = Object.values(allGroups)

  if (groups.length === 0) return m.reply("❌ Bot belum bergabung ke grup manapun.")

  let rows = []
  for (let gc of groups) {
    let jid = gc.id
    let isMuted = global.db.groups[jid]?.mute || false
    
    // Sistem Toggle Cerdas: Jika grup sedang mute, tombol akan menawarkan unmute, dan sebaliknya.
    let statusText = isMuted ? "🔇 Sedang Mute (Klik untuk Unmute)" : "🔊 Sedang Aktif (Klik untuk Mute)"
    let action = isMuted ? "off" : "on"

    rows.push({
      title: gc.subject || "Tanpa Nama",
      description: statusText,
      id: `.setmute ${jid} ${action}` // Mengirimkan command rahasia ke sistem saat diklik
    })
  }

  // 3. Merakit Pesan Interaktif
  let msg = await generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: { 
            text: `╭───┈ *「 MUTE MANAGER 」*\n│ 🤖 Silakan pilih grup untuk mengubah\n│ status respon bot secara instan.\n╰───────────────┈ ⳹\n\nTotal Grup: ${groups.length}` 
          },
          nativeFlowMessage: {
            buttons: [{
              name: "single_select",
              buttonParamsJson: JSON.stringify({
                title: "Pilih Grup",
                sections: [{
                  title: "Daftar Grup Bot",
                  rows: rows
                }]
              })
            }]
          }
        }
      }
    }
  }, { userJid: m.chat, quoted: m })

  await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}

handler.command = ["mute", "unmute", "setmute"]
handler.tags = ["owner"]
handler.help = ["mute"]
handler.owner = true // Hak akses dilindungi sistem handler.js khusus untuk Owner

module.exports = handler
