const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

// ==========================================
// 📢 UPLOAD STATUS WHATSAPP (BOT STORY)
// ⚙️ Ciptaan Pstar7 | HOT FIX: Anti-Undefined
// ==========================================

let handler = async (m, { sock, text, prefix, command }) => {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';
    let isMedia = /image|video|audio/.test(mime);

    // Validasi Format
    if (!text && !isMedia) {
        await m.react("⚠️");
        return m.reply(`╭──「 *⚠️ FORMAT SALAH* 」\n│ Kirim/balas media atau teks dengan perintah:\n│ ◦ \`${prefix + command} <teks>\`\n│ ◦ \`${prefix + command}\` (sambil balas media)\n╰────────────`);
    }

    await m.react("⏳"); // Indikator Proses

    try {
        // Mengambil seluruh JID dari database agar status terlihat oleh semua user
        let jids = Object.keys(global.db.users || {});
        if (jids.length === 0) jids = [m.sender]; 

        let content;

        if (isMedia) {
            // 🔥 FIX: MENGUPAS RAW OBJECT SAMPAI KE AKAR MEDIAKEY
            let rawMsg = m.quoted ? m.message?.extendedTextMessage?.contextInfo?.quotedMessage : m.message;
            
            // Bypass lapisan pesan sementara (ephemeral / view once) jika ada
            if (rawMsg?.ephemeralMessage) rawMsg = rawMsg.ephemeralMessage.message;
            if (rawMsg?.viewOnceMessage) rawMsg = rawMsg.viewOnceMessage.message;
            if (rawMsg?.viewOnceMessageV2) rawMsg = rawMsg.viewOnceMessageV2.message;
            if (rawMsg?.viewOnceMessageV2Extension) rawMsg = rawMsg.viewOnceMessageV2Extension.message;

            // Targetkan secara spesifik ke objek medianya
            let mediaObj = rawMsg?.imageMessage || rawMsg?.videoMessage || rawMsg?.audioMessage;
            
            if (!mediaObj) {
                // Fallback jika punya fungsi download bawaan dari botnya
                if (typeof q.download === 'function') {
                    mediaObj = await q.download();
                } else {
                    await m.react("❌");
                    return m.reply("❌ Gagal membaca metadata media. Coba kirim ulang medianya lalu reply lagi.");
                }
            }

            let type = mime.split('/')[0]; // Mendapatkan 'image', 'video', atau 'audio'
            let buffer;

            // Jika mediaObj sudah berupa buffer (dari fallback q.download)
            if (Buffer.isBuffer(mediaObj)) {
                buffer = mediaObj;
            } else {
                // Download resmi menggunakan Baileys
                let stream = await downloadContentFromMessage(mediaObj, type);
                buffer = Buffer.from([]);
                for await (const chunk of stream) {
                    buffer = Buffer.concat([buffer, chunk]);
                }
            }

            // Merakit payload berdasarkan tipe media
            if (type === 'image') {
                content = { image: buffer, caption: text || '' };
            } else if (type === 'video') {
                content = { video: buffer, caption: text || '' };
            } else if (type === 'audio') {
                content = { audio: buffer, mimetype: 'audio/mp4', ptt: true };
            }
        } else {
            // 📝 SISTEM TEKS STATUS (ELEGAN DARK MODE)
            content = {
                text: text,
                backgroundColor: '#1E1E1E', // Warna background status (Dark Grey elegan)
                font: 2 // Gaya font
            };
        }

        // 🚀 EKSEKUSI PENGIRIMAN KE SERVER STATUS BROADCAST
        await sock.sendMessage('status@broadcast', content, { statusJidList: jids });

        await m.react("✅");
        return m.reply("✅ *Status berhasil mengudara!*\nSilakan cek tab Status di WhatsApp Bot sekarang.");

    } catch (error) {
        console.error("[ERROR UPSW]", error);
        await m.react("❌");
        m.reply(`❌ Terjadi kesalahan sistem saat mengunggah status.\n\n_Log: ${error.message}_`);
    }
}

handler.command = ["upsw"];
handler.tags = ["owner"];
handler.help = ["upsw"];
handler.owner = true; 

module.exports = handler;
