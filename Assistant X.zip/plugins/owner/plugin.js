const fs = require("fs");
const path = require("path");

let handler = async (m, { sock, args, command, isOwner }) => {
  if (!isOwner) return m.reply("❌ Hanya owner yang bisa menggunakan fitur ini.");

  const pluginFolder = path.join(process.cwd(), "plugins");

  // ==================== SAVE PLUGIN (.sp) ====================
  if (command === "sp") {
    let quotedMsg = m.quoted ? m.quoted : m;

    if (!quotedMsg || (!quotedMsg.mimetype && !quotedMsg.msg?.mimetype)) {
      return m.reply(
        `❌ Reply file plugin (.js), lalu ketik perintah:\n\n` +
        `Contoh Folder: \`.sp ./plugins/search/\`\n` +
        `Contoh File: \`.sp ./plugins/search/pinterest.js\``
      );
    }

    try {
      await m.react("⏳");

      // Download file
      const { downloadContentFromMessage } = require("@whiskeysockets/baileys");
      let messageType = quotedMsg.mtype?.replace(/Message/gi, "") || "document";
      let stream = await downloadContentFromMessage(quotedMsg.msg || quotedMsg, messageType);

      let buffer = Buffer.from([]);
      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
      }

      // 🔥 FIX: Sistem Deteksi Nama File Akurat & Berlapis
      let originalName = quotedMsg.fileName || 
                         quotedMsg.msg?.fileName || 
                         quotedMsg.message?.documentMessage?.fileName || 
                         `plugin-${Date.now()}.js`;

      // Ambil path dari argumen
      let targetPath = args.join(" ").trim();
      if (!targetPath) targetPath = "./plugins/";

      let fullFolderPath;
      let finalFileName = originalName;

      // Cek apakah target akhirnya berupa folder atau nama file eksplisit
      if (targetPath.endsWith(".js")) {
        finalFileName = path.basename(targetPath);
        fullFolderPath = path.resolve(process.cwd(), path.dirname(targetPath));
      } else {
        fullFolderPath = path.resolve(process.cwd(), targetPath);
      }

      // Buat folder jika belum ada
      if (!fs.existsSync(fullFolderPath)) {
        fs.mkdirSync(fullFolderPath, { recursive: true });
      }

      const savePath = path.join(fullFolderPath, finalFileName);

      // Cek & Hapus File Lama jika ada bentrok nama
      let isOverwrite = fs.existsSync(savePath);
      if (isOverwrite) {
        fs.unlinkSync(savePath); 
      }

      // Simpan file baru ke server
      fs.writeFileSync(savePath, buffer);

      await m.react("✅");

      let statusText = isOverwrite 
        ? "✅ *Plugin lama berhasil dihancurkan dan ditimpa yang baru!*" 
        : "✅ *Plugin baru berhasil disimpan!*";

      let displayPath = targetPath.endsWith(".js") ? targetPath : path.join(targetPath, finalFileName);

      m.reply(
        `${statusText}\n\n` +
        `📁 *Lokasi:* \`${displayPath.replace(/\\/g, "/")}\``
      );

    } catch (e) {
      console.error("[SP ERROR]", e);
      await m.react("❌");
      m.reply("❌ Gagal menyimpan plugin.\nDetail: " + e.message);
    }
  }

  // ==================== LIST PLUGIN (.lp) ====================
  else if (command === "lp") {
    try {
      const files = fs.readdirSync(pluginFolder).filter(file => file.endsWith(".js"));

      if (files.length === 0) {
        return m.reply("📭 Tidak ada plugin yang ditemukan.");
      }

      let teks = `╭──「 *LIST PLUGIN* 」\n`;
      teks += `│ Total: ${files.length} plugin\n│\n`;

      files.forEach((file, i) => {
        teks += `│ ${i + 1}. ${file}\n`;
      });

      teks += `╰────────────`;
      m.reply(teks);

    } catch (e) {
      console.error("[LP ERROR]", e);
      m.reply("❌ Gagal membaca daftar plugin.");
    }
  }

  // ==================== DELETE PLUGIN (.dp) ====================
  else if (command === "dp") {
    if (!args[0]) {
      return m.reply(`❌ Format: \`.dp namaFile.js\`\nContoh: \`.dp setpp.js\``);
    }

    let fileName = args[0].endsWith(".js") ? args[0] : `${args[0]}.js`;
    const filePath = path.join(pluginFolder, fileName);

    if (!fs.existsSync(filePath)) {
      return m.reply(`❌ File *${fileName}* tidak ditemukan.`);
    }

    try {
      fs.unlinkSync(filePath);
      m.reply(`✅ Plugin *${fileName}* berhasil dihapus.`);
    } catch (e) {
      console.error("[DP ERROR]", e);
      m.reply("❌ Gagal menghapus plugin.");
    }
  }
};

handler.command = ["sp", "lp", "dp"];
handler.tags = ["owner"];
handler.owner = true;

module.exports = handler;
