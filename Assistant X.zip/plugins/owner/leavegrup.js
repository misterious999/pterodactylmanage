const { generateWAMessageFromContent } = require("@whiskeysockets/baileys")

let handler = async (m, { sock, text, command }) => {

  // 1. Logika Eksekusi (Aksi Latar Belakang dari Tombol)
  if (command === "executeleave") {
    let jid = text.trim()
    if (!jid) return m.reply("❌ Format ID grup tidak valid dari sistem tombol.")
    
    try {
      // Mengirim pesan pamit sebelum keluar (Opsional, agar sopan)
      await sock.sendMessage(jid, { text: "Mendapatkan perintah dari Owner. Bot izin keluar dari grup ini. Terima kasih semuanya! 👋" })
      
      // Jeda 1 detik agar pesan pamit terkirim sebelum benar-benar keluar
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      // Proses keluar dari grup
      await sock.groupLeave(jid)
      
      return m.reply(`✅ *Berhasil Keluar!*\nBot telah sukses keluar dari grup tersebut.`)
    } catch (e) {
      console.error(e)
      return m.reply("❌ Terjadi kesalahan saat mencoba keluar dari grup. Pastikan bot masih berada di dalam grup tersebut.")
    }
  }

  // 2. Logika Menampilkan List Tombol Interaktif (.leavegrup)
  let allGroups = await sock.groupFetchAllParticipating()
  let groups = Object.values(allGroups)

  if (groups.length === 0) return m.reply("❌ Bot saat ini tidak bergabung di grup manapun.")

  let rows = []
  for (let gc of groups) {
    let jid = gc.id
    let memberCount = gc.participants?.length || 0
    
    rows.push({
      title: gc.subject || "Grup Tanpa Nama",
      description: `Total Member: ${memberCount} | Klik untuk keluar dari grup ini.`,
      id: `.executeleave ${jid}` // Mengirimkan command rahasia ke sistem saat tombol diklik
    })
  }

  // 3. Merakit Pesan Interaktif
  let msg = await generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: { 
            text: `╭───┈ *「 LEAVE GROUP MANAGER 」*\n│ 🤖 Silakan pilih grup di bawah ini\n│ untuk memerintahkan bot keluar.\n╰───────────────┈ ⳹\n\nTotal Grup: ${groups.length}` 
          },
          nativeFlowMessage: {
            buttons: [{
              name: "single_select",
              buttonParamsJson: JSON.stringify({
                title: "Pilih Grup",
                sections: [{
                  title: "Daftar Grup Bot",
                  rows: rows
                }]
              })
            }]
          }
        }
      }
    }
  }, { userJid: m.chat, quoted: m })

  await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}

handler.command = ["leave", "leavegc", "out", "executeleave"]
handler.tags = ["owner"]
handler.help = ["leave"]
handler.owner = true // Akses dilindungi hanya untuk Owner

module.exports = handler
