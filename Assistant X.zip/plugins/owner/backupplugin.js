const fs = require('fs');
const path = require('path');
const archiver = require('archiver');

// ==========================================
// 🚀 ASSISTANT X VVIP BACKUP MANAGER (UPDATED)
// ⚙️ Features: Zip Folder + Ignore Files
// ==========================================

let handler = async (m, { sock, args, command, prefix, isOwner }) => {
    if (!isOwner) return m.reply("🔒 *Akses Ditolak!*");

    let targetPath = args.join(" ").trim() || "./plugins";
    let fullPath = path.resolve(process.cwd(), targetPath);

    if (!fs.existsSync(fullPath)) return m.reply(`❌ *Folder tidak ditemukan!*`);

    // 🔥 DAFTAR FILE/FOLDER YANG AKAN DI-SKIP
    const ignoreList = [
        'config.js',        // File sensitif
        '.env',             // File rahasia
        'node_modules/**',  // Folder berat
        '*.log',            // File log
        'session/**',       // Sesi WA
        'whitelisensi.js'   // File lisensi (Sesuai permintaan bosku)
    ];

    let folderName = path.basename(fullPath);
    let timeStamp = new Date().toLocaleDateString('id-ID').replace(/\//g, '-');
    let zipFileName = `Backup_${folderName}_${timeStamp}.zip`;
    let zipFilePath = path.join(process.cwd(), zipFileName);

    await m.react('⏳');
    let { key } = await sock.sendMessage(m.chat, { text: `📦 *Mengompresi Folder (Excluding: ${ignoreList.join(', ')})*...` }, { quoted: m });

    try {
        await new Promise((resolve, reject) => {
            const output = fs.createWriteStream(zipFilePath);
            const archive = archiver('zip', { zlib: { level: 9 } });

            output.on('close', () => resolve());
            archive.on('error', (err) => reject(err));

            archive.pipe(output);

            // ⚙️ FILTER FILE DENGAN GLOB
            archive.glob('**/*', {
                cwd: fullPath,
                ignore: ignoreList
            }, {
                prefix: folderName
            });

            archive.finalize();
        });

        const fileSizeMB = (fs.statSync(zipFilePath).size / 1024 / 1024).toFixed(2);
        
        await sock.sendMessage(m.chat, {
            document: fs.readFileSync(zipFilePath),
            fileName: zipFileName,
            mimetype: 'application/zip',
            caption: `✅ *B A C K U P   S U K S E S*\n\n📁 *Folder:* \`${targetPath}\`\n🚫 *Dikecualikan:* ${ignoreList.join(', ')}\n📦 *Ukuran:* ${fileSizeMB} MB`
        }, { quoted: m });

        if (fs.existsSync(zipFilePath)) fs.unlinkSync(zipFilePath);
        
        await sock.sendMessage(m.chat, { text: `✅ *Backup Selesai!*`, edit: key });
        await m.react('✅');

    } catch (e) {
        if (fs.existsSync(zipFilePath)) fs.unlinkSync(zipFilePath);
        await m.react('❌');
        await sock.sendMessage(m.chat, { text: `❌ *Gagal backup:* ${e.message}`, edit: key });
    }
};

handler.help = ['bp <folder>'];
handler.tags = ['owner'];
handler.command = ['bp'];
handler.owner = true;

module.exports = handler;
