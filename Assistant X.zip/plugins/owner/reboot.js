// ==========================================
// 🔄 RESTART SYSTEM (ANIMATED PROGRESS BAR)
// ==========================================

// Fungsi jeda/delay untuk mengatur kecepatan animasi
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

let handler = async (m, { sock, isOwner }) => {
    // Keamanan lapis pertama: Hanya Owner
    if (!isOwner) {
        return m.replyPremium("❌ Akses ditolak! Perintah ini khusus Administrator.");
    }

    // Koleksi Frame Animasi Progress Bar
    const anim = [
        "⏳ *INITIALIZING...* \n[■□□□□□□□□□] 10%",
        "⚙️ *SHUTTING DOWN PROCESS...* \n[■■■□□□□□□□] 30%",
        "💾 *SAVING DATABASE CACHE...* \n[■■■■■■□□□□] 60%",
        "🔌 *DISCONNECTING SERVER...* \n[■■■■■■■■□□] 85%",
        "🚀 *SYSTEM REBOOTING!* \n[■■■■■■■■■■] 100%"
    ];

    // 1. Kirim pesan frame pertama & simpan 'key' pesannya untuk diedit
    let { key } = await sock.sendMessage(m.chat, { 
        text: `╭───┈ *「 RESTART PROTOCOL 」*\n│\n│ ${anim[0]}\n│\n╰───────────────┈ ⳹` 
    }, { quoted: m });

    // 2. Looping untuk mengeksekusi animasi (Edit Pesan Berulang)
    for (let i = 1; i < anim.length; i++) {
        await delay(600); // Jeda 0.6 detik per frame agar tidak kena rate-limit WA
        await sock.sendMessage(m.chat, { 
            text: `╭───┈ *「 RESTART PROTOCOL 」*\n│\n│ ${anim[i]}\n│\n╰───────────────┈ ⳹`,
            edit: key 
        });
    }

    // 3. Eksekusi pemutusan sistem setelah animasi mencapai 100%
    await delay(500);
    process.exit(1); // Panel Pterodactyl akan otomatis me-restart sistem dari 0
}

handler.help = ['restart'];
handler.tags = ['owner'];
handler.command = ['restart', 'reboot'];
handler.owner = true;

module.exports = handler;
