const fetch = require("node-fetch");

// ==========================================
// 🛡️ VIP GITHUB WHITELIST MANAGER (SYNCED)
// ⚙️ ENGINE: API, Isolated Ownership, GOD MODE, GROUP LOCK & DYNAMIC DEL
// ==========================================

let handler = async (m, { sock, args, command, prefix, isOwner }) => {
    
    // 🔥 1. KEAMANAN OWNER & PREMIUM
    let isPremium = global.db?.users?.[m.sender]?.premium || false;

    if (!isOwner && !isPremium) {
        return m.reply("❌ *Akses Ditolak!*\nFitur manajemen lisensi ini eksklusif hanya untuk *Owner* dan *User Premium*.");
    }

    // 🧹 NORMALISASI NOMOR PENGIRIM (Anti Device-ID Bug)
    const senderNumber = m.sender.split('@')[0].split(':')[0]; 
    // SuperAdmin aktif jika pengguna adalah Owner bot atau nomor ID khusus
    const isSuperAdmin = isOwner || senderNumber === "62895416479539"; 

    // ==========================================
    // 🔒 2. VVIP SECURITY: GROUP LOCK ISOLATION
    // ==========================================
    const allowedGroups = [
        "120363000000000000@g.us", // 👈 GANTI INI DENGAN ID GRUP RESELLER BOSKU
    ];

    if (!isSuperAdmin) {
        if (!m.isGroup) {
            return m.reply("❌ *Perintah Ditolak!*\nSistem menolak akses dari Private Chat. Manajemen lisensi hanya bisa dilakukan di dalam *Grup Pusat Reseller*.");
        }
        /* [!] Buka komentar ini jika ID Grup di atas sudah diisi dengan benar
        if (!allowedGroups.includes(m.chat)) {
            return m.reply("🚫 *Area Terlarang!*\nGrup ini tidak memiliki izin (Not Authorized) untuk mengakses database lisensi pusat.");
        }
        */
    }

    const token = "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";
    const repoOwner = "misterious999";
    const repoName = "assistantx";
    const filePath = "whitelist.json";
    const apiUrl = `https://api.github.com/repos/${repoOwner}/${repoName}/contents/${filePath}`;

    // 📡 HELPER 1: Mengambil Data (BYPASS CACHE)
    async function getWhitelist() {
        try {
            const res = await fetch(`${apiUrl}?ref=main&t=${Date.now()}`, {
                headers: { 
                    "Authorization": `token ${token}`,
                    "Accept": "application/vnd.github.v3+json",
                    "Cache-Control": "no-cache, no-store, must-revalidate" 
                }
            });
            
            if (!res.ok) {
                if (res.status === 404) return [];
                throw new Error(`Status ${res.status}`);
            }
            
            const data = await res.json();
            if (data.content) {
                const decoded = Buffer.from(data.content, 'base64').toString('utf-8');
                return JSON.parse(decoded);
            }
            return [];
        } catch (e) {
            console.error("[GET WHITELIST ERROR]", e);
            return [];
        }
    }

    // 📡 HELPER 2: Menyimpan Data (PUT)
    async function updateWhitelist(data) {
        try {
            let sha = null;
            const getRes = await fetch(`${apiUrl}?ref=main&t=${Date.now()}`, {
                headers: { 
                    "Authorization": `token ${token}`, 
                    "Accept": "application/vnd.github.v3+json",
                    "Cache-Control": "no-cache, no-store, must-revalidate"
                }
            });

            if (getRes.ok) {
                const current = await getRes.json();
                sha = current.sha;
            }

            const content = Buffer.from(JSON.stringify(data, null, 2)).toString("base64");

            const body = {
                message: `Auto-Update Whitelist via Assistant X`,
                content: content,
                branch: "main"
            };
            if (sha) body.sha = sha;

            const putRes = await fetch(apiUrl, {
                method: "PUT",
                headers: {
                    "Authorization": `token ${token}`,
                    "Accept": "application/vnd.github.v3+json",
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(body)
            });

            if (!putRes.ok) return false;
            return true;
        } catch (e) {
            console.error("[UPDATE CATCH ERROR]", e);
            return false;
        }
    }

    const whitelist = await getWhitelist();

    // ==========================================
    // 🛠️ 3. FITUR: .addlisensi
    // ==========================================
    if (command === "addlisensi") {
        const fullText = args.join(" ");
        if (!fullText.includes("|")) {
            return m.reply(`❌ *Format Salah!*\n\nContoh:\n\`${prefix}addlisensi pstar7|62895416479539|628891020116\``);
        }

        const parts = fullText.split("|").map(v => v.trim());
        if (parts.length < 3) return m.reply(`❌ *Data Tidak Lengkap!*`);

        const username = parts[0];
        const ownerNumber = parts[1].replace(/[^0-9]/g, ""); 
        const botNumber = parts[2].replace(/[^0-9]/g, "");   

        if (!username || !ownerNumber || !botNumber) return m.reply("❌ *Data Invalid!*");

        let entry = whitelist.find(e => e.username === username);

        if (entry) {
            if (entry.added_by && entry.added_by !== senderNumber && !isSuperAdmin) {
                return m.reply(`🚫 *Akses Ditolak!*\nUsername *${username}* adalah milik reseller/pengguna lain.`);
            }
            if (entry.bot_numbers.includes(botNumber)) {
                return m.reply(`⚠️ *Gagal!*\nNomor bot *${botNumber}* sudah terdaftar untuk username *${username}*.`);
            }
            if (entry.bot_numbers.length >= 2) {
                return m.reply(`⚠️ *Limit Tercapai!*\nUsername *${username}* sudah memiliki batas maksimal (2 Nomor Bot).`);
            }
            entry.bot_numbers.push(botNumber);
            entry.owner_number = ownerNumber; 
        } else {
            whitelist.push({
                username: username,
                owner_number: ownerNumber,
                bot_numbers: [botNumber],
                added_by: senderNumber
            });
        }

        await m.react('⏳');
        const isSuccess = await updateWhitelist(whitelist);
        
        if (isSuccess) {
            await m.react('✅');
            let teks = `✅ *Lisensi Berhasil Ditambahkan!*\n\n👤 *Username:* ${username}\n👑 *Owner:* ${ownerNumber}\n🤖 *Bot Akses:* ${botNumber}`;
            return m.reply(teks);
        } else {
            await m.react('❌');
            return m.reply("❌ *Gagal menyimpan ke GitHub!*");
        }
    }

    // ==========================================
    // 🛠️ 4. FITUR: .listlisensi
    // ==========================================
    if (command === "listlisensi") {
        if (!whitelist || whitelist.length === 0) return m.reply("📂 *Database Whitelist Masih Kosong!*");

        const myWhitelist = isSuperAdmin ? whitelist : whitelist.filter(e => e.added_by === senderNumber);

        if (myWhitelist.length === 0) return m.reply("📭 *Lisensi Milikmu Kosong!*");

        let teks = isSuperAdmin ? `👑 *D A T A   W H I T E L I S T   ( G L O B A L )* 👑\n\n` : `✨ *D A T A   W H I T E L I S T   K A M U* ✨\n\n`;
        
        myWhitelist.forEach((d, i) => {
            teks += `*${i + 1}. ${d.username}*\n`;
            teks += `   👑 Owner: ${d.owner_number}\n`;
            teks += `   🤖 Bot List: ${d.bot_numbers.join(", ")}\n`;
            if (isSuperAdmin) {
                teks += `   🕵️‍♂️ Dibuat oleh: ${d.added_by ? d.added_by : "Sistem/Data Klasik"}\n`;
            }
            teks += `\n`;
        });
        
        teks += `_© Assistant X Security_`;
        return m.reply(teks);
    }

    // ==========================================
    // 🛠️ 5. FITUR MENU: .dellisensi (PILIHAN)
    // ==========================================
    if (command === "dellisensi") {
        const username = args.join(" ").trim();
        if (!username) return m.reply(`🤖 *Masukkan username yang ingin diatur!*\nContoh:\n\`${prefix}dellisensi pstar7\``);

        const index = whitelist.findIndex(e => e.username === username);
        if (index === -1) return m.reply(`❌ Username *${username}* tidak ditemukan di dalam database!`);

        const entry = whitelist[index];
        if (entry.added_by && entry.added_by !== senderNumber && !isSuperAdmin) {
            return m.reply(`🚫 *Akses Ditolak!*\nLisensi *${username}* adalah milik pengguna lain.`);
        }

        // TAMPILKAN MENU INTERAKTIF
        let teks = `⚙️ *P A N E L   H A P U S   L I S E N S I* ⚙️\n\n`;
        teks += `👤 *Username Target:* ${username}\n`;
        teks += `🤖 *Bot Terdaftar:* ${entry.bot_numbers.join(", ")}\n\n`;
        teks += `_Silakan copy/ketik salah satu perintah di bawah ini untuk mengeksekusi:_\n\n`;
        
        teks += `🗑️ *HAPUS SEMUA (Username & Bot)*\n`;
        teks += `👉 \`${prefix}delall ${username}\`\n\n`;
        
        teks += `📱 *HAPUS NOMOR TERTENTU SAJA*\n`;
        entry.bot_numbers.forEach(num => {
            teks += `👉 \`${prefix}delnomor ${username}|${num}\`\n`;
        });

        return m.reply(teks);
    }

    // ==========================================
    // 🛠️ 6. EKSEKUSI 1: .delall (HAPUS TOTAL)
    // ==========================================
    if (command === "delall") {
        const username = args.join(" ").trim();
        if (!username) return m.reply(`❌ Format: \`${prefix}delall <username>\``);

        const index = whitelist.findIndex(e => e.username === username);
        if (index === -1) return m.reply(`❌ Username *${username}* tidak ditemukan!`);

        const entry = whitelist[index];
        if (entry.added_by && entry.added_by !== senderNumber && !isSuperAdmin) {
            return m.reply(`🚫 *Penghapusan Ditolak!* Lisensi milik orang lain.`);
        }

        whitelist.splice(index, 1);
        
        await m.react('⏳');
        const isSuccess = await updateWhitelist(whitelist);

        if (isSuccess) {
            await m.react('✅');
            return m.reply(`✅ *Sukses Dihapus!*\nSeluruh data username *${username}* telah dihanguskan.`);
        } else {
            await m.react('❌');
            return m.reply("❌ *Gagal menghapus dari GitHub!*");
        }
    }

    // ==========================================
    // 🛠️ 7. EKSEKUSI 2: .delnomor (HAPUS SATUAN)
    // ==========================================
    if (command === "delnomor") {
        const fullText = args.join(" ");
        if (!fullText.includes("|")) {
            return m.reply(`❌ *Format Salah!*\nContoh: \`${prefix}delnomor pstar7|628891020116\``);
        }

        const parts = fullText.split("|").map(v => v.trim());
        const username = parts[0];
        const targetBot = parts[1].replace(/[^0-9]/g, "");

        const index = whitelist.findIndex(e => e.username === username);
        if (index === -1) return m.reply(`❌ Username *${username}* tidak ditemukan!`);

        const entry = whitelist[index];
        if (entry.added_by && entry.added_by !== senderNumber && !isSuperAdmin) {
            return m.reply(`🚫 *Penghapusan Ditolak!* Lisensi milik orang lain.`);
        }

        const botIndex = entry.bot_numbers.indexOf(targetBot);
        if (botIndex === -1) {
            return m.reply(`❌ Nomor bot *${targetBot}* tidak ditemukan di dalam username *${username}*.`);
        }

        entry.bot_numbers.splice(botIndex, 1);

        let msgTambahan = "";
        if (entry.bot_numbers.length === 0) {
            whitelist.splice(index, 1);
            msgTambahan = `\n_Karena tidak ada nomor bot yang tersisa, username *${username}* ikut dihapus dari database._`;
        }

        await m.react('⏳');
        const isSuccess = await updateWhitelist(whitelist);

        if (isSuccess) {
            await m.react('✅');
            return m.reply(`✅ *Satu Nomor Berhasil Dihapus!*\nAkses bot *${targetBot}* untuk username *${username}* telah dicabut.${msgTambahan}`);
        } else {
            await m.react('❌');
            return m.reply("❌ *Gagal menghapus dari GitHub!*");
        }
    }
};

handler.help = ['addlisensi', 'listlisensi', 'dellisensi', 'delall', 'delnomor'];
handler.tags = ['premium'];
handler.command = ["addlisensi", "listlisensi", "dellisensi", "delall", "delnomor"];
handler.premium = true;

module.exports = handler;
