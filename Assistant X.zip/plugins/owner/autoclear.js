// ==========================================
// 🧹 MANUAL MAINTENANCE: CLEAR TRASH & SESSION
// ==========================================

const fs = require('fs');
const path = require('path');

// --- PENGATURAN FOLDER ---
const FOLDERS_TO_CLEAN = ['tmp', 'temp', 'trash']; // Sesuaikan jika ada folder sampah lain
const SESSION_FOLDER = './session'; // Sesuaikan dengan nama folder sesi Bosku

let handler = async (m, { sock, isOwner }) => {
    // Command manual jika Bosku mau bersih-bersih sekarang
    if (!isOwner) return;
    
    // Gunakan fungsi react jika tersedia di handler.js Bosku
    if (typeof m.react === 'function') await m.react('⏳');
    
    let report = await clearTrash();
    m.reply(`🧹 *Pembersihan Manual Selesai!*\n\n${report}`);
    
    if (typeof m.react === 'function') await m.react('✅');
};

// --- FUNGSI INTI PEMBERSIHAN ---
async function clearTrash() {
    let deletedFiles = 0;
    let foldersCleaned = 0;

    // 1. Bersihkan Folder Sampah Umum
    for (let folder of FOLDERS_TO_CLEAN) {
        let dir = path.join(process.cwd(), folder);
        if (fs.existsSync(dir)) {
            let files = fs.readdirSync(dir);
            for (let file of files) {
                try {
                    fs.unlinkSync(path.join(dir, file));
                    deletedFiles++;
                } catch (e) {}
            }
            foldersCleaned++;
        }
    }

    // 2. Bersihkan Sampah di Folder Session
    if (fs.existsSync(SESSION_FOLDER)) {
        let sessionFiles = fs.readdirSync(SESSION_FOLDER);
        for (let file of sessionFiles) {
            // Kita HANYA hapus file pre-key, sender-key, dan app-state yang menumpuk
            if (file.startsWith('pre-key-') || file.startsWith('sender-key-') || file.startsWith('session-') || file.startsWith('app-state-')) {
                try {
                    fs.unlinkSync(path.join(SESSION_FOLDER, file));
                    deletedFiles++;
                } catch (e) {}
            }
        }
    }

    return `✅ *Laporan Maintenance:*\n- Folder Dibersihkan: ${foldersCleaned}\n- File Sampah Dihapus: ${deletedFiles}\n- Status: Storage Lebih Lega! 🚀`;
}

handler.help = ['cleartrash'];
handler.tags = ['owner'];
handler.command = ['cleartrash'];
handler.owner = true;

module.exports = handler;
