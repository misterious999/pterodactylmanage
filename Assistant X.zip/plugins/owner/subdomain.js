const axios = require('axios');
const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

// ==========================================
// 🌐 AUTO SUBDOMAIN CLOUDFLARE MANAGER
// ⚙️ Ciptaan Pstar7 | Panel & Node Generator
// ==========================================

let handler = async (m, { sock, conn, text, prefix, command, args, isOwner }) => {
    if (!isOwner) return m.reply("❌ Fitur eksklusif khusus Owner bosku!");
    let client = sock || conn;

    // Keamanan jika config belum dipasang
    if (!global.subdomain || Object.keys(global.subdomain).length === 0) {
        return m.reply("❌ Konfigurasi *global.subdomain* belum disetting di config.js bosku!");
    }

    switch (command) {
        // 🟢 1. MENU PEMILIHAN DOMAIN
        case 'subdo':
        case 'subdomain': {
            if (!text || !text.includes("|")) return m.reply(`❗ *Format Salah!*\nContoh: \`${prefix + command} hostname|192.168.1.1\``);

            const obj = Object.keys(global.subdomain);
            const hostname = text.split("|")[0].toLowerCase().trim();
            const ip = text.split("|")[1].trim();

            // Bikin list menu pop-up (Single Select)
            const rows = obj.map((domain, index) => ({
                header: "",
                title: `🌐 ${domain}`,
                description: `Hasil: https://${hostname}.${domain}`,
                id: `.subdomain-response ${index + 1} ${hostname}|${ip}`
            }));

            let msg = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: {
                    message: {
                        "messageContextInfo": { "deviceListMetadata": {}, "deviceListMetadataVersion": 2 },
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            body: proto.Message.InteractiveMessage.Body.create({
                                text: `╭──「 *🌐 SUBDOMAIN MANAGER* 」\n│\n│ 🏷️ *Host:* ${hostname}\n│ 📡 *IP VPS:* ${ip}\n│\n╰────────────🚀\n\nSilakan pilih domain utama yang ingin digunakan melalui menu di bawah ini:`
                            }),
                            footer: proto.Message.InteractiveMessage.Footer.create({
                                text: "© ZeroixDark Marketplace"
                            }),
                            header: proto.Message.InteractiveMessage.Header.create({ title: "", subtitle: "", hasMediaAttachment: false }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                buttons: [
                                    {
                                        "name": "single_select",
                                        "buttonParamsJson": JSON.stringify({
                                            title: "Pilih Domain",
                                            sections: [{ title: "List Domain Tersedia", rows: rows }]
                                        })
                                    }
                                ]
                            })
                        })
                    }
                }
            }, { quoted: m });

            await client.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
            break;
        }

        // 🟢 2. EKSEKUSI API CLOUDFLARE
        case 'subdomain-response': {
            if (!text) return;
            
            let indexData = args[0];
            let payload = args[1]; // isinya: hostname|ip
            
            if (!indexData || isNaN(indexData)) return m.reply("❌ Domain tidak ditemukan!");
            const dom = Object.keys(global.subdomain);
            const domainIndex = Number(indexData) - 1;
            
            if (domainIndex >= dom.length || domainIndex < 0) return m.reply("❌ Domain tidak terdaftar di config!");
            if (!payload || !payload.includes("|")) return m.reply("❌ Hostname/IP Tidak valid!");

            await m.react("⏳").catch(() => {});

            let tldnya = dom[domainIndex];
            const [host, ip] = payload.split("|").map(str => str.trim());

            // Mesin Tembak API Cloudflare
            async function createSubdomain(subhost, targetIp) {
                try {
                    let response = await axios.post(
                        `https://api.cloudflare.com/client/v4/zones/${global.subdomain[tldnya].zone}/dns_records`,
                        {
                            type: "A",
                            name: `${subhost.replace(/[^a-z0-9.-]/gi, "")}.${tldnya}`,
                            content: targetIp.replace(/[^0-9.]/gi, ""),
                            ttl: 3600,
                            priority: 10,
                            proxied: false, // Matikan proxy biar IP panel kebaca asli
                        },
                        {
                            headers: {
                                Authorization: `Bearer ${global.subdomain[tldnya].apitoken}`,
                                "Content-Type": "application/json",
                            },
                        }
                    );
                    let res = response.data;
                    if (res.success) return { success: true, name: res.result.name, ip: res.result.content };
                    return { success: false, error: "Gagal membuat subdomain." };
                } catch (error) {
                    let errorMsg = error.response?.data?.errors?.[0]?.message || error.message || "Terjadi kesalahan API Cloudflare!";
                    return { success: false, error: errorMsg };
                }
            }

            // Bikin Node Acak (Fix pengganti fungsi getRandom yang error di sc asli)
            let randomKarakter = Math.random().toString(36).substring(2, 6);
            const domnode = `node${randomKarakter}.${host}`;
            
            let panelDomain = "";
            let nodeDomain = "";

            // Eksekusi dua kali: 1 untuk Panel, 1 untuk Node
            for (let i = 0; i < 2; i++) {
                let subHost = i === 0 ? host : domnode;
                let result = await createSubdomain(subHost, ip);
                
                if (result.success) {
                    if (i === 0) panelDomain = result.name;
                    else nodeDomain = result.name;
                } else {
                    await m.react("❌").catch(() => {});
                    return m.reply(`❌ *Gagal:* ${result.error}`);
                }
            }

            // Pesan Hasil + Tombol Copy Canggih
            let teks = `╭──「 *✅ SUBDOMAIN CREATED* 」\n`;
            teks += `│\n`;
            teks += `│ 📡 *IP VPS:* ${ip}\n`;
            teks += `│ 🌐 *Panel:* ${panelDomain}\n`;
            teks += `│ ⚙️ *Node:* ${nodeDomain}\n`;
            teks += `│\n`;
            teks += `╰────────────🚀\n\n_Klik tombol di bawah ini untuk menyalin nama domain!_`;

            let msgFinal = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: {
                    message: {
                        "messageContextInfo": { "deviceListMetadata": {}, "deviceListMetadataVersion": 2 },
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
                            footer: proto.Message.InteractiveMessage.Footer.create({ text: "© ZeroixDark Marketplace" }),
                            header: proto.Message.InteractiveMessage.Header.create({ title: "", subtitle: "", hasMediaAttachment: false }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                buttons: [
                                    { 
                                        name: "cta_copy",
                                        buttonParamsJson: `{"display_text":"📄 COPY PANEL","copy_code":"${panelDomain}"}`
                                    },
                                    { 
                                        name: "cta_copy",
                                        buttonParamsJson: `{"display_text":"📄 COPY NODE","copy_code":"${nodeDomain}"}`
                                    }
                                ]
                            })
                        })
                    }
                }
            }, { quoted: m });

            await client.relayMessage(msgFinal.key.remoteJid, msgFinal.message, { messageId: msgFinal.key.id });
            await m.react("✅").catch(() => {});
            break;
        }
    }
}

handler.command = ['subdo', 'subdomain', 'subdomain-response'];
handler.tags = "owner"
handler.owner = true; // Fix keamanan: Hanya bosku yang bisa pakai

module.exports = handler;
