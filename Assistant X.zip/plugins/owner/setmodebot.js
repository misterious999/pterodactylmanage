// ==========================================
// ⚙️ FITUR KONTROL AKSES (ONLY GC / ONLY PC)
// ==========================================

let handler = async (m, { sock, args, command, prefix }) => {
    // Memastikan database setting tersedia
    global.db = global.db || {};
    global.db.settings = global.db.settings || {};
    let set = global.db.settings;

    let action = args[0] ? args[0].toLowerCase() : '';
    let isEnable = action === 'on' || action === 'enable';
    let isDisable = action === 'off' || action === 'disable';

    // Validasi format perintah
    if (!action || (!isEnable && !isDisable)) {
        await m.react("⚠️");
        let panduan = `╭───┈ *「 ⚙️ KONTROL MODE 」*\n`;
        panduan += `│ ❌ Format perintah salah!\n`;
        panduan += `├───────────────┈ ⳹\n`;
        panduan += `│ *Gunakan Format Berikut:*\n`;
        panduan += `│ ◦ \`${prefix + command} on\` : Mengaktifkan\n`;
        panduan += `│ ◦ \`${prefix + command} off\` : Mematikan\n`;
        panduan += `╰───────────────┈ ⳹`;
        return m.reply(panduan);
    }

    await m.react("⏳");

    if (command === 'onlygc') {
        if (isEnable) {
            set.onlygc = true;
            set.onlypc = false; // Mematikan onlypc secara paksa agar tidak tabrakan
            m.reply("✅ *MODE ONLY GROUP AKTIF!*\n\nBot sekarang hanya akan merespon perintah yang dikirim dari dalam Grup.\n_(Fitur Only PC otomatis dimatikan)_");
        } else {
            set.onlygc = false;
            m.reply("✅ *MODE ONLY GROUP MATI!*\n\nBot kembali merespon di semua obrolan (Grup & PC).");
        }
    }

    if (command === 'onlypc') {
        if (isEnable) {
            set.onlypc = true;
            set.onlygc = false; // Mematikan onlygc secara paksa agar tidak tabrakan
            m.reply("✅ *MODE ONLY PRIVATE AKTIF!*\n\nBot sekarang hanya akan merespon perintah yang dikirim dari Chat Pribadi.\n\n_(Fitur Only GC otomatis dimatikan)_");
        } else {
            set.onlypc = false;
            m.reply("✅ *MODE ONLY PRIVATE MATI!*\n\nBot kembali merespon di semua obrolan (Grup & PC).");
        }
    }
    
    await m.react("✅");
}

handler.command = ["onlygc", "onlypc"];
handler.tags = ["owner"];
handler.help = ["onlygc <on/off>", "onlypc <on/off>"];
handler.owner = true; // WAJIB! Hanya bosku (Owner) yang bisa mengaktifkan ini

module.exports = handler;
