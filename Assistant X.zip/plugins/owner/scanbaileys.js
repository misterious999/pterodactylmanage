const baileys = require('@whiskeysockets/baileys');

const handler = async (m, { isOwner }) => {
    // Matiin dulu sementar isOwner kalau lu masih kena kutukan LID "Member Standar"
    // if (!isOwner) return m.reply("Fitur intelijen X-Ray ini cuma buat Bos Besar!");

    m.reply("⏳ *Mengekstrak jeroan Baileys...*");

    try {
        // Nge-scan semua object/function yang diexport sama module Baileys
        const extractedModules = Object.keys(baileys).sort();
        
        let teks = `🔍 *BAILEYS X-RAY SCANNER* 🔍\n\n`;
        teks += `📦 *Engine:* @whiskeysockets/baileys\n`;
        teks += `⚙️ *Total Modul Terdeteksi:* ${extractedModules.length} Fitur\n\n`;
        teks += `📋 *Daftar Fungsi/Modul:* \n`;
        teks += `\`\`\`${extractedModules.map((v, i) => `${i + 1}. ${v}`).join('\n')}\`\`\`\n\n`;
        teks += `💡 *Tips:* Kalau lu nemu fungsi kayak 'sendCarousel' atau 'generateWAMessage', berarti fitur UI mahal bisa dipakai!`;

        // Pake m.reply biar aman sentosa, gausah manggil conn/sock lagi
        await m.reply(teks); 
    } catch (e) {
        console.error(e);
        m.reply("❌ Gagal menembus inti mesin Baileys bosku!");
    }
};

handler.help = ['scanbaileys'];
handler.tags = ['owner', 'tools'];
handler.command = ['scanbaileys']; 

module.exports = handler;
