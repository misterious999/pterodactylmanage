let handler = async (m, { sock, text, prefix, command, isOwner }) => {
    // 1. Sama seperti: if (!isCreator) return Reply(mess.owner)
    if (!isOwner) return m.reply("❌ *Akses Ditolak!*\nFitur ini khusus Owner.");
    
    // 2. Sama seperti: if (!text) return Reply(example("https://chat.whatsapp.com/xxxxx"))
    if (!text) return m.reply(`*Contoh penggunaan:*\n${prefix}${command} https://chat.whatsapp.com/xxxxx`);

    // 3. Regex ambil kode undangan (selaras 100% dengan case bosku)
    let match = text.match(/chat\.whatsapp\.com\/([0-9A-Za-z]+)/i);
    if (!match) return m.reply("❌ Link tautan tidak valid!");

    await m.react('⏳');
    try {
        // 4. Eksekusi Join (sock di sini fungsinya sama persis dengan alip)
        let res = await sock.groupAcceptInvite(match[1]);
        
        await m.react('✅');
        m.reply(`✅ Berhasil join ke grup!\nID: ${res}`);

    } catch (e) {
        console.error("Error join:", e);
        await m.react('❌');
        
        // Tetap Mini pertahankan alarm peringatan limit dari Meta 
        if (String(e).includes('account_reachout_restricted') || (e.output && e.output.statusCode === 463)) {
            m.reply("❌ Gagal join!\n⚠️ *LIMIT META AKTIF* ⚠️\nNomor bot sedang terkena cooldown anti-spam dari WhatsApp. Silakan masukkan bot secara manual (Add Peserta).");
        } else {
            // Sama seperti: Reply("❌ Gagal join! Link mungkin sudah expired atau invalid.")
            m.reply("❌ Gagal join! Link mungkin sudah expired atau invalid.");
        }
    }
}

handler.help = ['join <link>'];
handler.tags = ['owner'];
handler.command = ['join', 'joingc']; 
handler.owner = true; 

module.exports = handler;
