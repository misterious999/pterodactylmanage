// ==========================================
// 🏁 TURNAMEN MANCING GLOBAL (GROUP EVENT)
// ⚙️ COMPETITIVE MULTIPLAYER FISHING SYSTEM
// ==========================================

global.turnamenMancing = global.turnamenMancing || {};

let handler = async (m, { sock, args, prefix, command, isAdmin, isOwner }) => {
    let chatId = m.chat;
    let user = global.db.users[m.sender];
    
    if (!user || !user.registered) return m.reply("❌ Daftar dulu Bosku sebelum ikut turnamen!");

    // Database Hadiah & Target Turnamen
    const poolTurnamen = [
        { name: "🐡 Ikan Mas Koki", min: 5, max: 10, reward: 5000000, limit: 20 },
        { name: "🦈 Hiu Putih", min: 2, max: 5, reward: 15000000, limit: 50 },
        { name: "🐳 Paus Biru", min: 2, max: 4, reward: 25000000, limit: 80 },
        { name: "🦑 Kraken", min: 1, max: 2, reward: 50000000, limit: 150 },
        { name: "🦖 Megalodon", min: 1, max: 1, reward: 100000000, limit: 300 } // JACKPOT!
    ];

    let event = global.turnamenMancing[chatId];
    let action = args[0] ? args[0].toLowerCase() : '';

    // ==========================================
    // 1️⃣ LOGIKA MEMULAI TURNAMEN (ADMIN ONLY)
    // ==========================================
    if (command === 'startturnamen' || action === 'start') {
        if (!isAdmin && !isOwner) return m.reply("❌ Hanya Admin Grup atau Owner yang bisa memulai turnamen mancing!");
        if (event && event.active) return m.reply("⚠️ Turnamen masih berlangsung di grup ini! Selesaikan dulu atau ketik `.stopturnamen`.");

        // Gacha Target & Hadiah
        let target = poolTurnamen[Math.floor(Math.random() * poolTurnamen.length)];
        let amount = Math.floor(Math.random() * (target.max - target.min + 1)) + target.min;

        global.turnamenMancing[chatId] = {
            active: true,
            fishName: target.name,
            reqAmount: amount,
            rewardSaldo: target.reward,
            rewardLimit: target.limit,
            startTime: Date.now()
        };

        let teksStart = `╭───┈ *「 📢 TURNAMEN MANCING DIMULAI! 」*\n`;
        teksStart += `│ Admin telah membuka turnamen di danau grup ini!\n`;
        teksStart += `│ \n`;
        teksStart += `│ 🎯 *TARGET:* Siapa cepat mengumpulkan\n`;
        teksStart += `│ 🐟 *${amount}x ${target.name}*\n`;
        teksStart += `│ \n`;
        teksStart += `│ 🎁 *HADIAH JACKPOT:*\n`;
        teksStart += `│ 💰 Rp ${target.reward.toLocaleString('id-ID')}\n`;
        teksStart += `│ 🎟️ ${target.limit} Limit\n`;
        teksStart += `╰───────────────┈ ⳹\n\n`;
        teksStart += `_Mancinglah sekarang! Jika ikanmu sudah cukup, ketik cepat \`${prefix}klaimturnamen\` untuk menang!_`;

        return sock.sendMessage(m.chat, { text: teksStart });
    }

    // ==========================================
    // 2️⃣ LOGIKA KLAIM KEMENANGAN (ADU CEPAT)
    // ==========================================
    else if (command === 'klaimturnamen' || action === 'klaim') {
        if (!event || !event.active) return m.reply("❌ Tidak ada turnamen yang sedang berlangsung di grup ini!");

        let inv = user.rpg?.inventory || {};
        let stokUser = inv[event.fishName] || 0;

        if (stokUser < event.reqAmount) {
            return m.reply(`❌ Ikanmu belum cukup!\nTarget: *${event.reqAmount}x ${event.fishName}*\nStok kamu: *${stokUser} ekor*.\n\nAyo mancing lagi sebelum keduluan orang lain!`);
        }

        // POTONG IKAN & BERIKAN HADIAH
        user.rpg.inventory[event.fishName] -= event.reqAmount;
        user.balance = (user.balance || 0) + event.rewardSaldo;
        user.limit = (user.limit || 0) + event.rewardLimit;

        // MATIKAN TURNAMEN
        global.turnamenMancing[chatId].active = false;
        
        let durasi = Math.floor((Date.now() - event.startTime) / 60000); // dalam menit

        let teksMenang = `╭───┈ *「 🏆 PEMENANG TURNAMEN! 」*\n`;
        teksMenang += `│ 🎉 KITA PUNYA SANG JUARA!\n`;
        teksMenang += `│ 👤 *Pemenang:* @${m.sender.split('@')[0]}\n`;
        teksMenang += `│ ⏱️ *Waktu Diselesaikan:* ${durasi} Menit\n`;
        teksMenang += `│ \n`;
        teksMenang += `│ 🎁 *JACKPOT DICAIRKAN:*\n`;
        teksMenang += `│ 💰 +Rp ${event.rewardSaldo.toLocaleString('id-ID')}\n`;
        teksMenang += `│ 🎟️ +${event.rewardLimit} Limit\n`;
        teksMenang += `╰───────────────┈ ⳹\n\n`;
        teksMenang += `_Turnamen resmi ditutup! Tunggu info turnamen selanjutnya dari Admin!_`;

        return sock.sendMessage(m.chat, { text: teksMenang, mentions: [m.sender] });
    }

    // ==========================================
    // 3️⃣ LOGIKA CEK INFO TURNAMEN
    // ==========================================
    else if (command === 'infoturnamen' || action === 'info') {
        if (!event || !event.active) return m.reply("❌ Tidak ada turnamen yang sedang berlangsung saat ini.");

        let teksInfo = `╭───┈ *「 🏁 INFO TURNAMEN AKTIF 」*\n`;
        teksInfo += `│ 🎯 *Target:* ${event.reqAmount}x ${event.fishName}\n`;
        teksInfo += `│ 🎁 *Hadiah:* Rp ${event.rewardSaldo.toLocaleString('id-ID')} & ${event.rewardLimit} Limit\n`;
        teksInfo += `╰───────────────┈ ⳹\n\n`;
        teksInfo += `_Kumpulkan ikannya dan ketik \`${prefix}klaimturnamen\` untuk menang!_`;

        return sock.sendMessage(m.chat, { text: teksInfo });
    }

    // ==========================================
    // 4️⃣ LOGIKA MENGHENTIKAN TURNAMEN (ADMIN ONLY)
    // ==========================================
    else if (command === 'stopturnamen') {
        if (!isAdmin && !isOwner) return m.reply("❌ Hanya Admin Grup atau Owner yang bisa menghentikan turnamen!");
        if (!event || !event.active) return m.reply("❌ Tidak ada turnamen yang sedang berjalan.");

        global.turnamenMancing[chatId].active = false;
        return m.reply("🛑 *Turnamen dibatalkan paksa oleh Admin!*");
    }

    else {
        return m.reply(`*🏁 MENU TURNAMEN MANCING*\n\n▧ \`${prefix}startturnamen\` ➪ Memulai event (Admin)\n▧ \`${prefix}infoturnamen\` ➪ Cek target saat ini\n▧ \`${prefix}klaimturnamen\` ➪ Setor ikan & Ambil Jackpot!\n▧ \`${prefix}stopturnamen\` ➪ Hentikan event (Admin)`);
    }
}

handler.help = ['turnamenmancing'];
handler.tags = ['mancing'];
handler.command = ['turnamenmancing', 'startturnamen', 'infoturnamen', 'klaimturnamen', 'stopturnamen'];
handler.group = true; // 🔥 HANYA BISA DIMAINKAN DI DALAM GRUP

module.exports = handler;
