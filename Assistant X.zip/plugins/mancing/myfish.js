// ==========================================
// 🐟 FITUR LIST IKAN (RPG INVENTORY VIEW)
// ⚙️ V3: DENGAN TIER LIST & LEGEND INFOMATION
// ==========================================

let handler = async (m, { sock, prefix, command }) => {
    let user = global.db.users[m.sender];
    
    if (!user || !user.registered) return m.reply("❌ Daftar dulu Bosku!");

    // Ambil data inventory dari database RPG
    let inventory = user.rpg && user.rpg.inventory ? user.rpg.inventory : {};
    
    // Database Pemetaan Ikan & Tier (Rarity)
    const fishDatabase = {
        "🥾 Sepatu Bekas": "Sampah 🗑️",
        "🐟 Ikan Lele": "Common ⚪",
        "🐠 Ikan Nila": "Common ⚪",
        "🐡 Ikan Mas Koki": "Rare 🔵",
        "🦈 Hiu Putih": "Epic 🟣",
        "🐳 Paus Biru": "Epic 🟣",
        "🦑 Kraken": "Mythic 🟡",
        "🦖 Megalodon": "Mythic 🟡"
    };

    // Filter tas: Hanya ambil nama ikan yang ada di database kita
    let myFish = Object.keys(inventory).filter(item => Object.keys(fishDatabase).includes(item));

    if (myFish.length === 0) {
        return m.reply(`🎣 *Ehh? Tas Ikanmu Kosong!*\nSepertinya kamu belum pernah menangkap ikan apapun. Ketik \`${prefix}mancing\` sekarang!`);
    }

    let teks = `╭───┈ *「 🎒 ISI TAS IKANMU 」*\n`;
    teks += `│ 👤 *Owner:* @${m.sender.split('@')[0]}\n`;
    teks += `│ \n`;

    let totalIkan = 0;
    
    // Looping daftar ikan untuk dirender ke teks
    myFish.forEach((fish, index) => {
        let jumlah = inventory[fish];
        let tier = fishDatabase[fish]; 
        totalIkan += jumlah;
        
        teks += `│ ${index + 1}. ${fish}\n`;
        teks += `│    └─ *Tier:* ${tier} | *Total:* ${jumlah} ekor\n`;
    });

    teks += `│ \n`;
    teks += `│ 📊 *Total Muatan Tas:* ${totalIkan} Item\n`;
    teks += `╰───────────────┈ ⳹\n\n`;

    // 🔥 TAMBAHAN INFORMASI TIER LIST DI BAWAH 🔥
    teks += `╭───┈ *「 📜 INFO TIER KELANGKAAN 」*\n`;
    teks += `│ 🟡 *Mythic* : Legendaris / Paling Langka\n`;
    teks += `│ 🟣 *Epic* : Sangat Langka\n`;
    teks += `│ 🔵 *Rare* : Jarang Ditemukan\n`;
    teks += `│ ⚪ *Common* : Biasa / Mudah Didapat\n`;
    teks += `│ 🗑️ *Sampah* : Barang Rongsokan\n`;
    teks += `╰───────────────┈ ⳹\n\n`;

    teks += `_Tips: Pamerkan tangkapan Mythic-mu ke member lain!_`;

    await sock.sendMessage(m.chat, { text: teks, mentions: [m.sender] }, { quoted: m });
}

handler.help = ['listikan'];
handler.tags = ['mancing'];
handler.command = ['listikan', 'myfish', 'tasikan', 'hasilmancing'];

module.exports = handler;
