// ==========================================
// 🏪 TOKO MANCING (BUY, SELL, UPGRADE)
// ⚙️ ALL-IN-ONE FISHING ECONOMY SYSTEM
// ==========================================

let handler = async (m, { sock, args, prefix, command }) => {
    let user = global.db.users[m.sender];
    if (!user || !user.registered) return m.reply("❌ Daftar dulu Bosku sebelum masuk ke toko!");

    // Inisialisasi Database User jika belum ada
    user.rpg = user.rpg || { inventory: {} };
    user.rpg.pancingan = user.rpg.pancingan || { kail: 1, koil: 1, gagang: 1 };
    
    let inventory = user.rpg.inventory;
    let gear = user.rpg.pancingan;
    let balance = user.balance || 0;

    // 📦 DATABASE BARANG TOKO
    const shopUmpan = {
        "cacing": { nama: "🪱 Umpan Cacing (Common)", harga: 500, id: "umpan_cacing" },
        "pelet": { nama: "🍘 Umpan Pelet (Rare)", harga: 2500, id: "umpan_pelet" },
        "udang": { nama: "🦐 Umpan Udang (Epic)", harga: 10000, id: "umpan_udang" },
        "daging": { nama: "🥩 Daging Monster (Mythic)", harga: 50000, id: "umpan_daging" }
    };

    // 🐟 DATABASE HARGA JUAL IKAN (Sesuai dengan mancing.js)
    const sellFish = {
        "sepatu": { nama: "🥾 Sepatu Bekas", harga: 100 },
        "lele": { nama: "🐟 Ikan Lele", harga: 500 },
        "nila": { nama: "🐠 Ikan Nila", harga: 800 },
        "koki": { nama: "🐡 Ikan Mas Koki", harga: 2500 },
        "hiu": { nama: "🦈 Hiu Putih", harga: 15000 },
        "paus": { nama: "🐳 Paus Biru", harga: 25000 },
        "kraken": { nama: "🦑 Kraken", harga: 100000 },
        "megalodon": { nama: "🦖 Megalodon", harga: 150000 }
    };

    // 🔨 BIAYA UPGRADE ALAT PANCING (Per Level)
    const upgradeCost = { 1: 10000, 2: 50000, 3: 200000, 4: 1000000, 5: "MAX" };

    // ==========================================
    // 📖 MENU UTAMA TOKO (JIKA TIDAK ADA ARGUMEN)
    // ==========================================
    if (!args[0]) {
        let teksMenu = `╭───┈ *「 🏪 TOKO MANCING XENORIA 」*\n`;
        teksMenu += `│ 💰 *Saldomu:* Rp ${balance.toLocaleString('id-ID')}\n`;
        teksMenu += `╰───────────────┈ ⳹\n\n`;

        teksMenu += `╭───┈ *「 🛒 BELI UMPAN 」*\n`;
        for (let key in shopUmpan) {
            teksMenu += `│ ▧ *${key}* : Rp ${shopUmpan[key].harga.toLocaleString('id-ID')}\n`;
            teksMenu += `│   └─ ${shopUmpan[key].nama}\n`;
        }
        teksMenu += `│ 📌 *Cara:* \`${prefix}${command} beli <nama> <jumlah>\`\n`;
        teksMenu += `╰───────────────┈ ⳹\n\n`;

        teksMenu += `╭───┈ *「 🔨 UPGRADE ALAT PANCING 」*\n`;
        teksMenu += `│ ▧ *Kail* (Lv.${gear.kail}) ➪ Rp ${upgradeCost[gear.kail] ? upgradeCost[gear.kail].toLocaleString('id-ID') : 'MAX'}\n`;
        teksMenu += `│ ▧ *Koil* (Lv.${gear.koil}) ➪ Rp ${upgradeCost[gear.koil] ? upgradeCost[gear.koil].toLocaleString('id-ID') : 'MAX'}\n`;
        teksMenu += `│ ▧ *Gagang* (Lv.${gear.gagang}) ➪ Rp ${upgradeCost[gear.gagang] ? upgradeCost[gear.gagang].toLocaleString('id-ID') : 'MAX'}\n`;
        teksMenu += `│ 📌 *Cara:* \`${prefix}${command} upgrade <kail/koil/gagang>\`\n`;
        teksMenu += `╰───────────────┈ ⳹\n\n`;

        teksMenu += `╭───┈ *「 ⚖️ JUAL TANGKAPAN 」*\n`;
        teksMenu += `│ ▧ Harga Jual Ikan Bervariasi!\n`;
        teksMenu += `│ ▧ *sepatu, lele, nila, koki, hiu, paus, kraken, megalodon*\n`;
        teksMenu += `│ 📌 *Cara:* \`${prefix}${command} jual <nama_ikan> <jumlah>\`\n`;
        teksMenu += `│ 📌 *Jual Semua:* \`${prefix}${command} jualall\`\n`;
        teksMenu += `╰───────────────┈ ⳹`;

        return sock.sendMessage(m.chat, { text: teksMenu }, { quoted: m });
    }

    let action = args[0].toLowerCase();
    let item = args[1] ? args[1].toLowerCase() : null;
    let amount = args[2] ? parseInt(args[2]) : 1;

    if (amount < 1 || isNaN(amount)) return m.reply("❌ Jumlah harus berupa angka minimal 1!");

    // ==========================================
    // 🛒 LOGIKA MEMBELI UMPAN
    // ==========================================
    if (action === 'beli' || action === 'buy') {
        if (!item || !shopUmpan[item]) return m.reply("❌ Barang tidak ditemukan di toko! Cek daftar umpan.");
        
        let targetItem = shopUmpan[item];
        let totalHarga = targetItem.harga * amount;

        if (user.balance < totalHarga) return m.reply(`❌ Saldomu kurang! Total harga: Rp ${totalHarga.toLocaleString('id-ID')}`);

        user.balance -= totalHarga;
        user.rpg.inventory[targetItem.id] = (user.rpg.inventory[targetItem.id] || 0) + amount;

        return m.reply(`✅ *PEMBELIAN BERHASIL!*\nKamu membeli *${amount}x ${targetItem.nama}*\n💸 Total Biaya: -Rp ${totalHarga.toLocaleString('id-ID')}\n💰 Sisa Saldo: Rp ${user.balance.toLocaleString('id-ID')}`);
    }

    // ==========================================
    // ⚖️ LOGIKA MENJUAL IKAN
    // ==========================================
    else if (action === 'jual' || action === 'sell') {
        if (!item || !sellFish[item]) return m.reply("❌ Ikan tidak valid! Cek daftar nama ikan yang bisa dijual.");

        let targetFish = sellFish[item];
        let stok = inventory[targetFish.nama] || 0;

        if (stok < amount) return m.reply(`❌ Kamu tidak memiliki cukup *${targetFish.nama}*! Stokmu: ${stok}`);

        let totalDapat = targetFish.harga * amount;
        user.rpg.inventory[targetFish.nama] -= amount;
        user.balance += totalDapat;

        return m.reply(`✅ *PENJUALAN BERHASIL!*\nKamu menjual *${amount}x ${targetFish.nama}*\n🤑 Pendapatan: +Rp ${totalDapat.toLocaleString('id-ID')}\n💰 Saldo Sekarang: Rp ${user.balance.toLocaleString('id-ID')}`);
    }

    // ==========================================
    // 💸 LOGIKA JUAL SEMUA IKAN (SELL ALL)
    // ==========================================
    else if (action === 'jualall' || action === 'sellall') {
        let totalPendapatan = 0;
        let ikanTerjual = 0;
        let rincian = "";

        for (let key in sellFish) {
            let namaAsli = sellFish[key].nama;
            let harga = sellFish[key].harga;
            let stok = inventory[namaAsli] || 0;

            if (stok > 0) {
                let untung = stok * harga;
                totalPendapatan += untung;
                ikanTerjual += stok;
                inventory[namaAsli] = 0; // Kosongkan ikan dari tas
                rincian += `│ ▧ ${stok}x ${namaAsli} (+Rp ${untung.toLocaleString('id-ID')})\n`;
            }
        }

        if (ikanTerjual === 0) return m.reply("❌ Tas ikanmu kosong! Tidak ada yang bisa dijual.");

        user.balance += totalPendapatan;

        let teksSellAll = `╭───┈ *「 ⚖️ JUAL BORONGAN SUKSES! 」*\n`;
        teksSellAll += rincian;
        teksSellAll += `│ \n`;
        teksSellAll += `│ 🤑 *Total Pendapatan:* +Rp ${totalPendapatan.toLocaleString('id-ID')}\n`;
        teksSellAll += `│ 💰 *Saldo Sekarang:* Rp ${user.balance.toLocaleString('id-ID')}\n`;
        teksSellAll += `╰───────────────┈ ⳹`;

        return sock.sendMessage(m.chat, { text: teksSellAll }, { quoted: m });
    }

    // ==========================================
    // 🔨 LOGIKA UPGRADE ALAT PANCING
    // ==========================================
    else if (action === 'upgrade') {
        if (!['kail', 'koil', 'gagang'].includes(item)) return m.reply("❌ Alat yang bisa diupgrade hanya: *kail, koil, gagang*.");

        let currentLevel = gear[item];
        if (currentLevel >= 5) return m.reply(`🌟 *${item.toUpperCase()}* milikmu sudah mencapai Level MAX!`);

        let cost = upgradeCost[currentLevel];
        if (user.balance < cost) return m.reply(`❌ Saldomu kurang! Butuh *Rp ${cost.toLocaleString('id-ID')}* untuk upgrade ke Level ${currentLevel + 1}.`);

        user.balance -= cost;
        gear[item] += 1; // Naikkan level

        return m.reply(`✅ *UPGRADE BERHASIL!* 🔨\n*${item.toUpperCase()}* milikmu telah dinaikkan ke *Level ${gear[item]}*!\n💸 Biaya: -Rp ${cost.toLocaleString('id-ID')}`);
    }

    else {
        return m.reply(`❌ Perintah tidak dikenal!\nKetik \`${prefix}${command}\` untuk melihat panduan toko.`);
    }
}

handler.help = ['tokopancing'];
handler.tags = ['mancing'];
handler.command = ['tokomancing', 'tokopancing', 'shopikan', 'fishshop'];

module.exports = handler;
