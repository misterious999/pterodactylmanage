// ==========================================
// 🏛️ AKUARIUM SULTAN (PASSIVE INCOME SYSTEM)
// ⚙️ V2: DENGAN SISTEM ALIAS ANTI-TYPO
// ==========================================

let handler = async (m, { sock, args, prefix, command }) => {
    let user = global.db.users[m.sender];
    if (!user || !user.registered) return m.reply("❌ Daftar dulu Bosku!");

    // Inisialisasi Database Akuarium
    user.rpg = user.rpg || { inventory: {} };
    user.rpg.aquarium = user.rpg.aquarium || {
        slots: 2,
        fishes: [], 
        lastClaim: Date.now(),
        unclaimed: 0
    };

    let aq = user.rpg.aquarium;
    let inv = user.rpg.inventory;

    // DATABASE INCOME PER JAM
    const fishStats = {
        "🥾 Sepatu Bekas": { tier: "Sampah", income: 10 },
        "🐟 Ikan Lele": { tier: "Common", income: 100 },
        "🐠 Ikan Nila": { tier: "Common", income: 100 },
        "🐡 Ikan Mas Koki": { tier: "Rare", income: 500 },
        "🦈 Hiu Putih": { tier: "Epic", income: 2500 },
        "🐳 Paus Biru": { tier: "Epic", income: 2500 },
        "🦑 Kraken": { tier: "Mythic", income: 10000 },
        "🦖 Megalodon": { tier: "Mythic", income: 10000 }
    };

    // 🔥 SISTEM ALIAS: Menerjemahkan ketikan user ke nama asli Database
    const fishAlias = {
        "sepatu bekas": "🥾 Sepatu Bekas", "sepatu": "🥾 Sepatu Bekas",
        "ikan lele": "🐟 Ikan Lele", "lele": "🐟 Ikan Lele",
        "ikan nila": "🐠 Ikan Nila", "nila": "🐠 Ikan Nila",
        "ikan mas koki": "🐡 Ikan Mas Koki", "mas koki": "🐡 Ikan Mas Koki", "koki": "🐡 Ikan Mas Koki",
        "hiu putih": "🦈 Hiu Putih", "hiu": "🦈 Hiu Putih",
        "paus biru": "🐳 Paus Biru", "paus": "🐳 Paus Biru",
        "kraken": "🦑 Kraken",
        "megalodon": "🦖 Megalodon"
    };

    // 🕒 HITUNG PENDAPATAN YANG MENUMPUK (REAL-TIME)
    let totalIncomePerJam = aq.fishes.reduce((a, b) => a + b.income, 0);
    let msPassed = Date.now() - aq.lastClaim;
    let hoursPassed = msPassed / 3600000;
    let currentEarned = Math.floor(hoursPassed * totalIncomePerJam);

    let action = args[0] ? args[0].toLowerCase() : '';

    // ==========================================
    // 1️⃣ LOGIKA CLAIM SALDO
    // ==========================================
    if (action === 'claim' || action === 'ambil') {
        if (currentEarned < 100) return m.reply("❌ Pendapatanmu masih terlalu kecil (Minimal Rp 100). Tunggu sebentar lagi!");

        user.balance = (user.balance || 0) + currentEarned;
        aq.lastClaim = Date.now();

        return m.reply(`✅ *CLAIM BERHASIL!* 💰\nKamu mencairkan hasil investasi akuarium sebesar *Rp ${currentEarned.toLocaleString('id-ID')}* ke saldo utama!`);
    }

    // ==========================================
    // 2️⃣ LOGIKA PAJANG IKAN (MASUKKAN KE AKUARIUM)
    // ==========================================
    else if (action === 'pajang' || action === 'simpan') {
        if (aq.fishes.length >= aq.slots) return m.reply(`❌ Akuarium penuh! Slotmu cuma ${aq.slots}. Upgrade slot pakai \`${prefix}${command} upgrade\`.`);
        
        let inputRaw = args.slice(1).join(" ").toLowerCase(); // Ambil input polosan (cth: "hiu putih")
        if (!inputRaw) return m.reply(`❌ Ketik nama ikan yang mau dipajang!\n*Contoh:* \`${prefix}${command} pajang hiu putih\``);

        // Terjemahkan input user ke nama asli yang ada Emojinya
        let realFishName = fishAlias[inputRaw];

        if (!realFishName) return m.reply(`❌ Nama ikan tidak dikenali! Pastikan ejaannya benar. (Contoh: lele, hiu putih, megalodon)`);

        if ((inv[realFishName] || 0) < 1) return m.reply(`❌ Kamu nggak punya *${realFishName}* di tas ikanmu!`);

        // Masukkan ke akuarium pakai nama asli
        let stats = fishStats[realFishName];
        aq.fishes.push({ name: realFishName, tier: stats.tier, income: stats.income });
        inv[realFishName] -= 1; 

        return m.reply(`✅ *BERHASIL DIPAJANG!* 🐟\n*${realFishName}* sekarang menghasilkan Rp ${stats.income.toLocaleString('id-ID')}/jam di akuariummu!`);
    }

    // ==========================================
    // 3️⃣ LOGIKA LEPAS IKAN (KEMBALIKAN KE TAS)
    // ==========================================
    else if (action === 'lepas' || action === 'ambilikan') {
        let index = parseInt(args[1]) - 1;
        if (isNaN(index) || !aq.fishes[index]) return m.reply("❌ Masukkan nomor slot ikan yang mau dilepas! Cek nomor di daftar akuarium.");

        let removed = aq.fishes.splice(index, 1)[0];
        inv[removed.name] = (inv[removed.name] || 0) + 1;

        return m.reply(`✅ *BERHASIL DILEPAS!*\n*${removed.name}* telah dikembalikan ke tas ikanmu.`);
    }

    // ==========================================
    // 4️⃣ LOGIKA UPGRADE SLOT
    // ==========================================
    else if (action === 'upgrade') {
        if (aq.slots >= 5) return m.reply("🌟 Akuariummu sudah mencapai batas maksimal (5 Slot)!");
        
        let costs = { 2: 500000, 3: 2000000, 4: 10000000 };
        let cost = costs[aq.slots];

        if (user.balance < cost) return m.reply(`❌ Saldomu kurang! Butuh Rp ${cost.toLocaleString('id-ID')} untuk nambah jadi ${aq.slots + 1} slot.`);

        user.balance -= cost;
        aq.slots += 1;
        return m.reply(`✅ *UPGRADE BERHASIL!* 🏛️\nSlot akuariummu sekarang menjadi *${aq.slots} Slot*!`);
    }

    // ==========================================
    // 🏛️ TAMPILAN UTAMA AKUARIUM
    // ==========================================
    else {
        let teks = `╭───┈ *「 🏛️ AKUARIUM SULTAN 」*\n`;
        teks += `│ 👤 *Owner:* @${m.sender.split('@')[0]}\n`;
        teks += `│ 💰 *Pendapatan:* Rp ${totalIncomePerJam.toLocaleString('id-ID')}/jam\n`;
        teks += `│ ⏳ *Tersedia:* Rp ${currentEarned.toLocaleString('id-ID')}\n`;
        teks += `╰───────────────┈ ⳹\n\n`;

        teks += `╭───┈ *「 🖼️ KOLEKSI PAJANGAN 」*\n`;
        for (let i = 0; i < aq.slots; i++) {
            let f = aq.fishes[i];
            if (f) {
                teks += `│ ${i + 1}. ${f.name}\n`;
                teks += `│    └─ [ ${f.tier} ] ➪ +Rp ${f.income}/jam\n`;
            } else {
                teks += `│ ${i + 1}. [ 🔓 SLOT KOSONG ]\n`;
            }
        }
        teks += `╰───────────────┈ ⳹\n\n`;

        teks += `*💡 PANDUAN AKUARIUM:* \n`;
        teks += `▧ \`${prefix}${command} claim\` ➪ Ambil saldo terkumpul\n`;
        teks += `▧ \`${prefix}${command} pajang <nama>\` ➪ Pajang ikan dari tas\n`;
        teks += `▧ \`${prefix}${command} lepas <nomor>\` ➪ Lepas ikan ke tas\n`;
        teks += `▧ \`${prefix}${command} upgrade\` ➪ Beli slot baru\n`;

        return sock.sendMessage(m.chat, { text: teks, mentions: [m.sender] }, { quoted: m });
    }
}

handler.help = ['akuarium'];
handler.tags = ['mancing'];
handler.command = ['akuarium', 'aquarium', 'pajangikan'];

module.exports = handler;
