// ==========================================
// 📜 PESANAN RESTORAN (FISHING DAILY QUEST)
// ⚙️ DYNAMIC QUEST GENERATOR & REWARD SYSTEM
// ==========================================

let handler = async (m, { sock, args, prefix, command }) => {
    let user = global.db.users[m.sender];
    if (!user || !user.registered) return m.reply("❌ Daftar dulu Bosku sebelum ambil misi dari Restoran!");

    // Inisialisasi Database Quest Mancing & Inventory
    user.rpg = user.rpg || { inventory: {} };
    user.rpg.questMancing = user.rpg.questMancing || {
        active: false,
        lastCompleted: 0,
        reqs: [],
        rewards: { saldo: 0, xp: 0, limit: 0 }
    };

    let quest = user.rpg.questMancing;
    let inventory = user.rpg.inventory;

    // ⏱️ PENGATURAN COOLDOWN (12 Jam)
    let cooldownWaktu = 43200000; // 12 Jam dalam milidetik
    let sisaWaktu = (quest.lastCompleted + cooldownWaktu) - Date.now();

    // DATABASE IKAN KHUSUS MISI
    const questPool = [
        { name: "🐟 Ikan Lele", min: 5, max: 15, basePrice: 500 },
        { name: "🐠 Ikan Nila", min: 5, max: 12, basePrice: 800 },
        { name: "🐡 Ikan Mas Koki", min: 2, max: 6, basePrice: 2500 },
        { name: "🦈 Hiu Putih", min: 1, max: 3, basePrice: 15000 },
        { name: "🐳 Paus Biru", min: 1, max: 2, basePrice: 25000 }
    ];

    // DATABASE TIER IKAN UNTUK TAMPILAN
    const fishRarity = {
        "🐟 Ikan Lele": "Common ⚪",
        "🐠 Ikan Nila": "Common ⚪",
        "🐡 Ikan Mas Koki": "Rare 🔵",
        "🦈 Hiu Putih": "Epic 🟣",
        "🐳 Paus Biru": "Epic 🟣"
    };

    let action = args[0] ? args[0].toLowerCase() : '';

    // ==========================================
    // 1️⃣ LOGIKA MENYETOR IKAN (SELESAIKAN MISI)
    // ==========================================
    if (action === 'setor' || action === 'selesai') {
        if (!quest.active) return m.reply("❌ Kamu tidak punya misi aktif yang harus disetor! Ketik pesanannya dulu.");

        // Cek apakah ikan di tas mencukupi
        let isCukup = true;
        let pesanKekurangan = "❌ *SETORAN DITOLAK BAPAK RESTORAN!*\nBahan masakanmu belum lengkap:\n\n";

        for (let req of quest.reqs) {
            let stokUser = inventory[req.name] || 0;
            if (stokUser < req.amount) {
                isCukup = false;
                let tier = fishRarity[req.name] || "Biasa";
                pesanKekurangan += `│ ▧ ${req.name} (${tier}): Kurang ${req.amount - stokUser} ekor lagi!\n`;
            }
        }

        if (!isCukup) return m.reply(pesanKekurangan);

        // Jika Cukup: Tarik ikan dari tas, berikan hadiah
        for (let req of quest.reqs) {
            inventory[req.name] -= req.amount;
        }

        user.balance = (user.balance || 0) + quest.rewards.saldo;
        user.xp = (user.xp || 0) + quest.rewards.xp;
        user.limit = (user.limit || 0) + quest.rewards.limit;

        // Reset misi & mulai cooldown
        quest.active = false;
        quest.lastCompleted = Date.now();
        quest.reqs = [];
        quest.rewards = { saldo: 0, xp: 0, limit: 0 };

        let teksBerhasil = `╭───┈ *「 👨‍🍳 PESANAN SELESAI! 」*\n`;
        teksBerhasil += `│ Bapak Restoran sangat senang dengan ikan segarmu!\n`;
        teksBerhasil += `│ \n`;
        // Proteksi jika rewardnya undefine di versi lama
        let totalSaldo = user.rpg.questMancing.rewards?.saldo || quest.rewards.saldo || 0;
        teksBerhasil += `│ 💰 *Bonus Saldo:* +Rp ${totalSaldo.toLocaleString('id-ID')} (Harga 2.5x Lipat!)\n`;
        teksBerhasil += `│ 📈 *Bonus EXP:* +${quest.rewards.xp}\n`;
        teksBerhasil += `│ 🎟️ *Bonus Limit:* +${quest.rewards.limit}\n`;
        teksBerhasil += `╰───────────────┈ ⳹\n\n`;
        teksBerhasil += `_Silakan kembali lagi nanti untuk pesanan berikutnya!_`;

        return sock.sendMessage(m.chat, { text: teksBerhasil }, { quoted: m });
    }

    // ==========================================
    // 2️⃣ LOGIKA CEK / GENERATE MISI BARU
    // ==========================================
    
    // Jika masih dalam masa cooldown dan tidak ada quest aktif
    if (!quest.active && sisaWaktu > 0) {
        let jam = Math.floor(sisaWaktu / (1000 * 60 * 60));
        let menit = Math.floor((sisaWaktu % (1000 * 60 * 60)) / (1000 * 60));
        return m.reply(`👨‍🍳 *RESTO TUTUP!*\nBos Restoran masih kenyang dan belum butuh bahan masakan.\n\n⏳ Silakan kembali dalam *${jam} Jam ${menit} Menit* lagi!`);
    }

    // Jika belum punya quest aktif (Generate baru!)
    if (!quest.active) {
        // Acak 2 ikan berbeda
        let f1 = questPool[Math.floor(Math.random() * questPool.length)];
        let f2 = questPool[Math.floor(Math.random() * questPool.length)];
        while (f1.name === f2.name) f2 = questPool[Math.floor(Math.random() * questPool.length)];

        // Acak jumlah yang diminta
        let amt1 = Math.floor(Math.random() * (f1.max - f1.min + 1)) + f1.min;
        let amt2 = Math.floor(Math.random() * (f2.max - f2.min + 1)) + f2.min;

        // Kalkulasi Hadiah (Harga Pasar * 2.5 + Bonus)
        let totalValue = (amt1 * f1.basePrice) + (amt2 * f2.basePrice);
        let rewardSaldo = Math.floor(totalValue * 2.5); // Dibayar 2.5x lipat dari harga toko!
        let rewardXP = Math.floor(rewardSaldo / 10);
        let rewardLimit = Math.floor(Math.random() * 5) + 3; // Dapat 3 - 7 limit

        // Simpan ke database
        quest.active = true;
        quest.reqs = [
            { name: f1.name, amount: amt1 },
            { name: f2.name, amount: amt2 }
        ];
        quest.rewards = { saldo: rewardSaldo, xp: rewardXP, limit: rewardLimit };
    }

    // Tampilkan Papan Misi (Baik yang baru dibuat atau yang sedang berjalan)
    let teksMisi = `╭───┈ *「 📜 PESANAN RESTORAN 」*\n`;
    teksMisi += `│ Bos Restoran Xenoria sedang mencari bahan masakan berikut:\n`;
    teksMisi += `│ \n`;

    for (let req of quest.reqs) {
        let stok = inventory[req.name] || 0;
        let statusEmoji = stok >= req.amount ? "✅" : "❌";
        let tier = fishRarity[req.name] || "Biasa"; // Ambil Tier dari Database
        teksMisi += `│ ▧ ${req.name} *(${tier})*\n`;
        teksMisi += `│    └─ Progress: ${stok}/${req.amount} ekor ${statusEmoji}\n`;
    }

    teksMisi += `│ \n`;
    teksMisi += `│ 🎁 *IMBALAN MISI:*\n`;
    teksMisi += `│ 💰 Rp ${quest.rewards.saldo.toLocaleString('id-ID')}\n`;
    teksMisi += `│ 📈 ${quest.rewards.xp} XP\n`;
    teksMisi += `│ 🎟️ ${quest.rewards.limit} Limit\n`;
    teksMisi += `╰───────────────┈ ⳹\n\n`;
    
    let isBisaSetor = quest.reqs.every(req => (inventory[req.name] || 0) >= req.amount);
    
    if (isBisaSetor) {
        teksMisi += `🎉 *BAHAN SUDAH LENGKAP!*\nSegera ketik \`${prefix}${command} setor\` untuk mengklaim hadiah!`;
    } else {
        teksMisi += `_Mancinglah sampai bahan mencukupi, lalu ketik \`${prefix}${command} setor\` untuk menyelesaikan misi._`;
    }

    return sock.sendMessage(m.chat, { text: teksMisi }, { quoted: m });
}

handler.help = ['questmancing', 'setorikan'];
handler.tags = ['mancing'];
handler.command = ['questmancing', 'misimancing', 'pesanan', 'pesananrestoran'];

module.exports = handler;
