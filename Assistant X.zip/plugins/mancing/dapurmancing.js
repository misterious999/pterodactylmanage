// ==========================================
// 🍳 DAPUR MANCING (COOKING & BUFF SYSTEM)
// ⚙️ BRIDGING FISHING ECONOMY WITH RPG COMBAT
// ==========================================

let handler = async (m, { sock, args, prefix, command }) => {
    let user = global.db.users[m.sender];
    if (!user || !user.registered) return m.reply("❌ Daftar dulu Bosku sebelum masuk dapur!");

    // Inisialisasi Database Inventory & RPG
    user.rpg = user.rpg || { hp: 100, mp: 50, attack: 10, defense: 10, inventory: {} };
    let inv = user.rpg.inventory;

    // 📖 BUKU RESEP MASAKAN SULTAN
    const resep = {
        "pecel lele": { 
            bahan: "🐟 Ikan Lele", butuh: 5, hasil: "🍱 Pecel Lele", 
            efek: "+100 HP & +Rp 5.000", id: "pecel_lele", type: "heal" 
        },
        "sup nila": { 
            bahan: "🐠 Ikan Nila", butuh: 5, hasil: "🍲 Sup Nila", 
            efek: "+50 MP & +1.000 XP", id: "sup_nila", type: "mana" 
        },
        "sate koki": { 
            bahan: "🐡 Ikan Mas Koki", butuh: 3, hasil: "🍢 Sate Koki", 
            efek: "+10 ATK (Permanen)", id: "sate_koki", type: "atk" 
        },
        "sushi hiu": { 
            bahan: "🦈 Hiu Putih", butuh: 1, hasil: "🍣 Sushi Hiu", 
            efek: "+25 DEF (Permanen)", id: "sushi_hiu", type: "def" 
        }
    };

    // Alias Anti-Typo untuk Masak & Makan
    const masakanAlias = {
        "pecel": "pecel lele", "pecel lele": "pecel lele",
        "sup": "sup nila", "sup nila": "sup nila",
        "sate": "sate koki", "sate koki": "sate koki",
        "sushi": "sushi hiu", "sushi hiu": "sushi hiu"
    };

    let action = args[0] ? args[0].toLowerCase() : '';

    // ==========================================
    // 1️⃣ LOGIKA MEMASAK IKAN (.masak <resep>)
    // ==========================================
    if (action === 'masak' || command === 'masak') {
        let inputRaw = (command === 'masak' ? args.join(" ") : args.slice(1).join(" ")).toLowerCase();
        if (!inputRaw) return m.reply(`❌ Mau masak apa Chef?\n*Contoh:* \`${prefix}masak pecel lele\``);

        let menu = masakanAlias[inputRaw];
        if (!menu || !resep[menu]) return m.reply(`❌ Resep tidak ditemukan! Ketik \`${prefix}dapur\` untuk melihat menu.`);

        let dataResep = resep[menu];
        let stokBahan = inv[dataResep.bahan] || 0;

        if (stokBahan < dataResep.butuh) {
            return m.reply(`❌ Bahan kurang! Kamu butuh *${dataResep.butuh}x ${dataResep.bahan}* untuk memasak ini. (Stokmu: ${stokBahan})`);
        }

        // Proses Memasak (Kurangi bahan, tambah makanan)
        inv[dataResep.bahan] -= dataResep.butuh;
        inv[dataResep.hasil] = (inv[dataResep.hasil] || 0) + 1;

        return m.reply(`🍳 *MEMASAK SELESAI!*\nKamu berhasil membuat 1 porsi *${dataResep.hasil}*!\n\n_Ketik \`${prefix}makan ${menu}\` untuk mengkonsumsinya._`);
    }

    // ==========================================
    // 2️⃣ LOGIKA MAKAN (KONSUMSI BUFF)
    // ==========================================
    else if (action === 'makan' || command === 'makan') {
        let inputRaw = (command === 'makan' ? args.join(" ") : args.slice(1).join(" ")).toLowerCase();
        if (!inputRaw) return m.reply(`❌ Mau makan apa Bosku?\n*Contoh:* \`${prefix}makan sate koki\``);

        let menu = masakanAlias[inputRaw];
        if (!menu || !resep[menu]) return m.reply(`❌ Makanan tidak valid!`);

        let makanan = resep[menu].hasil;
        if ((inv[makanan] || 0) < 1) return m.reply(`❌ Kamu tidak punya *${makanan}* di tasmu! Masak dulu ngab.`);

        // Kurangi makanan dari tas
        inv[makanan] -= 1;

        // Berikan Efek (Buff)
        let efekMsg = "";
        if (resep[menu].type === "heal") {
            user.rpg.hp = (user.rpg.hp || 0) + 100;
            user.balance = (user.balance || 0) + 5000;
            efekMsg = "Darahmu (HP) bertambah 100 dan mendapat bonus Saldo Rp 5.000!";
        } else if (resep[menu].type === "mana") {
            user.rpg.mp = (user.rpg.mp || 0) + 50;
            user.xp = (user.xp || 0) + 1000;
            efekMsg = "Mana (MP) bertambah 50 dan mendapat bonus 1.000 XP!";
        } else if (resep[menu].type === "atk") {
            user.rpg.attack = (user.rpg.attack || 10) + 10;
            efekMsg = "Ototmu membesar! Serangan (ATK) bertambah +10 secara PERMANEN! 💪";
        } else if (resep[menu].type === "def") {
            user.rpg.defense = (user.rpg.defense || 10) + 25;
            efekMsg = "Kulitmu mengeras! Pertahanan (DEF) bertambah +25 secara PERMANEN! 🛡️";
        }

        return m.reply(`🍽️ *NYAM NYAM NYAM...*\nKamu memakan *${makanan}*.\n\n✨ *EFEK:* ${efekMsg}`);
    }

    // ==========================================
    // 3️⃣ TAMPILAN BUKU MENU DAPUR (.dapur)
    // ==========================================
    else {
        let teks = `╭───┈ *「 🍳 DAPUR MANCING 」*\n`;
        teks += `│ 👨‍🍳 *Chef:* @${m.sender.split('@')[0]}\n`;
        teks += `╰───────────────┈ ⳹\n\n`;

        teks += `╭───┈ *「 📖 BUKU RESEP SULTAN 」*\n`;
        for (let key in resep) {
            let r = resep[key];
            let stokBahan = inv[r.bahan] || 0;
            let stokMakanan = inv[r.hasil] || 0;
            let status = stokBahan >= r.butuh ? "✅ Bisa Dimasak" : "❌ Bahan Kurang";
            
            teks += `│ 🍽️ *${r.hasil}* (Punya: ${stokMakanan})\n`;
            teks += `│ ▧ Bahan: ${r.butuh}x ${r.bahan} _(${stokBahan}/${r.butuh})_\n`;
            teks += `│ ▧ Efek: ${r.efek}\n`;
            teks += `│ └─ Status: ${status}\n│ \n`;
        }
        teks += `╰───────────────┈ ⳹\n\n`;

        teks += `*💡 PANDUAN MASAK:*\n`;
        teks += `▧ \`${prefix}masak <resep>\` ➪ Membuat makanan\n`;
        teks += `▧ \`${prefix}makan <makanan>\` ➪ Konsumsi untuk Buff\n`;

        return sock.sendMessage(m.chat, { text: teks, mentions: [m.sender] }, { quoted: m });
    }
}

handler.help = ['dapur', 'masak', 'makan'];
handler.tags = ['mancing'];
handler.command = ['dapur', 'dapurmancing', 'masak', 'makan'];

module.exports = handler;
