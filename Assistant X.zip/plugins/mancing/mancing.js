// ==========================================
// 🎣 FITUR MANCING MANIA V8 (PERFECT EDITION)
// ⚙️ AUTO-COMPRESS HEADER + BLIND BATTLE (NO PHASE)
// ==========================================

global.mancing = global.mancing || {};
global.cuacaMancing = global.cuacaMancing || { status: "Cerah ☀️", expired: 0 };

// 🖼️ PENGATURAN LINK GAMBAR CATBOX BOSKU
const imgStrike = "https://files.catbox.moe/ghxo1r.png";  
const imgMenang = "https://files.catbox.moe/1jgpzr.png";  
const imgGagal  = "https://files.catbox.moe/5brtws.png";  

const fishDb = [
    { name: "🥾 Sepatu Bekas", rarity: "Sampah", price: 100, stages: 1 },
    { name: "🐟 Ikan Lele", rarity: "Common", price: 500, stages: 1 },
    { name: "🐠 Ikan Nila", rarity: "Common", price: 800, stages: 1 },
    { name: "🐡 Ikan Mas Koki", rarity: "Rare", price: 2500, stages: 2 },
    { name: "🦈 Hiu Putih", rarity: "Epic", price: 15000, stages: 3 },
    { name: "🐳 Paus Biru", rarity: "Epic", price: 25000, stages: 3 },
    { name: "🦑 Kraken", rarity: "Mythic", price: 100000, stages: 4 },
    { name: "🦖 Megalodon", rarity: "Mythic", price: 150000, stages: 5 } 
];

const battleMoves = [
    { condition: "Ikan menarik tali dengan sangat kuat! 🌊", answer: "ulur" },
    { condition: "Ikan berenang liar ke arah KIRI! ⬅️", answer: "kanan" },
    { condition: "Ikan berenang liar ke arah KANAN! ➡️", answer: "kiri" },
    { condition: "Ikan mulai kelelahan dan diam! 💦", answer: "tarik" }
];

// 🔥 TRIK DEWA: Auto-Compressor Gambar untuk WA Header
const createHeader = (title, body, imgUrl) => {
    // Ubah link asli menjadi link kompresi berformat JPG agar WA mau merender!
    let cleanUrl = imgUrl.replace(/^https?:\/\//, '');
    let compressedImg = `https://wsrv.nl/?url=${cleanUrl}&w=400&output=jpg&q=50`;

    return {
        externalAdReply: {
            title: title,
            body: body,
            thumbnailUrl: compressedImg, // Pakai gambar yang sudah dikompres
            sourceUrl: global.linkGrup || "https://chat.whatsapp.com", 
            mediaType: 1,
            renderLargerThumbnail: true
        }
    };
};

// ==========================================
// 1️⃣ MESIN PELEMPAR UMPAN & RADAR CUACA
// ==========================================
let handler = async (m, { sock, args, prefix, command }) => {
    let user = global.db.users[m.sender];
    if (!user || !user.registered) return m.reply("❌ Daftar dulu Bosku sebelum ke danau!");

    if (Date.now() > global.cuacaMancing.expired) {
        let chance = Math.random() * 100;
        let randWeather = "Cerah ☀️";
        if (chance > 90) randWeather = "Hujan Badai ⛈️"; 
        else if (chance > 60) randWeather = "Mendung ☁️"; 

        global.cuacaMancing = { status: randWeather, expired: Date.now() + 3600000 };
    }
    let cuaca = global.cuacaMancing.status;

    if (command === 'cekcuaca' || command === 'cuacamancing') {
        let efek = "Normal. Ikan berenang dengan tenang.";
        if (cuaca === "Mendung ☁️") efek = "Ikan langka sedikit lebih sering muncul (+10% Keberuntungan).";
        if (cuaca === "Hujan Badai ⛈️") efek = "Peluang besar mendapat Ikan Mythic (+25%)! TAPI tarikan pancing sangat liar dan cepat putus!";

        let teksCuaca = `╭───┈ *「 🌤️ RADAR CUACA DANAU 」*\n│ 🌥️ *Status:* ${cuaca}\n│ ⚡ *Efek:* ${efek}\n╰───────────────┈ ⳹\n\n_Cuaca berubah secara acak setiap 1 Jam._`;
        return sock.sendMessage(m.chat, { text: teksCuaca }, { quoted: m });
    }

    let id = m.chat + '_' + m.sender;
    if (global.mancing[id]) return m.reply("⚠️ Kamu masih bertarung dengan ikan! Fokus pancinganmu!");

    let umpanInput = args[0] ? args[0].toLowerCase() : null;
    let validUmpan = ['cacing', 'pelet', 'udang', 'daging'];
    if (!validUmpan.includes(umpanInput)) {
        return m.reply(`❌ Mau mancing pakai umpan apa Bosku?\n*Contoh:* \`${prefix}mancing cacing\`\n_(Pilihan: cacing, pelet, udang, daging)_\n\n💡 _Ketik \`${prefix}cekcuaca\` untuk melihat kondisi danau!_`);
    }

    user.rpg = user.rpg || { inventory: {}, pancingan: { kail: 1, koil: 1, gagang: 1 } };
    let idUmpan = "umpan_" + umpanInput;
    if ((user.rpg.inventory[idUmpan] || 0) < 1) {
        return m.reply(`❌ Umpan *${umpanInput.toUpperCase()}* kamu habis! Beli dulu di \`${prefix}tokomancing\`.`);
    }

    user.rpg.inventory[idUmpan] -= 1;

    let kailLvl = user.rpg.pancingan.kail || 1;
    let koilLvl = user.rpg.pancingan.koil || 1;
    let gagangLvl = user.rpg.pancingan.gagang || 1;

    let reactionTime = 8000 + (gagangLvl * 1000); 
    let stageReduction = Math.floor(koilLvl / 2); 

    let pool = [];
    let rand = Math.random() * 100;
    rand -= (kailLvl * 2); 

    if (cuaca === "Mendung ☁️") rand -= 10;
    if (cuaca === "Hujan Badai ⛈️") { rand -= 25; reactionTime -= 3000; }
    if (reactionTime < 3000) reactionTime = 3000; 

    if (umpanInput === 'cacing') {
        if (rand < 20) pool = ["Sampah"]; else if (rand < 70) pool = ["Common"]; else pool = ["Rare"];
    } else if (umpanInput === 'pelet') {
        if (rand < 10) pool = ["Sampah"]; else if (rand < 50) pool = ["Common"]; else if (rand < 80) pool = ["Rare"]; else pool = ["Epic"];
    } else if (umpanInput === 'udang') {
        if (rand < 20) pool = ["Common"]; else if (rand < 60) pool = ["Rare"]; else if (rand < 90) pool = ["Epic"]; else pool = ["Mythic"];
    } else if (umpanInput === 'daging') {
        if (rand < 10) pool = ["Rare"]; else if (rand < 60) pool = ["Epic"]; else pool = ["Mythic"];
    }

    let possibleFish = fishDb.filter(f => pool.includes(f.rarity));
    let fish = possibleFish[Math.floor(Math.random() * possibleFish.length)];

    let finalStages = fish.stages - stageReduction;
    if (finalStages < 1) finalStages = 1;

    await sock.sendMessage(m.chat, { text: `╭───┈ *「 🎣 MANCING MANIA 」*\n│ 🌤️ *Cuaca Danau:* ${cuaca}\n│ @${m.sender.split('@')[0]} melempar *Umpan ${umpanInput.toUpperCase()}*...\n│ ⚙️ _Kail Lv.${kailLvl} | Koil Lv.${koilLvl} | Gagang Lv.${gagangLvl}_\n╰───────────────┈ ⳹\n\n_Tunggu sebentar, perhatikan pancinganmu..._`, mentions: [m.sender] });

    let waitTime = Math.floor(Math.random() * 3000) + 3000;

    setTimeout(async () => {
        let move = { condition: "Pancinganmu tersambar dengan keras! 💥", answer: "tarik" };

        global.mancing[id] = {
            id: id, chatId: m.chat, sender: m.sender, fish: fish,
            stagesLeft: finalStages, totalStages: finalStages,
            currentAnswer: move.answer, reactionTime: reactionTime, prefixUsed: prefix,
            timer: createFailTimer(sock, id, reactionTime)
        };

        let teksBattle = `╭───┈ *「 ⚠️ STRIKE!! 」*\n│ ${move.condition}\n│ \n│ 🎯 Cepat ketik: *${move.answer}*\n╰───────────────┈ ⳹\n\n_Waktu reaksimu: ${(reactionTime / 1000).toFixed(1)} detik!_`;

        await sock.sendMessage(m.chat, { 
            text: teksBattle, 
            contextInfo: createHeader("🎣 STRIKE!!", "Adu mekanik dimulai!", imgStrike),
            mentions: [m.sender] 
        });

    }, waitTime);
}

// ==========================================
// 2️⃣ MESIN ADU MEKANIK & SISTEM PATAH PANCING
// ==========================================
handler.before = async (m, { sock }) => {
    let id = m.chat + '_' + m.sender;
    let session = global.mancing[id];

    if (!session || m.isBaileys || !m.text) return false;

    let input = m.text.toLowerCase().trim();

    // ❌ JIKA GAGAL / SALAH KETIK
    if (input !== session.currentAnswer) {
        clearTimeout(session.timer);
        delete global.mancing[id];
        let teksGagal = `❌ *GAGAL!* Kamu salah arah (Ngetik: ${input}). Tali pancing putus dan ${session.fish.name} berhasil kabur! 🌊`;
        
        return await sock.sendMessage(m.chat, { 
            text: teksGagal, 
            contextInfo: createHeader("💥 GAGAL!", "Ikan berhasil kabur...", imgGagal),
            mentions: [m.sender] 
        });
    }

    clearTimeout(session.timer);
    session.stagesLeft--;

    // ==========================================
    // LOGIKA PENANGKAPAN & GACHA PANCING PATAH
    // ==========================================
    if (session.stagesLeft <= 0) {
        let user = global.db.users[m.sender];
        let pancingan = user.rpg.pancingan;
        
        let avgGear = (pancingan.kail + pancingan.koil + pancingan.gagang) / 3;
        let breakChance = 0;

        if (session.fish.rarity === "Epic" && avgGear < 3) breakChance = 0.40; 
        else if (session.fish.rarity === "Mythic" && avgGear < 4) breakChance = 0.60; 

        if (Math.random() < breakChance) {
            let parts = ["kail", "koil", "gagang"];
            let brokenPart = parts[Math.floor(Math.random() * parts.length)];
            let isDowngraded = false;

            if (pancingan[brokenPart] > 1) {
                pancingan[brokenPart] -= 1;
                isDowngraded = true;
            }

            let msgBreak = `╭───┈ *「 💥 PANCINGAN PATAH! 」*\n│ Tarikan ${session.fish.name} terlalu brutal!\n│ Alat pancing hancur dan ikan kabur... 🌊\n`;
            if (isDowngraded) msgBreak += `│ \n│ 📉 *HUKUMAN:* Level *${brokenPart.toUpperCase()}* turun 1 tingkat!\n`;
            else msgBreak += `│ \n│ ⚠️ *PERINGATAN:* Segera upgrade pancingan!\n`;
            msgBreak += `╰───────────────┈ ⳹`;

            await sock.sendMessage(m.chat, { 
                text: msgBreak, 
                contextInfo: createHeader("💥 PANCINGAN PATAH!", "Senjatamu kurang kuat!", imgGagal),
                mentions: [m.sender] 
            });
            delete global.mancing[id];
            return true;
        }

        let rewardXP = session.totalStages * 150;
        user.xp = (user.xp || 0) + rewardXP;
        user.rpg.inventory[session.fish.name] = (user.rpg.inventory[session.fish.name] || 0) + 1;

        let teksMenang = `╭───┈ *「 🎉 TANGKAPAN BERHASIL! 」*\n│ 🎣 *Pemancing:* @${m.sender.split('@')[0]}\n│ 🐟 *Hasil:* ${session.fish.name} (${session.fish.rarity})\n│ \n│ 🎒 Masuk ke dalam tas ikan (.listikan)\n│ 📈 *EXP:* +${rewardXP}\n╰───────────────┈ ⳹`;

        await sock.sendMessage(m.chat, { 
            text: teksMenang, 
            contextInfo: createHeader("🎉 BERHASIL!!", "Hasil tangkapan mantap!", imgMenang),
            mentions: [m.sender] 
        });
        delete global.mancing[id];
        return true;
    }

    let nextMove = battleMoves[Math.floor(Math.random() * battleMoves.length)];
    session.currentAnswer = nextMove.answer;
    session.timer = createFailTimer(sock, id, session.reactionTime);

    // 🔥 FIX: TULISAN FASE DIHAPUS (BLIND BATTLE)
    let teksLanjut = `╭───┈ *「 ⚔️ IKAN MELAWAN! 」*\n│ ${nextMove.condition}\n│ \n│ 🎯 Cepat ketik: *${nextMove.answer}*\n╰───────────────┈ ⳹`;

    await sock.sendMessage(m.chat, { text: teksLanjut, mentions: [m.sender] });
    return true;
}

function createFailTimer(sock, id, time) {
    return setTimeout(async () => {
        let session = global.mancing[id];
        if (session) {
            let teksKabur = `⏳ *TERLAMBAT!* Ikan terlalu liar dan melepaskan diri dari pancingan @${session.sender.split('@')[0]}... 🌊`;
            
            await sock.sendMessage(session.chatId, { 
                text: teksKabur, 
                contextInfo: createHeader("⏳ WAKTU HABIS!", "Ikan terlanjur kabur...", imgGagal),
                mentions: [session.sender] 
            });
            delete global.mancing[id];
        }
    }, time); 
}

handler.help = ['mancing <umpan>', 'cekcuaca'];
handler.tags = ['mancing'];
handler.command = ['mancing', 'fishing', 'cekcuaca', 'cuacamancing'];

module.exports = handler;
