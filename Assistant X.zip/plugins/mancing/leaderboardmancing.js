// ==========================================
// 🏆 LEADERBOARD MANCING (HALL OF FAME)
// ⚙️ RANKING BY GEAR POWER & MYTHIC CATCHES
// ==========================================

let handler = async (m, { sock, prefix }) => {
    let users = Object.entries(global.db.users).map(([jid, data]) => {
        // Ambil data RPG & Pancingan, set default jika belum ada
        let rpg = data.rpg || {};
        let pancingan = rpg.pancingan || { kail: 1, koil: 1, gagang: 1 };
        let inv = rpg.inventory || {};

        let kail = pancingan.kail || 1;
        let koil = pancingan.koil || 1;
        let gagang = pancingan.gagang || 1;

        // 🛡️ Hitung Gear Power (Total Level Alat)
        let gearPower = kail + koil + gagang;
        
        // 🦖 Hitung Koleksi Ikan Mythic (Megalodon + Kraken)
        let mythicCount = (inv["🦖 Megalodon"] || 0) + (inv["🦑 Kraken"] || 0);

        return {
            jid,
            name: data.name || "Unknown Angler",
            level: data.level || 0,
            gearPower,
            kail, koil, gagang,
            mythicCount
        };
    });

    // 🔥 SORTING LOGIKA: Utamakan Gear Power tinggi, lalu jumlah Mythic
    users.sort((a, b) => {
        if (b.gearPower !== a.gearPower) return b.gearPower - a.gearPower;
        return b.mythicCount - a.mythicCount;
    });

    // Ambil Top 10 saja
    let top10 = users.slice(0, 10);
    
    let teks = `╭───┈ *「 🏆 ANGLER HALL OF FAME 」*\n`;
    teks += `│ _Peringkat pemancing terbaik di grup_\n`;
    teks += `╰───────────────┈ ⳹\n\n`;

    top10.forEach((user, index) => {
        let rankEmoji = index === 0 ? "🥇" : index === 1 ? "🥈" : index === 2 ? "🥉" : "👤";
        let tag = `@${user.jid.split('@')[0]}`;
        
        teks += `${rankEmoji} *RANK ${index + 1}* - ${user.name}\n`;
        teks += `│ 🏷️ *User:* ${tag}\n`;
        teks += `│ 🛡️ *Gear Power:* ${user.gearPower} ⚡\n`;
        teks += `│    └─ (Kail Lv.${user.kail} | Koil Lv.${user.koil} | Gagang Lv.${user.gagang})\n`;
        teks += `│ 🦖 *Mythic Catch:* ${user.mythicCount} Ekor\n`;
        teks += `╰───────────────┈ ⳹\n\n`;
    });

    teks += `_Ketik *${prefix}tokomancing upgrade* untuk meningkatkan Gear Power-mu dan naik peringkat!_`;

    await sock.sendMessage(m.chat, { 
        text: teks, 
        mentions: top10.map(u => u.jid) 
    }, { quoted: m });
}

handler.help = ['topmancing'];
handler.tags = ['mancing'];
handler.command = ['topmancing', 'rankmancing', 'anglerboard', 'papanmancing'];

module.exports = handler;
