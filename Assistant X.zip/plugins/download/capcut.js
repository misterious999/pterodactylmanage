const axios = require('axios');

// ==========================================
// 📥 XENORIA DOWNLOADER: CAPCUT ENGINE
// ⚙️ Minimalist & Clean UI Architecture
// ==========================================

const REQUEST_TIMEOUT = 120000;

function buildBotcahxUrl(endpoint, params = {}) {
    if (typeof global.botcahxUrl === 'function') {
        return global.botcahxUrl(endpoint, params);
    }

    const base = String(
        global.botcahxBaseUrl ||
        process.env.BOTCAHX_BASE_URL ||
        'https://api.botcahx.eu.org'
    ).replace(/\/$/, '');

    const apikey =
        global.btc ||
        global.botcahxKey ||
        process.env.BOTCAHX_APIKEY;

    if (!apikey) {
        throw new Error('BOTCAHX_APIKEY belum diatur di .env / Environment Variables panel.');
    }

    const url = new URL(`${base}${endpoint.startsWith('/') ? endpoint : `/${endpoint}`}`);

    for (const [key, value] of Object.entries(params)) {
        if (value !== undefined && value !== null && value !== '') {
            url.searchParams.set(key, String(value));
        }
    }

    url.searchParams.set('apikey', apikey);
    return url.toString();
}

function isCapcutUrl(url = '') {
    return /^https?:\/\/(www\.)?(capcut\.com|capcut\.net)\//i.test(url);
}

function pickString(value, fallback = '-') {
    if (value === undefined || value === null) return fallback;
    if (typeof value === 'string' || typeof value === 'number') {
        const result = String(value).trim();
        return result || fallback;
    }
    return fallback;
}

function findFirstUrl(input, keywords = [], depth = 0) {
    if (!input || depth > 8) return null;

    if (typeof input === 'string') {
        const value = input.trim();
        if (!value.startsWith('http')) return null;

        if (!keywords.length) return value;

        const lower = value.toLowerCase();
        if (keywords.some(key => lower.includes(key))) return value;

        return null;
    }

    if (Array.isArray(input)) {
        for (const item of input) {
            const found = findFirstUrl(item, keywords, depth + 1);
            if (found) return found;
        }
        return null;
    }

    if (typeof input === 'object') {
        for (const [key, value] of Object.entries(input)) {
            const keyLower = key.toLowerCase();

            if (
                keywords.length &&
                keywords.some(word => keyLower.includes(word))
            ) {
                const found = findFirstUrl(value, [], depth + 1);
                if (found) return found;
            }
        }

        for (const value of Object.values(input)) {
            const found = findFirstUrl(value, keywords, depth + 1);
            if (found) return found;
        }
    }

    return null;
}

function findValueByKeys(input, keys = [], depth = 0) {
    if (!input || depth > 8) return null;

    if (Array.isArray(input)) {
        for (const item of input) {
            const found = findValueByKeys(item, keys, depth + 1);
            if (found) return found;
        }
        return null;
    }

    if (typeof input === 'object') {
        for (const [key, value] of Object.entries(input)) {
            const keyLower = key.toLowerCase();

            if (keys.some(k => keyLower.includes(k))) {
                if (typeof value === 'string' || typeof value === 'number') {
                    const result = String(value).trim();
                    if (result) return result;
                }

                if (typeof value === 'object') {
                    const nested = findValueByKeys(value, keys, depth + 1);
                    if (nested) return nested;
                }
            }
        }

        for (const value of Object.values(input)) {
            const found = findValueByKeys(value, keys, depth + 1);
            if (found) return found;
        }
    }

    return null;
}

function normalizeCapcutResult(json = {}) {
    const raw = json.result || json.data || json.response || json;

    const videoUrl =
        findFirstUrl(raw, ['video', 'download', 'mp4', 'play', 'url']) ||
        findFirstUrl(raw, ['capcut']) ||
        findFirstUrl(raw, []);

    const coverUrl = findFirstUrl(raw, ['cover', 'thumbnail', 'thumb', 'image', 'poster']);
    const title = findValueByKeys(raw, ['title', 'name', 'template']) || 'CapCut Template';
    const author = findValueByKeys(raw, ['author', 'creator', 'username', 'nickname']) || '-';
    const usage = findValueByKeys(raw, ['usage', 'uses', 'used', 'use', 'pemakai']) || '-';
    const description = findValueByKeys(raw, ['description', 'desc', 'caption']) || '-';

    return {
        title: pickString(title, 'CapCut Template'),
        author: pickString(author),
        usage: pickString(usage),
        description: pickString(description),
        videoUrl,
        coverUrl
    };
}

async function getContentType(url) {
    try {
        const res = await axios.head(url, {
            timeout: 30000,
            validateStatus: () => true,
            headers: { 'User-Agent': 'Mozilla/5.0' }
        });
        return String(res.headers['content-type'] || '').toLowerCase();
    } catch {
        return '';
    }
}

async function downloadAsBuffer(url) {
    const res = await axios.get(url, {
        responseType: 'arraybuffer',
        timeout: REQUEST_TIMEOUT,
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
        validateStatus: () => true,
        headers: {
            'User-Agent': 'Mozilla/5.0',
            'Referer': 'https://www.capcut.com/'
        }
    });

    if (res.status >= 400) {
        throw new Error(`Gagal mengunduh media. Status HTTP ${res.status}`);
    }

    return Buffer.from(res.data);
}

// ==========================================
// 🚀 HANDLER UTAMA
// ==========================================
let handler = async (m, { sock, text, args, prefix, command }) => {
    const input = String(text || (args || []).join(' ') || '').trim();

    if (!input) {
        return m.reply(`✦ *Format Tidak Lengkap*\n\nSertakan tautan template CapCut.\nContoh: *${prefix}${command} https://www.capcut.com/template-detail/...*`);
    }

    const capcutUrl = input.match(/https?:\/\/[^\s]+/i)?.[0];

    if (!capcutUrl || !isCapcutUrl(capcutUrl)) {
        return m.reply(`✦ *Tautan Tidak Valid*\n\nPastikan tautan yang dimasukkan berasal dari domain resmi CapCut.`);
    }

    await m.react('⏳').catch(() => {});

    try {
        await sock.sendMessage(
            m.chat,
            { text: '✦ _Menghubungkan ke satelit CapCut... Mohon tunggu._' },
            { quoted: m }
        );

        const apiUrl = buildBotcahxUrl('/api/dowloader/capcut', { url: capcutUrl });

        const { data } = await axios.get(apiUrl, {
            timeout: REQUEST_TIMEOUT,
            validateStatus: () => true,
            headers: { 'User-Agent': 'Mozilla/5.0' }
        });

        if (!data) throw new Error('Respons server hampa.');

        if (data.status === false || data.success === false) {
            throw new Error(data.message || data.error || 'Gagal memproses tautan.');
        }

        const result = normalizeCapcutResult(data);

        if (!result.videoUrl) {
            throw new Error('Tautan video tidak ditemukan dalam respons.');
        }

        // Tampilan Minimalis & Elegan (Tanpa Garis Kaku)
        let caption = `✦ *C A P C U T   D O W N L O A D E R* ✦\n\n`;
        caption += `🎬 *Judul:* ${result.title}\n`;
        caption += `👤 *Kreator:* ${result.author}\n`;
        caption += `📊 *Penggunaan:* ${result.usage}\n`;

        if (result.description && result.description !== '-') {
            caption += `📝 *Deskripsi:* ${result.description.slice(0, 250)}\n`;
        }

        caption += `\n> 🔗 _Source: Verified Template_`;

        const contentType = await getContentType(result.videoUrl);

        if (contentType.includes('video') || result.videoUrl.toLowerCase().includes('.mp4')) {
            const videoBuffer = await downloadAsBuffer(result.videoUrl);
            await sock.sendMessage(m.chat, { video: videoBuffer, caption, mimetype: 'video/mp4' }, { quoted: m });
        } else if (contentType.includes('image')) {
            const imageBuffer = await downloadAsBuffer(result.videoUrl);
            await sock.sendMessage(m.chat, { image: imageBuffer, caption }, { quoted: m });
        } else {
            let teks = caption + `\n\n📥 *Direct Link:* ${result.videoUrl}`;
            if (result.coverUrl) teks += `\n🖼️ *Cover:* ${result.coverUrl}`;
            await sock.sendMessage(m.chat, { text: teks }, { quoted: m });
        }

        await m.react('✅').catch(() => {});

    } catch (error) {
        console.error('[CAPCUT ERROR]', error);
        await m.react('❌').catch(() => {});
        return m.reply(`✦ *Sistem Mengalami Kendala*\n\n_${error.message || error}_\n\nPastikan tautan bersifat publik dan aktif.`);
    }
};

handler.help = ['capcut <url>'];
handler.command = ['capcut'];
handler.tags = ['downloader'];
handler.limit = true;

module.exports = handler;
