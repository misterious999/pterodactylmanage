const axios = require('axios');
const {
    generateWAMessageFromContent,
    proto
} = require('@whiskeysockets/baileys');

const REQUEST_TIMEOUT = 60000;
const SESSION_TTL = 10 * 60 * 1000;

global.tiktokDownloadSessions = global.tiktokDownloadSessions || {};

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function cleanExpiredSessions() {
    const now = Date.now();
    for (const [id, session] of Object.entries(global.tiktokDownloadSessions || {})) {
        if (!session || now - Number(session.createdAt || 0) > SESSION_TTL) {
            delete global.tiktokDownloadSessions[id];
        }
    }
}

// 🔥 HELPER BARU: Mengunduh file media secara manual (Mencegah video error/blank)
async function fetchMediaBuffer(url) {
    try {
        const response = await axios.get(url, {
            responseType: 'arraybuffer',
            timeout: 30000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': '*/*',
                'Referer': 'https://www.tiktok.com/'
            }
        });
        
        const contentType = response.headers['content-type'] || '';
        if (contentType.includes('text/html') || contentType.includes('application/json')) {
            return null; // Tolak jika TikTok mengirim halaman error
        }
        
        return Buffer.from(response.data, 'binary');
    } catch (error) {
        return null;
    }
}

function buildBotcahxUrl(endpoint, params = {}) {
    if (typeof global.botcahxUrl === 'function') {
        return global.botcahxUrl(endpoint, params);
    }
    const base = String(global.botcahxBaseUrl || process.env.BOTCAHX_BASE_URL || 'https://api.botcahx.eu.org').replace(/\/$/, '');
    const apikey = global.btc || global.botcahxKey || process.env.BOTCAHX_APIKEY;

    if (!apikey) throw new Error('BOTCAHX_APIKEY belum diatur di .env / Environment Variables panel.');

    const url = new URL(`${base}${endpoint.startsWith('/') ? endpoint : `/${endpoint}`}`);
    for (const [key, value] of Object.entries(params || {})) {
        if (value !== undefined && value !== null && value !== '') {
            url.searchParams.set(key, String(value));
        }
    }
    url.searchParams.set('apikey', apikey);
    return url.toString();
}

function extractTikTokUrl(text = '') {
    const match = String(text || '').match(/https?:\/\/[^\s]+(?:tiktok|douyin)[^\s]*/i);
    return match ? match[0].trim() : null;
}

function safeText(value, fallback = '-') {
    if (value === undefined || value === null || value === '') return fallback;
    if (typeof value === 'object') {
        if (value.title) return safeText(value.title, fallback);
        if (value.name) return safeText(value.name, fallback);
        if (value.nickname) return safeText(value.nickname, fallback);
        if (value.unique_id) return safeText(value.unique_id, fallback);
        return fallback;
    }
    return String(value).trim() || fallback;
}

function isUrl(value = '') {
    return /^https?:\/\//i.test(String(value || '').trim());
}

function normalizeMediaUrl(url = '') {
    if (!url) return null;
    const clean = String(url).trim();
    if (!clean) return null;
    if (clean.startsWith('//')) return `https:${clean}`;
    if (clean.startsWith('/')) return `https://www.tikwm.com${clean}`;
    if (clean.startsWith('http')) return clean;
    return null;
}

function uniqueUrls(arr = []) {
    return [...new Set(arr.map(normalizeMediaUrl).filter(Boolean))];
}

function formatNumber(value) {
    if (value === undefined || value === null || value === '') return '-';
    if (typeof value === 'string' && /[.,]/.test(value) && !/^\d+([.,]\d+)?$/.test(value)) return value;
    const num = Number(String(value).replace(/[^\d.]/g, ''));
    if (!Number.isFinite(num)) return String(value);
    return num.toLocaleString('id-ID');
}

function formatDuration(value) {
    if (value === undefined || value === null || value === '') return '-';
    if (typeof value === 'string' && /detik|second|minute|menit|:|jam|hour/i.test(value)) return value;
    const seconds = Number(value);
    if (!Number.isFinite(seconds)) return String(value);
    if (seconds < 60) return `${seconds} Detik`;
    const minutes = Math.floor(seconds / 60);
    const rest = seconds % 60;
    if (minutes < 60) return `${minutes}:${String(rest).padStart(2, '0')} Menit`;
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}:${String(mins).padStart(2, '0')}:${String(rest).padStart(2, '0')} Jam`;
}

function formatDate(value) {
    if (value === undefined || value === null || value === '') return '-';
    if (typeof value === 'string' && !/^\d+$/.test(value)) return value;
    let num = Number(value);
    if (!Number.isFinite(num)) return String(value);
    if (num < 10000000000) num = num * 1000;
    try {
        return new Date(num).toLocaleString('id-ID', {
            weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
            hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Jakarta'
        });
    } catch {
        return String(value);
    }
}

function limitText(text = '', max = 350) {
    const clean = safeText(text, '-');
    if (clean.length <= max) return clean;
    return clean.slice(0, max).trim() + '...';
}

function collectUrls(input, depth = 0) {
    if (!input || depth > 8) return [];
    const results = [];
    if (typeof input === 'string') {
        if (isUrl(input) || input.startsWith('//') || input.startsWith('/')) {
            const normalized = normalizeMediaUrl(input);
            if (normalized) results.push(normalized);
        }
    } else if (Array.isArray(input)) {
        for (const item of input) results.push(...collectUrls(item, depth + 1));
    } else if (typeof input === 'object') {
        for (const value of Object.values(input)) results.push(...collectUrls(value, depth + 1));
    }
    return [...new Set(results)];
}

function getBotcahxRoot(data = {}) {
    return data?.result || data?.data?.result || data?.data || data?.response || data;
}

function normalizeBotcahx(data = {}) {
    const root = getBotcahxRoot(data);
    if (!root) return null;

    const videos = uniqueUrls([
        ...(Array.isArray(root.video) ? root.video : [root.video]),
        root.video_url, root.videoUrl, root.play, root.nowm,
        root.no_watermark, root.noWatermark, root.url, root.download,
        root.download_url, ...collectUrls(root.media)
    ]);

    const audios = uniqueUrls([
        ...(Array.isArray(root.audio) ? root.audio : [root.audio]),
        root.audio_url, root.audioUrl, root.music, root.music_url,
        root.musicUrl, root.sound, root.sound_url
    ]);

    const images = uniqueUrls([
        ...(Array.isArray(root.images) ? root.images : (root.images && typeof root.images === 'string' ? [root.images] : [])),
        ...(Array.isArray(root.image) ? root.image : (root.image && typeof root.image === 'string' ? [root.image] : [])),
        ...(Array.isArray(root.photo) ? root.photo : (root.photo && typeof root.photo === 'string' ? [root.photo] : []))
    ]);

    return {
        title: safeText(root.title || root.caption || root.desc || root.description, 'Video TikTok'),
        authorName: '-', username: '-',
        music: safeText(root.title_audio || root.music_title || root.musicTitle, '-'),
        uploaded: '-', duration: '-', region: '-',
        thumbnail: safeText(root.thumbnail || root.cover, '-'),
        videos, audios, images,
        stats: { views: undefined, likes: undefined, comments: undefined, shares: undefined, downloads: undefined },
        source: 'BOTCAHX'
    };
}

function normalizeTikwm(data = {}) {
    const root = data?.data || data?.result || data;
    if (!root) return null;

    const author = root.author || root.author_info || root.authorInfo || {};
    const musicInfo = root.music_info || root.musicInfo || {};

    const images = uniqueUrls([
        ...(Array.isArray(root.images) ? root.images : (root.images && typeof root.images === 'string' ? [root.images] : [])),
        ...(Array.isArray(root.image_post_info?.images) ? root.image_post_info.images.map(x => x.display_image?.url_list || x.url_list || x) : [])
    ]);

    const videos = uniqueUrls([
        root.play, root.hdplay, root.wmplay, root.video,
        root.video_url, root.download, root.download_url
    ]);

    const audios = uniqueUrls([
        root.music, root.music_url, root.audio, root.audio_url,
        musicInfo.play, musicInfo.url, musicInfo.download
    ]);

    return {
        title: safeText(root.title || root.desc || root.description, 'Video TikTok'),
        authorName: safeText(author.nickname || author.name, '-'),
        username: safeText(author.unique_id || author.uniqueId || author.username, '-'),
        music: safeText(root.music_title || root.musicTitle || musicInfo.title || musicInfo.name || '-', '-'),
        uploaded: formatDate(root.create_time || root.createTime || root.created_at),
        duration: formatDuration(root.duration),
        region: safeText(root.region || root.region_code || root.country, '-'),
        thumbnail: safeText(root.cover || root.origin_cover, '-'),
        videos, audios, images,
        stats: {
            views: root.play_count || root.playCount,
            likes: root.digg_count || root.diggCount,
            comments: root.comment_count || root.commentCount,
            shares: root.share_count || root.shareCount,
            downloads: root.download_count || root.downloadCount
        },
        source: 'TikWM'
    };
}

function mergeResults(primary = {}, meta = {}) {
    if (!primary && !meta) return null;
    if (!primary) return meta;
    if (!meta) return primary;

    return {
        title: primary.title && primary.title !== '-' && primary.title !== 'Video TikTok' ? primary.title : meta.title || primary.title,
        authorName: meta.authorName && meta.authorName !== '-' ? meta.authorName : primary.authorName,
        username: meta.username && meta.username !== '-' ? meta.username : primary.username,
        music: meta.music && meta.music !== '-' ? meta.music : primary.music,
        uploaded: meta.uploaded && meta.uploaded !== '-' ? meta.uploaded : primary.uploaded,
        duration: meta.duration && meta.duration !== '-' ? meta.duration : primary.duration,
        region: meta.region && meta.region !== '-' ? meta.region : primary.region,
        thumbnail: meta.thumbnail && meta.thumbnail !== '-' ? meta.thumbnail : primary.thumbnail,
        
        videos: uniqueUrls([...(primary.videos || []), ...(meta.videos || [])]),
        audios: uniqueUrls([...(primary.audios || []), ...(meta.audios || [])]),
        images: uniqueUrls([...(primary.images || []), ...(meta.images || [])]),
        
        stats: {
            views: meta.stats?.views || primary.stats?.views,
            likes: meta.stats?.likes || primary.stats?.likes,
            comments: meta.stats?.comments || primary.stats?.comments,
            shares: meta.stats?.shares || primary.stats?.shares,
            downloads: meta.stats?.downloads || primary.stats?.downloads
        },
        source: primary.source === 'BOTCAHX' && meta.source === 'TikWM' ? 'BOTCAHX + TikWM' : primary.source || meta.source || '-'
    };
}

function makeStatsTable(stats = {}) {
    const views = formatNumber(stats.views);
    const likes = formatNumber(stats.likes);
    const comments = formatNumber(stats.comments);
    const shares = formatNumber(stats.shares);
    const downloads = formatNumber(stats.downloads);

    const rows = [];
    if (views !== '-') rows.push(`│ 👀 *Views:* ${views}`);
    if (likes !== '-') rows.push(`│ ❤️ *Likes:* ${likes}`);
    if (comments !== '-') rows.push(`│ 💬 *Comments:* ${comments}`);
    if (shares !== '-') rows.push(`│ 📤 *Shares:* ${shares}`);
    if (downloads !== '-') rows.push(`│ 📥 *Downloads:* ${downloads}`);

    if (!rows.length) return '';
    return `├─「 *STATISTIK* 」\n${rows.join('\n')}`;
}

function makeTikTokCaption(result = {}) {
    let caption = `*TIKTOK DOWNLOADER*\n\n`;
    if (result.authorName && result.authorName !== '-') {
        caption += `👤 *Author:* ${result.authorName}`;
        if (result.username && result.username !== '-') {
            caption += `\n(@${String(result.username).replace(/^@/, '')})`;
        }
        caption += `\n\n`;
    }
    if (result.title && result.title !== '-' && result.title !== 'Video TikTok') {
        caption += `📝 *Caption:* ${limitText(result.title, 300)}\n\n`;
    }
    if (result.music && result.music !== '-') caption += `🎵 *Music:* ${limitText(result.music, 180)}\n\n`;
    if (result.uploaded && result.uploaded !== '-') caption += `📅 *Uploaded:* ${result.uploaded}\n\n`;
    if (result.duration && result.duration !== '-') caption += `⏱️ *Duration:* ${result.duration}\n\n`;
    if (result.region && result.region !== '-') caption += `🌎 *Region:* ${result.region}\n\n`;
    const table = makeStatsTable(result.stats);
    if (table) caption += `${table}\n\n`;
    caption += `🔌 *Source:* ${result.source || 'BOTCAHX'}`;
    return caption.trim();
}

async function sendAudioButton(sock, m, audioUrl) {
    if (!audioUrl) return;
    const text = `🌿 Mau dapetin audionya juga?\nkalau mau bisa tekan tombol dibawah`;
    const buttons = [{
        name: 'cta_url',
        buttonParamsJson: JSON.stringify({ display_text: '📩 Unduh Audionya', url: audioUrl, merchant_url: audioUrl })
    }];
    try {
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: `© ${global.botname || 'Assistant X Project'}` }),
                        header: proto.Message.InteractiveMessage.Header.create({ title: '', hasMediaAttachment: false }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons })
                    })
                }
            }
        }, { quoted: m });
        await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    } catch (error) {
        await sock.sendMessage(m.chat, { text: `${text}\n\n🎵 Audio:\n${audioUrl}` }, { quoted: m });
    }
}

async function sendSlideChoice(sock, m, prefix, url, result) {
    const sessionId = `${m.sender.split('@')[0]}_${Date.now()}`;
    global.tiktokDownloadSessions[sessionId] = { url, result, createdAt: Date.now() };
    const buttons = [
        { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🎵 Slide + Audio', id: `${prefix}ttconfirm ${sessionId} audio` }) },
        { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🔇 Slide Saja', id: `${prefix}ttconfirm ${sessionId} noaudio` }) }
    ];

    try {
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text: `📸 *TIKTOK SLIDE TERDETEKSI*\n\nBot menemukan *${result.images.length} foto*.\nMau sertakan audio asli?` }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: `© ${global.botname || 'Assistant X Project'}` }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons })
                    })
                }
            }
        }, { quoted: m });
        await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    } catch (error) {
        await m.reply(`📸 *TIKTOK SLIDE TERDETEKSI*\n\nBot menemukan *${result.images.length} foto*.\n\nGunakan:\n${prefix}ttconfirm ${sessionId} audio\natau\n${prefix}ttconfirm ${sessionId} noaudio`);
    }
}

async function sendTikTokImages(sock, m, result, withAudio = false) {
    const caption = makeTikTokCaption(result);
    const maxSlides = Math.min(result.images.length, 15);

    for (let i = 0; i < maxSlides; i++) {
        await sock.sendMessage(m.chat, {
            image: { url: result.images[i] },
            caption: i === 0 ? caption : `📸 Slide ${i + 1}/${maxSlides}`
        }, { quoted: m });
        await delay(1500); 
    }

    if (withAudio && result.audios[0]) {
        await delay(1000);
        const audioBuffer = await fetchMediaBuffer(result.audios[0]);
        if (audioBuffer) {
            await sock.sendMessage(m.chat, { audio: audioBuffer, mimetype: 'audio/mpeg', fileName: 'tiktok-audio.mp3' }, { quoted: m });
        }
    }
}

async function fetchBotcahxTikTokSlide(url) {
    const apiUrl = buildBotcahxUrl('/api/download/tiktokslide', { url });
    const { data, status } = await axios.get(apiUrl, { timeout: REQUEST_TIMEOUT, validateStatus: () => true, headers: { 'User-Agent': 'Mozilla/5.0' } });

    if (!data || status >= 400 || data.status === false || data.success === false) return null;

    const root = data.result || data.data || data;
    const images = [];

    if (Array.isArray(root)) {
        images.push(...root);
    } else if (root.images) {
        images.push(...(Array.isArray(root.images) ? root.images : [root.images]));
    } else if (root.image) {
        images.push(...(Array.isArray(root.image) ? root.image : [root.image]));
    } else if (root.photo) {
        images.push(...(Array.isArray(root.photo) ? root.photo : [root.photo]));
    }

    return {
        title: 'TikTok Slide', authorName: '-', username: '-', music: '-', uploaded: '-', duration: '-', region: '-', thumbnail: '-',
        videos: [], audios: root.audio ? [root.audio] : [], images: uniqueUrls(images), stats: {}, source: 'BOTCAHX Slide API'
    };
}

async function fetchBotcahxTikTok(url) {
    const apiUrl = buildBotcahxUrl('/api/dowloader/tiktok', { url });
    const { data, status } = await axios.get(apiUrl, { timeout: REQUEST_TIMEOUT, validateStatus: () => true, headers: { 'User-Agent': 'Mozilla/5.0' } });
    if (!data || status >= 400 || data.status === false || data.success === false) return null;
    return normalizeBotcahx(data);
}

async function fetchTikwmTikTok(url) {
    try {
        const { data, status } = await axios.get('https://www.tikwm.com/api/', { timeout: REQUEST_TIMEOUT, validateStatus: () => true, params: { url, hd: 1 }, headers: { 'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json' } });
        if (!data || status >= 400 || (data.code !== 0 && data.msg && !data.data)) return null;
        return normalizeTikwm(data);
    } catch (error) {
        return null;
    }
}

async function fetchTikTok(url) {
    let botcahxResult = await fetchBotcahxTikTok(url).catch(() => null);
    let tikwmResult = await fetchTikwmTikTok(url).catch(() => null);
    const merged = mergeResults(botcahxResult, tikwmResult);
    if (!merged) throw new Error('Gagal mengambil data TikTok dari BOTCAHX dan TikWM.');
    if (!merged.videos.length && !merged.images.length && !merged.audios.length) throw new Error('Media TikTok tidak ditemukan.');
    return merged;
}

let handler = async (m, { sock, text, command, prefix, args }) => {
    cleanExpiredSessions();
    let url = null;
    let action = null;
    let result = null;

    if (command === 'ttconfirm') {
        const sessionId = args[0];
        action = String(args[1] || '').toLowerCase();
        const session = global.tiktokDownloadSessions[sessionId];
        if (!session) return m.reply(`❌ *Sesi TikTok sudah expired.*\n\nSilakan kirim ulang link TikTok.`);
        url = session.url;
        result = session.result;
    } else {
        url = extractTikTokUrl(text || args.join(' '));
    }

    if (!url) return m.reply(`❌ *Input URL TikTok!*\n\nContoh:\n${prefix}tiktok https://vt.tiktok.com/xxxx`);

    await m.react('⏳').catch(() => {});

    try {
        if (!result) {
            await sock.sendMessage(m.chat, { text: '⏳ *Bentar ya...*\nMedia TikTok sedang diekstrak...' }, { quoted: m });

            if (command === 'ttslide') {
                let slideResult = await fetchBotcahxTikTokSlide(url);
                let tikwmResult = await fetchTikwmTikTok(url);
                result = mergeResults(slideResult, tikwmResult);
                if(!result || result.images.length === 0) throw new Error('Gagal mengekstrak foto slide, URL ini sepertinya adalah video biasa.');
            } else {
                result = await fetchTikTok(url);
            }
        }

        // 🔥 LOGIKA SMART DETECTION YANG BENAR
        const hasVideo = result.videos.length > 0;
        const hasImages = result.images.length > 0;
        
        // Dianggap SLIDE hanya jika: dipaksa pakai .ttslide ATAU (tidak ada video) ATAU (ada gambar LEBIH DARI 1)
        const isSlide = (command === 'ttslide') || (hasImages && !hasVideo) || (hasImages && result.images.length > 1);

        // 1. Eksekusi Video Murni
        if (hasVideo && !isSlide) {
            const caption = makeTikTokCaption(result);
            let videoSent = false;

            for (let vidUrl of result.videos) {
                const videoBuffer = await fetchMediaBuffer(vidUrl);
                if (videoBuffer) {
                    await sock.sendMessage(m.chat, { video: videoBuffer, caption, mimetype: 'video/mp4' }, { quoted: m });
                    videoSent = true;
                    break; 
                }
            }

            if (!videoSent) throw new Error('Gagal mengunduh file MP4. Server TikTok memblokir akses atau file sudah dihapus.');
            if (result.audios[0]) await sendAudioButton(sock, m, result.audios[0]);
            
            await m.react('✅').catch(() => {});
            return;
        }

        // 2. Eksekusi Slide Foto
        if (isSlide) {
            if (command !== 'ttconfirm' && command !== 'ttslide') {
                await sendSlideChoice(sock, m, prefix, url, result);
                await m.react('✅').catch(() => {});
                return;
            }

            const includeAudio = action === 'audio' || (command === 'ttslide' && result.audios.length > 0);
            await sendTikTokImages(sock, m, result, includeAudio);

            if (command === 'ttconfirm') delete global.tiktokDownloadSessions[args[0]];
            await m.react('✅').catch(() => {});
            return;
        }

        // 3. Fallback pengiriman audio saja
        if (result.audios.length > 0) {
            const audioBuffer = await fetchMediaBuffer(result.audios[0]);
            if (audioBuffer) {
                await sock.sendMessage(m.chat, { audio: audioBuffer, mimetype: 'audio/mpeg', fileName: 'tiktok-audio.mp3' }, { quoted: m });
            }
            await m.react('✅').catch(() => {});
            return;
        }

        throw new Error('Media tidak ditemukan atau formatnya tidak didukung.');
    } catch (error) {
        console.error('[TIKTOK DOWNLOADER ERROR]', error);
        await m.react('❌').catch(() => {});
        return m.reply(`❌ *Gagal download TikTok.*\n\nPenyebab:\n${error.message || error}\n\nPastikan link valid dan video tidak private.`);
    }
};

handler.tags = ['downloader'];
handler.help = ['tiktok <url>', 'ttslide <url>'];
handler.command = ['tiktok', 'tt', 'ttconfirm', 'ttslide'];
handler.limit = true;

module.exports = handler;
