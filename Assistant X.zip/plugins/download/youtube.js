const axios = require('axios');
const { generateWAMessageFromContent } = require('@whiskeysockets/baileys');

const API_TIMEOUT = 45000;
const MEDIA_TIMEOUT = 120000;
const RETRY_DELAY = 7000;
const MAX_RETRY = 4;
const MAX_BUFFER_SIZE = 95 * 1024 * 1024; // 95 MB

const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

function loadYtdl() {
    try {
        return require('@distube/ytdl-core');
    } catch (_) {
        try {
            return require('ytdl-core');
        } catch (_) {
            return null;
        }
    }
}

function ensureBotcahx() {
    if (!global.btc && !global.botcahxKey) {
        throw new Error('BOTCAHX_APIKEY belum diisi di file .env.');
    }

    if (typeof global.botcahxUrl !== 'function') {
        throw new Error('global.botcahxUrl belum tersedia. Cek config.js.');
    }
}

function isUrl(value = '') {
    return /^https?:\/\//i.test(String(value || '').trim());
}

function cleanText(text = '') {
    return String(text || '')
        .replace(/[<>`]/g, '')
        .replace(/\u200e|\u200f|\u202a|\u202b|\u202c/g, '')
        .trim();
}

function extractYoutubeId(input = '') {
    const text = cleanText(input);

    const patterns = [
        /youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/i,
        /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/i,
        /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/i,
        /youtube\.com\/live\/([a-zA-Z0-9_-]{11})/i,
        /youtu\.be\/([a-zA-Z0-9_-]{11})/i,
        /[?&]v=([a-zA-Z0-9_-]{11})/i,
        /\b([a-zA-Z0-9_-]{11})\b/
    ];

    for (const pattern of patterns) {
        const match = text.match(pattern);
        if (match) return match[1];
    }

    return null;
}

function normalizeYoutubeUrl(input = '') {
    const id = extractYoutubeId(input);
    if (!id) return null;

    return {
        id,
        url: `https://www.youtube.com/watch?v=${id}`
    };
}

function safeText(value, fallback = '-') {
    if (value === undefined || value === null || value === '') return fallback;

    if (typeof value === 'object') {
        if (value.title) return safeText(value.title, fallback);
        if (value.name) return safeText(value.name, fallback);
        return fallback;
    }

    return String(value).trim() || fallback;
}

function sanitizeFileName(text = 'youtube') {
    return String(text || 'youtube')
        .replace(/[\\/:*?"<>|]/g, '')
        .replace(/\s+/g, ' ')
        .trim()
        .slice(0, 80) || 'youtube';
}

function limitText(text = '', max = 180) {
    const clean = safeText(text, '-');
    if (clean.length <= max) return clean;
    return clean.slice(0, max).trim() + '...';
}

function formatNumber(value) {
    if (value === undefined || value === null || value === '') return '-';

    const num = Number(String(value).replace(/[^\d.]/g, ''));

    if (!Number.isFinite(num)) return String(value);

    return num.toLocaleString('id-ID');
}

function getRoot(data = {}) {
    return data?.result || data?.data?.result || data?.data || data?.response || data;
}

function collectUrls(input, depth = 0) {
    if (!input || depth > 8) return [];

    const results = [];

    if (typeof input === 'string') {
        if (isUrl(input)) results.push(input.trim());
    } else if (Array.isArray(input)) {
        for (const item of input) {
            results.push(...collectUrls(item, depth + 1));
        }
    } else if (typeof input === 'object') {
        for (const value of Object.values(input)) {
            results.push(...collectUrls(value, depth + 1));
        }
    }

    return [...new Set(results)];
}

function isImageUrl(url = '') {
    const lower = String(url).toLowerCase();

    return (
        lower.includes('ytimg.com') ||
        /\.(jpg|jpeg|png|webp|gif)(\?|$)/i.test(lower)
    );
}

function isYoutubePageUrl(url = '') {
    const lower = String(url).toLowerCase();

    return (
        lower.includes('youtube.com/watch') ||
        lower.includes('youtube.com/shorts') ||
        lower.includes('youtu.be/')
    );
}

function isKnownRedirectLoopUrl(url = '') {
    const lower = String(url || '').toLowerCase();

    return (
        lower.includes('c.ymcdn.org/api/v2/download') ||
        lower.includes('redirector.googlevideo.com')
    );
}

function pickYoutubeCandidates(data, isAudio = false, originalUrl = '') {
    const root = getRoot(data);
    if (!root) return [];

    let candidates = [];

    if (isAudio) {
        candidates.push(...collectUrls(root.mp3));
        candidates.push(...collectUrls(root.audio));
        candidates.push(...collectUrls(root.url_audio));
        candidates.push(...collectUrls(root.audio_url));
        candidates.push(...collectUrls(root.m4a));
        candidates.push(...collectUrls(root.download?.mp3));
        candidates.push(...collectUrls(root.download?.audio));
        candidates.push(...collectUrls(root.download?.m4a));
    } else {
        candidates.push(...collectUrls(root.mp4));
        candidates.push(...collectUrls(root.video));
        candidates.push(...collectUrls(root.url_video));
        candidates.push(...collectUrls(root.video_url));
        candidates.push(...collectUrls(root.hd));
        candidates.push(...collectUrls(root.sd));
        candidates.push(...collectUrls(root.download?.mp4));
        candidates.push(...collectUrls(root.download?.video));
    }

    if (!candidates.length) {
        candidates.push(...collectUrls(root.url));
        candidates.push(...collectUrls(root.download));
        candidates.push(...collectUrls(root.media));
    }

    if (!candidates.length) {
        candidates.push(...collectUrls(root));
    }

    return [...new Set(candidates)]
        .filter(Boolean)
        .filter(url => url !== originalUrl)
        .filter(url => !isYoutubePageUrl(url))
        .filter(url => !isImageUrl(url));
}

function pickMetaFromBotcahx(data = {}) {
    const root = getRoot(data) || {};

    return {
        title: safeText(root.title || root.nama || root.name, '-'),
        author: safeText(root.author || root.channel || root.creator, '-'),
        duration: safeText(root.duration || root.timestamp, '-'),
        thumbnail: safeText(root.thumbnail || root.thumb || root.image, '-')
    };
}

async function getYoutubeMeta(ytId) {
    try {
        const yts = require('yt-search');
        const info = await yts({ videoId: ytId });

        if (!info) return null;

        return {
            title: safeText(info.title, '-'),
            author: safeText(info.author?.name || info.author, '-'),
            duration: safeText(info.timestamp || info.duration?.timestamp, '-'),
            views: info.views || '-',
            thumbnail: safeText(info.thumbnail, '-'),
            url: info.url || `https://www.youtube.com/watch?v=${ytId}`
        };
    } catch (error) {
        console.log('[YT META ERROR]', error.message);
        return null;
    }
}

function mergeMeta(local = {}, botcahx = {}, fallbackUrl = '') {
    return {
        title:
            local?.title && local.title !== '-'
                ? local.title
                : botcahx?.title || 'YouTube Media',

        author:
            local?.author && local.author !== '-'
                ? local.author
                : botcahx?.author || '-',

        duration:
            local?.duration && local.duration !== '-'
                ? local.duration
                : botcahx?.duration || '-',

        views:
            local?.views && local.views !== '-'
                ? local.views
                : '-',

        thumbnail:
            local?.thumbnail && local.thumbnail !== '-'
                ? local.thumbnail
                : botcahx?.thumbnail || '-',

        url: local?.url || fallbackUrl
    };
}

function makeYoutubeCaption(meta = {}, format = 'MP4', source = 'BOTCAHX') {
    let caption = `╭──「 *📥 YOUTUBE DOWNLOADER* 」\n`;

    if (meta.title && meta.title !== '-') {
        caption += `│ 🎬 *Judul:* ${limitText(meta.title, 180)}\n`;
    }

    if (meta.author && meta.author !== '-') {
        caption += `│ 👤 *Channel:* ${limitText(meta.author, 80)}\n`;
    }

    if (meta.duration && meta.duration !== '-') {
        caption += `│ ⏱️ *Durasi:* ${meta.duration}\n`;
    }

    if (meta.views && meta.views !== '-') {
        caption += `│ 👀 *Views:* ${formatNumber(meta.views)}\n`;
    }

    caption += `│ 📦 *Format:* ${format}\n`;
    caption += `│ 🔌 *Source:* ${source}\n`;
    caption += `╰────────────`;

    return caption.trim();
}

async function fetchYoutubeFromBotcahx(url, isAudio) {
    ensureBotcahx();

    let lastError = null;

    for (let attempt = 1; attempt <= MAX_RETRY; attempt++) {
        try {
            const apiUrl = global.botcahxUrl('/api/dowloader/yt', { url });

            const { data, status } = await axios.get(apiUrl, {
                timeout: API_TIMEOUT,
                validateStatus: () => true,
                headers: {
                    'User-Agent': 'Mozilla/5.0',
                    Accept: 'application/json'
                }
            });

            if (!data) throw new Error(`Response BOTCAHX kosong.`);
            if (status >= 500) throw new Error(`Server BOTCAHX error. HTTP ${status}.`);
            if (status >= 400) throw new Error(`Request BOTCAHX gagal. HTTP ${status}.`);

            if (data.status === false || data.success === false) {
                throw new Error(data.message || data.error || 'BOTCAHX gagal memproses media.');
            }

            const candidates = pickYoutubeCandidates(data, isAudio, url);

            if (candidates.length) {
                return {
                    raw: data,
                    candidates
                };
            }

            throw new Error('URL download kosong dari BOTCAHX.');
        } catch (error) {
            lastError = error;
            console.log(`[BOTCAHX YT RETRY] ${attempt}/${MAX_RETRY}: ${error.message}`);

            if (attempt < MAX_RETRY) {
                await delay(RETRY_DELAY);
            }
        }
    }

    throw lastError || new Error('Gagal mengambil data dari BOTCAHX.');
}

async function downloadMediaBuffer(url, type = 'video') {
    if (isKnownRedirectLoopUrl(url)) {
        throw new Error('Link BOTCAHX terdeteksi redirect loop.');
    }

    const response = await axios.get(url, {
        responseType: 'arraybuffer',
        timeout: MEDIA_TIMEOUT,
        maxRedirects: 8,
        maxContentLength: MAX_BUFFER_SIZE,
        maxBodyLength: MAX_BUFFER_SIZE,
        validateStatus: status => status >= 200 && status < 400,
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36',
            Accept: '*/*',
            Referer: 'https://www.youtube.com/'
        }
    });

    const buffer = Buffer.from(response.data);

    if (!buffer.length) {
        throw new Error(`Buffer ${type} kosong.`);
    }

    return {
        buffer,
        contentType: response.headers['content-type'] || ''
    };
}

async function trySendBotcahxMedia(sock, m, candidates, isAudio, meta) {
    let lastError = null;
    const title = sanitizeFileName(meta.title || 'youtube');
    const caption = makeYoutubeCaption(meta, isAudio ? 'MP3' : 'MP4', 'BOTCAHX');

    for (let i = 0; i < candidates.length; i++) {
        const url = candidates[i];

        try {
            console.log(`[YT BOTCAHX MEDIA TRY] ${i + 1}/${candidates.length}: ${url.slice(0, 120)}`);

            const media = await downloadMediaBuffer(url, isAudio ? 'audio' : 'video');

            if (isAudio) {
                await sock.sendMessage(m.chat, {
                    audio: media.buffer,
                    mimetype: 'audio/mpeg',
                    fileName: `${title}.mp3`
                }, {
                    quoted: m
                });

                return true;
            }

            try {
                await sock.sendMessage(m.chat, {
                    video: media.buffer,
                    caption,
                    mimetype: 'video/mp4',
                    fileName: `${title}.mp4`
                }, {
                    quoted: m
                });

                return true;
            } catch (sendVideoError) {
                await sock.sendMessage(m.chat, {
                    document: media.buffer,
                    mimetype: 'video/mp4',
                    fileName: `${title}.mp4`,
                    caption: `${caption}\n\n⚠️ Dikirim sebagai dokumen karena WhatsApp gagal memproses video langsung.`
                }, {
                    quoted: m
                });

                return true;
            }
        } catch (error) {
            lastError = error;
            console.log(`[YT BOTCAHX MEDIA FAILED] ${i + 1}/${candidates.length}: ${error.message}`);
        }
    }

    throw lastError || new Error('Semua link BOTCAHX gagal.');
}

function streamToBuffer(stream, maxSize = MAX_BUFFER_SIZE) {
    return new Promise((resolve, reject) => {
        const chunks = [];
        let size = 0;

        stream.on('data', chunk => {
            size += chunk.length;

            if (size > maxSize) {
                stream.destroy(new Error(`Ukuran media melebihi batas ${Math.round(maxSize / 1024 / 1024)} MB.`));
                return;
            }

            chunks.push(chunk);
        });

        stream.on('end', () => resolve(Buffer.concat(chunks)));
        stream.on('error', reject);
    });
}

function chooseVideoFormat(ytdl, info) {
    const formats = info.formats || [];

    let format = formats.find(f => {
        return f.itag === 18 && f.hasVideo && f.hasAudio;
    });

    if (format) return format;

    format = formats.find(f => {
        return f.hasVideo && f.hasAudio && String(f.container || '').toLowerCase() === 'mp4';
    });

    if (format) return format;

    format = formats.find(f => f.hasVideo && f.hasAudio);

    if (format) return format;

    try {
        return ytdl.chooseFormat(formats, {
            quality: '18',
            filter: 'audioandvideo'
        });
    } catch (_) {
        return null;
    }
}

function chooseAudioFormat(ytdl, info) {
    try {
        return ytdl.chooseFormat(info.formats, {
            quality: 'highestaudio',
            filter: 'audioonly'
        });
    } catch (_) {
        return (info.formats || []).find(f => f.hasAudio && !f.hasVideo) || null;
    }
}

async function sendViaYtdlFallback(sock, m, cleanUrl, isAudio, meta) {
    const ytdl = loadYtdl();

    if (!ytdl) {
        throw new Error('Fallback ytdl belum terinstall. Jalankan: npm install @distube/ytdl-core');
    }

    if (typeof ytdl.validateURL === 'function' && !ytdl.validateURL(cleanUrl)) {
        throw new Error('URL YouTube tidak valid untuk fallback ytdl.');
    }

    console.log('[YT FALLBACK] Menggunakan @distube/ytdl-core');

    const info = await ytdl.getInfo(cleanUrl);
    const title = sanitizeFileName(meta.title || info.videoDetails?.title || 'youtube');

    if (isAudio) {
        const format = chooseAudioFormat(ytdl, info);

        if (!format) {
            throw new Error('Format audio tidak ditemukan dari fallback ytdl.');
        }

        const stream = ytdl.downloadFromInfo(info, {
            format,
            highWaterMark: 1 << 25
        });

        const buffer = await streamToBuffer(stream);

        const mimetype = String(format.mimeType || '').split(';')[0] || 'audio/mp4';

        await sock.sendMessage(m.chat, {
            audio: buffer,
            mimetype,
            fileName: `${title}.mp3`
        }, {
            quoted: m
        });

        return true;
    }

    const format = chooseVideoFormat(ytdl, info);

    if (!format) {
        throw new Error('Format video+audio tidak ditemukan dari fallback ytdl.');
    }

    const stream = ytdl.downloadFromInfo(info, {
        format,
        highWaterMark: 1 << 25
    });

    const buffer = await streamToBuffer(stream);
    const caption = makeYoutubeCaption(meta, 'MP4', '@distube/ytdl-core');

    try {
        await sock.sendMessage(m.chat, {
            video: buffer,
            caption,
            mimetype: 'video/mp4',
            fileName: `${title}.mp4`
        }, {
            quoted: m
        });
    } catch (_) {
        await sock.sendMessage(m.chat, {
            document: buffer,
            mimetype: 'video/mp4',
            fileName: `${title}.mp4`,
            caption
        }, {
            quoted: m
        });
    }

    return true;
}

async function sendFormatPicker(sock, m, prefix, url) {
    const rows = [
        {
            title: '🎥 VIDEO (MP4)',
            description: 'Download sebagai video',
            id: `${prefix}ytmp4 ${url}`
        },
        {
            title: '🎵 AUDIO (MP3)',
            description: 'Download sebagai audio',
            id: `${prefix}ytmp3 ${url}`
        }
    ];

    const bodyText = `╭──「 *📥 YOUTUBE DOWNLOADER* 」
│ 🔗 *Link:* ${url}
│
│ Jika tombol tidak muncul:
│ • ${prefix}ytmp4 ${url}
│ • ${prefix}ytmp3 ${url}
╰────────────

© ${global.botname || 'Assistant X Project'}`;

    const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: {
                        text: bodyText
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: 'single_select',
                                buttonParamsJson: JSON.stringify({
                                    title: 'Pilih Format',
                                    sections: [
                                        {
                                            title: 'OPSI UNDUHAN',
                                            rows
                                        }
                                    ]
                                })
                            }
                        ]
                    }
                }
            }
        }
    }, {
        userJid: m.chat,
        quoted: m
    });

    return sock.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id
    });
}

async function sendSearchPicker(sock, m, prefix, query, results) {
    const rows = results.map(video => ({
        title: `🎬 ${String(video.title || 'Tanpa Judul').substring(0, 60)}`,
        description: `⏱️ ${video.timestamp || '-'} | 👤 ${video.author?.name || '-'}`,
        id: `${prefix}yt ${video.url}`
    }));

    const bodyText = `╭──「 *🔍 YOUTUBE SEARCH* 」
│ 🔎 *Query:* ${query}
│ 📦 *Hasil:* ${results.length} video
╰────────────

© ${global.botname || 'Assistant X Project'}`;

    const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: {
                        text: bodyText
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: 'single_select',
                                buttonParamsJson: JSON.stringify({
                                    title: 'Pilih Video',
                                    sections: [
                                        {
                                            title: 'HASIL PENCARIAN',
                                            rows
                                        }
                                    ]
                                })
                            }
                        ]
                    }
                }
            }
        }
    }, {
        userJid: m.chat,
        quoted: m
    });

    return sock.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id
    });
}

let handler = async (m, { sock, text, args, prefix, command }) => {
    const cmd = String(command || '').toLowerCase();
    const usedPrefix = prefix || '.';

    if (cmd === 'yts' || cmd === 'ytsearch') {
        const query = String(text || (args || []).join(' ') || '').trim();

        if (!query) {
            await m.react('⚠️').catch(() => {});
            return m.reply(`❌ Cari video apa?

Contoh:
${usedPrefix + cmd} hindia`);
        }

        await m.react('⏳').catch(() => {});

        try {
            const yts = require('yt-search');
            const search = await yts(query);
            const results = (search.videos || []).slice(0, 5);

            if (!results.length) {
                throw new Error('Video tidak ditemukan.');
            }

            await sendSearchPicker(sock, m, usedPrefix, query, results);

            await m.react('✅').catch(() => {});
            return;
        } catch (error) {
            console.error('[YT SEARCH ERROR]', error);
            await m.react('❌').catch(() => {});
            return m.reply(`❌ Pencarian gagal.

Detail:
${error.message || error}`);
        }
    }

    if (cmd === 'yt' || cmd === 'ytdl') {
        const input = String(text || (args || []).join(' ') || '').trim();
        const normalized = normalizeYoutubeUrl(input);

        if (!normalized) {
            await m.react('⚠️').catch(() => {});
            return m.reply(`❌ Link YouTube tidak valid.

Contoh:
${usedPrefix + cmd} https://youtube.com/watch?v=xxxxxxxxxxx`);
        }

        await m.react('⏳').catch(() => {});

        try {
            await sendFormatPicker(sock, m, usedPrefix, normalized.url);

            await m.react('✅').catch(() => {});
            return;
        } catch (error) {
            console.error('[YT FORMAT PICKER ERROR]', error);
            await m.react('❌').catch(() => {});

            return m.reply(`❌ Gagal menampilkan pilihan format.

Gunakan manual:
${usedPrefix}ytmp4 ${normalized.url}
${usedPrefix}ytmp3 ${normalized.url}`);
        }
    }

    if (cmd === 'ytmp4' || cmd === 'ytmp3') {
        let input = String(text || (args || []).join(' ') || '').trim();

        if (!input && m.quoted && m.quoted.text) {
            input = m.quoted.text;
        }

        const normalized = normalizeYoutubeUrl(input);

        if (!normalized) {
            await m.react('⚠️').catch(() => {});
            return m.reply(`❌ Link YouTube tidak valid.

Contoh:
${usedPrefix + cmd} https://youtube.com/watch?v=xxxxxxxxxxx`);
        }

        const isAudio = cmd === 'ytmp3';

        await m.react('⏳').catch(() => {});

        try {
            await m.reply(`⏳ *Sedang mengambil ${isAudio ? 'audio' : 'video'}...*

Urutan proses:
1. Coba BOTCAHX
2. Kalau link BOTCAHX redirect loop, otomatis fallback ytdl`);

            const localMeta = await getYoutubeMeta(normalized.id);

            let botcahxMeta = {};
            let botcahxFailed = false;

            try {
                const result = await fetchYoutubeFromBotcahx(normalized.url, isAudio);
                botcahxMeta = pickMetaFromBotcahx(result.raw);

                const meta = mergeMeta(localMeta, botcahxMeta, normalized.url);

                await trySendBotcahxMedia(sock, m, result.candidates, isAudio, meta);

                await m.react('✅').catch(() => {});
                return;
            } catch (botcahxError) {
                botcahxFailed = true;
                console.log('[YT BOTCAHX FAILED - FALLBACK ACTIVE]', botcahxError.message);
            }

            const meta = mergeMeta(localMeta, botcahxMeta, normalized.url);

            await sendViaYtdlFallback(sock, m, normalized.url, isAudio, meta);

            await m.react('✅').catch(() => {});
            return;
        } catch (error) {
            console.error('[YT DOWNLOADER ERROR]', error.message || error);
            await m.react('❌').catch(() => {});

            const message = String(error.message || error);

            if (/install @distube\/ytdl-core|belum terinstall/i.test(message)) {
                return m.reply(`❌ *BOTCAHX gagal dan fallback belum terinstall.*

Jalankan di terminal panel:
npm install @distube/ytdl-core

Lalu restart bot.`);
            }

            if (/sign in|confirm|bot|403|410/i.test(message)) {
                return m.reply(`❌ *Fallback YouTube ditolak oleh YouTube.*

Penyebab:
YouTube meminta verifikasi/sign in atau membatasi server.

Coba:
1. Ulangi beberapa menit lagi.
2. Pakai link video biasa, bukan Shorts.
3. Coba format MP3 jika MP4 gagal.`);
            }

            return m.reply(`❌ *Gagal mengambil media YouTube.*

Detail:
${message}`);
        }
    }
};

handler.command = ['yts', 'ytsearch', 'yt', 'ytdl', 'ytmp4', 'ytmp3'];
handler.tags = ['downloader'];
handler.help = [
    'yt <url>',
    'ytmp4 <url>',
    'ytmp3 <url>',
    'yts <query>'
];
handler.limit = true;

module.exports = handler;