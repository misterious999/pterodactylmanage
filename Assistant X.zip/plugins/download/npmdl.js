const axios = require("axios")
const fs = require("fs")
const path = require("path")
const tar = require("tar")
const AdmZip = require("adm-zip")

let handler = async (m, { sock, text, prefix, command }) => {
  if (!text) {
    return m.reply(`✦ *Format Tidak Lengkap*\n\nSertakan nama package NPM.\nContoh: *${prefix}${command} @whiskeysockets/baileys*`)
  }

  await m.react('⏳').catch(() => {})
  let { key } = await sock.sendMessage(m.chat, { text: "✦ _Menyelaraskan sinyal dengan satelit NPM... Mohon tunggu._" }, { quoted: m })

  try {
    let pkgName = text.trim()

    const info = await axios.get(`https://registry.npmjs.org/${encodeURIComponent(pkgName)}`)
    const version = info.data["dist-tags"].latest

    const meta = await axios.get(`https://registry.npmjs.org/${encodeURIComponent(pkgName)}/${version}`)
    const tarballUrl = meta.data.dist.tarball

    if (!tarballUrl) throw new Error("Tarball tidak ditemukan untuk package ini.")

    await sock.sendMessage(m.chat, { text: `✦ _Mengunduh ${pkgName} v${version} dan merakit ulang arsip..._`, edit: key })

    const tmpDir = path.join(process.cwd(), "tmp")
    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true })

    const safeName = pkgName.replace(/[\/@]/g, "_")
    const tarballPath = path.join(tmpDir, `${safeName}-${version}.tgz`)
    const extractPath = path.join(tmpDir, `${safeName}-${version}`)

    const res = await axios.get(tarballUrl, { responseType: "arraybuffer" })
    fs.writeFileSync(tarballPath, res.data)

    fs.mkdirSync(extractPath, { recursive: true })
    await tar.x({ file: tarballPath, cwd: extractPath, strip: 1 })

    const zip = new AdmZip()
    zip.addLocalFolder(extractPath)

    const zipPath = path.join(tmpDir, `${safeName}-${version}.zip`)
    zip.writeZip(zipPath)

    let captionText = `✦ *N P M   D O W N L O A D E R* ✦\n\n`
    captionText += `📦 *Package:* ${pkgName}\n`
    captionText += `🏷️ *Version:* ${version}\n\n`
    captionText += `> 🔗 _Source: Verified NPM Registry_`

    await sock.sendMessage(
      m.chat,
      {
        document: fs.readFileSync(zipPath),
        mimetype: "application/zip",
        fileName: `${safeName}-${version}.zip`,
        caption: captionText
      },
      { quoted: m }
    )

    fs.unlinkSync(tarballPath)
    fs.rmSync(extractPath, { recursive: true, force: true })
    fs.unlinkSync(zipPath)

    await sock.sendMessage(m.chat, { delete: key }).catch(() => {})
    await m.react('✅').catch(() => {})

  } catch (err) {
    console.error("[NPM ERROR]", err.message)
    await m.react('❌').catch(() => {})
    await sock.sendMessage(m.chat, { text: `✦ *Sistem Mengalami Kendala*\n\n_${err.message || "Package tidak ditemukan atau koneksi terputus."}_`, edit: key })
  }
}

handler.help = ['npmdl <package>']
handler.tags = ['download']
handler.command = ['npmdl'] 
handler.owner = true

module.exports = handler
