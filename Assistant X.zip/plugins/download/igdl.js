const axios = require('axios');

// ==========================================
// 📸 XENORIA DOWNLOADER: INSTAGRAM ENGINE
// ⚙️ Minimalist & Clean UI Architecture
// ==========================================

let handler = async (m, { sock, args, prefix, command }) => {
    if (!args[0]) {
        return m.reply(`✦ *Format Tidak Lengkap*\n\nSertakan tautan Instagram (Reels, Post, IGTV, atau Story).\nContoh: *${prefix + command} https://www.instagram.com/p/xxx*`);
    }

    let url = args[0];

    if (!url.match(/(?:https?:\/\/)?(?:www\.)?(?:instagram\.com\/)(?:reel|p|tv|stories)\/?([a-zA-Z0-9_-]+)/i)) {
        return m.reply("✦ *Tautan Tidak Valid*\n\nPastikan tautan yang dimasukkan berasal dari domain resmi Instagram.");
    }

    if (!global.btc) {
        await m.react("🔒").catch(() => {});
        return m.reply("✦ *Sistem Terkunci*\n\nKunci API Botcahx belum dikonfigurasi di server.");
    }

    await m.react("⏳").catch(() => {});
    let { key } = await sock.sendMessage(m.chat, { text: "✦ _Menyelaraskan sinyal dengan satelit Instagram... Mohon tunggu._" }, { quoted: m });

    try {
        let apiUrl = global.botcahxUrl('/api/dowloader/igdowloader', { url });
        
        let { data } = await axios.get(apiUrl, { timeout: 30000 });
        let resultData = data.result || data.data || data;

        if (!resultData || resultData.length === 0) {
             throw new Error("Data media hampa. Pastikan akun target tidak bersifat Private.");
        }

        if (!Array.isArray(resultData)) {
            resultData = [resultData];
        }

        let totalMedia = resultData.length;
        await sock.sendMessage(m.chat, { text: `✦ _Berhasil menemukan ${totalMedia} media. Memulai proses ekstraksi..._`, edit: key });

        for (let i = 0; i < totalMedia; i++) {
            let mediaUrl = resultData[i].url || resultData[i];
            let isVideo = mediaUrl.includes('.mp4') || !mediaUrl.includes('.jpg');
            
            let captionText = `✦ *I G   D O W N L O A D E R* ✦\n\n`;
            captionText += `📸 *Slide:* ${i + 1} dari ${totalMedia}\n\n`;
            captionText += `> 🔗 _Source: Verified Instagram_`;

            try {
                let mediaRes = await axios.get(mediaUrl, {
                    responseType: 'arraybuffer',
                    headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' },
                    timeout: 30000
                });
                let buffer = Buffer.from(mediaRes.data);

                if (isVideo) {
                    await sock.sendMessage(m.chat, { video: buffer, caption: captionText }, { quoted: m });
                } else {
                    await sock.sendMessage(m.chat, { image: buffer, caption: captionText }, { quoted: m });
                }
            } catch (errSend) {
                await sock.sendMessage(m.chat, { text: `✦ *Ekstraksi Slide ${i+1} Terkendala*\n\nSilakan unduh manual melalui tautan berikut:\n📥 ${mediaUrl}` }, { quoted: m });
            }
            
            if (totalMedia > 1) await new Promise(resolve => setTimeout(resolve, 2000));
        }
        
        await sock.sendMessage(m.chat, { delete: key }).catch(() => {});
        await m.react("✅").catch(() => {});

    } catch (e) {
        console.error("[INSTAGRAM ERROR]", e.message);
        await m.react("❌").catch(() => {});
        
        await sock.sendMessage(m.chat, { text: `✦ *Sistem Mengalami Kendala*\n\n_${e.message || 'Gagal memproses tautan.'}_`, edit: key });
    }
}

handler.command = ['ig'];
handler.tags = ['downloader'];
handler.help = ['ig <url instagram>']; 
handler.limit = true;

module.exports = handler;
