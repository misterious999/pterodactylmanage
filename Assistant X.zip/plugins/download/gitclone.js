// ==========================================
// 📦 XENORIA DOWNLOADER: GITHUB CLONE
// ⚙️ Minimalist & Clean UI Architecture
// ==========================================

let handler = async (m, { sock, text, prefix, command }) => {
  // Pengecekan input kosong
  if (!text) {
    return m.reply(`✦ *Format Tidak Lengkap*\n\nSertakan tautan repositori GitHub.\nContoh: *${prefix}${command} https://github.com/Skyzopedia/Wabot*`);
  }

  // Validasi URL menggunakan Regex
  let regex = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i; //[span_1](start_span)[span_1](end_span)
  if (!regex.test(text)) {
    return m.reply(`✦ *Tautan Tidak Valid*\n\nPastikan tautan yang dimasukkan adalah URL repositori GitHub yang sah.`);
  }

  // Indikator proses dimulai
  await m.react('⏳').catch(() => {});
  await sock.sendMessage(m.chat, { text: '✦ _Menarik data dari satelit GitHub... Mohon tunggu._' }, { quoted: m });

  try {
    // Ekstraksi nama User dan Repositori
    let [, user, repo] = text.match(regex) || []; //[span_2](start_span)[span_2](end_span)
    repo = repo.replace(/\.git$/, ""); //[span_3](start_span)[span_3](end_span)

    // Membentuk URL API Github
    let url = `https://api.github.com/repos/${user}/${repo}/zipball`; //[span_4](start_span)[span_4](end_span)
    let res = await fetch(url, { method: "HEAD" }); //[span_5](start_span)[span_5](end_span)

    // Menangani error jika repo private atau dihapus
    if (!res.ok) throw new Error("Repositori tidak ditemukan (Mungkin Private atau Dihapus).");

    // Mengambil nama file dari response header
    let cd = res.headers.get("content-disposition"); //[span_6](start_span)[span_6](end_span)
    let filename = cd ? cd.match(/attachment; filename="?([^"]+)"?/)[1] : `${repo}.zip`; //[span_7](start_span)[span_7](end_span)

    // Antarmuka Teks Elegan (Tanpa Garis Kaku)
    let caption = `✦ *G I T H U B   C L O N E* ✦\n\n`;
    caption += `📦 *Repositori:* ${repo}\n`;
    caption += `👤 *Kreator:* ${user}\n\n`;
    caption += `> 🔗 _Source: Verified Repository_`;

    // Mengirim dokumen zip
    await sock.sendMessage(
      m.chat,
      {
        document: { url }, //[span_8](start_span)[span_8](end_span)
        mimetype: "application/zip", //[span_9](start_span)[span_9](end_span)
        fileName: filename, //[span_10](start_span)[span_10](end_span)
        caption: caption
      },
      { quoted: m }
    );

    // Indikator sukses
    await m.react('✅').catch(() => {});

  } catch (e) {
    console.error('[GITCLONE ERROR]', e);
    await m.react('❌').catch(() => {});
    m.reply(`✦ *Sistem Mengalami Kendala*\n\n_${e.message || "Tautan tidak valid atau koneksi terputus."}_`);
  }
}

handler.command = ["gitclone"];
handler.tags = ["downloader"]; 
handler.help = ["gitclone <url github>"]; 

module.exports = handler; 
