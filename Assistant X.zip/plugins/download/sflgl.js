const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36';

function parseCookies(res, existing = {}) {
    const map = { ...existing };
    (res.headers.getSetCookie?.() || []).forEach(c => {
        const [pair] = c.split(';');
        const idx = pair.indexOf('=');
        if (idx > 0) map[pair.slice(0, idx).trim()] = pair.slice(idx + 1).trim();
    });
    return map;
}

const cookieStr = map => Object.entries(map).map(([k, v]) => `${k}=${v}`).join('; ');

async function fetchFollowManual(url, opts = {}, cookieMap = {}) {
    let currentUrl = url;
    let cookies = { ...cookieMap };
    let res;

    for (let i = 0; i < 10; i++) {
        res = await fetch(currentUrl, {
            ...opts,
            headers: { ...(opts.headers || {}), 'cookie': cookieStr(cookies) },
            redirect: 'manual'
        });
        cookies = parseCookies(res, cookies);

        if (res.status >= 300 && res.status < 400) {
            const loc = res.headers.get('location');
            if (!loc) break;
            currentUrl = loc.startsWith('http') ? loc : new URL(loc, currentUrl).href;
        } else {
            break;
        }
    }

    return { res, finalUrl: currentUrl, cookies };
}

async function bypassSflGl(targetUrl) {
    const startTime = Date.now();
    const t = () => `${((Date.now() - startTime) / 1000).toFixed(2)}s`;
    let cookies = {};

    try {
        const { res: res1, cookies: c1 } = await fetchFollowManual(targetUrl, {
            headers: { 'user-agent': UA, 'accept': 'text/html,*/*', 'accept-language': 'en-US,en;q=0.9' }
        }, cookies);
        cookies = c1;
        const html1 = await res1.text();

        const rayId = html1.match(/name="ray_id"\s+value="([^"]+)"/)?.[1];
        const alias = html1.match(/name="alias"\s+value="([^"]+)"/)?.[1];
        if (!rayId || !alias) throw new Error(`Ray_id/Alias tidak ditemukan. Sistem keamanan mungkin diperbarui.`);

        const khaddaviBase = 'https://app.khaddavi.net';
        
        const { res: res2, finalUrl: pageUrl, cookies: c2 } = await fetchFollowManual(
            `${khaddaviBase}/redirect.php?ray_id=${rayId}&alias=${alias}`,
            { headers: { 'user-agent': UA, 'accept': 'text/html,*/*', 'referer': targetUrl } },
            cookies
        );
        cookies = c2;

        const xsrf = cookies['XSRF-TOKEN'] ? decodeURIComponent(cookies['XSRF-TOKEN']) : '';

        const apiHeaders = {
            'user-agent': UA,
            'content-type': 'application/json',
            'accept': 'application/json, */*',
            'accept-language': 'en-US,en;q=0.9',
            'origin': khaddaviBase,
            'referer': pageUrl,
            'x-xsrf-token': xsrf,
            'sec-ch-ua': '"Chromium";v="127", "Not)A;Brand";v="99", "Google Chrome";v="127"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'cors',
            'sec-fetch-dest': 'empty'
        };

        const res3 = await fetch(`${khaddaviBase}/api/verify`, {
            method: 'POST',
            headers: { ...apiHeaders, 'cookie': cookieStr(cookies) },
            body: JSON.stringify({ _a: 0 })
        });
        cookies = parseCookies(res3, cookies);
        const verifyData = await res3.json();
        if (!verifyData.target) throw new Error(`Verifikasi gagal dibongkar.`);

        const k = Math.floor(Math.random() * 1000);
        const r = Math.random().toString(16).slice(2);
        const size = `${(1920 + k) * 2}.${(1080 + k) * 2}`;

        const res6 = await fetch(`${khaddaviBase}/api/go`, {
            method: 'POST',
            headers: {
                ...apiHeaders,
                'x-requested-with': 'XMLHttpRequest',
                'idempotency-key': r,
                'cookie': cookieStr(cookies)
            },
            body: JSON.stringify({ key: k, size, _dvc: r })
        });
        const goData = await res6.json();

        const readyUrl = goData.url;
        if (!readyUrl) throw new Error(`Gagal mendapatkan link injeksi akhir.`);

        const { res: res7 } = await fetchFollowManual(readyUrl, {
            headers: { 'user-agent': UA, 'accept': 'text/html,*/*', 'referer': khaddaviBase }
        });
        const html7 = await res7.text();

        const finalMatch = html7.match(/window\.location\.href\s*=\s*"([^"]+)"/);
        if (!finalMatch) throw new Error(`Tautan akhir tidak ditemukan.`);

        const finalUrl = finalMatch[1].replace(/\\\//g, '/');

        return { status: 'success', result: finalUrl, time_taken: t() };

    } catch (err) {
        return { status: 'failed', error: err.message, time_taken: t() };
    }
}

let handler = async (m, { sock, args, prefix, command }) => {
    if (!args[0]) {
        return m.reply(`✦ *Format Tidak Lengkap*\n\nSertakan tautan Sfl.gl.\nContoh: *${prefix}${command} https://sfl.gl/xxx*`);
    }

    let url = args[0];

    if (!url.includes('sfl.gl')) {
        return m.reply("✦ *Tautan Tidak Valid*\n\nPastikan tautan yang dimasukkan berasal dari domain resmi Sfl.gl.");
    }

    await m.react('⏳').catch(() => {});
    let { key } = await sock.sendMessage(m.chat, { text: "✦ _Membongkar sistem keamanan Sfl.gl... Mohon tunggu._" }, { quoted: m });

    try {
        let res = await bypassSflGl(url);

        if (res.status === 'failed') {
            throw new Error(res.error);
        }

        let teksSukses = `✦ *S F L . G L   B Y P A S S E R* ✦\n\n`;
        teksSukses += `⏱️ *Waktu Eksekusi:* ${res.time_taken}\n\n`;
        teksSukses += `🚀 *H A S I L   M U R N I:*\n${res.result}\n\n`;
        teksSukses += `> 🔗 _Source: Verified Bypasser Engine_`;

        await sock.sendMessage(m.chat, { text: teksSukses, edit: key });
        await m.react('✅').catch(() => {});

    } catch (e) {
        console.error('[SFLGL BYPASS ERROR]', e);
        await m.react('❌').catch(() => {});
        await sock.sendMessage(m.chat, { 
            text: `✦ *Sistem Mengalami Kendala*\n\n_${e.message || e}_` 
        }, { edit: key });
    }
}

handler.help = ['sflgl <link>'];
handler.tags = ['downloader'];
handler.command = ['sflgl']; 

module.exports = handler;
