const { generateWAMessageFromContent } = require("@whiskeysockets/baileys");

// ==========================================
// 🗣️ VIP SMART RESPONDER (INTERACTIVE UI)
// ==========================================

let handler = m => m;

handler.before = async function (m, { sock }) {
    // Abaikan jika pesan dari bot sendiri atau bukan teks
    if (m.isBaileys || !m.text) return false;

    // Bersihkan teks dari tanda baca untuk mendeteksi panggilan dengan akurat
    let teksBersih = m.text.toLowerCase().trim().replace(/[^\w\s]/gi, '');
    
    // Daftar kata kunci panggilan
    let daftarPanggilan = ["bot", "mini", "halo bot", "p", "woy", "oy", "assisten", "assistant", "botnya mana", "halo mini"];
    
    if (daftarPanggilan.includes(teksBersih)) {
        await m.react("👋").catch(() => {});

        // 20 Koleksi Balasan Random VIP yang Asyik & Friendly
        let koleksiRespon = [
            `Hadir Bosku! Ada yang bisa Mini bantu eksekusi hari ini? 🚀`,
            `Siap sedia 24/7! Mau bikin inovasi apa kita sekarang? ✨`,
            `Mini di sini! Tinggal klik tombol di bawah, langsung gas! 😎`,
            `Wuzz! Bot Assistant X meluncur! Ada target operasi baru? 🎯`,
            `Halo kak! Ada yang perlu dibantu sama mesin canggih ini? 🤖`,
            `Panggil aku Mini! Ada yang bisa dikerjakan? 🛠️`,
            `Hadir! Sistem 100% online dan siap menerima arahan! ⚡`,
            `Yuhuuu~ Mini siap melayani! Mau cari fitur apa nih? 🔍`,
            `Nggak usah teriak, Mini udah standby di sini kok! 🤭 Ada apa bos?`,
            `Command center Assistant X mendengarkan. Laksanakan perintah! 📡`,
            `Cring! ✨ Asisten virtual paling asyik sejagat raya hadir!`,
            `Sistem siap tempur! Apa rencana besar kita hari ini? 🔥`,
            `Bot kesayanganmu ada di sini! Jangan ragu buat ngasih tugas ya! 💼`,
            `Halo! Kalau butuh sesuatu, klik aja tombol menu di bawah ya! 📜`,
            `Bip boop! 🤖 Sensor mendeteksi ada yang manggil. Ada apa nih?`,
            `Asisten VIP siap meluncur! Mau di-spill fitur baru atau butuh bantuan lain? 💎`,
            `Mini sudah bangun dan siap ngegas! Ada project apa hari ini? 🚀`,
            `Yo! Ada yang bisa dibantu sama asisten terpintar ini? 😎`,
            `Hadir! Tinggal tunjuk aja mana yang mau dieksekusi! 🎯`,
            `Assistant X Project online! Siap melayani dengan kecepatan cahaya! ⚡`
        ];

        // Mesin Pengacak Balasan
        let balasanTerpilih = koleksiRespon[Math.floor(Math.random() * koleksiRespon.length)];

        // 🏗️ Struktur Native Flow Message (Tombol Quick Reply)
        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: { text: balasanTerpilih },
                        footer: { text: `© ${global.botname || 'Assistant X Project'}` },
                        nativeFlowMessage: {
                            buttons: [{
                                name: "quick_reply",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "📜 LIHAT MENU", // Tampilan di tombol
                                    id: ".menu" // Perintah gaib yang tereksekusi saat tombol diklik
                                })
                            }]
                        },
                        contextInfo: { 
                            mentionedJid: [m.sender],
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: global.idChannel || "1203631@newsletter",
                                newsletterName: "✨ Assistant X Intercom",
                                serverId: 1
                            }
                        }
                    }
                }
            }
        }, { userJid: m.chat, quoted: m });

        // Eksekusi pengiriman pesan tombol
        await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

        return true; 
    }

    return false;
}

module.exports = handler;
