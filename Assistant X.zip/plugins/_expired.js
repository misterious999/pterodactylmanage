// ==========================================
// 🕵️‍♂️ VIP EXPIRED PROTECTOR (AUTO-LEAVE SYSTEM)
// ==========================================

let handler = m => m;

handler.before = async function (m, { sock }) {
    // 1. Validasi Dasar: Hanya bekerja di Grup dan bukan dari pesan bot sendiri
    if (!m.isGroup || m.isBaileys) return false;

    // Pastikan database grup tersedia
    if (!global.db.groups) global.db.groups = {};
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = { expired: 0 };

    let sekarang = Date.now();
    let dataGrup = global.db.groups[m.chat];

    // 2. CEK STATUS EXPIRED
    // Hanya diproses jika expired lebih dari 0 (artinya grup ini statusnya menyewa)
    if (dataGrup.expired > 0 && sekarang > dataGrup.expired) {
        
        await m.react("⚠️").catch(() => {});

        // Pesan Pamit VVIP yang Elegan
        let teksPamit = `╭───「 *⚠️ MASA SEWA HABIS* 」\n`;
        teksPamit += `│\n`;
        teksPamit += `│ Halo teman-teman di *${m.metadata.subject}*,\n`;
        teksPamit += `│ Pemberitahuan otomatis dari sistem pusat.\n`;
        teksPamit += `│\n`;
        teksPamit += `│ Kontrak sewa Bot Assistant X di grup ini\n`;
        teksPamit += `│ telah berakhir tepat pada hari ini.\n`;
        teksPamit += `│\n`;
        teksPamit += `│ ⏳ *Status:* Expired / Selesai\n`;
        teksPamit += `│ 🏢 *Owner:* @${global.nomorBos || 'Pstar7'}\n`;
        teksPamit += `│\n`;
        teksPamit += `╰───────────────⳹\n\n`;
        teksPamit += `_Bot akan otomatis keluar dalam 5 detik. Sampai jumpa lagi!_ ✨`;

        // Kirim pesan pamit dengan gaya Newsletter Premium
        await sock.sendMessage(m.chat, { 
            text: teksPamit,
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: global.idChannel || "1203631@newsletter",
                    newsletterName: "🛡️ Rental Expired System",
                    serverId: 1
                }
            }
        });

        // Jeda 5 detik agar member sempat membaca pesan pamitnya
        await new Promise(resolve => setTimeout(resolve, 5000));

        // 🛑 EKSEKUSI: Bot Keluar Grup Secara Otomatis
        await sock.groupLeave(m.chat);

        // Reset data expired di database agar tidak terjadi looping pesan pamit
        dataGrup.expired = 0;
        
        console.log(`[!] AUTO LEAVE: Bot baru saja keluar dari ${m.metadata.subject} karena expired.`);
        return true;
    }

    return false;
}

module.exports = handler;
