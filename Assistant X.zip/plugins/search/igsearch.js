const axios = require('axios');

let handler = async (m, { sock, args, prefix, command }) => {
    if (!args[0]) {
        let teksBantuan = `╭───┈ *「 PANDUAN PELACAKAN INSTAGRAM 」*\n`;
        teksBantuan += `│ Parameter *Username* tidak ditemukan.\n`;
        teksBantuan += `│\n`;
        teksBantuan += `│ ▪ Format: ${prefix + command} <username>\n`;
        teksBantuan += `│ ▪ Contoh: ${prefix + command} jokowi\n`;
        teksBantuan += `╰───────────────┈ ⳹`;
        return m.reply(teksBantuan);
    }

    let username = args[0].replace('@', '');
    if (!global.btc) return m.reply('❌ BOTCAHX_APIKEY belum diisi di file .env.');

    await m.reply("_Sistem sedang mengekstraksi data intelijen profil, harap tunggu..._");

    try {
        let { data } = await axios.get(global.botcahxUrl('/api/stalk/ig', { username }));
        
        if (!data.status) {
            return m.reply("[SISTEM] Pelacakan dibatalkan. Pengguna tidak ditemukan atau akun sedang ditangguhkan.");
        }
        
        let res = data.result;
        
        let teksInfo = `╭───┈ *「 DATA INTELIJEN INSTAGRAM 」*\n`;
        teksInfo += `│ ◈ *Username:* ${res.username || '-'}\n`;
        teksInfo += `│ ◈ *Nama Lengkap:* ${res.fullName || '-'}\n`;
        teksInfo += `│ ◈ *Pengikut:* ${res.followers || 0}\n`;
        teksInfo += `│ ◈ *Mengikuti:* ${res.following || 0}\n`;
        teksInfo += `│ ◈ *Total Kiriman:* ${res.postsCount || 0}\n`;
        teksInfo += `│\n`;
        teksInfo += `│ ◈ *Biografi:*\n`;
        teksInfo += `│ ${res.biography || 'Tidak ada biografi'}\n`;
        teksInfo += `╰───────────────┈ ⳹\n\n`;
        teksInfo += `_Assistant X Project - Divisi Pelacakan Data_`;
        
        await sock.sendMessage(m.chat, { 
            image: { url: res.profilePicHD || res.profilePic }, 
            caption: teksInfo 
        }, { quoted: m });

    } catch (e) {
        console.error("[ERROR IG STALK]", e);
        m.reply("[KESALAHAN] Terjadi kegagalan komunikasi dengan peladen penyedia data.");
    }
}

handler.command = ['igsearch', 'igstalk', 'stalkig'];
handler.tags = ['search'];
handler.help = ['igsearch <username>'];

module.exports = handler;
