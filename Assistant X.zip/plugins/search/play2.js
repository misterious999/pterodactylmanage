const crypto = require('node:crypto');
const { proto, generateWAMessageFromContent } = require('@whiskeysockets/baileys'); 
const { spotifyCardHtml } = require(process.cwd() + '/lib/spotify_ui.js');

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

(function startBackend() {
  // --- KONFIGURASI SERVER & PTERODACTYL ---
  const PORT = process.env.SERVER_PORT || process.env.PORT || 2004; 
  
  // JIKA LU PUNYA PROXY/DOMAIN SENDIRI DARI PANEL PTERO, ISI DI SINI.
  // Contoh: 'https://spotify.publikv2.bypstar7.online'
  // Jika diisi, bot TIDAK AKAN mendownload Cloudflare Tunnel.
  const CUSTOM_PUBLIC_URL = ''; 
  // ----------------------------------------

  let WSImpl = null;
  try { WSImpl = require('ws'); }
  catch (e1) {
    try { WSImpl = require('@whiskeysockets/baileys/node_modules/ws'); } 
    catch (e2) { console.log('[MUSIC] modul ws tidak tersedia'); return; }
  }

  if (global.__musicBackend) {
    try { global.__musicBackend.close(); } catch (e) {}
    global.__musicBackend = null;
  }
  if (!global.__musicCards) global.__musicCards = new Map();

  if (CUSTOM_PUBLIC_URL) {
    global.__musicTunnel = { url: CUSTOM_PUBLIC_URL };
    console.log('[MUSIC] Menggunakan custom URL Ptero:', CUSTOM_PUBLIC_URL);
  } else {
    startTunnel();
  }

  function validCard(c) {
    if (!c || !global.__musicCards.has(c)) return false;
    const exp = global.__musicCards.get(c);
    if (exp < Date.now()) { global.__musicCards.delete(c); return false; }
    return true;
  }

  function httpGetJson(url, ms) {
    return new Promise((resolve, reject) => {
      const to = setTimeout(() => reject(new Error('timeout')), ms || 95000);
      https.get(url, { headers: { 'User-Agent': 'Mozilla/5.0 Chrome/124' } }, (r) => {
        let b = '';
        r.on('data', (c) => (b += c));
        r.on('end', () => { clearTimeout(to); try { resolve(JSON.parse(b)); } catch (e) { reject(e); } });
      }).on('error', (e) => { clearTimeout(to); reject(e); });
    });
  }

  function apikeyOf() {
    return global.api_betabotz || global.api_botcahx || global.api || 'kirito';
  }

  function ytSearch(q) {
    return new Promise((resolve, reject) => {
      const body = JSON.stringify({
        context: { client: { clientName: 'WEB', clientVersion: '2.20240701.00.00', hl: 'id', gl: 'ID' } },
        query: q
      });
      const req = https.request({
        host: 'www.youtube.com',
        path: '/youtubei/v1/search?prettyPrint=false',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(body),
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/124.0.0.0 Safari/537.36'
        }
      }, (r) => {
        let b = '';
        r.on('data', (c) => (b += c));
        r.on('end', () => {
          try {
            const d = JSON.parse(b);
            const secs = (((d.contents || {}).twoColumnSearchResultsRenderer || {}).primaryContents || {}).sectionListRenderer;
            const out = [];
            for (const sec of ((secs || {}).contents || [])) {
              for (const it of (((sec.itemSectionRenderer || {}).contents) || [])) {
                const v = it.videoRenderer;
                if (!v || !v.videoId) continue;
                out.push({
                  videoId: v.videoId,
                  title: ((v.title || {}).runs || [{}])[0].text || '',
                  artist: ((v.ownerText || {}).runs || [{}])[0].text || '',
                  timestamp: ((v.lengthText || {}).simpleText) || '',
                  url: 'https://www.youtube.com/watch?v=' + v.videoId
                });
              }
            }
            resolve(out);
          } catch (e) { reject(e); }
        });
      });
      req.setTimeout(20000, () => { req.destroy(new Error('timeout')); });
      req.on('error', reject);
      req.write(body);
      req.end();
    });
  }

  function ytsUrl(q) {
    return 'https://api.botcahx.eu.org/api/search/yts?apikey=' + apikeyOf() + '&query=' + encodeURIComponent(q);
  }

  function dlCandidates(cleanUrl) {
    const u = encodeURIComponent(cleanUrl);
    const k = apikeyOf();
    return [
      'https://api.botcahx.eu.org/api/dowloader/yt?url=' + u + '&apikey=' + k,
      'https://api.botcahx.eu.org/api/download/yt?url=' + u + '&apikey=' + k
    ];
  }

  function parseDur(v) {
    const p = String(v || '').split(/[.:]/).reverse();
    let s = 0;
    for (let i = 0; i < p.length && i < 3; i++) s += (parseInt(p[i], 10) || 0) * Math.pow(60, i);
    return s;
  }

  const LOG = [];
  function logEv(o) {
    o.at = new Date().toISOString().slice(11, 19);
    LOG.push(o);
    if (LOG.length > 100) LOG.shift();
  }

  const MP3_CACHE = new Map();
  const BUF_CACHE = new Map();
  const IMG_CACHE = new Map();
  const STREAMS = new Map();
  const INFLIGHT = new Map();

  function cacheKey(u) { const m = String(u).match(/[?&]v=([0-9A-Za-z_-]{6,})/); return m ? m[1] : String(u); }

  function pickMp3(d) {
    if (!d) return null;
    const paths = [
      d.result && d.result.mp3,
      d.result && d.result.url,
      d.result && d.result.download && d.result.download.mp3,
      d.result && d.result.audio && (d.result.audio.url || d.result.audio),
      d.result && d.result.audioUrl,
      d.url, d.mp3, d.download
    ];
    for (const p of paths) {
      if (typeof p === 'string' && (p.startsWith('https:') || p.startsWith('http:'))) return p;
    }
    return null;
  }

  function getJsonAny(url, ms) {
    const mod = url.startsWith('https:') ? https : http;
    return new Promise((resolve, reject) => {
      const to = setTimeout(() => reject(new Error('timeout')), ms || 95000);
      mod.get(url, { headers: { 'User-Agent': 'Mozilla/5.0 Chrome/124' } }, (r) => {
        let b = '';
        r.on('data', (c) => (b += c));
        r.on('end', () => { clearTimeout(to); try { resolve(JSON.parse(b)); } catch (e) { reject(e); } });
      }).on('error', (e) => { clearTimeout(to); reject(e); });
    });
  }

  function probeAudio(u) {
    return new Promise((resolve) => {
      const mod = u.startsWith('https:') ? https : http;
      const req = mod.get(u, { headers: { Range: 'bytes=0-1023', 'User-Agent': 'Mozilla/5.0' } }, (r) => {
        const t = r.headers['content-type'] || '';
        const ok = r.statusCode >= 200 && r.statusCode < 300 && /audio[/]|octet-stream|video[/]mp4/.test(t);
        r.destroy();
        resolve(ok);
      });
      req.on('error', () => resolve(false));
      req.setTimeout(10000, () => { req.destroy(); resolve(false); });
    });
  }

  function tryOneEndpoint(u) {
    return httpGetJson(u, 45000).then(async (d) => {
      const mp3 = pickMp3(d);
      if (!mp3) throw new Error('tanpa mp3');
      if (!(await probeAudio(mp3))) throw new Error('audio tergated');
      return mp3;
    });
  }

  function resolveViaBackbone(title, artist) {
    return getJsonAny('http://node18.sairistore.web.id:3537/api/audio/resolve?q=' + encodeURIComponent(title + '|' + artist), 45000).then((d) => {
      if (d && d.ok && typeof d.url === 'string' && (d.url.startsWith('http:') || d.url.startsWith('https:'))) return d.url;
      throw new Error('backbone kosong');
    });
  }

  let qActive = 0;
  const qWait = [];
  function queueDrain() { const nx = qWait.shift(); if (nx) nx(); }
  function queueRun(fn) {
    return new Promise((resolve, reject) => {
      const go = () => {
        qActive++;
        fn().then(
          (v) => { qActive--; queueDrain(); resolve(v); },
          (e) => { qActive--; queueDrain(); reject(e); }
        );
      };
      if (qActive < 2) go(); else qWait.push(go);
    });
  }

  function doExtract(cleanUrl, ck, title, artist) {
    return queueRun(() => doExtractCore(cleanUrl, ck, title, artist));
  }

  function doExtractCore(cleanUrl, ck, title, artist) {
    const t0 = Date.now();
    return (async () => {
      let lastErr = null;
      if (title) {
        for (let att = 0; att < 2; att++) {
          try {
            const mp3 = await resolveViaBackbone(title, artist);
            logEv({ ev: 'mp3ok', via: 'backbone', ms: Date.now() - t0, retry: att > 0 });
            MP3_CACHE.set(ck, { mp3, exp: Date.now() + 25 * 60 * 1000 });
            return mp3;
          } catch (e) {
            lastErr = e;
            logEv({ ev: 'backbonefail', err: String(e && e.message), retry: att });
            if (att === 0 && /timeout/.test(String(e && e.message))) continue;
            break;
          }
        }
      }
      const cands = dlCandidates(cleanUrl);
      for (let i = 0; i < cands.length; i++) {
        try {
          const mp3 = await tryOneEndpoint(cands[i]);
          logEv({ ev: 'mp3ok', i, ms: Date.now() - t0, host: String(mp3).slice(8, 40) });
          MP3_CACHE.set(ck, { mp3, exp: Date.now() + 25 * 60 * 1000 });
          return mp3;
        } catch (e) {
          lastErr = e;
        }
      }
      logEv({ ev: 'mp3fail', err: String(lastErr && lastErr.message) });
      throw lastErr || new Error('gagal ekstrak');
    })();
  }

  function extractMp3(cleanUrl, title, artist) {
    const ck = cacheKey(cleanUrl);
    const hit = MP3_CACHE.get(ck);
    if (hit && hit.exp > Date.now()) return Promise.resolve(hit.mp3);
    if (INFLIGHT.has(ck)) return INFLIGHT.get(ck);
    const job = doExtract(cleanUrl, ck, title, artist);
    INFLIGHT.set(ck, job);
    job.then(() => INFLIGHT.delete(ck), () => INFLIGHT.delete(ck));
    return job;
  }

  function warm(item) {
    const ck = cacheKey(item.url);
    const hit = MP3_CACHE.get(ck);
    if (hit && hit.exp > Date.now()) return;
    extractMp3(item.url, item.title, item.artist).catch(() => {});
  }

  function resolveBuffer(url) {
    const hit = BUF_CACHE.get(url);
    if (hit && hit.exp > Date.now()) return Promise.resolve(hit.buf);
    return new Promise((resolve, reject) => {
      const grab = (u, depth) => (u.startsWith('https:') ? https : http).get(u, { headers: { 'User-Agent': 'Mozilla/5.0' } }, (r) => {
        if (r.statusCode >= 300 && r.statusCode < 400 && r.headers.location && depth < 3) { r.destroy(); return grab(r.headers.location, depth + 1); }
        if (r.statusCode !== 200) { r.destroy(); return reject(new Error('upstream ' + r.statusCode)); }
        const parts = [];
        r.on('data', (c) => parts.push(c));
        r.on('end', () => {
          const buf = Buffer.concat(parts);
          BUF_CACHE.set(url, { buf, exp: Date.now() + 25 * 60 * 1000 });
          resolve(buf);
        });
        r.on('error', reject);
      }).on('error', reject);
      grab(url, 0);
    });
  }

  function resolveImage(url) {
    const hit = IMG_CACHE.get(url);
    if (hit && hit.exp > Date.now()) return Promise.resolve(hit.buf);
    return new Promise((resolve, reject) => {
      const grab = (u, depth) => https.get(u, { headers: { 'User-Agent': 'Mozilla/5.0' } }, (r) => {
        if (r.statusCode >= 300 && r.statusCode < 400 && r.headers.location && depth < 3) { r.destroy(); return grab(r.headers.location, depth + 1); }
        if (r.statusCode !== 200) { r.destroy(); return reject(new Error('upstream ' + r.statusCode)); }
        const parts = [];
        r.on('data', (c) => parts.push(c));
        r.on('end', () => {
          const buf = Buffer.concat(parts);
          IMG_CACHE.set(url, { buf, exp: Date.now() + 6 * 3600 * 1000 });
          resolve(buf);
        });
        r.on('error', reject);
      }).on('error', reject);
      grab(url, 0);
    });
  }

  function cleanTitle(t) {
    return String(t || '').replace(/\([^)]*\)/g, ' ').replace(/\s+/g, ' ').trim();
  }

  function fetchLyrics(title, artist) {
    const ct = cleanTitle(title);
    const art = String(artist || '').trim();
    const qs = [];
    if (ct && art) { qs.push(ct + ' ' + art); qs.push(art + ' ' + ct); }
    if (ct) qs.push(ct);
    if (art) qs.push(art);
    const seen = new Set();
    return (async () => {
      for (const q of qs) {
        if (!q || seen.has(q)) continue;
        seen.add(q);
        try {
          const d = await httpGetJson('https://lrclib.net/api/search?q=' + encodeURIComponent(q), 12000);
          const list = Array.isArray(d) ? d : [];
          const hit = list.find((x) => x && x.syncedLyrics) || list.find((x) => x && x.plainLyrics);
          if (hit) {
            logEv({ ev: 'lyhit', q: q.slice(0, 40), synced: !!hit.syncedLyrics });
            return { plain: hit.plainLyrics || '', synced: hit.syncedLyrics || '' };
          }
        } catch (e) {}
      }
      logEv({ ev: 'lymiss', q: (ct + ' ' + art).slice(0, 40) });
      return { plain: '', synced: '' };
    })();
  }

  function tunnelOrigin() {
    return (global.__musicTunnel && global.__musicTunnel.url) || '';
  }

  async function thumbDataUri(vid) {
    try {
      const buf = await resolveImage('https://i.ytimg.com/vi/' + vid + '/mqdefault.jpg');
      return 'data:image/jpeg;base64,' + buf.toString('base64');
    } catch (e) {
      return '';
    }
  }

  async function searchTracks(q) {
    let raw = [];
    try {
      raw = (await ytSearch(q)).slice(0, 12);
    } catch (e) {
      raw = [];
    }
    if (!raw.length) {
      try {
        const d = await httpGetJson(ytsUrl(q), 25000);
        raw = ((d && d.result) || []).slice(0, 12);
      } catch (e) {
        raw = [];
      }
    }
    const items = raw.map((t) => {
      const url = t.url || (t.videoId ? 'https://www.youtube.com/watch?v=' + t.videoId : '');
      const vid = t.videoId || t.id || ((String(url).match(/[?&]v=([0-9A-Za-z_-]{6,})/) || [])[1]) || '';
      return {
        title: t.title || '',
        artist: (t.author && t.author.name) || t.author || t.channel || '',
        timestamp: t.timestamp || t.duration || '',
        seconds: parseDur(t.timestamp || t.duration),
        url,
        videoId: vid,
        thumbnail: '',
        previewUrl: ''
      };
    }).filter((it) => it.url);
    const single = items.filter((it) => {
      if (it.seconds < 90 || it.seconds > 600) return false;
      const t = String(it.title).toLowerCase();
      if (/kumpulan|kompilasi|compilation|playlist|full album|fullalbum|album penuh|full movie|official album|full bass|full mix|mixtape|medley|nonstop|non stop|tiktok|viral|hits 20|best of/.test(t)) return false;
      if (/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{2190}-\u{21FF}]/u.test(String(it.title))) return false;
      return true;
    });
    const list = single;
    await Promise.all(list.map(async (it) => {
      if (it.videoId) it.thumbnail = await thumbDataUri(it.videoId);
    }));
    list.slice(0, 6).forEach((it, i) => setTimeout(() => warm(it), i * 1500));
    return list;
  }

  function startTunnel() {
    if (global.__musicTunnel) return;
    const bin = path.join(process.cwd(), '.cache', 'cloudflared');
    const download = () => new Promise((resolve) => {
      try {
        if (fs.existsSync(bin)) return resolve(true);
        fs.mkdirSync(path.dirname(bin), { recursive: true });
        const grab = (u, depth) => https.get(u, { headers: { 'User-Agent': 'curl/8' } }, (r) => {
          if (r.statusCode >= 300 && r.statusCode < 400 && r.headers.location && depth < 3) { r.destroy(); return grab(r.headers.location, depth + 1); }
          if (r.statusCode !== 200) { r.destroy(); return resolve(false); }
          const f = fs.createWriteStream(bin + '.part');
          r.pipe(f);
          f.on('finish', () => f.close(() => {
            try { fs.renameSync(bin + '.part', bin); fs.chmodSync(bin, 0o755); } catch (e) {}
            resolve(true);
          }));
        }).on('error', () => resolve(false));
        grab('https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64', 0);
      } catch (e) { resolve(false); }
    });
    download().then((ok) => {
      if (!ok) { setTimeout(startTunnel, 60000); return; }
      const proc = spawn(bin, ['tunnel', '--url', 'http://localhost:' + PORT, '--no-autoupdate'], { stdio: ['ignore', 'pipe', 'pipe'] });
      global.__musicTunnel = { proc, url: null };
      const scan = (b) => {
        const text = String(b);
        // FILTER PERBAIKAN: Abaikan URL API internal Cloudflare
        if (text.includes('api.trycloudflare.com') || text.includes('update.trycloudflare.com')) return;
        
        const m = text.match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com/);
        if (m && global.__musicTunnel && !global.__musicTunnel.url) {
          global.__musicTunnel.url = m[0];
          console.log('[MUSIC] tunnel siap:', m[0]);
        }
      };
      proc.stdout.on('data', scan);
      proc.stderr.on('data', scan);
      proc.on('exit', () => { global.__musicTunnel = null; setTimeout(startTunnel, 15000); });
    });
  }

  const server = http.createServer((req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    if (req.method === 'OPTIONS') { res.statusCode = 204; res.end(); return; }

    if (req.url.startsWith('/img?')) {
      const u = decodeURIComponent((req.url.split('?u=')[1] || '').split('&')[0]);
      if (!/^https:[/][/]i\.ytimg\.com[/]/.test(u)) { res.statusCode = 403; res.end(); return; }
      resolveImage(u)
        .then((buf) => {
          res.statusCode = 200;
          res.setHeader('Content-Type', 'image/jpeg');
          res.setHeader('Cache-Control', 'public, max-age=21600');
          res.end(buf);
        })
        .catch(() => { res.statusCode = 502; res.end(); });
      return;
    }

    if (req.url.startsWith('/api/spotify/stream')) {
      const sid = decodeURIComponent((req.url.split('t=')[1] || '').split('&')[0]);
      const it = STREAMS.get(sid);
      if (!it || it.exp < Date.now()) { res.statusCode = 404; res.end('sesi berakhir'); return; }
      logEv({ ev: 'httpstream', sid });
      (async () => {
        let u = it.url;
        if (!u) { u = await it.pending; it.url = u; }
        const buf = await resolveBuffer(u);
        logEv({ ev: 'httpbufok', bytes: buf.length });
        res.statusCode = 200;
        res.setHeader('Content-Type', 'audio/mpeg');
        res.setHeader('Content-Length', buf.length);
        res.end(buf);
      })().catch(() => { if (!res.headersSent) { res.statusCode = 502; res.end('audio gagal'); } });
      return;
    }

    if (req.url.startsWith('/api/spotify/') && req.method === 'POST') {
      const op = req.url.split('/api/spotify/')[1].split('?')[0];
      const qc = decodeURIComponent((req.url.split('c=')[1] || '').split('&')[0] || '');
      let body = '';
      req.on('data', (c) => { body += c; });
      req.on('end', async () => {
        let m = {};
        try { m = JSON.parse(body || '{}'); } catch (e) {}
        if (!validCard(qc || m.c)) { res.statusCode = 403; res.end(JSON.stringify({ ok: false, reason: 'sesi tidak dikenal' })); return; }
        try {
          if (op === 'join') {
            res.end(JSON.stringify({ ok: true, id: crypto.randomUUID().slice(0, 8), host: true }));
          } else if (op === 'search') {
            const items = await searchTracks(m.q || '');
            res.end(JSON.stringify({ ok: true, items }));
          } else if (op === 'pick') {
            const sid = crypto.randomUUID().slice(0, 12);
            const job = extractMp3(m.url || '', m.title || '', m.artist || '');
            STREAMS.set(sid, { url: null, pending: job, exp: Date.now() + 25 * 60 * 1000 });
            res.end(JSON.stringify({ ok: true, streamId: sid, title: m.title || '', artist: m.artist || '', duration: m.duration || m.seconds || 0, cover: m.thumbnail || '' }));
            job.catch(() => {});
          } else if (op === 'lyrics') {
            try {
              const ly = await fetchLyrics(m.title || '', m.artist || '');
              res.end(JSON.stringify({ ok: true, title: m.title || '', artist: m.artist || '', plain: ly.plain, synced: ly.synced }));
            } catch (e) {
              res.end(JSON.stringify({ ok: true, title: m.title || '', artist: m.artist || '', plain: '', synced: '' }));
            }
          } else if (op === 'state') {
            res.end(JSON.stringify({ ok: true }));
          } else if (op === 'global') {
            res.end(JSON.stringify({ ok: true, rooms: [] }));
          } else {
            res.end(JSON.stringify({ ok: false }));
          }
        } catch (e) {
          res.end(JSON.stringify({ ok: false, reason: 'Gagal memutar.', error: String(e.message) }));
        }
      });
      return;
    }

    res.statusCode = 200;
    res.end('ok');
  });

  const wss = new WSImpl.Server({ server });
  const send = (sock, obj) => { try { if (sock.readyState === 1) sock.send(JSON.stringify(obj)); } catch (e) {} };

  wss.on('connection', (sock, req) => {
    const c = decodeURIComponent(String(((req && req.url) || '').split('c=')[1] || '').split('&')[0]);
    if (!validCard(c)) { try { sock.close(); } catch (e) {} return; }
    sock.__card = c;
    sock.on('message', async (raw) => {
      let m;
      try { m = JSON.parse(raw.toString()); } catch (e) { return; }
      if (!validCard(sock.__card)) { try { sock.close(); } catch (e) {} return; }
      if (m.t === 'clog') {
        logEv({ ev: 'clog', m: m.m });
        return;
      }
      if (m.t === 'join') {
        send(sock, { t: 'welcome', id: crypto.randomUUID().slice(0, 8), host: true });
      } else if (m.t === 'search') {
        try { send(sock, { t: 'results', items: await searchTracks(m.q || '') }); }
        catch (e) { send(sock, { t: 'results', items: [] }); }
      } else if (m.t === 'pick') {
        if (STREAMS.size > 40) for (const [k2, v2] of STREAMS) if (v2.exp < Date.now()) STREAMS.delete(k2);
        const sid = crypto.randomUUID().slice(0, 12);
        const job = extractMp3(m.url || '', m.title || '', m.artist || '');
        const entry = { url: null, pending: job, exp: Date.now() + 25 * 60 * 1000 };
        STREAMS.set(sid, entry);
        logEv({ ev: 'pickstart', sid, title: String(m.title || '').slice(0, 40) });
        send(sock, { t: 'pickResult', ok: true, streamId: sid, title: m.title || '', artist: m.artist || '', duration: m.duration || m.seconds || 0, cover: m.thumbnail || '' });
        job.then(
          (u) => { entry.url = u; logEv({ ev: 'pickok', sid, dur: m.duration || m.seconds }); },
          (e) => { logEv({ ev: 'pickfail', err: String(e && e.message) }); send(sock, { t: 'audioErr', m: 'Audio tidak dapat dimuat.' }); }
        );
      } else if (m.t === 'playStream') {
        const it = STREAMS.get(m.sid);
        if (!it || it.exp < Date.now()) { send(sock, { t: 'audioErr', m: 'Sesi audio berakhir.' }); return; }
        logEv({ ev: 'stream', sid: m.sid });
        try {
          let u = it.url;
          if (!u) { u = await it.pending; it.url = u; }
          const buf = await resolveBuffer(u);
          logEv({ ev: 'bufok', bytes: buf.length });
          const CH = 16384;
          send(sock, { t: 'audioMeta', total: Math.ceil(buf.length / CH), mse: 0 });
          for (let o = 0; o < buf.length; o += CH) {
            if (sock.readyState !== 1) break;
            sock.send(buf.slice(o, o + CH));
          }
          logEv({ ev: 'done' });
          send(sock, { t: 'audioDone' });
        } catch (e) {
          logEv({ ev: 'streamfail', err: String(e && e.message) });
          send(sock, { t: 'audioErr', m: 'Audio tidak dapat dimuat.' });
        }
      } else if (m.t === 'lyrics') {
        try {
          const ly = await fetchLyrics(m.title || '', m.artist || '');
          send(sock, { t: 'lyrics', title: m.title || '', artist: m.artist || '', plain: ly.plain, synced: ly.synced });
        } catch (e) {
          send(sock, { t: 'lyrics', title: m.title || '', artist: m.artist || '', plain: '', synced: '' });
        }
      } else if (m.t === 'global') {
        send(sock, { t: 'rooms', rooms: [] });
      } else if (m.t === 'state') {
        send(sock, { t: 'state', ok: true });
      }
    });
  });

  server.listen(PORT, '0.0.0.0', () => console.log('[MUSIC] backend siap di :' + PORT));
  server.on('error', (e) => console.log('[MUSIC] gagal listen:', e.message));
  global.__musicBackend = server;
})();

let handler = async (m, context) => {
  const sock = context?.sock || context?.conn || context?.client || context;

  let tun = global.__musicTunnel && global.__musicTunnel.url;
  if (!tun) {
    for (let k = 0; k < 16 && !tun; k++) {
      await new Promise((r) => setTimeout(r, 500));
      tun = global.__musicTunnel && global.__musicTunnel.url;
    }
  }
  if (!tun) return m.reply('⏳ Server musik baru nyala, coba beberapa detik lagi ya sayang.');

  const cardId = crypto.randomUUID().slice(0, 8);
  if (!global.__musicCards) global.__musicCards = new Map();
  global.__musicCards.set(cardId, Date.now() + 12 * 3600 * 1000);
  for (const [k, v] of global.__musicCards) {
    if (v < Date.now()) global.__musicCards.delete(k);
  }

  const wssUrl = 'wss://' + tun.replace(/^https?:[/][/]/, '') + '/ws/spotify?c=' + cardId;
  const httpsUrl = tun;

  const html = spotifyCardHtml({
    recommended: [],
    cardId,
    expiresAt: Date.now() + 12 * 3600 * 1000,
    wsUrls: [wssUrl],
    origins: [httpsUrl],
    initialQuery: ''
  });

  const unified = {
    response_id: crypto.randomUUID(),
    sections: [{
      view_model: {
        primitive: {
          __typename: 'FOAHtmlPrimitiveDemoDONOTUSE',
          payload: html.trim(),
          url: 'https://assistant-x.dev',           // <-- INI YANG KEMARIN LUPA
          trusted_sources: ['assistant-x.dev']     // <-- INI YANG KEMARIN LUPA
        },
        __typename: 'GenAISingleLayoutViewModel'
      }
    }]
  };

  const content = proto.Message.fromObject({
    messageContextInfo: {
      deviceListMetadata: {},
      deviceListMetadataVersion: 2,
      botMetadata: {
        capabilityMetadata: {
          capabilities: [34, 58, 29, 1, 67, 60, 55, 8]
        }
      }
    },
    botForwardedMessage: {
      message: {
        richResponseMessage: {
          messageType: 1,
          submessages: [{
            messageType: 2,
            messageText: '> 🎧 Spotify Live'
          }],
          unifiedResponse: { data: Buffer.from(JSON.stringify(unified), 'utf8') },
          contextInfo: {
            isForwarded: true,
            forwardingScore: 1,
            forwardedAiBotMessageInfo: { botJid: '867051314767696@bot' },
            forwardOrigin: 4
          }
        }
      }
    }
  });

  await sock.sendMessage(m.chat, { react: { text: '🎵', key: m.key } }).catch(() => {});
  const generated = generateWAMessageFromContent(m.chat, content, { userJid: sock.user?.id, quoted: m });
  return await sock.relayMessage(m.chat, generated.message, { messageId: generated.key.id });
};

handler.help = ['play2'];
handler.tags = ['search'];
handler.command = ['play2'];

module.exports = handler;
