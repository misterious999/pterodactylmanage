const axios = require('axios');

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function pickAudioUrl(data) {
  const result = data?.result || data?.data?.result || data?.data || data;
  return result?.mp3 || result?.audio || result?.url_audio || result?.download?.mp3 || result?.download?.audio || result?.url || null;
}

async function fetchAudioWithRetry(url, maxRetries = 7, delayMs = 9000) {
  if (!global.btc) throw new Error('BOTCAHX_APIKEY belum diisi di file .env.');
  const apiUrl = global.botcahxUrl('/api/dowloader/yt', { url });
  let lastError;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const { data } = await axios.get(apiUrl, { timeout: 45000 });
      const audioUrl = pickAudioUrl(data);
      if (audioUrl) return audioUrl;
      throw new Error(`Data audio kosong dari BOTCAHX (percobaan ${attempt}).`);
    } catch (err) {
      lastError = err;
      console.log(`[⏳ BOTCAHX PLAY] Menunggu audio... (${attempt}/${maxRetries})`);
      if (attempt < maxRetries) await delay(delayMs);
    }
  }

  throw lastError;
}

let handler = async (m, { sock, text, prefix, command }) => {
  if (!text) {
    await m.react('⚠️');
    return m.replyPremium(`❌ Judul lagunya apa?\n*Contoh:* \`${prefix + command} matahariku\``);
  }

  const user = global.db.users[m.sender];
  if (user && user.limit < 3 && !user.premium && !m.isOwner) {
    await m.react('🚫');
    return m.replyPremium('❌ *Limit Tidak Cukup!*\nKamu butuh minimal *3 Limit* untuk menggunakan pemutar musik VIP ini.');
  }

  await m.react('⏳');

  try {
    const yts = require('yt-search');
    const search = await yts(text);
    const video = search.videos[0];

    if (!video) throw new Error('Lagu tidak ditemukan di YouTube.');
    if (video.seconds > 3600) throw new Error('Durasi video lebih dari 1 jam.');

    const downloadUrl = await fetchAudioWithRetry(video.url);

    if (user) user.limit -= 3;

    const caption = `╭───┈ *「 🎵 YOUTUBE PLAY VIP 」*\n` +
      `│ 🎬 *Judul:* ${video.title}\n` +
      `│ ⏱️ *Durasi:* ${video.timestamp}\n` +
      `│ 👁️ *Dilihat:* ${video.views} kali\n` +
      `│ 🎟️ *Biaya:* -3 Limit\n` +
      `│ 🔌 *API:* BOTCAHX\n` +
      `╰───────────────┈ ⳹\n\n` +
      `_⏳ Sedang mengirim audio, mohon tunggu..._\n` +
      `_© ${global.botname}_`;

    await sock.sendMessage(m.chat, { image: { url: video.thumbnail }, caption }, { quoted: m });
    await sock.sendMessage(m.chat, {
      audio: { url: downloadUrl },
      mimetype: 'audio/mpeg',
      ptt: false,
    }, { quoted: m });

    await m.react('✅');
  } catch (error) {
    console.error('[BOTCAHX PLAY ERROR]', error.response?.data || error.message);
    await m.react('❌');
    return m.replyPremium(`❌ Gagal memutar lagu.\n*Error:* ${error.message}`);
  }
};

handler.command = ['play', 'lagu'];
handler.tags = ['search'];
handler.help = ['play <judul lagu>'];
handler.limit = true;

module.exports = handler;
