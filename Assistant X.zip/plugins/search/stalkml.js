const axios = require('axios');

const REQUEST_TIMEOUT = 60000;

function buildBotcahxUrl(endpoint, params = {}) {
    if (typeof global.botcahxUrl === 'function') {
        return global.botcahxUrl(endpoint, params);
    }

    const base = String(
        global.botcahxBaseUrl ||
        process.env.BOTCAHX_BASE_URL ||
        'https://api.botcahx.eu.org'
    ).replace(/\/$/, '');

    const apikey =
        global.btc ||
        global.botcahxKey ||
        process.env.BOTCAHX_APIKEY;

    if (!apikey) {
        throw new Error('BOTCAHX_APIKEY belum diatur di .env / Environment Variables panel.');
    }

    const url = new URL(`${base}${endpoint.startsWith('/') ? endpoint : `/${endpoint}`}`);

    for (const [key, value] of Object.entries(params || {})) {
        if (value !== undefined && value !== null && value !== '') {
            url.searchParams.set(key, String(value));
        }
    }

    url.searchParams.set('apikey', apikey);
    return url.toString();
}

function parseInput(text = '') {
    const input = String(text || '').trim();

    const result = {
        version: 'v1',
        id: null,
        server: null
    };

    if (!input) return result;

    const clean = input
        .replace(/[,|/]+/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();

    const parts = clean.split(' ').filter(Boolean);

    if (['v1', '1'].includes(String(parts[0] || '').toLowerCase())) {
        result.version = 'v1';
        parts.shift();
    } else if (['v2', '2'].includes(String(parts[0] || '').toLowerCase())) {
        result.version = 'v2';
        parts.shift();
    }

    result.id = parts[0] || null;
    result.server = parts[1] || null;

    return result;
}

function getEndpoint(version = 'v1') {
    return version === 'v2'
        ? '/api/stalk/ml-v2'
        : '/api/stalk/ml';
}

function normKey(key = '') {
    return String(key)
        .toLowerCase()
        .replace(/[^a-z0-9]/g, '');
}

function safeText(value, fallback = '-') {
    if (value === undefined || value === null) return fallback;

    const text = String(value)
        .replace(/\+/g, '+')
        .replace(/\s+/g, ' ')
        .trim();

    return text || fallback;
}

function getRootData(json = {}) {
    return json.result || json.data || json.response || json;
}

function deepFindByKeys(input, targetKeys = [], depth = 0) {
    if (!input || depth > 8) return null;

    const normalizedTargets = targetKeys.map(normKey);

    if (Array.isArray(input)) {
        for (const item of input) {
            const found = deepFindByKeys(item, targetKeys, depth + 1);
            if (found !== null && found !== undefined && found !== '') return found;
        }
        return null;
    }

    if (typeof input === 'object') {
        for (const [key, value] of Object.entries(input)) {
            const normalizedKey = normKey(key);

            if (normalizedTargets.includes(normalizedKey)) {
                if (
                    value !== null &&
                    value !== undefined &&
                    value !== '' &&
                    typeof value !== 'object'
                ) {
                    return value;
                }
            }
        }

        for (const value of Object.values(input)) {
            const found = deepFindByKeys(value, targetKeys, depth + 1);
            if (found !== null && found !== undefined && found !== '') return found;
        }
    }

    return null;
}

function findStalkDataObject(input, depth = 0) {
    if (!input || depth > 8) return null;

    if (Array.isArray(input)) {
        for (const item of input) {
            const found = findStalkDataObject(item, depth + 1);
            if (found) return found;
        }
        return null;
    }

    if (typeof input === 'object') {
        for (const [key, value] of Object.entries(input)) {
            const k = normKey(key);

            if (
                [
                    'stalkdata',
                    'stalk',
                    'account',
                    'accountdata',
                    'player',
                    'playerdata',
                    'userdata',
                    'user'
                ].includes(k) &&
                value &&
                typeof value === 'object' &&
                !Array.isArray(value)
            ) {
                return value;
            }
        }

        for (const value of Object.values(input)) {
            const found = findStalkDataObject(value, depth + 1);
            if (found) return found;
        }
    }

    return null;
}

function scorePlayerObject(obj = {}) {
    if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return 0;

    let score = 0;

    for (const key of Object.keys(obj)) {
        const k = normKey(key);

        if (['nickname', 'username', 'ingamenickname', 'ign', 'playername'].includes(k)) score += 5;
        if (['userid', 'useraccountid', 'accountid', 'id'].includes(k)) score += 3;
        if (['serverid', 'server', 'zoneid', 'zone'].includes(k)) score += 3;
        if (['country', 'region'].includes(k)) score += 2;

        // Hindari object produk/topup seperti goods/items.
        if (['goods', 'items', 'title', 'description', 'limits', 'inventoryleft'].includes(k)) score -= 4;
    }

    return score;
}

function findBestPlayerObject(input, depth = 0) {
    if (!input || depth > 8) return { score: 0, object: null };

    let best = { score: 0, object: null };

    if (Array.isArray(input)) {
        for (const item of input) {
            const candidate = findBestPlayerObject(item, depth + 1);
            if (candidate.score > best.score) best = candidate;
        }
        return best;
    }

    if (typeof input === 'object') {
        const currentScore = scorePlayerObject(input);
        if (currentScore > best.score) {
            best = { score: currentScore, object: input };
        }

        for (const value of Object.values(input)) {
            const candidate = findBestPlayerObject(value, depth + 1);
            if (candidate.score > best.score) best = candidate;
        }
    }

    return best;
}

function getNickname(root) {
    const priorityObject =
        findStalkDataObject(root) ||
        findBestPlayerObject(root).object ||
        root;

    const nick =
        deepFindByKeys(priorityObject, [
            'In-Game Nickname',
            'ingame_nickname',
            'ingameNickname',
            'nickname',
            'nick',
            'userName',
            'username',
            'ign',
            'playerName',
            'player_name'
        ]) ||
        deepFindByKeys(root, [
            'In-Game Nickname',
            'ingame_nickname',
            'ingameNickname',
            'nickname',
            'nick',
            'userName',
            'username',
            'ign',
            'playerName',
            'player_name'
        ]);

    return safeText(nick);
}

function getCountry(root) {
    const priorityObject =
        findStalkDataObject(root) ||
        findBestPlayerObject(root).object ||
        root;

    const country =
        deepFindByKeys(priorityObject, [
            'country',
            'Country',
            'region',
            'Region',
            'area'
        ]) ||
        deepFindByKeys(root, [
            'country',
            'Country',
            'region',
            'Region',
            'area'
        ]);

    return safeText(country);
}

async function stalkML(id, server, version = 'v1') {
    const endpoint = getEndpoint(version);

    const apiUrl = buildBotcahxUrl(endpoint, {
        id,
        server
    });

    const { data } = await axios.get(apiUrl, {
        timeout: REQUEST_TIMEOUT,
        validateStatus: () => true,
        headers: {
            'User-Agent': 'Mozilla/5.0'
        }
    });

    if (!data) {
        throw new Error('Response API kosong.');
    }

    if (data.status === false || data.success === false) {
        throw new Error(data.message || data.error || 'API BOTCAHX gagal mengambil data ML.');
    }

    const root = getRootData(data);

    console.log(`[STALK ML ${version.toUpperCase()} RAW]`, JSON.stringify(data, null, 2).slice(0, 2000));

    return {
        nickname: getNickname(root),
        country: getCountry(root),
        raw: root
    };
}

let handler = async (m, { text, args, prefix, command }) => {
    const input = String(text || (args || []).join(' ') || '').trim();
    const parsed = parseInput(input);

    if (!parsed.id || !parsed.server) {
        return m.reply(`❌ *Format salah!*

Contoh:
${prefix}${command} 214885010 2253

Untuk versi tertentu:
${prefix}${command} v1 214885010 2253
${prefix}${command} v2 214885010 2253

Format alternatif:
${prefix}${command} 214885010|2253`);
    }

    if (!/^\d{4,20}$/.test(parsed.id)) {
        return m.reply('❌ *ID Mobile Legends tidak valid.*\nID harus berupa angka.');
    }

    if (!/^\d{3,10}$/.test(parsed.server)) {
        return m.reply('❌ *Server Mobile Legends tidak valid.*\nServer harus berupa angka.');
    }

    await m.react('⏳').catch(() => {});

    try {
        const data = await stalkML(parsed.id, parsed.server, parsed.version);

        let teks = `╭──「 *STALK MOBILE LEGENDS* 」\n`;
        teks += `│ 🎮 *Nickname:* ${data.nickname}\n`;
        teks += `│ 🆔 *ID:* ${parsed.id}\n`;
        teks += `│ 🌐 *Server:* ${parsed.server}\n`;
        teks += `│ 📍 *Region:* ${data.country}\n`;
        teks += `│ ⚙️ *Mode:* ${parsed.version.toUpperCase()}\n`;
        teks += `╰────────────`;

        await m.reply(teks);
        await m.react('✅').catch(() => {});
    } catch (error) {
        console.error('[STALK ML ERROR]', error);
        await m.react('❌').catch(() => {});

        return m.reply(`❌ *Gagal stalk akun Mobile Legends.*

Penyebab:
${error.message || error}

Pastikan ID dan server benar.`);
    }
};

handler.help = [
    'stalkml <id> <server>',
    'stalkml v1 <id> <server>',
    'stalkml v2 <id> <server>'
];

handler.command = ['stalkml'];

handler.tags = ['search'];
handler.limit = true;

module.exports = handler;