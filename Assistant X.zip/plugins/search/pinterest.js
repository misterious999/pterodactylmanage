// ==========================================
// 📌 FITUR PINTEREST SEARCH 
// 🖼️ INTERACTIVE BUTTON EDITION (1 GAMBAR + BUTTONS)
// ⚡ PURE DIRECT SCRAPER (NO BOTCAHX / NO API KEY)
// ==========================================

const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = require("@whiskeysockets/baileys");
const axios = require('axios');

let handler = async (m, { sock, text, prefix, command }) => {
    let user = global.db.users[m.sender];
    if (!user) return m.reply("❌ Kamu belum terdaftar di database bot!");

    // ==========================================
    // 🔑 PENGECEKAN LIMIT (-1 Limit)
    // ==========================================
    let costLimit = 1; 
    if (user.limit < costLimit) {
        return m.reply(`💸 Limit kamu tidak cukup!\nKamu butuh *${costLimit} Limit* untuk mencari gambar. (Sisa: ${user.limit})`);
    }

    if (!text) {
        let usage = `🖼️ *PINTEREST SEARCH*\n`;
        usage += `───────────────────\n`;
        usage += `› Masukkan kata kunci pencarian!\n`;
        usage += `› Contoh: *${prefix}${command} lofi aesthetic*\n\n`;
        usage += `⚠️ *Biaya:* ${costLimit} Limit`;
        return m.reply(usage);
    }

    await m.react("⏳");

    try {
        let validUrls = [];
        let apiUsed = "Direct Scraper ⚡";

        // ==========================================
        // 🚀 TAHAP 1: PURE SCRAPING LANGSUNG KE PINTEREST
        // ==========================================
        try {
            let queryData = JSON.stringify({ options: { query: encodeURIComponent(text) } });
            let scrapeUrl = "https://www.pinterest.com/resource/BaseSearchResource/get/?data=" + encodeURIComponent(queryData);

            let res = await axios.head(scrapeUrl, {
                headers: {
                    "screen-dpr": "4",
                    "x-pinterest-pws-handler": "www/search/[scope].js"
                }
            });

            let linkHeader = res.headers.link || res.headers['link'];

            if (linkHeader) {
                let urls = [...linkHeader.matchAll(/<(.*?)>/gm)].map(a => a[1]);
                validUrls = urls.filter(u => u.includes('pinimg.com') && (u.endsWith('.jpg') || u.endsWith('.png')));
            }
        } catch (err) {
            console.log("[SCRAPER ERROR]", err.message);
        }

        // Jika Scraper gagal menemukan gambar
        if (validUrls.length === 0) {
            await m.react("❌");
            return m.reply(`❌ Gambar tidak ditemukan untuk: *${text}*\n\n_💡 Tip: Hindari kata kunci vulgar dan gunakan istilah bahasa Inggris._`);
        }

        // Ambil 1 gambar secara acak
        let imgUrl = validUrls[Math.floor(Math.random() * validUrls.length)];

        // ==========================================
        // 🚀 TAHAP 2: PROSES DOWNLOAD & RENDER MEDIA
        // ==========================================
        let imgRes = await axios.get(imgUrl, { responseType: 'arraybuffer' });
        let imageBuffer = Buffer.from(imgRes.data, 'binary');
        let imgsc = await prepareWAMessageMedia({ image: imageBuffer }, { upload: sock.waUploadToServer });

        // ==========================================
        // 🚀 TAHAP 3: TEXT CAPTION PREMIUM (TIDAK BERSTILE KOTAK)
        // ==========================================
        let captionText = `🖼️ *PINTEREST EXPLORER*\n`;
        captionText += `───────────────────\n`;
        captionText += `🔍 *Query*  : ${text.toUpperCase()}\n`;
        captionText += `📡 *Fetch*  : ${apiUsed}\n`;
        captionText += `───────────────────`;

        // ==========================================
        // 🚀 TAHAP 4: SUSUN INTERACTIVE MESSAGE
        // ==========================================
        const msgii = await generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                        body: proto.Message.InteractiveMessage.Body.fromObject({
                            text: captionText
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.fromObject({
                            text: "© Assistant X Project"
                        }),
                        header: proto.Message.InteractiveMessage.Header.fromObject({
                            hasMediaAttachment: true,
                            ...imgsc
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                            buttons: [
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "⏭️ Berikutnya",
                                        id: `${prefix}${command} ${text}`
                                    })
                                },
                                {
                                    name: "cta_url",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "🌐 Telusuri",
                                        url: `https://www.pinterest.com/search/pins/?q=${encodeURIComponent(text)}`
                                    })
                                }
                            ]
                        }),
                        contextInfo: { mentionedJid: [m.sender] }
                    })
                }
            }
        }, { userJid: m.sender });

        // Kirim pesannya
        await sock.relayMessage(m.chat, msgii.message, { messageId: msgii.key.id });

        // Potong limit
        user.limit -= costLimit;
        await m.react("✅");

    } catch (error) {
        console.error("[PINTEREST ERROR]", error);
        await m.react("❌");
        m.reply(`❌ *TERJADI KESALAHAN!*\nSistem gagal memproses permintaan.`);
    }
}

handler.command = ["pinterest", "pin"];
handler.tags = ["search"];
handler.help = ["pinterest <query>"];

module.exports = handler;
