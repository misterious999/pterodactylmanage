const axios = require('axios');

const REQUEST_TIMEOUT = 90000;

const CERITA_PENDEK_TYPES = [
    'remaja',
    'anak',
    'misteri',
    'cinta',
    'budaya',
    'romantis',
    'galau',
    'gokil',
    'inspiratif',
    'kehidupan',
    'sastra',
    'jepang',
    'korea',
    'keluarga',
    'persahabatan',
    'kristen',
    'ramadhan',
    'liburan',
    'lingkungan',
    'mengharukan',
    'motivasi',
    'perjuangan',
    'nasihat',
    'pendidikan',
    'petualangan'
];

function buildBotcahxUrl(endpoint, params = {}) {
    if (typeof global.botcahxUrl === 'function') {
        return global.botcahxUrl(endpoint, params);
    }

    const base = String(
        global.botcahxBaseUrl ||
        process.env.BOTCAHX_BASE_URL ||
        'https://api.botcahx.eu.org'
    ).replace(/\/$/, '');

    const apikey =
        global.btc ||
        global.botcahxKey ||
        process.env.BOTCAHX_APIKEY;

    if (!apikey) {
        throw new Error('BOTCAHX_APIKEY belum diatur di .env / Environment Variables panel.');
    }

    const url = new URL(`${base}${endpoint.startsWith('/') ? endpoint : `/${endpoint}`}`);

    for (const [key, value] of Object.entries(params || {})) {
        if (value !== undefined && value !== null && value !== '') {
            url.searchParams.set(key, String(value));
        }
    }

    url.searchParams.set('apikey', apikey);
    return url.toString();
}

function cleanType(type = '') {
    return String(type)
        .toLowerCase()
        .trim()
        .replace(/^cerpen\s+/i, '')
        .replace(/\s+/g, '-');
}

function toTitleCase(text = '') {
    return String(text)
        .replace(/-/g, ' ')
        .replace(/\b\w/g, char => char.toUpperCase());
}

function stripHtml(text = '') {
    return String(text)
        .replace(/<br\s*\/?>/gi, '\n')
        .replace(/<\/p>/gi, '\n\n')
        .replace(/<p[^>]*>/gi, '')
        .replace(/<[^>]*>/g, '')
        .replace(/&#x([0-9a-fA-F]+);/g, (_, hex) => {
            try {
                return String.fromCodePoint(parseInt(hex, 16));
            } catch {
                return _;
            }
        })
        .replace(/&#([0-9]+);/g, (_, num) => {
            try {
                return String.fromCodePoint(parseInt(num, 10));
            } catch {
                return _;
            }
        })
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&#x27;/g, "'")
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&nbsp;/g, ' ')
        .replace(/\r/g, '')
        .replace(/[ \t]+\n/g, '\n')
        .replace(/\n{4,}/g, '\n\n\n')
        .trim();
}

function pickText(value, fallback = '-') {
    if (value === undefined || value === null) return fallback;

    if (typeof value === 'string' || typeof value === 'number') {
        const result = stripHtml(String(value)).trim();
        return result || fallback;
    }

    if (Array.isArray(value)) {
        for (const item of value) {
            const found = pickText(item, '');
            if (found) return found;
        }
    }

    if (typeof value === 'object') {
        const keys = [
            'text',
            'value',
            'title',
            'judul',
            'name',
            'nama',
            'cerita',
            'story',
            'content',
            'isi',
            'body',
            'result',
            'data'
        ];

        for (const key of keys) {
            if (value[key] !== undefined) {
                const found = pickText(value[key], '');
                if (found) return found;
            }
        }
    }

    return fallback;
}

function findByKeys(input, keys = [], depth = 0) {
    if (!input || depth > 8) return null;

    const targets = keys.map(key => String(key).toLowerCase());

    if (Array.isArray(input)) {
        for (const item of input) {
            const found = findByKeys(item, keys, depth + 1);
            if (found !== null && found !== undefined && found !== '') return found;
        }
        return null;
    }

    if (typeof input === 'object') {
        for (const [key, value] of Object.entries(input)) {
            if (targets.includes(String(key).toLowerCase())) {
                if (value !== null && value !== undefined && value !== '') return value;
            }
        }

        for (const value of Object.values(input)) {
            const found = findByKeys(value, keys, depth + 1);
            if (found !== null && found !== undefined && found !== '') return found;
        }
    }

    return null;
}

function getRootData(json = {}) {
    return json.result || json.data || json.response || json.message || json;
}

function normalizeCerpen(json = {}, type = '') {
    const root = getRootData(json);

    const title = pickText(
        findByKeys(root, ['title', 'judul', 'name', 'nama']) ||
        `Cerpen ${toTitleCase(type)}`,
        `Cerpen ${toTitleCase(type)}`
    );

    const author = pickText(
        findByKeys(root, ['author', 'penulis', 'writer', 'by']),
        '-'
    );

    const source = pickText(
        findByKeys(root, ['source', 'sumber', 'url', 'link']),
        '-'
    );

    const category = pickText(
        findByKeys(root, ['category', 'kategori', 'genre', 'type']),
        toTitleCase(type)
    );

    let content = pickText(
        findByKeys(root, ['cerita', 'story', 'content', 'isi', 'body', 'text', 'hasil']),
        ''
    );

    if (!content || content === '[object Object]') {
        content = pickText(root, '');
    }

    if (content === title || content === '[object Object]') {
        content = '';
    }

    return {
        title,
        author,
        source,
        category,
        content
    };
}

function chunkText(text = '', max = 3300) {
    const clean = String(text || '').trim();

    if (clean.length <= max) return [clean];

    const chunks = [];
    let rest = clean;

    while (rest.length > max) {
        let cut = rest.lastIndexOf('\n\n', max);

        if (cut < max * 0.5) {
            cut = rest.lastIndexOf('. ', max);
        }

        if (cut < max * 0.5) {
            cut = max;
        }

        chunks.push(rest.slice(0, cut).trim());
        rest = rest.slice(cut).trim();
    }

    if (rest) chunks.push(rest);

    return chunks;
}

function menuText(prefix = '.') {
    let teks = `╭──「 *CERITA PENDEK* 」\n`;
    teks += `│ 📚 Total kategori: ${CERITA_PENDEK_TYPES.length}\n`;
    teks += `│ ⚙️ Source: BOTCAHX Story API\n`;
    teks += `╰────────────\n\n`;

    teks += `*Cara pakai:*\n`;
    teks += `• ${prefix}cerpen <kategori>\n`;
    teks += `• ${prefix}cerpen list\n`;
    teks += `• ${prefix}cerpen random\n\n`;

    teks += `*Contoh:*\n`;
    teks += `• ${prefix}cerpen remaja\n`;
    teks += `• ${prefix}cerpen misteri\n`;
    teks += `• ${prefix}cerpen persahabatan\n\n`;

    teks += `*Daftar kategori:*\n`;
    teks += CERITA_PENDEK_TYPES
        .map((type, index) => `${index + 1}. ${toTitleCase(type)}`)
        .join('\n');

    return teks;
}

async function fetchCerpen(type) {
    const apiUrl = buildBotcahxUrl('/api/story/cerpen', {
        type
    });

    const { data, status } = await axios.get(apiUrl, {
        timeout: REQUEST_TIMEOUT,
        validateStatus: () => true,
        headers: {
            'User-Agent': 'Mozilla/5.0'
        }
    });

    if (!data) {
        throw new Error('Response API kosong.');
    }

    if (status >= 500) {
        throw new Error(`Server BOTCAHX error. HTTP ${status}`);
    }

    if (status >= 400) {
        throw new Error(`Request gagal. HTTP ${status}`);
    }

    if (data.status === false || data.success === false) {
        throw new Error(data.message || data.error || 'BOTCAHX gagal mengambil cerpen.');
    }

    return normalizeCerpen(data, type);
}

async function sendCerpen(m, story, type) {
    if (!story.content) {
        throw new Error('Isi cerita tidak ditemukan dari response API.');
    }

    const chunks = chunkText(story.content, 3200);

    const header =
        `╭──「 *CERITA PENDEK* 」\n` +
        `│ 📖 *Judul:* ${story.title}\n` +
        `│ 🏷️ *Kategori:* ${story.category || toTitleCase(type)}\n` +
        `│ ✍️ *Penulis:* ${story.author || '-'}\n` +
        `╰────────────\n\n`;

    const footer = story.source && story.source !== '-'
        ? `\n\n🔗 *Sumber:* ${story.source}`
        : '';

    for (let i = 0; i < chunks.length; i++) {
        const page = chunks.length > 1
            ? `\n\n_Bagian ${i + 1}/${chunks.length}_`
            : '';

        const text = i === 0
            ? `${header}${chunks[i]}${page}${i === chunks.length - 1 ? footer : ''}`
            : `${chunks[i]}${page}${i === chunks.length - 1 ? footer : ''}`;

        await m.reply(text);
    }
}

let handler = async (m, { text, args, prefix, command }) => {
    const input = String(text || (args || []).join(' ') || '').trim();
    const lower = input.toLowerCase();

    if (!input || ['menu', 'list', 'kategori', 'category', 'daftar'].includes(lower)) {
        return m.reply(menuText(prefix));
    }

    let type = cleanType(input);

    if (['random', 'acak'].includes(type)) {
        type = CERITA_PENDEK_TYPES[Math.floor(Math.random() * CERITA_PENDEK_TYPES.length)];
    }

    if (!CERITA_PENDEK_TYPES.includes(type)) {
        return m.reply(`❌ *Kategori cerpen tidak tersedia.*

Kategori yang kamu masukkan: *${input}*

Ketik:
${prefix}${command} list

Contoh:
${prefix}${command} remaja`);
    }

    await m.react('⏳').catch(() => {});

    try {
        const story = await fetchCerpen(type);
        await sendCerpen(m, story, type);
        await m.react('✅').catch(() => {});
    } catch (error) {
        console.error('[CERPEN STORY ERROR]', error);
        await m.react('❌').catch(() => {});

        return m.reply(`❌ *Gagal mengambil cerpen ${toTitleCase(type)}.*

Penyebab:
${error.message || error}

Pastikan endpoint BOTCAHX aktif dan API key masih valid.`);
    }
};

handler.help = [
    'cerpen',
    'cerpen list',
    'cerpen random',
    'cerpen remaja',
    'cerpen anak',
    'cerpen misteri',
    'cerpen cinta',
    'cerpen budaya',
    'cerpen romantis',
    'cerpen galau',
    'cerpen gokil',
    'cerpen inspiratif',
    'cerpen kehidupan',
    'cerpen sastra',
    'cerpen jepang',
    'cerpen korea',
    'cerpen keluarga',
    'cerpen persahabatan',
    'cerpen kristen',
    'cerpen ramadhan',
    'cerpen liburan',
    'cerpen lingkungan',
    'cerpen mengharukan',
    'cerpen motivasi',
    'cerpen perjuangan',
    'cerpen nasihat',
    'cerpen pendidikan',
    'cerpen petualangan'
];

handler.command = ['cerpen'];
handler.tags = ['search'];
handler.limit = true;

module.exports = handler;