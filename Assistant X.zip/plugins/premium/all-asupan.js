const axios = require('axios');

// ==========================================
// 🎭 VIP ASUPAN MASTER (FOTO & VIDEO GACHA DETECTOR)
// ==========================================

let handler = async (m, { sock, prefix, command, args }) => {
    let apiKey = global.btc;

    if (!apiKey) {
        await m.react("⚠️").catch(() => {});
        return m.reply("❌ *Sistem Terkunci!*\nBOTCAHX_APIKEY belum diatur di file `.env`.");
    }

    await m.react("⏳").catch(() => {});

    try {
        let apiUrl = "";
        let judulAsupan = command.toUpperCase();

        if (command === 'vtiktok' || command === 'asupantiktok') {
            let query = args.join(" ") || "natajadeh";
            apiUrl = global.botcahxUrl('/api/asupan/tiktok', { query });
            judulAsupan = `TIKTOK: ${query.toUpperCase()}`;
        } else {
            apiUrl = global.botcahxUrl(`/api/asupan/${command}`);
        }

        // 🚀 Ambil data dari server
        let { data, headers } = await axios.get(apiUrl, { 
            responseType: 'arraybuffer', 
            timeout: 60000 
        });
        
        let contentType = String(headers['content-type'] || '').toLowerCase();
        let mediaBuffer = data;

        // 🧠 JIKA SERVER NGASIH JSON (STRUK URL)
        if (contentType.includes('application/json')) {
            let jsonText = Buffer.from(data).toString('utf-8');
            let json = JSON.parse(jsonText);
            
            let resData = json.result || json.data || json;
            let urlFinal = "";

            if (typeof resData === 'string' && resData.startsWith('http')) urlFinal = resData;
            else if (Array.isArray(resData) && resData.length > 0) {
                let item = resData[0];
                if (typeof item === 'string') urlFinal = item;
                else if (item && typeof item === 'object') urlFinal = item.url || item.video || item.video_url;
            } 
            else if (typeof resData === 'object') {
                urlFinal = resData.url || resData.video || resData.video_url || resData.url_video || resData.data?.play || resData.video_data?.nwm_video_url || resData.video_data?.wm_video_url;
            }

            if (!urlFinal || !urlFinal.startsWith('http')) throw new Error("Gagal mengekstrak URL dari JSON BOTCAHX.");
            
            // Karena ini link URL, kita harus download dulu filenya untuk ngecek dia Foto/Video
            let fetchMedia = await axios.get(urlFinal, { responseType: 'arraybuffer', timeout: 60000 });
            mediaBuffer = fetchMedia.data;
            contentType = String(fetchMedia.headers['content-type'] || '').toLowerCase();
        } 
        
        // 🎨 RAKIT UI CAPTION VIP
        let teksCaption = `╭───「 *🎭 ASUPAN ${judulAsupan}* 」\n`;
        teksCaption += `│ 🎥 *Source:* BOTCAHX API\n`;
        teksCaption += `│ 👤 *Request:* @${m.sender.split('@')[0]}\n`;
        teksCaption += `│ 🎟️ *Biaya:* -1 Limit\n`;
        teksCaption += `╰──────────────\n\n`;
        teksCaption += `_Nih asupan spesial buat Bosku! Jangan lupa kedip._ 👀✨`;

        await m.react("✅").catch(() => {});

        // 🧬 SENSOR DNA MEDIA (Pemilah Foto vs Video)
        let mediaMessage = {};
        
        if (contentType.includes('image')) {
            // Jika terdeteksi sebagai Gambar/Foto
            mediaMessage = { image: mediaBuffer };
        } else if (contentType.includes('video') || contentType.includes('application/octet-stream')) {
            // Jika terdeteksi sebagai Video (octet-stream biasanya default MP4 mentah)
            mediaMessage = { video: mediaBuffer };
        } else {
            throw new Error(`Tipe media tidak didukung dari server: ${contentType}`);
        }

        // 🎬 Eksekusi Kirim Media VIP
        await sock.sendMessage(m.chat, { 
            ...mediaMessage, // Menyuntikkan hasil deteksi otomatis (image/video)
            caption: teksCaption,
            contextInfo: { 
                mentionedJid: [m.sender],
                forwardingScore: 999, 
                isForwarded: true,
                forwardedNewsletterMessageInfo: { 
                    newsletterJid: global.idChannel || "1203631@newsletter", 
                    newsletterName: "🎭 Assistant X Asupan", 
                    serverId: 1 
                } 
            }
        }, { quoted: m });

    } catch (err) {
        console.error(`🔴 [ASUPAN ${command.toUpperCase()} ERROR]:`, err.message || err);
        await m.react("❌").catch(() => {});
        return m.reply(`❌ *Gagal Mengambil Asupan!*\n${err.message || 'Server sedang sibuk. Coba lagi nanti.'}`);
    }
}

handler.command = [
    "anony", "bocil", "cecan", "douyin", "euni", 
    "hijaber", "gheayubi", "natajadeh", "rikagusriani", 
    "santuy", "ukhty", "vtiktok", "asupantiktok"
];
handler.tags = ["premium"]; 
handler.help = [
    "anony", "bocil", "cecan", "douyin", "euni", 
    "hijaber", "gheayubi", "natajadeh", "rikagusriani", 
    "santuy", "ukhty", "vtiktok <query>"
];
handler.limit = true; 
handler.premium = true;


module.exports = handler;
