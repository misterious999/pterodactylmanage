const axios = require('axios');
const FormData = require('form-data');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

// Fungsi Jeda (Sleep) untuk antrean
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// ==========================================
// 📡 NATIVE BAILEYS DOWNLOADER (HELPER)
// ==========================================
async function downloadMedia(q) {
    try {
        if (typeof q.download === 'function') {
            const buffer = await q.download();
            if (Buffer.isBuffer(buffer) && buffer.length) return buffer;
        }

        let msg = q.msg || q;
        let mime = msg.mimetype || q.mediaType || '';
        let mediaType = mime.split('/')[0];
        
        if (mediaType === 'image') {
            const stream = await downloadContentFromMessage(msg, 'image');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
            if (buffer.length > 0) return buffer;
        }
        throw new Error('Buffer kosong atau media bukan gambar.');
    } catch (e) {
        throw new Error(`Gagal menyedot gambar. Pastikan kamu me-reply gambar yang valid.`);
    }
}

// ==========================================
// ⚙️ WEB2APK SERVICE CORE (SINGLE SESSION)
// ==========================================
class Web2ApkService {
    constructor({ apiUrl = 'https://webappcreator.amethystlab.org/api/build-apk', baseUrl = 'https://webappcreator.amethystlab.org' } = {}) {
        this.apiUrl = apiUrl;
        this.baseUrl = baseUrl;
        this.sessionCookie = ''; // 🔥 VVIP: Penyimpan Karcis Sesi agar tidak dianggap user baru
    }

    isValidUrl(url) {
        return /^https?:\/\//i.test(url);
    }

    buildPackageName(appName) {
        const cleaned = appName.toLowerCase().replace(/[^a-z0-9]/g, '');
        return `com.${cleaned || 'app'}.web2apk`;
    }

    async build({ url, appName, iconBuffer, versionName = '1.0.0', versionCode = 1, onQueueCallback }) {
        if (!this.isValidUrl(url)) throw new Error('URL harus diawali dengan http:// atau https://');
        if (!appName) throw new Error('Nama aplikasi tidak boleh kosong.');
        if (!iconBuffer) throw new Error('Icon aplikasi wajib disertakan.');

        const packageName = this.buildPackageName(appName);
        let attempt = 1;
        const maxAttempts = 20; // Cukup untuk nunggu sekitar 5 menit di satu sesi

        while (attempt <= maxAttempts) {
            const form = new FormData();
            form.append('websiteUrl', url);
            form.append('appName', appName);
            form.append('icon', iconBuffer, { filename: 'icon.png', contentType: 'image/png' });
            form.append('packageName', packageName);
            form.append('versionName', versionName);
            form.append('versionCode', versionCode);

            let headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
                'Accept': 'application/json, text/plain, */*',
                'Origin': this.baseUrl,
                'Referer': `${this.baseUrl}/`,
                ...form.getHeaders()
            };

            // 🔥 SUNTIKAN SESI: Jika bot sudah punya karcis antrean, pakai karcis itu!
            if (this.sessionCookie) {
                headers['Cookie'] = this.sessionCookie;
            }

            try {
                const response = await axios.post(this.apiUrl, form, {
                    headers: headers,
                    maxContentLength: Infinity,
                    maxBodyLength: Infinity,
                    timeout: 60000 
                });

                // TANGKAP SESI: Simpan cookie dari server di percobaan pertama
                if (response.headers['set-cookie'] && !this.sessionCookie) {
                    this.sessionCookie = response.headers['set-cookie'].map(c => c.split(';')[0]).join('; ');
                }

                const data = response.data;

                // SISTEM DETEKSI ANTREAN (TUNGGU DI SATU SESI)
                if (!data.success) {
                    const errorMsg = data.message || '';
                    if (errorMsg.toLowerCase().includes('queue')) {
                        if (onQueueCallback) await onQueueCallback(errorMsg, attempt, maxAttempts);
                        
                        attempt++;
                        await sleep(15000); // Diam menahan sesi selama 15 detik sebelum cek lagi
                        continue; 
                    }
                    
                    throw new Error(errorMsg || 'Gagal mem-build APK dari server Amethystlab.');
                }

                return {
                    success: true,
                    appName,
                    packageName,
                    downloadUrl: `${this.baseUrl}${data.downloadUrl}`
                };

            } catch (err) {
                if (err.code === 'ECONNABORTED' || (err.message && err.message.includes('timeout'))) {
                     attempt++;
                     await sleep(10000);
                     continue;
                }
                throw err;
            }
        }

        throw new Error("Waktu tunggu habis (Timeout). Antrean server sedang sangat penuh, silakan coba lagi nanti.");
    }
}

// ==========================================
// 🚀 MAIN HANDLER BOT
// ==========================================
let handler = async (m, { sock, args, text, prefix, command, isOwner, isPrems }) => {
    
    let isPremiumUser = isPrems || isOwner || (global.db?.data?.users?.[m.sender]?.premium);
    if (!isPremiumUser) {
        return m.reply("❌ *Akses Ditolak!*\nFitur VVIP ini secara eksklusif hanya dapat digunakan oleh *Owner* dan pengguna *Premium*.");
    }

    if (!text || !text.includes('|')) {
        let panduan = `🤖 *Format Tidak Valid!*\n\n`;
        panduan += `Gunakan format: \`${prefix}${command} <URL> | <Nama Aplikasi>\`\n\n`;
        panduan += `*Contoh Penggunaan:*\n`;
        panduan += `\`${prefix}${command} https://google.com | Google App\`\n\n`;
        panduan += `⚠️ _PENTING: Jangan lupa kirim/balas (reply) sebuah gambar persegi untuk dijadikan icon APK-nya!_`;
        return m.reply(panduan);
    }

    let [url, ...appNameArr] = text.split('|');
    url = url.trim();
    let appName = appNameArr.join('|').trim();

    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || q.mimetype || q.mediaType || '';
    if (!/image/.test(mime)) {
        return m.reply("❌ *Icon Tidak Ditemukan!*\nHarap kirimkan atau balas (reply) sebuah gambar yang akan dijadikan Icon Aplikasi.");
    }

    await m.react('⏳');
    let { key } = await sock.sendMessage(m.chat, { text: "🔄 _Menyedot gambar icon dan memanggil server builder..._" }, { quoted: m });

    try {
        const iconBuffer = await downloadMedia(q);
        
        await sock.sendMessage(m.chat, { text: `🔨 _Mengkompilasi **${appName}** menjadi APK...\nMohon tunggu, bot sedang menahan koneksi dengan server._`, edit: key });

        const service = new Web2ApkService();
        
        const result = await service.build({
            url: url,
            appName: appName,
            iconBuffer: iconBuffer,
            onQueueCallback: async (queueStatus, currentAttempt, maxAttempts) => {
                // UI yang lebih elegan, menunjukkan bot diam menahan antrean
                let queueMsg = `🚦 *ANTREAN SERVER BERJALAN*\n\n`;
                queueMsg += `📝 _Informasi Server:_ ${queueStatus}\n`;
                queueMsg += `⏳ _Menahan sesi di dalam antrean... (${currentAttempt}/${maxAttempts})_\n\n`;
                queueMsg += `_Sistem bot tetap berada di antrean yang sama. APK akan otomatis dikirim jika antrean sudah selesai._ ☕`;
                
                await sock.sendMessage(m.chat, { text: queueMsg, edit: key }).catch(() => {});
            }
        });

        let teksSukses = `✨ *W E B   T O   A P K* ✨\n\n`;
        teksSukses += `✅ *Aplikasi Berhasil Dibangun!*\n`;
        teksSukses += `╭──────────────\n`;
        teksSukses += `│ 📱 *Nama App:* ${result.appName}\n`;
        teksSukses += `│ 📦 *Package:* ${result.packageName}\n`;
        teksSukses += `│ 🔗 *Tautan Akses:* ${result.downloadUrl}\n`;
        teksSukses += `╰──────────────\n\n`;
        teksSukses += `_Sedang mengirimkan file APK langsung ke ruang obrolan ini..._ 🚀`;

        await sock.sendMessage(m.chat, { text: teksSukses, edit: key });

        await sock.sendMessage(m.chat, {
            document: { url: result.downloadUrl },
            fileName: `${result.appName}.apk`,
            mimetype: 'application/vnd.android.package-archive'
        }, { quoted: m });

        await m.react('✅');

    } catch (e) {
        console.error('[WEB2APK ERROR]', e);
        await m.react('❌');
        await sock.sendMessage(m.chat, { 
            text: `❌ *Sistem Gagal Mem-build APK!*\n\n📝 _Log:_ ${e.message}` 
        }, { edit: key });
    }
}

handler.help = ['web2apk <url> | <nama>'];
handler.tags = ['premium'];
handler.command = ['web2apk']; 
handler.premium = true; 

module.exports = handler;
