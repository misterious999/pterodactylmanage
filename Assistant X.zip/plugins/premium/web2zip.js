const APIKEY = process.env.BOTCAHX_APIKEY || 'pstar';

function isValidUrl(url) {
    try {
        const parsed = new URL(url);
        return ['http:', 'https:'].includes(parsed.protocol);
    } catch {
        return false;
    }
}

function getHostName(url) {
    try {
        return new URL(url).hostname.replace(/[^a-zA-Z0-9.-]/g, '_');
    } catch {
        return 'website';
    }
}

function checkPremiumAccess(m, isOwner, isPrems) {
    const sender = m.sender;

    const user =
        global.db?.data?.users?.[sender] ||
        global.db?.users?.[sender] ||
        {};

    const premiumFromDb =
        user.premium === true ||
        user.premiumTime === Infinity ||
        Number(user.premiumTime || 0) > Date.now();

    return Boolean(
        isOwner ||
        isPrems ||
        m.isOwner ||
        m.isPremium ||
        premiumFromDb
    );
}

async function fetchBuffer(url) {
    const response = await fetch(url, {
        method: 'GET',
        headers: {
            'User-Agent': 'Mozilla/5.0 AssistantXBot/1.0'
        }
    });

    if (!response.ok) {
        let errorText = '';
        try {
            errorText = await response.text();
        } catch {}

        throw new Error(`Request gagal: ${response.status} ${response.statusText}${errorText ? ` - ${errorText.slice(0, 200)}` : ''}`);
    }

    const arrayBuffer = await response.arrayBuffer();

    return {
        buffer: Buffer.from(arrayBuffer),
        contentType: response.headers.get('content-type') || ''
    };
}

async function web2zip(targetUrl) {
    const apiUrl = `https://api.botcahx.eu.org/api/tools/web2zip?url=${encodeURIComponent(targetUrl)}&apikey=${encodeURIComponent(APIKEY)}`;

    const response = await fetch(apiUrl, {
        method: 'GET',
        headers: {
            'User-Agent': 'Mozilla/5.0 AssistantXBot/1.0'
        }
    });

    const contentType = response.headers.get('content-type') || '';

    if (!response.ok) {
        let errorText = '';
        try {
            errorText = await response.text();
        } catch {}

        throw new Error(`API gagal: ${response.status} ${response.statusText}${errorText ? ` - ${errorText.slice(0, 200)}` : ''}`);
    }

    if (
        contentType.includes('application/zip') ||
        contentType.includes('application/octet-stream') ||
        contentType.includes('application/x-zip-compressed')
    ) {
        const arrayBuffer = await response.arrayBuffer();
        return Buffer.from(arrayBuffer);
    }

    if (contentType.includes('application/json')) {
        const json = await response.json();

        if (json.status === false) {
            throw new Error(json.message || 'API mengembalikan status false.');
        }

        const resultUrl =
            json.result ||
            json.url ||
            json.link ||
            json.download ||
            json.data?.url ||
            json.data?.link ||
            json.data?.download;

        if (!resultUrl || typeof resultUrl !== 'string') {
            throw new Error('Link file ZIP tidak ditemukan dari response API.');
        }

        const { buffer } = await fetchBuffer(resultUrl);
        return buffer;
    }

    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    if (!buffer.length) {
        throw new Error('File ZIP kosong atau tidak berhasil dibuat.');
    }

    return buffer;
}

let handler = async (m, { sock, conn, text, args, command, prefix, isOwner, isPrems }) => {
    const client = sock || conn;
    const usedPrefix = prefix || '.';
    const input = String(text || (args || []).join(' ') || '').trim();

    const hasPremiumAccess = checkPremiumAccess(m, isOwner, isPrems);

    if (!hasPremiumAccess) {
        return m.reply(`╭──「 *FITUR PREMIUM* 」
│
│ ❌ Fitur *Web2Zip* hanya dapat digunakan
│ oleh user premium.
│
│ 📦 *Fitur:* Web to ZIP
│ 🔐 *Status:* Premium Only
│
│ Silakan upgrade ke premium untuk
│ menggunakan fitur ini.
╰────────────`);
    }

    if (!client) {
        return m.reply('❌ Client bot tidak ditemukan.');
    }

    if (!input) {
        return m.reply(`╭──「 *WEB TO ZIP* 」
│
│ Ubah website menjadi file ZIP.
│
│ 🔐 *Status:* Premium Only
│
│ *Cara pakai:*
│ ${usedPrefix}${command} https://google.com
│
╰────────────`);
    }

    if (!isValidUrl(input)) {
        return m.reply(`❌ URL tidak valid.

Contoh:
${usedPrefix}${command} https://google.com`);
    }

    await m.react('⏳').catch(() => {});

    try {
        await m.reply(`╭──「 *WEB2ZIP DIPROSES* 」
│ 🌐 *URL:* ${input}
│ 📦 *Status:* Membuat file ZIP
│ 🔐 *Akses:* Premium
╰────────────

_Mohon tunggu, proses bisa memakan waktu beberapa detik._`);

        const zipBuffer = await web2zip(input);

        if (!zipBuffer || !zipBuffer.length) {
            throw new Error('Buffer ZIP kosong.');
        }

        const hostName = getHostName(input);
        const fileName = `${hostName}.zip`;

        await client.sendMessage(m.chat, {
            document: zipBuffer,
            mimetype: 'application/zip',
            fileName,
            caption: `╭──「 *WEB2ZIP SELESAI* 」
│ 🌐 *Website:* ${input}
│ 📦 *File:* ${fileName}
│ ✅ *Status:* Berhasil dibuat
│ 🔐 *Akses:* Premium
╰────────────`
        }, {
            quoted: m
        });

        await m.react('✅').catch(() => {});
    } catch (error) {
        console.error('[WEB2ZIP ERROR]', error);

        await m.react('❌').catch(() => {});

        return m.reply(`❌ *Web2Zip gagal diproses.*

Kemungkinan penyebab:
• URL tidak bisa diakses
• Website terlalu besar
• API sedang limit/down
• Website memblokir proses cloning

Detail:
${error.message || error}`);
    }
};

handler.command = [
    'web2zip',
    'webtozip',
    'sitezip'
];

handler.tags = ['premium'];

handler.help = [
    'web2zip <url>'
];

handler.premium = true;
handler.limit = true;

module.exports = handler;