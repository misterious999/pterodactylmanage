const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const os = require("os");
const { exec } = require("child_process");
const { downloadContentFromMessage } = require("@whiskeysockets/baileys");

// ==========================================
// 💎 PREMIUM STICKER WATERMARK CHANGER
// ⚙️️ FIXED: Smart Detector Anti-Buta
// ==========================================

function isPremiumUser(m, isOwner, isPremium) {
    const user = global.db?.users?.[m.sender] || {};

    return Boolean(
        isOwner ||
        isPremium ||
        user.premium ||
        user.premiumTime > Date.now()
    );
}

// 🛠️ Fungsi Pembuat Metadata EXIF
async function addExif(buffer, packname, author) {
    const json = {
        "sticker-pack-id": "com.assistantx.project",
        "sticker-pack-name": packname,
        "sticker-pack-publisher": author,
        "emojis": ["✨"]
    };

    const exifAttr = Buffer.from([
        0x49, 0x49, 0x2A, 0x00,
        0x08, 0x00, 0x00, 0x00,
        0x01, 0x00, 0x41, 0x57,
        0x07, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x16, 0x00,
        0x00, 0x00
    ]);

    const jsonBuff = Buffer.from(JSON.stringify(json), "utf-8");
    const exif = Buffer.concat([exifAttr, jsonBuff]);

    exif.writeUIntLE(jsonBuff.length, 14, 4);

    try {
        // Engine 1: node-webpmux
        const webp = require("node-webpmux");
        const img = new webp.Image();

        await img.load(buffer);
        img.exif = exif;

        return await img.save(null);
    } catch (error) {
        // Engine 2: fallback webpmux CLI
        return new Promise((resolve) => {
            const tmpdir = os.tmpdir();
            const tmpFile = path.join(
                tmpdir,
                crypto.randomBytes(6).readUIntLE(0, 6).toString(36) + ".webp"
            );
            const exifFile = path.join(
                tmpdir,
                crypto.randomBytes(6).readUIntLE(0, 6).toString(36) + ".exif"
            );

            try {
                fs.writeFileSync(tmpFile, buffer);
                fs.writeFileSync(exifFile, exif);

                exec(`webpmux -set exif "${exifFile}" "${tmpFile}" -o "${tmpFile}"`, (err) => {
                    try {
                        if (err) {
                            safeUnlink(tmpFile);
                            safeUnlink(exifFile);
                            return resolve(buffer);
                        }

                        const finalBuffer = fs.readFileSync(tmpFile);

                        safeUnlink(tmpFile);
                        safeUnlink(exifFile);

                        return resolve(finalBuffer);
                    } catch (_) {
                        safeUnlink(tmpFile);
                        safeUnlink(exifFile);
                        return resolve(buffer);
                    }
                });
            } catch (_) {
                safeUnlink(tmpFile);
                safeUnlink(exifFile);
                return resolve(buffer);
            }
        });
    }
}

function safeUnlink(filePath) {
    try {
        if (filePath && fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
        }
    } catch (_) {}
}

function parseWatermark(text = "") {
    let packname = "";
    let author = "";

    if (!text) {
        return { packname, author };
    }

    const parts = String(text).split("|");

    packname = parts[0] ? parts[0].trim() : "";
    author = parts[1] ? parts[1].trim() : "";

    return { packname, author };
}

let handler = async (m, { sock, conn, text, prefix, command, isOwner, isPremium }) => {
    const client = sock || conn || global.conn;

    if (!isPremiumUser(m, isOwner, isPremium)) {
        return m.reply(`╭─〔 *💎 FITUR PREMIUM* 〕\n│ Fitur ini khusus user premium.\n│\n│ Ingin akses fitur premium?\n│ Hubungi owner dengan command:\n│ ${prefix}owner\n╰────────────`);
    }

    if (!m.quoted) {
        return m.reply(`╭─〔 *💎 STICKER WATERMARK* 〕\n│ Balas stiker yang ingin diubah WM-nya.\n╰────────────\n\nFormat:\n│ ${prefix}${command} PackName | Author\n│ ${prefix}${command} Assistant X | Pstar7\n│ ${prefix}${command}\n\nCatatan:\n│ Kosongkan teks untuk membuat WM polos.`);
    }

    // 🔥 SMART DETECTOR: Bypass Bug Framework
    let q = m.quoted;
    let rawStickerMsg = m.message?.extendedTextMessage?.contextInfo?.quotedMessage?.stickerMessage;
    
    let isSticker = (q && q.mtype === 'stickerMessage') || 
                    (q && q.msg && q.msg.mimetype === 'image/webp') || 
                    (q && /webp/.test(q.mimetype || '')) || 
                    !!rawStickerMsg;

    if (!isSticker) {
        return m.reply("❌ Yang kamu balas bukan stiker.");
    }

    await m.react("⏳").catch(() => {});

    const { packname, author } = parseWatermark(text);

    try {
        let buffer;
        
        // 🔥 MULTI-ENGINE DOWNLOADER
        if (typeof q.download === 'function') {
            buffer = await q.download();
        } else {
            // Ekstraksi manual via Baileys Murni jika q.download gagal/tidak ada
            if (!rawStickerMsg) throw new Error("Struktur stiker tidak valid di database WA.");
            
            const stream = await downloadContentFromMessage(rawStickerMsg, "sticker");
            buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }
        }

        if (!buffer || buffer.length === 0) throw new Error("Gagal mengekstrak data stiker.");

        const finalSticker = await addExif(buffer, packname, author);

        await client.sendMessage(m.chat, {
            sticker: finalSticker
        }, {
            quoted: m
        });

        await m.react("✅").catch(() => {});
    } catch (error) {
        console.error("[WM PREMIUM ERROR]", error);

        await m.react("❌").catch(() => {});

        return m.reply(`❌ Terjadi kesalahan saat memproses stiker.\n\nDetail:\n${error.message || error}`);
    }
};

handler.command = ["wm", "colong"];
handler.tags = ["premium"];
handler.help = ["wm <packname>|<author>"];
handler.premium = true;
handler.limit = true;

module.exports = handler;
