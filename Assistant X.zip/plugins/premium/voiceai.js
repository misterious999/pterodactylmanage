const axios = require("axios");

const LANGS = {
    id: "Indonesia",
    en: "English",
    ja: "Japanese",
    ko: "Korean",
    ar: "Arabic",
    ms: "Malay",
    zh: "Chinese",
    es: "Spanish",
    fr: "French",
    de: "German",
    ru: "Russian",
    th: "Thai",
    vi: "Vietnamese",
    hi: "Hindi"
};

function cleanText(text = "") {
    return String(text || "")
        .replace(/\u200e|\u200f|\u202a|\u202b|\u202c/g, "")
        .trim();
}

function parseInput(text = "") {
    const raw = cleanText(text);

    if (!raw) {
        return {
            lang: "id",
            text: ""
        };
    }

    if (raw.includes("|")) {
        const [lang, ...rest] = raw.split("|");

        return {
            lang: cleanText(lang || "id").toLowerCase(),
            text: cleanText(rest.join("|"))
        };
    }

    const first = raw.split(/\s+/)[0]?.toLowerCase();
    const rest = raw.split(/\s+/).slice(1).join(" ");

    if (LANGS[first] && rest) {
        return {
            lang: first,
            text: cleanText(rest)
        };
    }

    return {
        lang: "id",
        text: raw
    };
}

function makeLangList(prefix = ".", command = "voiceai") {
    const rows = Object.entries(LANGS)
        .map(([code, name]) => `│ ${code.padEnd(4)} = ${name}`)
        .join("\n");

    return `╭─〔 *VOICE AI LANG* 〕
${rows}
╰────────────

Contoh:
│ ${prefix}${command} halo semuanya
│ ${prefix}${command} id|halo semuanya
│ ${prefix}${command} en|hello everyone
│ ${prefix}${command} ja|ohayou gozaimasu`;
}

async function textToSpeechGoogle(text, lang = "id") {
    const url = "https://translate.google.com/translate_tts";

    const response = await axios.get(url, {
        responseType: "arraybuffer",
        timeout: 30000,
        params: {
            ie: "UTF-8",
            q: text,
            tl: lang,
            client: "tw-ob"
        },
        headers: {
            "User-Agent": "Mozilla/5.0"
        },
        validateStatus: () => true
    });

    if (response.status >= 400) {
        throw new Error(`Google TTS HTTP ${response.status}`);
    }

    const buffer = Buffer.from(response.data);

    if (!buffer.length) {
        throw new Error("Audio kosong.");
    }

    return buffer;
}

let handler = async (m, { sock, conn, text, args, prefix, command }) => {
    const client = sock || conn || global.conn;
    const input = cleanText(text || (args || []).join(" "));

    if (input.toLowerCase() === "list") {
        return m.reply(makeLangList(prefix, command));
    }

    const quotedText = cleanText(
        m.quoted?.text ||
        m.quoted?.caption ||
        m.quoted?.body ||
        ""
    );

    const parsed = parseInput(input || quotedText);

    if (!parsed.text) {
        return m.reply(`╭─〔 *VOICE AI* 〕
│ Ubah teks menjadi suara AI.
╰────────────

Contoh:
│ ${prefix}${command} halo semuanya
│ ${prefix}${command} id|halo semuanya
│ ${prefix}${command} en|hello everyone
│ ${prefix}${command} list`);
    }

    if (!LANGS[parsed.lang]) {
        return m.reply(`❌ Kode bahasa *${parsed.lang}* belum tersedia.

Cek daftar:
${prefix}${command} list`);
    }

    const finalText = parsed.text.slice(0, 200);

    if (parsed.text.length > 200) {
        await m.reply("⚠️ Teks terlalu panjang. Hanya 200 karakter pertama yang diproses.");
    }

    await m.react("🎙️").catch(() => {});

    try {
        const audioBuffer = await textToSpeechGoogle(finalText, parsed.lang);

        await client.sendMessage(m.chat, {
            audio: audioBuffer,
            mimetype: "audio/mpeg",
            ptt: true,
            fileName: "voiceai.mp3"
        }, {
            quoted: m
        });

        await m.react("✅").catch(() => {});
    } catch (error) {
        console.error("[VOICEAI ERROR]", error);

        await m.react("❌").catch(() => {});
        return m.reply(`❌ Gagal membuat voice AI.

Detail:
${error.message || error}`);
    }
};

handler.command = ["voiceai"];
handler.tags = ["premium"];
handler.help = ["voiceai <teks>"];
handler.premium = true;
handler.limit = true;

module.exports = handler;