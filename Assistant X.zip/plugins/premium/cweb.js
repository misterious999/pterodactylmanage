let handler = async (m, { sock, text, prefix, command, isOwner, isPrems }) => {
    // 🛡️ GERBANG KEAMANAN MUTLAK (SECURITY GATE)
    // Jika BUKAN Owner DAN BUKAN Premium, akses langsung diblokir.
    if (!isOwner && !isPrems) {
        await m.react('❌').catch(() => {});
        return m.reply(`[ 🔒 AKSES DITOLAK ]\n\nMaaf, fitur Deploy Website (*${prefix}${command}*) ini sangat eksklusif dan menguras resource server.\n\nFitur ini HANYA bisa digunakan oleh *User Premium* atau *Developer* saja! ✨`);
    }

    if (!text) return m.reply(`❗ *Mana nama webnya?*\n\nContoh:\n${prefix + command} mywebsite`);
    const webName = sanitizeWebName(text);
    if (!webName || webName.length < 3) return m.reply('❌ Nama web tidak valid. Minimal 3 karakter, hanya huruf kecil, angka, strip, dan underscore.');

    const q = m.quoted ? m.quoted : m;
    const mime = getMime(q);

    if (!/zip|html/i.test(mime)) {
        await m.react('❌').catch(() => {});
        return m.reply('❗ *Format Salah!*\nSilakan balas (reply) file yang berformat .zip atau .html.');
    }

    await m.react('⏳').catch(() => {});

    try {
        const mediaData = await downloadQuotedMedia(q);
        const filesToUpload = await extractFiles(mediaData, mime);

        if (command === 'cweb' || command === 'createweb') {
            await m.reply(`⏳ Sedang mendeploy ke Vercel: *${webName}.vercel.app*...`);
            const url = await deployToVercel(webName, filesToUpload);
            await m.react('✅').catch(() => {});
            return m.reply(`✅ *Website Berhasil Mengudara via Vercel!*\n\n🌐 URL:\n${url}\n\n_Catatan: Tunggu 5-10 detik agar server memuat halaman barumu sebelum diklik._`);
        }

        if (command === 'cweb2' || command === 'createweb2') {
            await m.reply(`⏳ Sedang mendeploy ke GitHub Pages: *${webName}-website*...`);
            const url = await deployToGithubPages(webName, filesToUpload);
            await m.react('✅').catch(() => {});
            return m.reply(`✅ *Website Berhasil Mengudara via GitHub Pages!*\n\n🌐 URL:\n${url}\n\n_Catatan: GitHub Pages biasanya membutuhkan waktu 1-2 menit untuk online sepenuhnya._`);
        }
    } catch (error) {
        console.error('[CWEB ERROR]', error.response?.data || error.message || error);
        await m.react('❌').catch(() => {});
        return m.reply(`${error.response?.data?.message || error.response?.data?.error?.message || error.message || error}`);
    }
};

handler.command = ['cweb', 'createweb', 'cweb2', 'createweb2'];
handler.tags = ['premium'];
handler.help = ['cweb <nama web>', 'cweb2 <nama web>'];
handler.premium = true; 
handler.owner = false; // Memastikan property ini false agar premium tetap bisa akses

module.exports = handler;
