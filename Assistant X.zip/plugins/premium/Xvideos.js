const axios = require("axios")

// ======================================
// 🔞 XVIDEOS SEARCH + DOWNLOAD (1 FILE)
// ======================================

let handler = async (m, { sock, prefix, command, text }) => {

const apiKey = global.btc
if (!apiKey) return m.reply("BOTCAHX_APIKEY belum diisi")

// ======================================
// 🔍 SEARCH
// ======================================
if (command === "xvideos") {

if (!text) {
return m.reply(
`Contoh:
${prefix}xvideos japan`
)
}

await m.react("⏳").catch(()=>{})

try {

const api = global.botcahxUrl('/api/search/xvideos', { query: text })

const { data } = await axios.get(api)

if (!data.status || !data.result?.length)
throw "Tidak ditemukan"

let teks = `╭─「 🔎 XVIDEOS SEARCH 」\n`
teks += `│ Query : ${text}\n`
teks += `│ Hasil : ${data.result.length}\n`
teks += `╰────────────────\n\n`

data.result.slice(0,5).forEach((v,i)=>{

const link = v.url || v.link || v.href

teks += `*${i+1}. ${v.title}*\n`
teks += `⏱️ ${v.duration || "-"}\n`
teks += `👁️ ${v.views || "-"}\n`
teks += `🔗 ${link}\n`
teks += `──────────────────\n\n`

})

teks += `Download:
${prefix}xvideosdl <link>`

await sock.sendMessage(m.chat,{
text: teks,
contextInfo:{
forwardingScore:999,
isForwarded:true
}
},{quoted:m})

await m.react("✅")

} catch(e){
console.log(e)
m.reply("error search")
}

}


// ======================================
// 📥 DOWNLOAD
// ======================================
if (command === "xvideosdl") {

if (!text) return m.reply("Masukkan link xvideos")

await m.react("⏳")

try {

const api = global.botcahxUrl('/api/download/xvideosdl', { url: text })

const { data } = await axios.get(api)

if (!data.status) throw "API error"

const v = data.result

const video =
v.url ||
v.video ||
v.download ||
v.files?.high ||
v.files?.low ||
v.mp4

if (!video) throw "Video tidak ditemukan"

let caption = `╭─「 📥 XVIDEOS DOWNLOAD 」\n`
caption += `│ 🎬 ${v.title || "-"}\n`
caption += `│ ⏱️ ${v.duration || "-"}\n`
caption += `│ 👁️ ${v.views || "-"}\n`
caption += `╰────────────────`

await sock.sendMessage(m.chat,{
video:{ url: video },
caption: caption
},{quoted:m})

await m.react("✅")

} catch(e){
console.log(e)
m.reply("download gagal / api error")
}

}

}

handler.command = [
"xvideos",
"xvideosdl"
]

handler.tags = ["premium"]
handler.help = [
"xvideos <query>",
"xvideosdl <link>"
]

handler.limit = true
handler.premium = true

module.exports = handler