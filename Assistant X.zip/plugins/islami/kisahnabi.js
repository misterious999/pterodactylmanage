// ==========================================
// 🕌 VIP KISAH NABI (BETABOTZ ENGINE)
// ⚙️ SMART EXTRACTOR & NATIVE FLOW BUTTONS
// ==========================================

const axios = require('axios');
// 📦 Import module khusus untuk merakit Native Flow Message dari Baileys
const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

let handler = async (m, { sock, text, prefix, command }) => {
    if (!text) {
        await m.react("⚠️").catch(() => {});
        return m.reply(`❌ *Sebutkan nama nabinya Bosku!*\n\n*Contoh:* \`${prefix + command} yusuf\``);
    }

    await m.react("⏳").catch(() => {});

    try {
        let apiKey = global.btc || "Apiapii";
        let apiUrl = global.botcahxUrl('/api/muslim/kisahnabi2');
        
        let { data, status } = await axios.get(apiUrl, { 
            timeout: 15000,
            validateStatus: () => true 
        });

        if (status !== 200 || data.status === false) {
            let alasan = data.message || data.error || `HTTP Status ${status}`;
            throw new Error(`*Ditolak oleh Server BOTCAHX!*\nAlasan: ${alasan}`);
        }

        // resArray akan menampung seluruh daftar nabi untuk kita jadikan tombol menu
        let resArray = data.result || data.data || data;
        let resObj = null;

        if (Array.isArray(resArray)) {
            let cariNabi = resArray.find(v => 
                (v.name && v.name.toLowerCase().includes(text.toLowerCase())) || 
                (v.nama && v.nama.toLowerCase().includes(text.toLowerCase())) || 
                (v.nabi && v.nabi.toLowerCase().includes(text.toLowerCase()))
            );
            resObj = cariNabi ? cariNabi : null;
        } else {
            resObj = resArray;
            resArray = [resObj]; // Jaga-jaga kalau API cuma ngirim 1 nabi
        }

        if (!resObj) throw new Error(`Kisah Nabi *${text}* tidak ditemukan. Pastikan ejaan namanya benar!`);

        // Ekstraksi Data
        let nama = resObj.name || resObj.nama || resObj.nabi || text;
        let lahir = resObj.kelahiran || resObj.lahir || resObj.thn_kelahiran || "-";
        let umur = resObj.umur || resObj.usia || "-";
        let tempat = resObj.tempat || resObj.lokasi || resObj.tmp || resObj.tempat_diutus || "-"; 
        let kisah = resObj.kisah || resObj.story || resObj.description || resObj.deskripsi || resObj.detail || "Kisah tidak tersedia.";
        let namaBersih = nama.toUpperCase().replace(/NABI\s+/g, "").trim();

        // 🎨 RAKIT TEKS UTAMA
        let teks = `╭───┈ *「 🕌 KISAH NABI 」*\n`;
        teks += `│ 👤 *Nama:* Nabi ${namaBersih}\n`;
        teks += `│ 👶 *Lahir:* ${lahir}\n`;
        teks += `│ ⏳ *Usia:* ${umur}\n`;
        teks += `│ 📍 *Tempat:* ${tempat}\n`;
        teks += `╰───────────────┈ ⳹\n\n`;
        teks += `📖 *Kisah Perjalanan:*\n${kisah}\n\n`;
        teks += `_© ${global.botname} Religi_`;

        // 🎛️ RAKIT MENU LIST (NATIVE FLOW MESSAGE)
        let rows = [];
        if (Array.isArray(resArray)) {
            resArray.forEach(v => {
                let nName = v.name || v.nama || v.nabi || "Unknown";
                let nBersih = nName.toUpperCase().replace(/NABI\s+/g, "").trim();
                
                // Masukkan ke dalam daftar menu tombol
                rows.push({
                    header: `Nabi ${nBersih}`,
                    title: `Baca Kisah Nabi ${nBersih}`,
                    description: `Tempat: ${v.tempat || v.lokasi || v.tmp || "-"}`,
                    id: `${prefix + command} ${nBersih}` // Perintah yang tereksekusi saat tombol dipencet
                });
            });
        }

        let sections = [{
            title: "📚 Daftar 25 Nabi & Rasul",
            rows: rows
        }];

        let buttonParamsJson = JSON.stringify({
            title: "📜 Pilih Nabi Lainnya", // Nama Tombol Utama
            sections: sections
        });

        // 🚀 EKSEKUSI PENGIRIMAN INTERACTIVE MESSAGE
        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        // Memasukkan UI VVIP Newsletter
                        contextInfo: {
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: global.idChannel || "1203631@newsletter",
                                newsletterName: "🕌 Assistant X Religi",
                                serverId: 1
                            }
                        },
                        body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: "Silakan klik tombol di bawah untuk membaca kisah nabi lainnya:" }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            title: "",
                            subtitle: "",
                            hasMediaAttachment: false
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                {
                                    name: "single_select",
                                    buttonParamsJson: buttonParamsJson
                                }
                            ]
                        })
                    })
                }
            }
        }, { quoted: m });

        await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await m.react("✅").catch(() => {});

    } catch (error) {
        console.error("🔴 [ERROR KISAH NABI]", error.message);
        await m.react("❌").catch(() => {});
        return m.reply(`❌ *SISTEM MENGALAMI GANGGUAN!*\n\n${error.message}`);
    }
}

handler.command = ["kisahnabi"];
handler.tags = ["islami"];
handler.help = ["kisahnabi <nama>"];
handler.limit = false; 

module.exports = handler;
