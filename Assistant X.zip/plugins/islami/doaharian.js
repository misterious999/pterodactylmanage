// ==========================================
// 🤲 VIP DOA HARIAN (BETABOTZ ENGINE)
// ⚙️ FUZZY SEARCH & AUTO-RETRY SYSTEM
// ==========================================

const axios = require('axios');
const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

let handler = async (m, { sock, text, prefix, command }) => {
    await m.react("⏳").catch(() => {});

    try {
        let apiKey = global.btc || "Apiapii";
        let apiUrl = global.botcahxUrl('/api/muslim/doaharian');
        
        let data, status, success = false;

        // 🔄 AUTO-RETRY SYSTEM: Coba tembak API maksimal 3 kali kalau servernya ngadat
        for (let i = 1; i <= 3; i++) {
            try {
                let response = await axios.get(apiUrl, { timeout: 15000, validateStatus: () => true });
                data = response.data;
                status = response.status;
                if (status === 200 && data.status !== false) {
                    success = true;
                    break;
                }
            } catch (err) {
                if (i === 3) throw err;
                await delay(2000); // Tunggu 2 detik sebelum coba lagi
            }
        }

        if (!success) {
            let alasan = data?.message || data?.error || `HTTP Status ${status}`;
            throw new Error(`*Server API BOTCAHX Sedang Sibuk!*\nSilakan coba lagi dalam beberapa detik.\n(Log: ${alasan})`);
        }

        let resArray = data.result || data.data || data;

        if (!Array.isArray(resArray)) {
            if (resArray && Array.isArray(resArray.data)) resArray = resArray.data;
            else if (resArray && Array.isArray(resArray.result)) resArray = resArray.result;
            else resArray = [resArray];
        }

        if (!resArray || resArray.length === 0 || !resArray[0]) {
            throw new Error("Data doa harian kosong dari API BOTCAHX.");
        }

        // 🎯 LOGIKA 1: JIKA USER MENCARI DOA SPESIFIK 
        if (text) {
            // 🧠 FUZZY SEARCH: Pecah input user berdasarkan spasi agar kebal double-space
            let targetWords = text.toLowerCase().split(' ').filter(v => v.trim() !== '');

            let cariDoa = resArray.find(v => {
                let judulFilter = String(v.title || v.nama || v.doa || "").toLowerCase();
                // Pastikan semua kata yang diketik user ada di dalam judul (kebal urutan berantakan/spasi ganda)
                return targetWords.every(word => judulFilter.includes(word));
            });

            if (!cariDoa) {
                await m.react("⚠️").catch(() => {});
                return m.reply(`❌ *Doa tidak ditemukan!*\nSistem tidak mengenali: "${text}".\nSilakan klik tombol di bawah untuk melihat daftar.`);
            }

            let judul = cariDoa.title || cariDoa.nama || cariDoa.doa || "Doa Harian";
            let arabic = cariDoa.arabic || cariDoa.arab || "-";
            let latin = cariDoa.latin || "-";
            let terjemahan = cariDoa.translation || cariDoa.terjemahan || cariDoa.arti || "-";

            let teks = `╭───┈ *「 🤲 DOA HARIAN 」*\n`;
            teks += `│ ✨ *Judul:* ${judul}\n`;
            teks += `╰───────────────┈ ⳹\n\n`;
            teks += `*Arab:*\n${arabic}\n\n`;
            teks += `*Latin:*\n_${latin}_\n\n`;
            teks += `*Artinya:*\n"${terjemahan}"\n\n`;
            teks += `_© ${global.botname} Religi_`;

            await m.react("✅").catch(() => {});
            return sock.sendMessage(m.chat, { 
                text: teks,
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: global.idChannel || "1203631@newsletter",
                        newsletterName: "🕌 Assistant X Religi",
                        serverId: 1
                    }
                }
            }, { quoted: m });
        }

        // 🎛️ LOGIKA 2: TAMPILKAN MENU LIST (NATIVE FLOW)
        let rows = [];
        
        resArray.slice(0, 50).forEach(v => {
            let nTitle = v.title || v.nama || v.doa || "Unknown Doa";
            
            // Bersihkan spasi ganda di tombol agar lebih rapi dilihat user
            let cleanTitle = nTitle.replace(/\s+/g, ' ').trim(); 

            if (nTitle !== "Unknown Doa") {
                rows.push({
                    header: `✨ ${cleanTitle}`,
                    title: `Lihat ${cleanTitle}`,
                    description: `Klik untuk melihat teks Arab & terjemahan`,
                    // ID tetap menggunakan nTitle agar aman ditangkap sistem Fuzzy Search
                    id: `${prefix + command} ${cleanTitle}`
                });
            }
        });

        let sections = [{
            title: "🤲 Daftar Doa Harian",
            rows: rows
        }];

        let buttonParamsJson = JSON.stringify({
            title: "📖 Pilih Doa",
            sections: sections
        });

        let teksMenu = `╭───┈ *「 🕌 DOA HARIAN 」*\n`;
        teksMenu += `│ Kumpulan doa-doa harian lengkap\n`;
        teksMenu += `│ untuk aktivitas sehari-hari.\n`;
        teksMenu += `╰───────────────┈ ⳹\n\n`;

        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        contextInfo: {
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: global.idChannel || "1203631@newsletter",
                                newsletterName: "🕌 Assistant X Religi",
                                serverId: 1
                            }
                        },
                        body: proto.Message.InteractiveMessage.Body.create({ text: teksMenu }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: "Silakan pilih doa melalui tombol di bawah:" }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                {
                                    name: "single_select",
                                    buttonParamsJson: buttonParamsJson
                                }
                            ]
                        })
                    })
                }
            }
        }, { quoted: m });

        await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await m.react("✅").catch(() => {});

    } catch (error) {
        console.error("🔴 [ERROR DOA HARIAN]", error.message);
        await m.react("❌").catch(() => {});
        return m.reply(`❌ *SISTEM MENGALAMI GANGGUAN!*\n\n${error.message}`);
    }
}

handler.command = ["doaharian"];
handler.tags = ["islami"];
handler.help = ["doaharian"];
handler.limit = false; 

module.exports = handler;
