// ==========================================
// 🕌 BACAAN SHOLAT (BETABOTZ ENGINE)
// ⚙️ INTERACTIVE MENU & ANTI-BUG ID
// ==========================================

const axios = require('axios');
const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

let handler = async (m, { sock, text, prefix, command }) => {
    await m.react("⏳").catch(() => {});

    try {
        let apiKey = global.btc || "Apiapii";
        let apiUrl = global.botcahxUrl('/api/muslim/bacaanshalat');
        
        let { data, status } = await axios.get(apiUrl, { 
            timeout: 15000,
            validateStatus: () => true 
        });

        if (status !== 200 || data.status === false) {
            let alasan = data.message || data.error || `HTTP Status ${status}`;
            throw new Error(`*Ditolak oleh Server BOTCAHX!*\nAlasan: ${alasan}`);
        }

        let resArray = data.result || data.data || data;

        if (!Array.isArray(resArray) || resArray.length === 0) {
            throw new Error("Data bacaan sholat tidak ditemukan atau format API berubah.");
        }

        // 🎯 JIKA USER MENCARI BACAAN SPESIFIK 
        if (text) {
            // 🔥 FIX: Paksa semua data (termasuk ID angka) menjadi String agar kebal error
            let cariBacaan = resArray.find(v => {
                let namaFilter = String(v.name || v.nama || "").toLowerCase();
                let idFilter = String(v.id || "").toLowerCase();
                let target = text.toLowerCase();
                
                return namaFilter.includes(target) || idFilter === target;
            });

            if (!cariBacaan) {
                await m.react("⚠️").catch(() => {});
                return m.reply(`❌ *Bacaan "${text}" tidak ditemukan.*\nSilakan ketik \`${prefix + command}\` tanpa teks untuk melihat daftar lengkap.`);
            }

            let nama = cariBacaan.name || cariBacaan.nama || "Bacaan Sholat";
            let arabic = cariBacaan.arabic || cariBacaan.arab || "-";
            let latin = cariBacaan.latin || "-";
            let terjemahan = cariBacaan.terjemahan || cariBacaan.arti || "-";

            let teks = `╭───┈ *「 🕌 BACAAN SHOLAT 」*\n`;
            teks += `│ 📖 *Bagian:* ${nama}\n`;
            teks += `╰───────────────┈ ⳹\n\n`;
            teks += `*Arab:*\n${arabic}\n\n`;
            teks += `*Latin:*\n_${latin}_\n\n`;
            teks += `*Artinya:*\n"${terjemahan}"\n\n`;
            teks += `_© ${global.botname} Religi_`;

            await m.react("✅").catch(() => {});
            return sock.sendMessage(m.chat, { 
                text: teks,
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: global.idChannel || "1203631@newsletter",
                        newsletterName: "🕌 Assistant X Religi",
                        serverId: 1
                    }
                }
            }, { quoted: m });
        }

        // 🎛️ JIKA USER TIDAK MEMASUKKAN TEKS (TAMPILKAN MENU LIST)
        let rows = [];
        resArray.forEach(v => {
            let nName = v.name || v.nama || "Unknown";
            rows.push({
                header: `📖 ${nName}`,
                title: `Lihat Bacaan ${nName}`,
                description: `Arab, Latin & Terjemahan`,
                // ID yang dikirim harus sama persis dengan yang nanti diekstrak
                id: `${prefix + command} ${nName}` 
            });
        });

        let sections = [{
            title: "📚 Daftar Bacaan Sholat",
            rows: rows
        }];

        let buttonParamsJson = JSON.stringify({
            title: "📜 Pilih Bacaan",
            sections: sections
        });

        let teksMenu = `╭───┈ *「 🕌 PANDUAN SHOLAT 」*\n`;
        teksMenu += `│ Silakan pilih bacaan sholat\n`;
        teksMenu += `│ yang ingin kamu pelajari.\n`;
        teksMenu += `╰───────────────┈ ⳹\n\n`;

        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        contextInfo: {
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: global.idChannel || "1203631@newsletter",
                                newsletterName: "🕌 Assistant X Religi",
                                serverId: 1
                            }
                        },
                        body: proto.Message.InteractiveMessage.Body.create({ text: teksMenu }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: "Silakan klik tombol di bawah ini:" }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            title: "",
                            subtitle: "",
                            hasMediaAttachment: false
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                {
                                    name: "single_select",
                                    buttonParamsJson: buttonParamsJson
                                }
                            ]
                        })
                    })
                }
            }
        }, { quoted: m });

        await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await m.react("✅").catch(() => {});

    } catch (error) {
        console.error("🔴 [ERROR BACAAN SHOLAT]", error.message);
        await m.react("❌").catch(() => {});
        return m.reply(`❌ *SISTEM MENGALAMI GANGGUAN!*\n\n${error.message}`);
    }
}

handler.command = ["bacaansholat"];
handler.tags = ["islami"];
handler.help = ["bacaansholat"];
handler.limit = false; 

module.exports = handler;
