const { generateWAMessageFromContent } = require("@whiskeysockets/baileys");

// ==========================================
// 🧠 VIP SMART TYPO DETECTOR (QUERY PRESERVATION)
// ==========================================

let handler = m => m;

handler.before = async function (m, { sock }) {
    if (m.isBaileys || !m.text) return false;

    // 1. Sensor Prefix
    let usedPrefix = m.text.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?#$%^&.©^]/);
    if (!usedPrefix) return false; 

    // 2. Memisahkan Perintah Inti dan Sisa Teks (Query)
    let parts = m.text.slice(usedPrefix[0].length).trim().split(/ +/);
    let usedCommand = parts.shift().toLowerCase(); // Mengambil kata pertama (ex: 'plai')
    let queryArg = parts.join(" "); // Menyimpan sisa kalimat (ex: 'setiap waktu -hindia')

    if (!usedCommand) return false;

    // 3. Kumpulkan semua daftar memori perintah
    let allCommands = [];
    for (let p in global.plugins) {
        let plugin = global.plugins[p];
        if (!plugin || !plugin.command) continue;
        
        if (Array.isArray(plugin.command)) {
            allCommands.push(...plugin.command);
        } else if (typeof plugin.command === 'string') {
            allCommands.push(plugin.command);
        }
    }

    if (allCommands.includes(usedCommand)) return false;

    // 4. Mesin Levenshtein Distance
    function getDistance(a, b) {
        if (a.length === 0) return b.length;
        if (b.length === 0) return a.length;
        let matrix = [];
        for (let i = 0; i <= b.length; i++) matrix[i] = [i];
        for (let j = 0; j <= a.length; j++) matrix[0][j] = j;
        
        for (let i = 1; i <= b.length; i++) {
            for (let j = 1; j <= a.length; j++) {
                if (b.charAt(i - 1) == a.charAt(j - 1)) {
                    matrix[i][j] = matrix[i - 1][j - 1];
                } else {
                    matrix[i][j] = Math.min(
                        matrix[i - 1][j - 1] + 1,
                        Math.min(matrix[i][j - 1] + 1, matrix[i - 1][j] + 1)
                    );
                }
            }
        }
        return matrix[b.length][a.length];
    }

    let closestCommand = "";
    let minDistance = Infinity;

    for (let cmd of allCommands) {
        if (typeof cmd !== 'string') continue; 
        
        let dist = getDistance(usedCommand, cmd.toLowerCase());
        if (dist < minDistance) {
            minDistance = dist;
            closestCommand = cmd;
        }
    }

    // 5. Eksekusi Jika Masuk Akal (Salah 1 atau 2 huruf)
    if (minDistance > 0 && minDistance <= 2) {
        
        let balasanFriendly = [
            `Oops, jarinya kepeleset ya Bosku? 🤭`,
            `Halo! Perintah itu tidak ditemukan di database. 🧐`,
            `Sepertinya ada salah ketik sedikit nih. 💭`,
            `Mesin tidak mengenali perintah tersebut. Tapi tenang, bot peka kok! ✨`
        ];

        let teksKomentar = balasanFriendly[Math.floor(Math.random() * balasanFriendly.length)];
        
        // 🧩 Merakit Perintah Benar + Menyelamatkan Query Asli
        let cmdBenarSingkat = `${usedPrefix[0]}${closestCommand}`;
        let fullPerintah = queryArg ? `${cmdBenarSingkat} ${queryArg}` : cmdBenarSingkat;

        // 🎨 Merakit UI Interaktif VIP
        let teksUI = `╭───「 *🤖 SMART DETECTOR* 」\n`;
        teksUI += `│\n`;
        teksUI += `│ ${teksKomentar}\n`;
        teksUI += `│\n`;
        teksUI += `│ ❌ *Ketik:* ${m.text}\n`; // Menampilkan persis seperti yang diketik user
        teksUI += `│ ✅ *Maksudnya:* ${fullPerintah}\n`; // Menampilkan versi yang sudah dibenarkan
        teksUI += `│\n`;
        teksUI += `╰───────────────⳹\n\n`;
        teksUI += `_Klik tombol di bawah ini untuk langsung mengeksekusi perintah tanpa mengetik ulang!_`;

        // 🏗️ Struktur Native Flow Message
        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: { text: teksUI },
                        footer: { text: `© ${global.botname || 'Assistant X Project'}` },
                        nativeFlowMessage: {
                            buttons: [{
                                name: "quick_reply",
                                buttonParamsJson: JSON.stringify({
                                    // Teks tombol kita buat singkat agar tidak error kena limit WhatsApp
                                    display_text: `🚀 GAS ${cmdBenarSingkat.toUpperCase()}`,
                                    // Tapi Payload/ID kita injeksi dengan perintah FULL + Query-nya
                                    id: fullPerintah 
                                })
                            }]
                        }
                    }
                }
            }
        }, { userJid: m.chat, quoted: m });

        await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        return true; 
    }

    return false;
}

module.exports = handler;
