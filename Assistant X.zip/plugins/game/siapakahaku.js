const axios = require('axios');

// ==========================================
// 🕵️‍♂️ VIP SIAPAKAH AKU (GITHUB RAW ENGINE)
// ==========================================

let handler = async (m, { sock, prefix, command }) => {
    sock.siapakahaku = sock.siapakahaku ? sock.siapakahaku : {};

    if (m.chat in sock.siapakahaku) {
        await m.react("⚠️").catch(() => {});
        return sock.sendMessage(m.chat, { text: "❌ *Masih ada tebakan yang belum terjawab di grup ini!*\nSelesaikan atau ketik *nyerah* terlebih dahulu." }, { quoted: m });
    }

    await m.react("⏳").catch(() => {});

    try {
        // 🚀 CORE: Sedot Database dari GitHub
        let { data } = await axios.get("https://raw.githubusercontent.com/BochilTeam/database/master/games/siapakahaku.json", { timeout: 15000 });
        
        let resData = data[Math.floor(Math.random() * data.length)];

        if (!resData || !resData.soal) throw new Error("Format Database Kosong.");

        let soal = resData.soal;
        let jawabanAsli = String(resData.jawaban);
        let jawabanBersih = jawabanAsli.toLowerCase().replace(/[^\w\s]/g, '').trim();

        let user = global.db.users[m.sender];
        if (user) user.limit -= 1;

        let hadiahXP = Math.floor(Math.random() * 250) + 100; 
        let hadiahUang = Math.floor(Math.random() * 6000) + 2000; 

        // 🧠 MESIN PEMBUAT CLUE/HINT
        let clueBantuan = jawabanAsli.replace(/[a-zA-Z]/g, (c, i) => i % 2 !== 0 ? '⬛' : c);

        let teksBuka = `╭───「 *🕵️‍♂️ SIAPAKAH AKU* 」\n`;
        teksBuka += `│ ❓ *Clue:* ${soal}\n`;
        teksBuka += `│ 🎁 *Hadiah:* +${hadiahXP} XP & Rp ${hadiahUang.toLocaleString('id-ID')}\n`;
        teksBuka += `│ 🎟️ *Biaya:* -1 Limit\n`;
        teksBuka += `╰──────────────\n\n`;
        teksBuka += `_Waktu: 60 Detik_\n_Ketik jawabanmu di bawah!_\n_Ketik *bantuan* untuk membuka huruf rahasia._ 💡\n_Ketik *nyerah* jika otak sudah buntu._ 🏳️`;

        sock.siapakahaku[m.chat] = {
            id: m.chat,
            soal: soal,
            jawaban: jawabanBersih, 
            jawabanAsli: jawabanAsli, 
            clue: clueBantuan,
            hadiahXP: hadiahXP,
            hadiahUang: hadiahUang,
            timeout: setTimeout(async () => {
                if (sock.siapakahaku[m.chat]) {
                    let room = sock.siapakahaku[m.chat];
                    let sisaJawaban = `⏳ *WAKTU HABIS!*\n\nIdentitas misterius tersebut adalah:\n*${room.jawabanAsli.toUpperCase()}* 🕵️‍♂️`;
                    
                    await sock.sendMessage(m.chat, { text: sisaJawaban });
                    delete sock.siapakahaku[m.chat];
                }
            }, 60000) 
        };

        await m.react("✅").catch(() => {});
        
        return sock.sendMessage(m.chat, {
            text: teksBuka,
            contextInfo: {
                forwardingScore: 999, isForwarded: true,
                forwardedNewsletterMessageInfo: { newsletterJid: global.idChannel || "1203631@newsletter", newsletterName: "🕵️‍♂️ Assistant X Mystery", serverId: 1 }
            }
        }, { quoted: m });

    } catch (error) {
        console.error("🔴 [ERROR SIAPAKAH AKU]", error.message);
        await m.react("❌").catch(() => {});
        return sock.sendMessage(m.chat, { text: `❌ *Gagal Terhubung!*\nServer Database sedang gangguan.` }, { quoted: m });
    }
}

handler.before = async (m, { sock }) => {
    sock.siapakahaku = sock.siapakahaku ? sock.siapakahaku : {};
    
    if (!m.chat || !(m.chat in sock.siapakahaku) || !m.text) return false;

    let room = sock.siapakahaku[m.chat];
    let text = m.text.toLowerCase().replace(/[^\w\s]/g, '').trim();

    if (text === "bantuan" || text === "hint" || text === "clue") {
        await m.react("💡").catch(() => {});
        let teksHint = `💡 *B A N T U A N   V I P* 💡\n\nIdentitas misterius ini memiliki pola nama:\n*${room.clue.toUpperCase()}*`;
        await sock.sendMessage(m.chat, { text: teksHint }, { quoted: m });
        return true;
    }

    if (text === "nyerah" || text === "menyerah") {
        await m.react("🏳️").catch(() => {});
        let ansTeks = `🏳️ *TEBAKAN DIBATALKAN*\n\nIdentitas misterius tersebut sebenarnya adalah:\n*${room.jawabanAsli.toUpperCase()}* 🕵️‍♂️`;
        await sock.sendMessage(m.chat, { text: ansTeks }, { quoted: m });
        clearTimeout(room.timeout);
        delete sock.siapakahaku[m.chat];
        return true;
    }

    if (text === room.jawaban) {
        let user = global.db.users[m.sender];
        if (user) {
            user.balance = (user.balance || 0) + room.hadiahUang;
            user.xp = (user.xp || 0) + room.hadiahXP;
        }

        await m.react("✅").catch(() => {});

        let uangRapi = typeof global.toRupiah === 'function' ? global.toRupiah(room.hadiahUang) : `Rp ${room.hadiahUang.toLocaleString('id-ID')}`;
        
        let teksUpdate = `🎉 *TEBAKAN AKURAT!* 🎉\n\n`;
        teksUpdate += `*@${m.sender.split("@")[0]}* berhasil membongkar identitas misterius!\n`;
        teksUpdate += `🎁 *Mendapatkan:* +${room.hadiahXP} XP & +${uangRapi}\n\n`;
        teksUpdate += `_Jawaban:_ *${room.jawabanAsli.toUpperCase()}* ✨`;

        await sock.sendMessage(m.chat, { 
            text: teksUpdate, 
            contextInfo: { 
                mentionedJid: [m.sender],
                forwardingScore: 999, isForwarded: true,
                forwardedNewsletterMessageInfo: { newsletterJid: global.idChannel || "1203631@newsletter", newsletterName: "🕵️‍♂️ Assistant X Mystery", serverId: 1 } 
            } 
        }, { quoted: m });
        
        clearTimeout(room.timeout);
        delete sock.siapakahaku[m.chat];
        return true; 
    }
    
    return false;
}

handler.command = ["siapakahaku"];
handler.tags = ["game"];
handler.help = ["siapakahaku"];
handler.limit = true;

module.exports = handler;
