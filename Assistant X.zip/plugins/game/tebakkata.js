let handler = async (m, { sock, prefix }) => {
    sock.tebakkata = sock.tebakkata ? sock.tebakkata : {}
    let id = m.chat

    if (id in sock.tebakkata) {
        return sock.sendMessage(m.chat, { text: "⚠️ Masih ada soal Tebak Kata yang belum terjawab di grup ini!" }, { quoted: m })
    }

    try {
        await m.react("⏳"); 
        let apikey = global.btc; 
        if (!apikey) return m.reply("❌ BOTCAHX_APIKEY belum diisi di file .env!");

        let apiUrl = global.botcahxUrl('/api/game/tebakkata'); 
        let res = await fetch(apiUrl);
        if (!res.ok) throw new Error("API Down atau Limit Habis");
        let json = await res.json();

        let soalDariApi = json.data ? json.data.soal : json.soal;
        let jawabanDariApi = json.data ? json.data.jawaban : json.jawaban;

        if (!soalDariApi || !jawabanDariApi) return m.reply("❌ Error dari API: Soal tidak ditemukan.");

        // 💰 KALKULASI HADIAH
        let rewardXP = Math.floor(Math.random() * 1451) + 50;
        let rewardMoney = Math.floor(Math.random() * 40000) + 10000;
        let uangRapi = typeof global.toRupiah === 'function' ? global.toRupiah(rewardMoney) : `Rp ${rewardMoney.toLocaleString('id-ID')}`;

        let teks = `╭───┈ *「 🎮 TEBAK KATA 」*\n`;
        teks += `│ 💬 *Soal:* Susun huruf berikut:\n`;
        teks += `│ 🧩 *${soalDariApi}*\n`;
        teks += `│ \n`;
        teks += `│ ⏳ *Waktu:* 60 Detik\n`;
        teks += `│ 🎁 *Hadiah:* ${rewardXP} XP & ${uangRapi}\n`;
        teks += `╰───────────────┈ ⳹\n\n`;
        teks += `_Ketik jawabanmu langsung di grup ini! (Ketik "nyerah" jika tidak sanggup)_`;

        sock.tebakkata[id] = [
            await sock.sendMessage(m.chat, { text: teks }, { quoted: m }),
            { soal: soalDariApi, jawaban: jawabanDariApi }, 
            setTimeout(() => {
                if (sock.tebakkata[id]) {
                    sock.sendMessage(m.chat, { text: `⏰ Waktu habis!\nJawaban yang benar adalah: *${jawabanDariApi}*` });
                    delete sock.tebakkata[id];
                }
            }, 60000), 
            rewardXP,
            rewardMoney
        ];
        
        await m.react("🎮"); 
    } catch (e) {
        return m.reply("❌ Waduh, gagal mengambil soal dari API.");
    }
}

handler.before = async (m, { sock }) => {
    sock.tebakkata = sock.tebakkata ? sock.tebakkata : {}
    let id = m.chat
    if (!m.text || m.isBaileys) return false

    if (id in sock.tebakkata) {
        if (/^nyerah$/i.test(m.text)) {
            clearTimeout(sock.tebakkata[id][2])
            delete sock.tebakkata[id]
            return sock.sendMessage(m.chat, { text: "🏳️ Ada yang mengibarkan bendera putih. Game dihentikan!" }, { quoted: m })
        }

        let dataApi = sock.tebakkata[id][1]
        if (m.text.toLowerCase().trim() === dataApi.jawaban.toLowerCase().trim()) {
            
            // 🔥 EKSEKUSI HADIAH KE DATABASE
            let user = global.db.users[m.sender]
            if (user) {
                user.xp = (user.xp || 0) + sock.tebakkata[id][3]
                user.balance = (user.balance || 0) + sock.tebakkata[id][4]
            }

            let uangRapi = typeof global.toRupiah === 'function' ? global.toRupiah(sock.tebakkata[id][4]) : `Rp ${sock.tebakkata[id][4].toLocaleString('id-ID')}`;

            let teksMenang = `🎉 *TEBAKAN BENAR!* 🎉\n\n`
            teksMenang += `Selamat @${m.sender.split('@')[0]}, instingmu tajam!\n`
            teksMenang += `🎁 *Hadiah:* +${sock.tebakkata[id][3]} XP & +${uangRapi}\n\n`
            teksMenang += `_Cek .profil kamu untuk melihat peningkatan Saldo & XP!_`
            
            await sock.sendMessage(m.chat, { text: teksMenang, mentions: [m.sender] }, { quoted: m })
            clearTimeout(sock.tebakkata[id][2])
            delete sock.tebakkata[id]
        }
    }
    return false 
}

handler.command = ["tebakkata"]
handler.tags = ["game"]
handler.help = ["tebakkata"]

module.exports = handler
