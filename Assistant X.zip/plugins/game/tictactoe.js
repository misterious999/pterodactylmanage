// ==========================================
// ⭕❌ GAME TIC-TAC-TOE (PvP TERINTEGRASI RPG)
// ⚙️ FIXED: FULL REWARD & PENALTY SYSTEM
// ==========================================

let handler = async (m, { sock, prefix, command }) => {
    sock.tictactoe = sock.tictactoe ? sock.tictactoe : {};
    let id = m.chat;

    // Game ini wajib dimainkan di grup agar bisa adu mekanik
    if (!m.isGroup) return m.reply("👥 Fitur duel Tic-Tac-Toe PvP hanya bisa dimainkan di dalam Grup!");

    let room = sock.tictactoe[id];

    // SKENARIO 1: Belum ada room, buat penawaran tantangan baru
    if (!room) {
        sock.tictactoe[id] = {
            state: 'WAITING',
            playerX: m.sender,
            playerO: null,
            // Papan catur pakai emoji angka biar keren
            board: ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣'],
            turn: 'X', // X jalan duluan (tapi pakai emoji ⭕ biar estetik)
            timeout: setTimeout(() => {
                if (sock.tictactoe[id] && sock.tictactoe[id].state === 'WAITING') {
                    sock.sendMessage(m.chat, { text: "⏳ Waktu habis! Sepertinya tidak ada lawan yang bernyali." });
                    delete sock.tictactoe[id];
                }
            }, 60000)
        };
        return sock.sendMessage(m.chat, { 
            text: `╭───┈ *「 ⭕ MENCARI LAWAN 」*\n│ 👤 *Penantang:* @${m.sender.split('@')[0]}\n│ ⏳ *Waktu:* 60 Detik\n╰───────────────┈ ⳹\n\n_Ketik *${prefix}${command}* untuk menerima tantangan dan bermain sebagai ❌!_`, 
            mentions: [m.sender] 
        }, { quoted: m });
    }

    // SKENARIO 2: Ada room waiting, member lain ikut join
    if (room.state === 'WAITING') {
        if (room.playerX === m.sender) return m.reply("⚠️ Kamu tidak bisa bermain melawan dirimu sendiri! Tunggu pemain lain.");
        
        clearTimeout(room.timeout); // Hapus timer waiting agar tidak hangus
        room.playerO = m.sender;
        room.state = 'PLAYING';

        let boardStr = `\n${room.board[0]}${room.board[1]}${room.board[2]}\n${room.board[3]}${room.board[4]}${room.board[5]}\n${room.board[6]}${room.board[7]}${room.board[8]}\n`;
        
        let teks = `╭───┈ *「 ⭕ TIC-TAC-TOE ❌ 」*\n`;
        teks += `│ ⭕ @${room.playerX.split('@')[0]} (Giliran Pertama)\n`;
        teks += `│ ❌ @${room.playerO.split('@')[0]}\n`;
        teks += `╰───────────────┈ ⳹\n`;
        teks += `\n*Papan Permainan:*${boardStr}\n`;
        teks += `_Ketik angka *1-9* pada kolom chat untuk meletakkan bidakmu!_`;

        return sock.sendMessage(m.chat, { text: teks, mentions: [room.playerX, room.playerO] });
    }

    // SKENARIO 3: Kalau ada yang nge-spam .ttt saat game sedang berjalan
    if (room.state === 'PLAYING') {
        return m.reply("⚠️ Sedang ada pertandingan seru di grup ini! Tunggu sampai selesai.");
    }
}

// ==========================================
// 📡 MESIN PENANGKAP LANGKAH CATUR (AUTO-CHECK)
// ==========================================
handler.before = async (m, { sock }) => {
    sock.tictactoe = sock.tictactoe ? sock.tictactoe : {};
    let id = m.chat;
    let room = sock.tictactoe[id];

    // Cek apakah game valid dan chat bukan dari bot
    if (!room || room.state !== 'PLAYING' || !m.text || m.isBaileys) return false;

    // Pastikan yang ngetik adalah SALAH SATU pemain yang lagi tanding
    let isPlayer = m.sender === room.playerX || m.sender === room.playerO;
    if (!isPlayer) return false;

    let input = m.text.trim();
    let validAngka = ['1', '2', '3', '4', '5', '6', '7', '8', '9'];

    // Fitur Menyerah
    if (/^nyerah$/i.test(input)) {
        let winner = m.sender === room.playerX ? room.playerO : room.playerX;
        delete sock.tictactoe[id];
        return sock.sendMessage(m.chat, { text: `🏳️ @${m.sender.split('@')[0]} Menyerah ketakutan!\n🎉 Pemenangnya adalah @${winner.split('@')[0]}`, mentions: [m.sender, winner] });
    }

    // Kalau chat biasa (bukan angka), abaikan saja
    if (!validAngka.includes(input)) return false;

    // Cek Giliran
    let isTurnX = room.turn === 'X';
    if (isTurnX && m.sender !== room.playerX) return m.reply("⏳ Sabar bro, ini masih giliran lawanmu (⭕)!");
    if (!isTurnX && m.sender !== room.playerO) return m.reply("⏳ Sabar bro, ini masih giliran lawanmu (❌)!");

    // Cek ketersediaan kotak
    let index = parseInt(input) - 1;
    if (room.board[index] === '⭕' || room.board[index] === '❌') {
        return m.reply("⚠️ Kotak itu sudah terisi! Pilih kotak (angka) yang masih kosong.");
    }

    // Update papan catur
    let bidak = isTurnX ? '⭕' : '❌';
    room.board[index] = bidak;

    // Algoritma Cek Menang (Garis lurus & menyilang)
    const checkWin = (board) => {
        const lines = [[0,1,2], [3,4,5], [6,7,8], [0,3,6], [1,4,7], [2,5,8], [0,4,8], [2,4,6]];
        for (let line of lines) {
            if (board[line[0]] === board[line[1]] && board[line[1]] === board[line[2]]) return board[line[0]]; 
        }
        return null;
    }

    let winnerBidak = checkWin(room.board);
    let isDraw = !room.board.some(v => v.length > 2); // ngecek apakah masih ada sisa emoji angka

    let boardStr = `\n${room.board[0]}${room.board[1]}${room.board[2]}\n${room.board[3]}${room.board[4]}${room.board[5]}\n${room.board[6]}${room.board[7]}${room.board[8]}\n`;

    // ==========================================
    // 🏆 SKENARIO: KALAU ADA YANG MENANG
    // ==========================================
    if (winnerBidak) {
        let winnerJid = winnerBidak === '⭕' ? room.playerX : room.playerO;
        let loserJid = winnerBidak === '⭕' ? room.playerO : room.playerX;
        
        // 💰 Hadiah Kemenangan RPG (PvP WINNER & LOSER)
        let rewardXP = Math.floor(Math.random() * 1451) + 50;
        let rewardMoney = Math.floor(Math.random() * 40000) + 10000;
        let loseMoney = Math.floor(Math.random() * 10001) + 5000;
        
        let userWinner = global.db.users[winnerJid];
        let userLoser = global.db.users[loserJid];

        if (userWinner) {
            userWinner.xp = (userWinner.xp || 0) + rewardXP;
            userWinner.balance = (userWinner.balance || 0) + rewardMoney;
        }
        if (userLoser) {
            userLoser.balance -= loseMoney;
            if (userLoser.balance < 0) userLoser.balance = 0; // Cegah minus
        }

        // Format Uang Rapi
        let uangMenang = typeof global.toRupiah === 'function' ? global.toRupiah(rewardMoney) : `Rp ${rewardMoney.toLocaleString('id-ID')}`;
        let uangKalah = typeof global.toRupiah === 'function' ? global.toRupiah(loseMoney) : `Rp ${loseMoney.toLocaleString('id-ID')}`;

        let teksMenang = `╭───┈ *「 🎉 TIC-TAC-TOE SELESAI 」*\n`;
        teksMenang += `│ 👑 *Pemenang:* @${winnerJid.split('@')[0]}\n`;
        teksMenang += `│ 🎁 *Mendapatkan:* +${rewardXP} XP & +${uangMenang}\n`;
        teksMenang += `│ \n`;
        teksMenang += `│ 💀 *Kalah:* @${loserJid.split('@')[0]}\n`;
        teksMenang += `│ 💸 *Denda:* -${uangKalah} Saldo\n`;
        teksMenang += `╰───────────────┈ ⳹\n`;
        teksMenang += `\n*Papan Akhir:*${boardStr}`;

        delete sock.tictactoe[id];
        return sock.sendMessage(m.chat, { text: teksMenang, mentions: [winnerJid, loserJid] });
    }

    // ==========================================
    // 🤝 SKENARIO: KALAU SERI
    // ==========================================
    if (isDraw) {
        let teksSeri = `╭───┈ *「 🤝 TIC-TAC-TOE DRAW 」*\n`;
        teksSeri += `│ Permainan Seri! Keduanya sama-sama kuat.\n`;
        teksSeri += `╰───────────────┈ ⳹\n`;
        teksSeri += `\n*Papan Akhir:*${boardStr}`;
        
        delete sock.tictactoe[id];
        return sock.sendMessage(m.chat, { text: teksSeri, mentions: [room.playerX, room.playerO] });
    }

    // ==========================================
    // 🔄 SKENARIO: GAME LANJUT, GANTI GILIRAN
    // ==========================================
    room.turn = isTurnX ? 'O' : 'X';
    let nextPlayer = room.turn === 'X' ? room.playerX : room.playerO;

    let teksLanjut = `╭───┈ *「 ⭕ TIC-TAC-TOE ❌ 」*\n`;
    teksLanjut += `│ 🟢 *Giliran:* @${nextPlayer.split('@')[0]} (${room.turn === 'X' ? '⭕' : '❌'})\n`;
    teksLanjut += `╰───────────────┈ ⳹\n`;
    teksLanjut += `\n*Papan Permainan:*${boardStr}\n`;
    teksLanjut += `_Ketik angka *1-9* pada area kotak yang masih kosong!_`;

    return sock.sendMessage(m.chat, { text: teksLanjut, mentions: [nextPlayer] });
}

handler.command = ["tictactoe"]
handler.tags = ["game"]
handler.help = ["tictactoe"]

module.exports = handler;
