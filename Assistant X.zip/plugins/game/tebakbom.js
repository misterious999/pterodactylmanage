// ==========================================
// 💣 GAME BOMB SQUAD (MULTIPLAYER)
// 🎮 REWARD ADJUSTED: Rp 1.000 - Rp 25.000
// ==========================================

global.bom = global.bom || {}; 

let handler = async (m, { sock, args, prefix, command }) => {
    let user = global.db.users[m.sender];
    if (!user) return m.reply("❌ Kamu belum terdaftar di database bot!");

    let chatId = m.chat;
    let action = args[0] ? args[0].toLowerCase() : '';

    if (!global.bom[chatId]) {
        if (action === '' || action === 'start') {
            let board = Array(9).fill('📦');
            let bombIndex = Math.floor(Math.random() * 9); 
            
            global.bom[chatId] = {
                board,
                bombIndex,
                opened: 0,
                timeout: setTimeout(() => {
                    if (global.bom[chatId]) {
                        sock.sendMessage(chatId, { text: "⏳ Waktu habis! Arena dibersihkan." });
                        delete global.bom[chatId];
                    }
                }, 120000) 
            };

            let teks = `╭───┈ *「 💣 BOMB SQUAD 」*\n`;
            teks += `│ ⚠️ Ada 1 Bom mematikan! Rebutan brankasnya!\n│\n`;
            teks += `│ *Cara main:* \`${prefix}${command} <1-9>\`\n`;
            teks += `╰───────────────┈ ⳹\n\n`;
            teks += renderBoard(global.bom[chatId].board);
            return sock.sendMessage(chatId, { text: teks }, { quoted: m });
        } else {
            return m.reply(`⚠️ Tidak ada game Bom yang aktif! Ketik \`${prefix}${command}\` untuk mulai.`);
        }
    }

    if (global.bom[chatId]) {
        let game = global.bom[chatId];

        if (action === 'nyerah' || action === 'stop') {
            clearTimeout(game.timeout);
            delete global.bom[chatId];
            return m.reply("🏳️ Game dihentikan.");
        }

        let choice = parseInt(action);
        if (isNaN(choice) || choice < 1 || choice > 9) {
            return m.reply(`⚠️ Pilih nomor kotak 1-9!`);
        }

        let idx = choice - 1;
        if (game.board[idx] !== '📦') return m.reply(`⚠️ Kotak itu sudah terbuka!`);

        // 💥 CASE: KENA BOM (DENDA TETAP ADA)
        if (idx === game.bombIndex) {
            clearTimeout(game.timeout);
            game.board[idx] = '💥';
            
            let denda = Math.floor(Math.random() * 5000) + 2000;
            user.balance -= denda;
            if (user.balance < 0) user.balance = 0;

            let teks = `╭───┈ *「 💥 DUAAAARRRR!!! 」*\n`;
            teks += `│ 💀 *@${m.sender.split('@')[0]}* meledak!\n`;
            teks += `│ 💸 Denda Kerusakan: -${global.toRupiah ? global.toRupiah(denda) : 'Rp ' + denda}\n`;
            teks += `╰───────────────┈ ⳹\n\n`;
            teks += renderBoard(game.board, game.bombIndex, true);
            
            delete global.bom[chatId];
            return sock.sendMessage(chatId, { text: teks, mentions: [m.sender] }, { quoted: m });
        } 
        
        // 💰 CASE: AMAN (HADIAH NAIK!)
        else {
            game.board[idx] = '💰';
            game.opened += 1;
            
            // Hadiah per kotak: Rp 1.000 - Rp 5.000
            let dapet = Math.floor(Math.random() * 4000) + 1000;
            user.balance += dapet;
            let dapetRapi = global.toRupiah ? global.toRupiah(dapet) : `Rp ${dapet}`;

            // 🎉 JIKA MENANG (JACKPOT 25K)
            if (game.opened === 8) {
                clearTimeout(game.timeout);
                let jackpot = 25000;
                user.balance += jackpot; 
                let jackpotRapi = global.toRupiah ? global.toRupiah(jackpot) : `Rp ${jackpot}`;

                let teks = `╭───┈ *「 🎉 MISSION PASSED 」*\n`;
                teks += `│ Brankas terakhir diamankan oleh *${m.pushName}*!\n`;
                teks += `│ 🎰 Bonus Jackpot: +${jackpotRapi}\n`;
                teks += `╰───────────────┈ ⳹\n\n`;
                teks += renderBoard(game.board, game.bombIndex, true);
                
                delete global.bom[chatId];
                return sock.sendMessage(chatId, { text: teks }, { quoted: m });
            } 
            
            // 🔄 LANJUT MAIN
            else {
                let teks = `╭───┈ *「 ✅ AMAN 」*\n`;
                teks += `│ *${m.pushName}* dapet: +${dapetRapi}\n`;
                teks += `│ ⚠️ Sisa Brankas Aman: ${8 - game.opened}\n`;
                teks += `╰───────────────┈ ⳹\n\n`;
                teks += renderBoard(game.board);
                
                return sock.sendMessage(chatId, { text: teks }, { quoted: m });
            }
        }
    }
}

function renderBoard(board, bombIndex = -1, showAll = false) {
    let emojis = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣'];
    let res = '';
    for (let i = 0; i < 9; i++) {
        if (showAll) {
            if (i === bombIndex && board[i] !== '💥') res += '💣';
            else res += board[i] !== '📦' ? board[i] : '📦';
        } else {
            res += board[i] === '📦' ? emojis[i] : board[i];
        }
        res += (i + 1) % 3 === 0 ? '\n' : ' ';
    }
    return res;
}

handler.command = ["bom"];
handler.tags = ["game"];
handler.help = ["bom"];

module.exports = handler;
