// ==========================================
// 🎮 GAME SUIT PvP (PLAYER VS PLAYER)
// ==========================================

// Membuat wadah memori untuk menyimpan sesi pertandingan
global.suit = global.suit || {};

let handler = async (m, { sock, args, prefix, command }) => {
    let user = global.db.users[m.sender];
    if (!user || !user.registered) return m.reply(`❌ Daftar dulu Bosku sebelum main judi suit!`);

    let isGroup = m.chat.endsWith('@g.us');
    let pilihan = args[0] ? args[0].toLowerCase() : '';
    let validPilihan = ['batu', 'gunting', 'kertas'];

    // 1. MENCARI SESI PERTANDINGAN USER INI
    let room = Object.values(global.suit).find(room => room.id === m.sender || room.lawan === m.sender);

    // ====================================================
    // ⚔️ FASE 3: USER MEMASUKKAN PILIHAN (WAJIB DI PC/DM)
    // ====================================================
    if (validPilihan.includes(pilihan)) {
        if (!room) return m.reply("❌ Kamu sedang tidak dalam sesi suit PvP!");
        if (room.status !== 'PLAYING') return m.reply("❌ Sesi suit belum dimulai atau masih menunggu persetujuan lawan!");
        
        // Anti-Nyontek: Tolak kalau dijawab di grup!
        if (isGroup) {
            await m.reply("🤫 *RAHASIA BOSKU!*\n\nJangan jawab di grup, nanti dicontek lawan! Kirim pilihanmu via Chat Pribadi (PC) ke bot!");
            // Opsional: Hapus pesan aslinya agar lawan tidak sempat lihat (jika bot punya akses admin)
            // sock.sendMessage(m.chat, { delete: m.key });
            return;
        }

        // Menyimpan pilihan masing-masing player
        if (room.id === m.sender) {
            if (room.pilihanA) return m.reply("❌ Kamu sudah memilih! Tunggu lawanmu.");
            room.pilihanA = pilihan;
        } else {
            if (room.pilihanB) return m.reply("❌ Kamu sudah memilih! Tunggu lawanmu.");
            room.pilihanB = pilihan;
        }

        m.reply(`✅ Pilihan tersimpan: *${pilihan.toUpperCase()}* 🥷\n\nTunggu lawanmu memilih, hasil akan diumumkan di Grup!`);

        // JIKA KEDUANYA SUDAH MEMILIH -> TENTUKAN PEMENANG!
        if (room.pilihanA && room.pilihanB) {
            let win = ''; 
            let pA = room.pilihanA;
            let pB = room.pilihanB;
            
            // Rumus Suit
            if (pA === pB) win = 'SERI';
            else if ((pA === 'batu' && pB === 'gunting') || (pA === 'gunting' && pB === 'kertas') || (pA === 'kertas' && pB === 'batu')) win = 'A';
            else win = 'B';

            let hadiah = room.taruhan;
            let userA = global.db.users[room.id];
            let userB = global.db.users[room.lawan];

            // Render Pengumuman di Grup
            let teks = `╭───┈ *「 🏆 HASIL SUIT PvP 」*\n`;
            teks += `│ 👤 *@${room.id.split('@')[0]}* memilih ${pA.toUpperCase()}\n`;
            teks += `│ 👤 *@${room.lawan.split('@')[0]}* memilih ${pB.toUpperCase()}\n`;
            teks += `│ \n`;

            if (win === 'SERI') {
                teks += `│ 🤝 *HASIL: SERI!*\n`;
                teks += `│ 💰 Taruhan ${hadiah} Saldo dikembalikan.\n`;
            } else if (win === 'A') {
                teks += `│ 🎉 *PEMENANG: @${room.id.split('@')[0]}*\n`;
                teks += `│ 💎 Mendapatkan +${hadiah} Saldo\n`;
                userA.balance += hadiah;
                userB.balance -= hadiah;
            } else {
                teks += `│ 🎉 *PEMENANG: @${room.lawan.split('@')[0]}*\n`;
                teks += `│ 💎 Mendapatkan +${hadiah} Saldo\n`;
                userA.balance -= hadiah;
                userB.balance += hadiah;
            }
            teks += `╰───────────────┈ ⳹`;

            // Kirim ke Grup & Hapus Sesi
            await sock.sendMessage(room.chatId, { text: teks, mentions: [room.id, room.lawan] });
            clearTimeout(room.waktu);
            delete global.suit[room.id];
        }
        return;
    }

    // ====================================================
    // ⚔️ FASE 2: TERIMA ATAU TOLAK TANTANGAN
    // ====================================================
    if (pilihan === 'terima') {
        if (!isGroup) return m.reply("❌ Perintah ini hanya bisa digunakan di grup!");
        if (!room) return m.reply("❌ Tidak ada tantangan suit untukmu!");
        if (room.lawan !== m.sender) return m.reply("❌ Woi! Ini bukan tantangan buat kamu!");
        if (room.status !== 'WAITING') return m.reply("❌ Tantangan ini sudah berjalan!");

        if (user.balance < room.taruhan) return m.reply(`❌ Saldomu tidak cukup untuk menerima tantangan ini! (Butuh: ${room.taruhan})`);

        // Ganti status jadi PLAYING
        room.status = 'PLAYING';
        clearTimeout(room.waktu);
        
        // Kasih waktu 60 detik untuk PC bot
        room.waktu = setTimeout(() => {
            if (global.suit[room.id]) {
                sock.sendMessage(room.chatId, { text: `⏳ Waktu suit habis! Sesi dibatalkan karena ada player yang kabur/AFK.`, mentions: [room.id, room.lawan] });
                delete global.suit[room.id];
            }
        }, 60000);

        let teksMulai = `✅ *TANTANGAN DITERIMA!*\n\nSilakan *@${room.id.split('@')[0]}* dan *@${room.lawan.split('@')[0]}* segera PC/Chat Pribadi ke bot ini dan ketik:\n\n👉 \`.suit batu\` / \`.suit gunting\` / \`.suit kertas\``;
        return sock.sendMessage(m.chat, { text: teksMulai, mentions: [room.id, room.lawan] }, { quoted: m });
    }

    if (pilihan === 'tolak') {
        if (!isGroup) return m.reply("❌ Perintah ini hanya bisa digunakan di grup!");
        if (!room) return m.reply("❌ Tidak ada tantangan suit untukmu!");
        if (room.lawan !== m.sender) return m.reply("❌ Woi! Ini bukan tantangan buat kamu!");
        
        sock.sendMessage(room.chatId, { text: `❌ *@${m.sender.split('@')[0]}* ketakutan dan menolak tantangan suit dari *@${room.id.split('@')[0]}*!`, mentions: [room.id, m.sender] });
        clearTimeout(room.waktu);
        delete global.suit[room.id];
        return;
    }

    // ====================================================
    // ⚔️ FASE 1: MEMBUAT TANTANGAN (CREATE ROOM)
    // ====================================================
    if (!isGroup) return m.reply("❌ Fitur tantang suit PvP hanya bisa digunakan di dalam Grup!");
    
    let lawan = m.mentionedJid[0] || (m.quoted ? m.quoted.sender : null);
    if (!lawan) return m.reply(`╭───┈ *「 🎮 CARA SUIT PvP 」*\n│\n│ ◦ *Tantang:* ${prefix}${command} @tag <taruhan>\n│ ◦ *Terima:* ${prefix}${command} terima\n│ ◦ *Tolak:* ${prefix}${command} tolak\n╰───────────────┈ ⳹`);
    
    if (lawan === m.sender) return m.reply("❌ Masa suit sama diri sendiri Bosku? Mending tidur gih.");
    let botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    if (lawan === botId) return m.reply("❌ Lawan player asli dong Bos! Jangan jadikan AI sebagai pelampiasan.");

    let taruhan = args[1] ? parseInt(args[1]) : 100;
    if (isNaN(taruhan) || taruhan < 10) return m.reply("❌ Minimal taruhan adalah 10 Saldo!");
    if (user.balance < taruhan) return m.reply(`❌ Saldo kamu tidak cukup Bosku! (Sisa: ${user.balance})`);

    let userB = global.db.users[lawan];
    if (!userB || !userB.registered) return m.reply("❌ Lawanmu belum terdaftar di database RPG!");
    if (userB.balance < taruhan) return m.reply(`❌ Saldo lawanmu tidak cukup untuk menutupi taruhan ini! Cari lawan sepadan.`);

    if (room) return m.reply("❌ Kamu atau target sedang dalam sesi suit yang belum selesai! Selesaikan dulu.");

    // Simpan Sesi
    global.suit[m.sender] = {
        id: m.sender,
        lawan: lawan,
        taruhan: taruhan,
        chatId: m.chat,
        status: 'WAITING',
        pilihanA: null,
        pilihanB: null,
        waktu: setTimeout(() => {
            if (global.suit[m.sender]) {
                sock.sendMessage(m.chat, { text: `⏳ Waktu habis! *@${lawan.split('@')[0]}* terlalu takut untuk merespons tantangan suit.`, mentions: [lawan] });
                delete global.suit[m.sender];
            }
        }, 60000) // Waktu tunggu 60 detik untuk jawab "terima/tolak"
    };

    let teksTantangan = `╭───┈ *「 ⚔️ TANTANGAN SUIT 」*\n`;
    teksTantangan += `│ 👤 *@${m.sender.split('@')[0]}* menantang *@${lawan.split('@')[0]}*\n`;
    teksTantangan += `│ 💰 *Taruhan:* ${taruhan} Saldo\n`;
    teksTantangan += `│ \n`;
    teksTantangan += `│ ⏱️ Target, ketik \`.suit terima\` atau \`.suit tolak\`\n`;
    teksTantangan += `│ Waktu: 60 detik!\n`;
    teksTantangan += `╰───────────────┈ ⳹`;

    return sock.sendMessage(m.chat, { text: teksTantangan, mentions: [m.sender, lawan] }, { quoted: m });
}

handler.command = ["suit"];
handler.tags = ["game"];
handler.help = ["suit @tag <taruhan>"];

module.exports = handler;
