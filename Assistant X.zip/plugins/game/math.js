// ==========================================
// 🧮 GAME KUIS MATEMATIKA (ALL-IN-ONE ENGINE)
// ⚙️ TINGKAT KESULITAN & HADIAH DINAMIS
// ==========================================

global.math = global.math || {};

// 🔥 PENGATURAN MODE & TINGKAT KESULITAN
const modes = {
    noob: { max: 10, ops: ['+', '-'], waktu: 60000, reward: 5000, xp: 200 },
    easy: { max: 20, ops: ['+', '-'], waktu: 60000, reward: 10000, xp: 400 },
    medium: { max: 50, ops: ['+', '-', '*'], waktu: 45000, reward: 25000, xp: 800 },
    hard: { max: 100, ops: ['+', '-', '*', '/'], waktu: 45000, reward: 50000, xp: 1500 },
    extreme: { max: 500, ops: ['+', '-', '*', '/'], waktu: 30000, reward: 80000, xp: 2500 },
    impossible: { max: 1000, ops: ['+', '-', '*', '/'], waktu: 30000, reward: 150000, xp: 5000 }
};

// ⚙️ MESIN PEMBUAT SOAL OTOMATIS
function genMath(mode) {
    let m = modes[mode];
    let op = m.ops[Math.floor(Math.random() * m.ops.length)];
    let a = Math.floor(Math.random() * m.max) + 1;
    let b = Math.floor(Math.random() * m.max) + 1;
    let ans = 0;
    let soal = '';

    if (op === '/') {
        ans = a; // Jawaban murni angka bulat
        let c = a * b; // Hasil perkalian dijadikan soal pembagian
        soal = `${c} ÷ ${b}`;
    } else if (op === '-') {
        // Biar nggak pusing ada minus, angka besar ditaruh depan
        if (a < b) { let temp = a; a = b; b = temp; }
        ans = a - b;
        soal = `${a} - ${b}`;
    } else if (op === '+') {
        ans = a + b;
        soal = `${a} + ${b}`;
    } else if (op === '*') {
        ans = a * b;
        soal = `${a} × ${b}`;
    }
    return { soal, jawaban: ans, waktu: m.waktu, reward: m.reward, xp: m.xp };
}

let handler = async (m, { sock, args, prefix, command }) => {
    let id = m.chat;

    if (global.math[id]) {
        return sock.sendMessage(m.chat, { text: "⚠️ Masih ada soal Matematika yang belum dijawab di grup ini!" }, { quoted: m });
    }

    let mode = args[0] ? args[0].toLowerCase() : '';
    if (!mode || !modes[mode]) {
        let teksMode = `╭───┈ *「 🧮 KUIS MATEMATIKA 」*\n`;
        teksMode += `│ Pilih tingkat kesulitan untuk bermain!\n│\n`;
        teksMode += `│ *Daftar Mode:*\n`;
        teksMode += `│ ◦ noob\n│ ◦ easy\n│ ◦ medium\n│ ◦ hard\n│ ◦ extreme\n│ ◦ impossible\n│\n`;
        teksMode += `│ *Cara main:* \`${prefix}${command} medium\`\n`;
        teksMode += `╰───────────────┈ ⳹`;
        return m.reply(teksMode);
    }

    await m.react("⏳");
    let mathData = genMath(mode);

    let uangRapi = typeof global.toRupiah === 'function' ? global.toRupiah(mathData.reward) : `Rp ${mathData.reward.toLocaleString('id-ID')}`;
    let waktuDetik = mathData.waktu / 1000;

    let teksSoal = `╭───┈ *「 🧮 KUIS MATEMATIKA 」*\n`;
    teksSoal += `│ 📊 *Mode:* ${mode.toUpperCase()}\n`;
    teksSoal += `│ ❓ *Berapa hasil dari:* ${mathData.soal}\n`;
    teksSoal += `│ \n`;
    teksSoal += `│ ⏳ *Waktu:* ${waktuDetik} Detik\n`;
    teksSoal += `│ 🎁 *Hadiah:* ${mathData.xp} XP & ${uangRapi}\n`;
    teksSoal += `╰───────────────┈ ⳹\n\n`;
    teksSoal += `_Ketik jawaban berupa angka langsung di grup ini! (Ketik "nyerah" jika otak mulai berasap)_`;

    // Simpan sesi ke memori bot
    global.math[id] = [
        await sock.sendMessage(m.chat, { text: teksSoal }, { quoted: m }),
        mathData, // Data Soal & Hadiah
        setTimeout(() => {
            if (global.math[id]) {
                sock.sendMessage(m.chat, { text: `⏰ Waktu habis!\nJawaban dari *${mathData.soal}* adalah: *${mathData.jawaban}*` });
                delete global.math[id];
            }
        }, mathData.waktu)
    ];

    await m.react("🎮");
}

// ==========================================
// 📡 MESIN PENANGKAP JAWABAN (AUTO-CHECK)
// ==========================================
handler.before = async (m, { sock }) => {
    global.math = global.math || {};
    let id = m.chat;

    if (!m.text || m.isBaileys) return false;

    if (id in global.math) {
        let inputTeks = m.text.toLowerCase().trim();
        let mathData = global.math[id][1];
        
        // Fitur Menyerah
        if (/^nyerah$/i.test(inputTeks)) {
            clearTimeout(global.math[id][2]);
            delete global.math[id];
            return sock.sendMessage(m.chat, { text: "🏳️ Ada yang otaknya kepanasan. Game Matematika dihentikan!" }, { quoted: m });
        }

        // Cek apakah input berupa angka
        if (/^-?\d+$/.test(inputTeks)) {
            let jawabanUser = parseInt(inputTeks);

            // 🎯 JIKA JAWABAN BENAR 100%
            if (jawabanUser === mathData.jawaban) {
                let user = global.db.users[m.sender];
                if (user) {
                    user.xp = (user.xp || 0) + mathData.xp;
                    user.balance = (user.balance || 0) + mathData.reward;
                }

                let uangRapi = typeof global.toRupiah === 'function' ? global.toRupiah(mathData.reward) : `Rp ${mathData.reward.toLocaleString('id-ID')}`;

                let teksMenang = `🎉 *JAWABAN BENAR!* 🎉\n\n`;
                teksMenang += `Kalkulator berjalan @${m.sender.split('@')[0]} berhasil menjawab!\n`;
                teksMenang += `🎁 *Hadiah:* +${mathData.xp} XP & +${uangRapi}\n\n`;
                teksMenang += `_Cek .profil kamu untuk melihat peningkatan Saldo & XP!_`;
                
                await sock.sendMessage(m.chat, { text: teksMenang, mentions: [m.sender] }, { quoted: m });
                
                clearTimeout(global.math[id][2]);
                delete global.math[id];
                return true;
            } 
            // ❌ JIKA JAWABAN SALAH (Beri reaction silang biar ga spam)
            else {
                await m.react("❌");
            }
        }
    }
    return false;
}

handler.command = ["math"];
handler.tags = ["game"];
handler.help = ["math <mode>"];

module.exports = handler;
