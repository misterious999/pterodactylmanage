// ==========================================
// 💡 FITUR BANTUAN (UNIVERSAL HINT MASTER)
// ⚙️ SUPPORT: TEBAK HEWAN, TEBAK GAMBAR, TEBAK KATA
// ==========================================

let handler = async (m, { sock, prefix, command }) => {
    let id = m.chat;
    let found = false;

    // ==========================================
    // 1️⃣ BANTUAN UNTUK TEBAK HEWAN
    // ==========================================
    if (global.tebakhewan && global.tebakhewan[id]) {
        let game = global.tebakhewan[id];
        if (game.hint) return m.reply("⚠️ Petunjuk Tebak Hewan sudah diberikan sebelumnya!");
        
        game.hint = true;
        found = true;
        return m.reply(`╭───┈ *「 💡 PETUNJUK HEWAN 」*\n│ 🐾 *Clue:* ${game.clue}\n╰───────────────┈ ⳹`);
    }

    // ==========================================
    // 2️⃣ BANTUAN UNTUK TEBAK GAMBAR
    // ==========================================
    if (sock.tebakgambar && sock.tebakgambar[id]) {
        let dataApi = sock.tebakgambar[id][1];
        let ans = dataApi.jawaban;
        
        // Clue Gambar: Tampilkan huruf PERTAMA dan TERAKHIR saja
        let clueTxt = ans.replace(/[a-zA-Z]/gi, (c, i) => (i === 0 || i === ans.length - 1) ? c : '_ ');
        
        found = true;
        return m.reply(`╭───┈ *「 💡 PETUNJUK GAMBAR 」*\n│ 🖼️ *Clue:* ${clueTxt.trim()}\n╰───────────────┈ ⳹`);
    }

    // ==========================================
    // 3️⃣ BANTUAN UNTUK TEBAK KATA
    // ==========================================
    if (sock.tebakkata && sock.tebakkata[id]) {
        let dataApi = sock.tebakkata[id][1];
        let ans = dataApi.jawaban;
        
        // Clue Kata: Tampilkan huruf PERTAMA saja
        let clueTxt = ans.replace(/[a-zA-Z]/gi, (c, i) => i === 0 ? c : '_ ');
        
        found = true;
        return m.reply(`╭───┈ *「 💡 PETUNJUK KATA 」*\n│ 🧩 *Clue:* ${clueTxt.trim()}\n╰───────────────┈ ⳹`);
    }

    // ==========================================
    // JIKA TIDAK ADA GAME SAMA SEKALI
    // ==========================================
    if (!found) {
        return m.reply("⚠️ Tidak ada game yang sedang berlangsung di grup ini yang membutuhkan petunjuk!");
    }
}

handler.command = ['hint', 'petunjuk'];
handler.tags = ['game'];
handler.help = ['hint'];
handler.limit = true; // 💸 Potong 1 limit biar member gak spam minta bocoran!

module.exports = handler;
