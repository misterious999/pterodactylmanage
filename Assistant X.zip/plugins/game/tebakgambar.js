// ==========================================
// 🎮 TEBAK GAMBAR PREMIUM (GITHUB RAW ENGINE)
// ⚙️ SESSION MANAGER, RPG INTEGRATION & ANTI-ERROR
// 🎟️ COST: -3 LIMIT
// ==========================================

const axios = require('axios');

global.tebakgambar = global.tebakgambar || {};

const similarity = (s1, s2) => {
    let longer = s1;
    let shorter = s2;
    if (s1.length < s2.length) { longer = s2; shorter = s1; }
    let longerLength = longer.length;
    if (longerLength == 0) return 1.0;
    let costs = new Array();
    for (let i = 0; i <= longer.length; i++) {
        let lastValue = i;
        for (let j = 0; j <= shorter.length; j++) {
            if (i == 0) costs[j] = j;
            else {
                if (j > 0) {
                    let newValue = costs[j - 1];
                    if (longer.charAt(i - 1) != shorter.charAt(j - 1))
                        newValue = Math.min(Math.min(newValue, lastValue), costs[j]) + 1;
                    costs[j - 1] = lastValue;
                    lastValue = newValue;
                }
            }
        }
        if (i > 0) costs[shorter.length] = lastValue;
    }
    return (longerLength - costs[shorter.length]) / parseFloat(longerLength);
}

let handler = async (m, { sock, prefix, command }) => {
    let chatId = m.chat;

    if (chatId in global.tebakgambar) {
        return m.reply("⚠️ Masih ada soal Tebak Gambar yang belum terjawab di grup ini!\n_Jawab dulu atau tunggu waktunya habis._");
    }

    let user = global.db.users[m.sender];
    if (user) {
        if (user.limit < 3 && !user.premium && !m.isOwner) {
            await sock.sendMessage(m.chat, { react: { text: '🚫', key: m.key } });
            return m.reply("❌ *Limit Tidak Cukup!*\nKamu butuh minimal *3 Limit* untuk memulai Tebak Gambar.");
        }
        user.limit -= 3;
    }

    await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
        // 🚀 CORE: Sedot Database Tebak Gambar dari GitHub (Super Stabil)
        let { data } = await axios.get("https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakgambar.json");
        
        let randomData = data[Math.floor(Math.random() * data.length)];
        let imageLink = randomData.img;
        let jawaban = randomData.jawaban.toLowerCase().trim();
        let deskripsi = randomData.deskripsi || "Coba perhatikan baik-baik susunan gambarnya!";

        if (!imageLink || !jawaban) throw new Error("Format Database Invalid");

        let rewardSaldo = Math.floor(Math.random() * 8000) + 3000; 
        let rewardXP = Math.floor(Math.random() * 600) + 200; 

        let captionText = `╭───┈ *「 🎮 TEBAK GAMBAR 」*\n`;
        captionText += `│ Silakan tebak gambar di atas!\n`;
        captionText += `│ 💡 *Clue:* ${deskripsi}\n`;
        captionText += `│ 🎟️ *Biaya:* -3 Limit\n`;
        captionText += `│ ⏱️ *Waktu:* 60 Detik\n`;
        captionText += `│ 💰 *Hadiah:* ${global.toRupiah ? global.toRupiah(rewardSaldo) : rewardSaldo} Saldo & ${rewardXP} XP\n`;
        captionText += `╰───────────────┈ ⳹\n\n`;
        captionText += `_Ketik jawabanmu langsung di grup ini!_`;

        let msg = await sock.sendMessage(m.chat, { 
            image: { url: imageLink }, 
            caption: captionText 
        }, { quoted: m });

        global.tebakgambar[chatId] = [
            msg, 
            jawaban, 
            rewardSaldo, 
            rewardXP,
            setTimeout(() => {
                if (global.tebakgambar[chatId]) {
                    sock.sendMessage(m.chat, { 
                        text: `⏳ *WAKTU HABIS!*\n\nJawabannya adalah: *${jawaban.toUpperCase()}*\n_Yah, 3 limit melayang sia-sia..._ 🤭` 
                    }, { quoted: global.tebakgambar[chatId][0] });
                    delete global.tebakgambar[chatId]; 
                }
            }, 60000)
        ];

        await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error(e);
        await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return m.reply("❌ *SISTEM LUMPUH!*\nGagal mengambil database dari server GitHub.");
    }
}

handler.before = async (m, { sock }) => {
    let chatId = m.chat;
    if (!m.text || m.key.fromMe || !global.tebakgambar[chatId]) return false;

    let session = global.tebakgambar[chatId];
    let jawabanAsli = session[1];
    let rewardSaldo = session[2];
    let rewardXP = session[3];
    
    let tebakanMember = m.text.toLowerCase().replace(/[^\w\s]/gi, '').replace(/\s+/g, ' ').trim();

    if (tebakanMember === jawabanAsli) {
        await sock.sendMessage(m.chat, { react: { text: '🎉', key: m.key } });
        
        let userRpg = global.db.users[m.sender];
        if (userRpg) {
            userRpg.balance = (userRpg.balance || 0) + rewardSaldo;
            userRpg.xp = (userRpg.xp || 0) + rewardXP;
        }

        let congratsText = `🎉 *BENAR SEKALI!*\n\n`;
        congratsText += `👤 *Penebak:* @${m.sender.split('@')[0]}\n`;
        congratsText += `🎁 *Hadiah:* ${global.toRupiah ? global.toRupiah(rewardSaldo) : rewardSaldo} Saldo & ${rewardXP} XP\n\n`;
        congratsText += `_Saldo & XP telah masuk ke akunmu!_`;

        await sock.sendMessage(m.chat, { text: congratsText, mentions: [m.sender] }, { quoted: m });

        clearTimeout(session[4]);
        delete global.tebakgambar[chatId];
        return true;
    } 
    else if (similarity(tebakanMember, jawabanAsli) >= 0.70) {
        await sock.sendMessage(m.chat, { react: { text: '🤏', key: m.key } });
        await m.reply("🤏 *Sedikit lagi!* Jawabanmu hampir benar, ayo coba lagi.");
        return true;
    } else {
        await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }

    return false; 
}

handler.tags = ['game'];
handler.command = ['tebakgambar'];
handler.group = true; 

module.exports = handler;
