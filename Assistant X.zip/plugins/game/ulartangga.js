const axios = require('axios');

// ==========================================
// 🎲 VIP GAME: ULAR TANGGA (MULTIPLAYER)
// ⚙️ SMART DETECTOR BYPASS FIX
// ==========================================

const ladders = { 4: 14, 9: 31, 20: 38, 28: 84, 40: 59, 51: 67, 63: 81, 71: 91 };
const snakes = { 17: 7, 54: 34, 62: 19, 64: 60, 87: 24, 93: 73, 95: 75, 99: 78 };

let handler = async (m, { sock, args, prefix, command }) => {
    if (!global.db.ulartangga) global.db.ulartangga = {};
    
    let chat = m.chat;
    let sender = m.sender;
    let ut = global.db.ulartangga[chat];

    // 🚀 FIX: Logika lempar dadu dipindah ke command utama agar diakui oleh Smart Detector
    if (command === 'kocok') {
        if (!ut || ut.state !== 'PLAYING') return m.reply(`❌ Tidak ada permainan yang sedang berlangsung! Bikin room dulu ketik \`${prefix}ut create\`.`);

        let currentPlayer = ut.players[ut.turnIndex];
        
        if (sender !== currentPlayer) {
            return m.reply(`❌ Sabar Bosku! Belum giliran Anda. Sekarang giliran @${currentPlayer.split('@')[0]}`, { mentions: [currentPlayer] });
        }

        let dadu = Math.floor(Math.random() * 6) + 1;
        let oldPos = ut.positions[sender];
        let newPos = oldPos + dadu;
        
        let msg = `🎲 Anda mengocok dadu dan mendapat angka *${dadu}*!\nPosisi: ${oldPos} ➡️ ${newPos}\n`;

        if (newPos > 100) {
            let sisa = newPos - 100;
            newPos = 100 - sisa;
            msg += `Mundur karena kelebihan langkah! Posisi akhir: ${newPos}\n`;
        } else if (newPos === 100) {
            msg += `\n🎉 *SELAMAT! @${sender.split('@')[0]} MEMENANGKAN PERMAINAN!* 🎉`;
            ut.positions[sender] = newPos;
            await sock.sendMessage(m.chat, { text: msg, mentions: [sender] }, { quoted: m });
            await renderBoard(sock, m, ut);
            delete global.db.ulartangga[chat];
            return;
        }

        if (ladders[newPos]) {
            msg += `🧗‍♂️ *MANTAP!* Anda naik tangga ke posisi ${ladders[newPos]}\n`;
            newPos = ladders[newPos];
        } else if (snakes[newPos]) {
            msg += `🐍 *YAH!* Anda digigit ular dan turun ke posisi ${snakes[newPos]}\n`;
            newPos = snakes[newPos];
        }

        ut.positions[sender] = newPos;
        
        ut.turnIndex = (ut.turnIndex + 1) % ut.players.length;
        let nextPlayer = ut.players[ut.turnIndex];
        
        msg += `\nGiliran selanjutnya: @${nextPlayer.split('@')[0]} (Ketik .kocok)`;
        await sock.sendMessage(m.chat, { text: msg, mentions: [nextPlayer] }, { quoted: m });
        
        return await renderBoard(sock, m, ut);
    }

    let action = args[0] ? args[0].toLowerCase() : '';

    if (action === 'create' || action === 'buat') {
        if (ut) return m.reply("❌ Masih ada permainan yang berlangsung di grup ini! Ketik `.ut stop` untuk membubarkan.");
        
        global.db.ulartangga[chat] = {
            state: 'WAITING',
            players: [sender],
            positions: { [sender]: 1 },
            turnIndex: 0
        };
        return m.reply(`🎮 *ROOM ULAR TANGGA DIBUAT!*\n\nSilakan ketik \`${prefix}ut join\` untuk bergabung (Maksimal 4 pemain).\nJika sudah siap, Host bisa mengetik \`${prefix}ut start\`.`);
    }

    if (action === 'join' || action === 'ikut') {
        if (!ut) return m.reply(`❌ Belum ada room yang dibuat! Bikin dulu pakai \`${prefix}ut create\``);
        if (ut.state === 'PLAYING') return m.reply("❌ Permainan sudah dimulai, Anda telat bergabung!");
        if (ut.players.includes(sender)) return m.reply("❌ Anda sudah ada di dalam room!");
        if (ut.players.length >= 4) return m.reply("❌ Room penuh! Maksimal hanya 4 pemain.");
        
        ut.players.push(sender);
        ut.positions[sender] = 1; 
        return m.reply(`✅ *Berhasil Bergabung!*\nTotal pemain saat ini: ${ut.players.length}/4\n\nKetik \`${prefix}ut start\` untuk memulai permainan!`);
    }

    if (action === 'start' || action === 'mulai') {
        if (!ut) return m.reply("❌ Belum ada room yang aktif!");
        if (ut.state === 'PLAYING') return m.reply("❌ Permainan sudah berjalan!");
        if (ut.players.length < 2) return m.reply("❌ Minimal dibutuhkan 2 pemain untuk memulai.");
        
        ut.state = 'PLAYING';
        ut.turnIndex = 0;
        
        await m.reply(`🎲 *PERMAINAN DIMULAI!*\n\nGiliran pertama adalah @${ut.players[0].split('@')[0]}!\nSilakan ketik \`.kocok\` untuk melempar dadu!`, { mentions: [ut.players[0]] });
        return await renderBoard(sock, m, ut);
    }

    if (action === 'stop' || action === 'henti') {
        if (!ut) return m.reply("❌ Tidak ada permainan yang berjalan.");
        delete global.db.ulartangga[chat];
        return m.reply("🛑 *Permainan Ular Tangga dibubarkan secara paksa.*");
    }

    return m.reply(`╭───┈ *「 🎲 VIP ULAR TANGGA 」*\n│\n│ *Perintah Game:*\n│ ▹ \`${prefix}ut create\` : Buat room\n│ ▹ \`${prefix}ut join\` : Ikut bermain\n│ ▹ \`${prefix}ut start\` : Mulai permainan\n│ ▹ \`${prefix}ut stop\` : Bubarkan game\n│\n│ *Cara Bermain:*\n│ Saat permainan sudah dimulai,\n│ pemain yang mendapat giliran cukup\n│ mengetik \`.kocok\` untuk melempar dadu.\n╰───────────────┈ ⳹`);
}

// 🎨 FUNGSI RENDER PAPAN
async function renderBoard(sock, m, ut) {
    await m.react("⏳").catch(() => {});
    let apiKey = global.btc;
    if (!apiKey) return m.reply("❌ BOTCAHX_APIKEY belum diisi di file .env.");
    let apiUrl = global.botcahxUrl('/api/maker/ulartangga');
    
    let pps = [];
    let positions = [];

    for (let player of ut.players) {
        let pp;
        try {
            pp = await sock.profilePictureUrl(player, 'image');
        } catch (e) {
            pp = global.botcahxUrl('/api/maker/ppgc-default');
        }
        pps.push(pp);
        positions.push(ut.positions[player]);
    }

    for (let pp of pps) apiUrl += `&pp=${encodeURIComponent(pp)}`;
    for (let pos of positions) apiUrl += `&positions=${pos}`;

    try {
        let response = await axios.get(apiUrl, { responseType: 'arraybuffer', timeout: 30000 });
        
        let cap = "📊 *PAPAN ULAR TANGGA*\n\n";
        ut.players.forEach((p, i) => {
            cap += `Player ${i+1}: @${p.split('@')[0]} (Pos: ${ut.positions[p]})\n`;
        });

        await sock.sendMessage(m.chat, { image: response.data, caption: cap, mentions: ut.players });
        await m.react("✅").catch(() => {});
    } catch (e) {
        console.error("🔴 [BOARD RENDER ERROR]", e.message);
        await m.reply("⚠️ Papan sedang digambar, namun permainan tetap berjalan. Silakan ketik `.kocok` untuk melanjutkan.");
    }
}

handler.help = ["ulartangga"];
// 🎯 INI KUNCINYA: Tambahkan "kocok" ke dalam array command agar diakui resmi!
handler.command = ["ulartangga", "ut", "kocok"];
handler.tags = ["game"];

module.exports = handler;
