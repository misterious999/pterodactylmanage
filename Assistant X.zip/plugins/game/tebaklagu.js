const axios = require('axios');

// ==========================================
// 🎧 VIP TEBAK LAGU (GITHUB RAW ENGINE)
// ⚙️ 100% FREE, ANTI-HANG, & ANTI-TYPO
// ==========================================

// 🧠 FITUR NORMALISASI & TYPO DETECTOR
const normalize = (text) => text.toLowerCase().replace(/[^a-z0-9]/g, '').trim();

const isTypo = (input, target) => {
    const distance = (a, b) => {
        let matrix = Array.from({ length: a.length + 1 }, (_, i) => [i]);
        for (let j = 0; j <= b.length; j++) matrix[0][j] = j;
        for (let i = 1; i <= a.length; i++) {
            for (let j = 1; j <= b.length; j++) {
                matrix[i][j] = a[i - 1] === b[j - 1] ? matrix[i - 1][j - 1] : Math.min(matrix[i - 1][j - 1] + 1, matrix[i][j - 1] + 1, matrix[i - 1][j] + 1);
            }
        }
        return matrix[a.length][b.length];
    };
    let dist = distance(input, target);
    return dist <= (target.length > 5 ? 2 : 1); // Toleransi 1 huruf untuk kata pendek, 2 huruf untuk kata panjang
};

let handler = async (m, { sock, prefix, command }) => {
    sock.tebaklagu = sock.tebaklagu ? sock.tebaklagu : {};

    // 1. Cek apakah ada game yang masih berjalan
    if (m.chat in sock.tebaklagu) {
        await m.react("⚠️").catch(() => {});
        return m.reply("❌ *Sabar Bosku!*\nMasih ada game Tebak Lagu yang belum diselesaikan di obrolan ini.");
    }

    // 2. Potong Limit Diawal
    let user = global.db.users[m.sender];
    if (user) {
        if (user.limit < 3 && !user.premium && !m.isOwner) {
            return m.reply("❌ *Limit Tidak Cukup!*\nKamu butuh minimal *3 Limit* untuk memulai game ini.");
        }
        user.limit -= 3;
    }

    await m.react("⏳").catch(() => {});

    try {
        // 🚀 CORE: Sedot Database Tebak Lagu dari GitHub (Super Stabil)
        let { data } = await axios.get("https://raw.githubusercontent.com/BochilTeam/database/master/games/tebaklagu.json", { timeout: 15000 });
        
        let randomData = data[Math.floor(Math.random() * data.length)];

        // Smart Parser
        let jawabanAsli = randomData.judul || randomData.jawaban || randomData.title;
        let audioUrl = randomData.url || randomData.link_song || randomData.audio;
        let artis = randomData.artis || randomData.artist || "";

        if (!jawabanAsli || !audioUrl) throw new Error("Data lagu dari GitHub rusak atau kosong.");

        // 🎨 RAKIT UI ARCADE VVIP
        let teksBuka = `╭───「 *🎧 TEBAK LAGU* 」\n`;
        if (artis) teksBuka += `│ 🎤 *Penyanyi:* ${artis}\n`;
        teksBuka += `│ ❓ *Tebak apa judul lagu ini?*\n`;
        teksBuka += `│ 🎟️ *Biaya:* -3 Limit\n`; 
        teksBuka += `╰──────────────\n\n`;
        teksBuka += `⏳ Waktu: *120 Detik*\n`;
        teksBuka += `_Ketik jawabanmu sekarang!_\n_Ketik *nyerah* untuk menyerah._ 🏳️`;

        // Simpan Data Game ke Memori Server
        sock.tebaklagu[m.chat] = {
            id: m.chat,
            jawaban: jawabanAsli,
            poin: Math.floor(Math.random() * 8000) + 3000, 
            xp: Math.floor(Math.random() * 600) + 200,      
            timeout: setTimeout(async () => {
                if (sock.tebaklagu[m.chat]) {
                    let room = sock.tebaklagu[m.chat];
                    let sisaJawaban = `⏳ *WAKTU HABIS!*\n\nJudul lagunya adalah: *${room.jawaban.toUpperCase()}* ✅\n_Yah, 3 limit melayang sia-sia..._ 🤭`;
                    
                    await sock.sendMessage(m.chat, { text: sisaJawaban });
                    delete sock.tebaklagu[m.chat];
                }
            }, 120000) 
        };

        await m.react("🎵").catch(() => {});
        
        // Kirim Voice Note / Audio
        let vnMsg = await sock.sendMessage(m.chat, {
            audio: { url: audioUrl },
            mimetype: 'audio/mpeg',
            ptt: true 
        }, { quoted: m });

        return sock.sendMessage(m.chat, {
            text: teksBuka,
            contextInfo: {
                forwardingScore: 999, isForwarded: true,
                forwardedNewsletterMessageInfo: { 
                    newsletterJid: global.idChannel || "1203631@newsletter", 
                    newsletterName: "🎧 Music Arcade Scanner", 
                    serverId: 1 
                }
            }
        }, { quoted: vnMsg });

    } catch (error) {
        console.error("🔴 [ERROR TEBAK LAGU]", error.message);
        await m.react("❌").catch(() => {});
        
        // Kembalikan limit jika gagal
        let userRpg = global.db.users[m.sender];
        if (userRpg) userRpg.limit += 3;

        return m.reply(`❌ *SISTEM MENGALAMI GANGGUAN!*\n\nGagal mengambil audio dari GitHub Database.`);
    }
}

// ==========================================
// 📡 RADAR JAWABAN (GAMEPLAY LOOP)
// ==========================================
handler.before = async (m, { sock }) => {
    sock.tebaklagu = sock.tebaklagu ? sock.tebaklagu : {};
    
    if (!m.chat || !(m.chat in sock.tebaklagu) || !m.text) return false;

    let room = sock.tebaklagu[m.chat];
    
    // 🔥 PENGGUNAAN NORMALIZER ANTI-TYPO
    let inputUser = normalize(m.text);
    let jawabanBersih = normalize(room.jawaban);
    
    let textRaw = m.text.toLowerCase().trim();

    if (textRaw === "nyerah" || textRaw === "menyerah") {
        await m.react("🏳️").catch(() => {});
        let ansTeks = `🏳️ *MENYERAH!*\n\nJudul lagu yang dimaksud adalah: *${room.jawaban.toUpperCase()}* ✅`;
        await sock.sendMessage(m.chat, { text: ansTeks }, { quoted: m });
        clearTimeout(room.timeout);
        delete sock.tebaklagu[m.chat];
        return true;
    }

    // 🎯 JIKA BENAR 100%
    if (inputUser === jawabanBersih) {
        let user = global.db.users[m.sender];
        if (user) {
            user.balance = (user.balance || 0) + room.poin;
            user.xp = (user.xp || 0) + room.xp;
        }

        await m.react("🎉").catch(() => {});

        let uangRapi = typeof global.toRupiah === 'function' ? global.toRupiah(room.poin) : `Rp ${room.poin.toLocaleString('id-ID')}`;
        
        let teksUpdate = `🎉 *BINGO! TEBAKAN TEPAT* 🎉\n\n`;
        teksUpdate += `Lagu: *${room.jawaban.toUpperCase()}* ✅\n`;
        teksUpdate += `Maestro: *@${m.sender.split("@")[0]}*\n`;
        teksUpdate += `Reward: *+${room.xp} XP* & *+${uangRapi}*\n\n`;
        teksUpdate += `_Gila! Pengorbanan 3 limitmu terbayar tuntas!_ 🎧`;

        await sock.sendMessage(m.chat, { 
            text: teksUpdate, 
            contextInfo: { 
                mentionedJid: [m.sender],
                forwardingScore: 999, isForwarded: true,
                forwardedNewsletterMessageInfo: { 
                    newsletterJid: global.idChannel || "1203631@newsletter", 
                    newsletterName: "🎧 Music Arcade Scanner", 
                    serverId: 1 
                } 
            } 
        }, { quoted: m });
        
        clearTimeout(room.timeout);
        delete sock.tebaklagu[m.chat];
        return true; 
    }
    // 🤏 JIKA TYPO (Dikit Lagi)
    else if (isTypo(inputUser, jawabanBersih)) {
        await m.react("🤏").catch(() => {});
        await m.reply("🤏 *Dikit lagi!* Judul lagunya masih ada yang salah eja.");
        return true;
    }
    
    return false;
}

handler.command = ["tebaklagu"];
handler.tags = ["game"];
handler.help = ["tebaklagu"];
handler.limit = true; 

module.exports = handler;
