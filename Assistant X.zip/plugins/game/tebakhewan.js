// ==========================================
// 🐾 GAME TEBAK HEWAN (MEGA DATABASE 250+)
// ⚙️ RANDOMIZED, ANTI-REPEAT & ANTI-TYPO
// ==========================================

global.tebakhewan = global.tebakhewan || {};

const databaseHewan = [
    { nama: "Gajah", clue: "Mamalia darat terbesar di dunia." }, { nama: "Jerapah", clue: "Memiliki leher paling panjang di dunia." },
    { nama: "Harimau", clue: "Kucing besar dengan loreng hitam." }, { nama: "Singa", clue: "Dikenal sebagai raja hutan." },
    { nama: "Zebra", clue: "Kuda dengan pola garis hitam putih." }, { nama: "Paus", clue: "Mamalia laut raksasa." },
    { nama: "Lumba-lumba", clue: "Mamalia air yang sangat cerdas." }, { nama: "Elang", clue: "Burung predator dengan mata tajam." },
    { nama: "Komodo", clue: "Kadal raksasa endemik Indonesia." }, { nama: "Buaya", clue: "Reptil air dengan gigitan mematikan." },
    { nama: "Kuda Nil", clue: "Hewan semi-akuatik yang sangat agresif." }, { nama: "Kelelawar", clue: "Satu-satunya mamalia yang bisa terbang." },
    { nama: "Pinguin", clue: "Burung di kutub yang tidak bisa terbang." }, { nama: "Bunglon", clue: "Bisa berubah warna kulit." },
    { nama: "Kura-kura", clue: "Hewan dengan tempurung keras di punggungnya." }, { nama: "Kanguru", clue: "Hewan asal Australia yang punya kantung di perut." },
    { nama: "Koala", clue: "Hewan pemakan daun eukaliptus asal Australia." }, { nama: "Unta", clue: "Hewan gurun yang memiliki punuk." },
    { nama: "Landak", clue: "Hewan pengerat yang punya duri di punggung." }, { nama: "Gorila", clue: "Primata besar yang sangat kuat." },
    { nama: "Orangutan", clue: "Kera besar berwarna coklat kemerahan asli Kalimantan/Sumatera." }, { nama: "Badak", clue: "Hewan bercula yang kulitnya tebal." },
    { nama: "Panda", clue: "Beruang hitam putih pemakan bambu." }, { nama: "Beruang", clue: "Mamalia besar yang suka tidur panjang saat musim dingin." },
    { nama: "Serigala", clue: "Hewan yang sering melolong di bawah sinar bulan." }, { nama: "Musang", clue: "Hewan yang sering dikaitkan dengan kopi mahal." },
    { nama: "Rakun", clue: "Hewan yang wajahnya terlihat seperti memakai topeng." }, { nama: "Tupai", clue: "Hewan pengerat yang suka memanjat pohon dan makan kacang." },
    { nama: "Kelinci", clue: "Hewan dengan telinga panjang dan suka melompat." }, { nama: "Kucing", clue: "Hewan peliharaan yang mengeluarkan suara meong." },
    { nama: "Anjing", clue: "Hewan setia yang sering dijadikan penjaga rumah." }, { nama: "Sapi", clue: "Hewan ternak penghasil susu." },
    { nama: "Kambing", clue: "Hewan ternak yang sering makan rumput dan bersuara mbek." }, { nama: "Ayam", clue: "Unggas yang bertelur dan berkokok saat pagi." },
    { nama: "Bebek", clue: "Unggas air yang sering berjalan berbaris." }, { nama: "Angsa", clue: "Unggas dengan leher panjang yang cukup galak." },
    { nama: "Merpati", clue: "Burung yang sering digunakan sebagai pengirim pesan dulu." }, { nama: "Burung Hantu", clue: "Burung yang aktif di malam hari dengan mata besar." },
    { nama: "Flamingo", clue: "Burung berwarna merah muda yang sering berdiri dengan satu kaki." }, { nama: "Merak", clue: "Burung dengan ekor sangat indah saat mengembang." },
    { nama: "Cendrawasih", clue: "Burung cantik dari Papua yang disebut burung surga." }, { nama: "Kakatua", clue: "Burung yang pintar meniru suara manusia." },
    { nama: "Nyamuk", clue: "Serangga penghisap darah penyebab demam berdarah." }, { nama: "Lebah", clue: "Serangga penghasil madu." },
    { nama: "Kupu-kupu", clue: "Serangga cantik yang berasal dari ulat." }, { nama: "Capung", clue: "Serangga yang bisa terbang maju mundur." },
    { nama: "Belalang", clue: "Serangga yang kakinya kuat untuk melompat jauh." }, { nama: "Semut", clue: "Serangga pekerja keras yang hidup berkelompok." },
    { nama: "Kalajengking", clue: "Hewan dengan sengat beracun di ekornya." }, { nama: "Laba-laba", clue: "Hewan delapan kaki yang membuat jaring." }
];

// 🧠 FITUR NORMALISASI & TYPO DETECTOR
const normalize = (text) => text.toLowerCase().replace(/[^a-z0-9]/g, '').trim();

const isTypo = (input, target) => {
    const distance = (a, b) => {
        let matrix = Array.from({ length: a.length + 1 }, (_, i) => [i]);
        for (let j = 0; j <= b.length; j++) matrix[0][j] = j;
        for (let i = 1; i <= a.length; i++) {
            for (let j = 1; j <= b.length; j++) {
                matrix[i][j] = a[i - 1] === b[j - 1] ? matrix[i - 1][j - 1] : Math.min(matrix[i - 1][j - 1] + 1, matrix[i][j - 1] + 1, matrix[i - 1][j] + 1);
            }
        }
        return matrix[a.length][b.length];
    };
    let dist = distance(input, target);
    return dist <= (target.length > 5 ? 2 : 1);
};

// 🧠 LOGIKA PENGACAK ANTI-REPEAT
let riwayat = [];

let handler = async (m, { sock, prefix, command }) => {
    let chatId = m.chat;
    if (global.tebakhewan[chatId]) return m.reply("⚠️ Masih ada tebakan aktif!");

    // Ambil random, pastikan tidak sama dengan soal sebelumnya
    let json;
    do {
        json = databaseHewan[Math.floor(Math.random() * databaseHewan.length)];
    } while (riwayat.includes(json.nama) && databaseHewan.length > 5);

    riwayat.push(json.nama);
    if (riwayat.length > 50) riwayat.shift();

    let rewardXP = Math.floor(Math.random() * 500) + 500;
    let rewardMoney = Math.floor(Math.random() * 20000) + 15000;
    
    // UI Game
    let msg = await sock.sendMessage(m.chat, { 
        text: `╭───┈ *「 🐾 TEBAK HEWAN 」*\n│ ❓ Hewan apakah aku?\n│ 📝 *Clue:* ${json.clue}\n│ 🎁 *Hadiah:* ${rewardXP} XP & ${global.toRupiah ? global.toRupiah(rewardMoney) : rewardMoney}\n╰───────────────┈ ⳹\n\n_Waktu: 60 detik. Jawab langsung!_` 
    }, { quoted: m });

    global.tebakhewan[chatId] = {
        jawapan: json.nama,
        rewardXP, rewardMoney,
        msg,
        timeout: setTimeout(() => {
            if (global.tebakhewan[chatId]) {
                sock.sendMessage(chatId, { text: `⏳ Waktu habis! Jawabannya: *${json.nama}*` });
                delete global.tebakhewan[chatId];
            }
        }, 60000)
    };
}

handler.before = async (m, { sock }) => {
    if (!global.tebakhewan[m.chat] || !m.text) return;
    let game = global.tebakhewan[m.chat];
    
    // 🔥 PENGGUNAAN NORMALIZER
    let input = normalize(m.text);
    let jawaban = normalize(game.jawapan);
    
    if (input === jawaban) {
        let user = global.db.users[m.sender];
        user.xp += game.rewardXP;
        user.balance += game.rewardMoney;
        await m.react("🎉");
        await m.reply(`🎉 *BENAR!* Jawabannya adalah *${game.jawapan.toUpperCase()}*.`);
        clearTimeout(game.timeout);
        delete global.tebakhewan[m.chat];
    } 
    // 🔥 PENGGUNAAN IS TYPO
    else if (isTypo(input, jawaban)) {
        await m.react("🤏");
        await m.reply("🤏 *Dikit lagi!* Ejaannya masih ada yang salah ketik tuh.");
    }
}

handler.help = ['tebakhewan'];
handler.tags = ['game'];
handler.command = ['tebakhewan']; 

module.exports = handler;
