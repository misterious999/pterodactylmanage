const axios = require('axios');

// ==========================================
// 🎯 VIP FAMILY 100 (GITHUB RAW ENGINE) - ANTI DOWN
// ==========================================

let handler = async (m, { sock, prefix, command }) => {
    sock.family100 = sock.family100 ? sock.family100 : {};

    // 1. Cek apakah ada game yang masih berjalan
    if (m.chat in sock.family100) {
        await m.react("⚠️").catch(() => {});
        return sock.sendMessage(m.chat, { text: "❌ *Sabar Bosku!*\nMasih ada sesi Family 100 yang belum diselesaikan di obrolan ini." }, { quoted: m });
    }

    await m.react("⏳").catch(() => {});

    try {
        // 🚀 CORE: Tinggalkan BOTCAHX, Pindah ke Database Terbuka (Super Stabil)
        let apiUrl = `https://raw.githubusercontent.com/BochilTeam/database/master/games/family100.json`;
        
        let { data } = await axios.get(apiUrl, { timeout: 15000 });
        
        if (!data || data.length === 0) throw new Error("Gagal mengambil database Family 100.");

        // Ambil 1 soal secara acak dari ribuan database
        let resData = data[Math.floor(Math.random() * data.length)];

        let soal = resData.soal || resData.question;
        let rawJawaban = resData.jawaban || resData.answers || resData.answer;

        // 🔥 Pemotong Array Ganda (Tetap dipertahankan untuk keamanan)
        let jawaban = [];
        if (typeof rawJawaban === 'string') {
            jawaban = rawJawaban.split(/,|\n/);
        } else if (Array.isArray(rawJawaban)) {
            jawaban = rawJawaban;
        }

        // Bersihkan spasi berlebih, ubah ke huruf kecil, dan buang data kosong
        jawaban = jawaban.map(v => String(v).toLowerCase().trim()).filter(v => v.length > 0);

        // Potong Limit Player
        let user = global.db.users[m.sender];
        if (user) user.limit -= 1;

        // 🎨 RAKIT UI VIP DASHBOARD
        let teksBuka = `╭───「 *🎯 FAMILY 100* 」\n`;
        teksBuka += `│ ❓ *Soal:* ${soal}\n`;
        teksBuka += `│ 📝 *Total Jawaban:* ${jawaban.length}\n`;
        teksBuka += `│ 🎟️ *Biaya:* -1 Limit\n`;
        teksBuka += `╰──────────────\n\n`;
        
        // Papan Sensor (Kotak-kotak hitam)
        for (let i = 0; i < jawaban.length; i++) {
            let sensor = jawaban[i].replace(/[a-zA-Z0-9]/g, '⬛');
            teksBuka += `${i + 1}. ${sensor}\n`;
        }

        teksBuka += `\n_Ketik jawabanmu di obrolan ini!_\n_Ketik *nyerah* jika otak sudah ngebul._ 🏳️`;

        // Simpan Data Game ke Memori Server
        sock.family100[m.chat] = {
            id: m.chat,
            soal: soal,
            jawaban: jawaban,
            terjawab: [],
            timeout: setTimeout(async () => {
                if (sock.family100[m.chat]) {
                    let room = sock.family100[m.chat];
                    let sisaJawaban = `⏳ *WAKTU HABIS!*\n\nBerikut kunci jawabannya:\n\n`;
                    room.jawaban.forEach((ans, i) => {
                        sisaJawaban += room.terjawab.includes(ans) ? `${i + 1}. ✅ ${ans.toUpperCase()}\n` : `${i + 1}. ❌ ${ans.toUpperCase()}\n`;
                    });
                    
                    await sock.sendMessage(m.chat, { text: sisaJawaban });
                    delete sock.family100[m.chat];
                }
            }, 120000) // 2 Menit Timeout
        };

        await m.react("✅").catch(() => {});
        
        // Kirim Pesan dengan Label VIP
        return sock.sendMessage(m.chat, {
            text: teksBuka,
            contextInfo: {
                forwardingScore: 999, isForwarded: true,
                forwardedNewsletterMessageInfo: { newsletterJid: global.idChannel || "1203631@newsletter", newsletterName: "🎮 Assistant X Arcade", serverId: 1 }
            }
        }, { quoted: m });

    } catch (error) {
        console.error("🔴 [ERROR FAMILY 100]", error.message);
        await m.react("❌").catch(() => {});
        return sock.sendMessage(m.chat, { text: `❌ *Gagal Terhubung!*\nGagal mengambil database Family 100. Coba beberapa saat lagi.` }, { quoted: m });
    }
}

// ==========================================
// 📡 RADAR JAWABAN (GAMEPLAY LOOP)
// ==========================================
handler.before = async (m, { sock }) => {
    sock.family100 = sock.family100 ? sock.family100 : {};
    
    // Abaikan jika tidak ada game di grup ini atau pesan tidak ada teksnya
    if (!m.chat || !(m.chat in sock.family100) || !m.text) return false;

    let room = sock.family100[m.chat];
    
    // 🔥 FILTER DEWA: Huruf kecil otomatis + Hapus simbol/emoji + Hapus spasi ganda
    let text = m.text.toLowerCase().replace(/[^\w\s]/gi, '').replace(/\s+/g, ' ').trim();

    // 🏳️ LOGIKA MENYERAH
    if (text === "nyerah" || text === "menyerah") {
        await m.react("🏳️").catch(() => {});
        
        let ansTeks = `🏳️ *PERMAINAN DIBATALKAN*\n\nBerikut adalah kunci jawabannya:\n\n`;
        room.jawaban.forEach((ans, i) => {
            ansTeks += room.terjawab.includes(ans) ? `${i + 1}. ✅ ${ans.toUpperCase()}\n` : `${i + 1}. ❌ ${ans.toUpperCase()}\n`;
        });

        await sock.sendMessage(m.chat, { text: ansTeks }, { quoted: m });
        clearTimeout(room.timeout);
        delete sock.family100[m.chat];
        return true;
    }

    // 🎯 LOGIKA MENEBAK JAWABAN BENAR
    let jawabanBersih = room.jawaban.map(ans => String(ans).toLowerCase().replace(/[^\w\s]/gi, '').replace(/\s+/g, ' ').trim());
    let indexJawaban = jawabanBersih.indexOf(text);

    if (indexJawaban !== -1) {
        let jawabanAsli = room.jawaban[indexJawaban];

        if (room.terjawab.includes(jawabanAsli)) {
            await m.react("⚠️").catch(() => {});
            await m.reply("⚠️ Jawaban ini sudah terbuka!");
            return true;
        }

        room.terjawab.push(jawabanAsli);
        
        // 💰 REWARD SYSTEM
        let rewardXP = Math.floor(Math.random() * 251) + 50; 
        let rewardMoney = Math.floor(Math.random() * 8001) + 2000; 
        
        let user = global.db.users[m.sender];
        if (user) {
            user.balance = (user.balance || 0) + rewardMoney;
            user.xp = (user.xp || 0) + rewardXP;
        }

        await m.react("✅").catch(() => {});

        let isWin = room.terjawab.length === room.jawaban.length;
        let uangRapi = typeof global.toRupiah === 'function' ? global.toRupiah(rewardMoney) : `Rp ${rewardMoney.toLocaleString('id-ID')}`;
        
        // 🎨 UPDATE PAPAN PERMAINAN
        let teksUpdate = `╭───「 *🎯 FAMILY 100* 」\n`;
        teksUpdate += `│ ❓ *Soal:* ${room.soal}\n`;
        teksUpdate += `╰──────────────\n\n`;
        
        room.jawaban.forEach((ans, i) => {
            if (room.terjawab.includes(ans)) {
                teksUpdate += `${i + 1}. ✅ ${String(ans).toUpperCase()}\n`;
            } else {
                teksUpdate += `${i + 1}. ${String(ans).replace(/[a-zA-Z0-9]/g, '⬛')}\n`;
            }
        });

        teksUpdate += `\n🎁 *@${m.sender.split("@")[0]}* menebak benar!\n_(+${rewardXP} XP & +${uangRapi})_\n`;

        if (isWin) {
            teksUpdate += `\n🎉 *PERFECT CLEARED!* Semua jawaban berhasil ditebak!`;
            clearTimeout(room.timeout);
            delete sock.family100[m.chat];
        } else {
            teksUpdate += `\n_Ayo tebak sisa kotak hitam di atas!_`;
        }

        await sock.sendMessage(m.chat, { 
            text: teksUpdate, 
            contextInfo: { 
                mentionedJid: [m.sender],
                forwardingScore: 999, isForwarded: true,
                forwardedNewsletterMessageInfo: { newsletterJid: global.idChannel || "1203631@newsletter", newsletterName: "🎮 Assistant X Arcade", serverId: 1 } 
            } 
        }, { quoted: m });
        
        return true; 
    }
    
    // ❌ LOGIKA MENEBAK SALAH
    await m.react("❌").catch(() => {});
    return false;
}

handler.command = ["family100"];
handler.tags = ["game"];
handler.help = ["family100"];
handler.limit = true; 

module.exports = handler;
