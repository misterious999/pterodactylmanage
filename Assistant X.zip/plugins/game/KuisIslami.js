// ==========================================
// 🕌 VIP KUIS ISLAMI (100 MEGA DATABASE OFFLINE)
// ⚙️ ZERO PING & TOLERANSI JAWABAN TINGKAT DEWA
// ==========================================

const kuisDatabase = [
    { soal: "Malaikat yang bertugas menyampaikan wahyu adalah?", jawaban: "Jibril" },
    { soal: "Malaikat yang bertugas membagikan rezeki dan menurunkan hujan adalah?", jawaban: "Mikail" },
    { soal: "Malaikat peniup sangkakala pada hari kiamat adalah?", jawaban: "Israfil" },
    { soal: "Malaikat pencabut nyawa adalah?", jawaban: "Izrail" },
    { soal: "Malaikat penjaga pintu surga adalah?", jawaban: "Ridwan" },
    { soal: "Malaikat penjaga pintu neraka adalah?", jawaban: "Malik" },
    { soal: "Malaikat pencatat amal baik manusia adalah?", jawaban: "Raqib" },
    { soal: "Malaikat pencatat amal buruk manusia adalah?", jawaban: "Atid" },
    { soal: "Nabi dan manusia pertama yang diciptakan Allah adalah?", jawaban: "Adam" },
    { soal: "Nabi yang diperintahkan membuat kapal besar untuk selamat dari banjir bandang adalah Nabi?", jawaban: "Nuh" },
    { soal: "Nabi yang dibakar oleh Raja Namrud namun tidak hangus adalah Nabi?", jawaban: "Ibrahim" },
    { soal: "Nabi yang disembelih namun diganti dengan domba oleh Allah adalah Nabi?", jawaban: "Ismail" },
    { soal: "Nabi yang ditelan oleh ikan paus karena meninggalkan kaumnya adalah Nabi?", jawaban: "Yunus" },
    { soal: "Nabi yang sangat rupawan dan pernah dipenjara di Mesir adalah Nabi?", jawaban: "Yusuf" },
    { soal: "Nabi yang memiliki mukjizat dapat membelah Laut Merah adalah Nabi?", jawaban: "Musa" },
    { soal: "Nabi yang bisa berbicara dengan binatang dan menguasai jin adalah Nabi?", jawaban: "Sulaiman" },
    { soal: "Nabi yang diberi mukjizat menyembuhkan orang buta dan lepra adalah Nabi?", jawaban: "Isa" },
    { soal: "Nabi penutup para nabi dan rasul adalah Nabi?", jawaban: "Muhammad" },
    { soal: "Kitab suci yang diturunkan kepada Nabi Daud adalah?", jawaban: "Zabur" },
    { soal: "Kitab suci yang diturunkan kepada Nabi Musa adalah?", jawaban: "Taurat" },
    { soal: "Kitab suci yang diturunkan kepada Nabi Isa adalah?", jawaban: "Injil" },
    { soal: "Kitab suci penyempurna seluruh kitab sebelumnya adalah?", jawaban: "Al Quran" },
    { soal: "Paman Nabi Muhammad yang menentang dakwah dan namanya diabadikan di Al-Quran adalah?", jawaban: "Abu Lahab" },
    { soal: "Paman Nabi Muhammad yang sangat melindungi dan merawat beliau sejak kecil adalah?", jawaban: "Abu Thalib" },
    { soal: "Istri pertama Nabi Muhammad SAW adalah?", jawaban: "Khadijah" },
    { soal: "Istri Nabi Muhammad yang merupakan putri dari Abu Bakar adalah?", jawaban: "Aisyah" },
    { soal: "Putri bungsu Nabi Muhammad yang menikah dengan Ali bin Abi Thalib adalah?", jawaban: "Fatimah" },
    { soal: "Kakek Nabi Muhammad SAW yang merawat beliau setelah ibunya wafat adalah?", jawaban: "Abdul Muthalib" },
    { soal: "Ibu kandung Nabi Muhammad SAW bernama?", jawaban: "Aminah" },
    { soal: "Ayah kandung Nabi Muhammad SAW bernama?", jawaban: "Abdullah" },
    { soal: "Sahabat Nabi yang membenarkan peristiwa Isra Miraj pertama kali adalah?", jawaban: "Abu Bakar" },
    { soal: "Sahabat Nabi yang sangat tegas dan bergelar Al-Faruq adalah?", jawaban: "Umar bin Khattab" },
    { soal: "Sahabat Nabi yang kaya raya, dermawan, dan menjadi khalifah ke-3 adalah?", jawaban: "Utsman bin Affan" },
    { soal: "Sahabat Nabi yang menjadi menantu dan khalifah ke-4 adalah?", jawaban: "Ali bin Abi Thalib" },
    { soal: "Panglima perang Islam yang bergelar Pedang Allah yang Terhunus adalah?", jawaban: "Khalid bin Walid" },
    { soal: "Muazin pertama dalam sejarah Islam yang memiliki suara merdu adalah?", jawaban: "Bilal bin Rabah" },
    { soal: "Perang pertama antara umat Islam dan kaum Quraisy Makkah adalah perang?", jawaban: "Badar" },
    { soal: "Perang di mana umat Islam mengalami kekalahan karena pasukan pemanah melanggar perintah adalah perang?", jawaban: "Uhud" },
    { soal: "Perang di mana umat Islam menggali parit untuk pertahanan kota Madinah adalah perang?", jawaban: "Khandaq" },
    { soal: "Masjid pertama yang dibangun oleh Nabi Muhammad SAW adalah Masjid?", jawaban: "Quba" },
    { soal: "Kiblat pertama umat Islam sebelum dipindahkan ke Ka'bah adalah?", jawaban: "Masjidil Aqsa" },
    { soal: "Kiblat umat Islam seluruh dunia saat ini berada di bangunan yang bernama?", jawaban: "Kabah" },
    { soal: "Surah pertama atau surah pembuka dalam Al-Qur'an adalah surah?", jawaban: "Al Fatihah" },
    { soal: "Surah terpanjang di dalam Al-Qur'an adalah surah?", jawaban: "Al Baqarah" },
    { soal: "Surah Al-Baqarah memiliki arti?", jawaban: "Sapi Betina" },
    { soal: "Satu-satunya surah dalam Al-Qur'an yang tidak diawali dengan lafaz Basmalah adalah surah?", jawaban: "At Taubah" },
    { soal: "Surah Al-Falaq memiliki arti?", jawaban: "Waktu Subuh" },
    { soal: "Surah yang menceritakan tentang pasukan bergajah yang ingin menghancurkan Ka'bah adalah surah?", jawaban: "Al Fiil" },
    { soal: "Surah yang sering disebut sebagai jantungnya Al-Qur'an adalah surah?", jawaban: "Yasin" },
    { soal: "Rukun Islam yang pertama adalah membaca?", jawaban: "Syahadat" },
    { soal: "Rukun Islam yang kedua adalah mendirikan?", jawaban: "Shalat" },
    { soal: "Rukun Islam yang ketiga adalah menunaikan?", jawaban: "Zakat" },
    { soal: "Rukun Islam yang keempat adalah melaksanakan?", jawaban: "Puasa" },
    { soal: "Rukun Islam yang kelima (bagi yang mampu) adalah melaksanakan ibadah?", jawaban: "Haji" },
    { soal: "Rukun Iman yang pertama adalah beriman kepada?", jawaban: "Allah" },
    { soal: "Shalat wajib lima waktu yang jumlah rakaatnya paling sedikit adalah shalat?", jawaban: "Subuh" },
    { soal: "Shalat wajib yang dikerjakan saat matahari mulai terbenam adalah shalat?", jawaban: "Maghrib" },
    { soal: "Shalat sunnah yang hanya ada pada malam hari di bulan Ramadhan disebut shalat?", jawaban: "Tarawih" },
    { soal: "Puasa sunnah mingguan biasanya dilaksanakan pada hari Senin dan?", jawaban: "Kamis" },
    { soal: "Puasa sunnah yang dilaksanakan pada tanggal 9 Dzulhijjah disebut puasa?", jawaban: "Arafah" },
    { soal: "Ibadah berlari-lari kecil antara bukit Shafa dan Marwah saat Haji/Umrah disebut?", jawaban: "Sai" },
    { soal: "Ibadah mengelilingi Ka'bah sebanyak 7 kali putaran disebut?", jawaban: "Thawaf" },
    { soal: "Zakat yang wajib dikeluarkan setiap muslim menjelang Idul Fitri untuk menyucikan jiwa adalah zakat?", jawaban: "Fitrah" },
    { soal: "Zakat yang dikeluarkan atas harta kekayaan yang telah mencapai nishab disebut zakat?", jawaban: "Mal" },
    { soal: "Hukum bacaan Al-Qur'an yang berarti mendengung disebut?", jawaban: "Ghunnah" },
    { soal: "Hukum bacaan Al-Qur'an yang berarti memantul disebut?", jawaban: "Qalqalah" },
    { soal: "Jumlah nama-nama Allah yang indah dan baik (Asmaul Husna) ada sebanyak?", jawaban: "99" },
    { soal: "Asmaul Husna (Ar-Rahman) memiliki arti Maha?", jawaban: "Pengasih" },
    { soal: "Asmaul Husna (Ar-Rahim) memiliki arti Maha?", jawaban: "Penyayang" },
    { soal: "Asmaul Husna (Al-Alim) memiliki arti Maha?", jawaban: "Mengetahui" },
    { soal: "Asmaul Husna (Al-Quddus) memiliki arti Maha?", jawaban: "Suci" },
    { soal: "Hewan yang membuat jaring dan menyelamatkan Nabi saat bersembunyi di Gua Tsur adalah?", jawaban: "Laba laba" },
    { soal: "Burung yang diutus Allah membawa batu panas untuk menghancurkan pasukan Abrahah adalah burung?", jawaban: "Ababil" },
    { soal: "Hewan tunggangan yang membawa Nabi Muhammad saat Isra Miraj bernama?", jawaban: "Buraq" },
    { soal: "Tempat Nabi Muhammad SAW menerima wahyu pertama kali bernama Gua?", jawaban: "Hira" },
    { soal: "Peristiwa turunnya Al-Qur'an pertama kali disebut dengan?", jawaban: "Nuzulul Quran" },
    { soal: "Malam kemuliaan di bulan Ramadhan yang lebih baik dari 1000 bulan disebut malam?", jawaban: "Lailatul Qadar" },
    { soal: "Hari raya umat Islam yang dirayakan setelah berpuasa di bulan Ramadhan adalah Idul?", jawaban: "Fitri" },
    { soal: "Hari raya umat Islam yang dirayakan pada bulan Dzulhijjah bersamaan ibadah Haji adalah Idul?", jawaban: "Adha" },
    { soal: "Shalat sunnah yang dilakukan umat Islam untuk meminta turunnya hujan disebut shalat?", jawaban: "Istisqa" },
    { soal: "Shalat sunnah yang dilakukan untuk memohon petunjuk atas suatu pilihan disebut shalat?", jawaban: "Istikharah" },
    { soal: "Nama bulan pertama dalam kalender Hijriyah adalah bulan?", jawaban: "Muharram" },
    { soal: "Bulan dalam kalender Hijriyah di mana Nabi Muhammad SAW dilahirkan adalah bulan?", jawaban: "Rabiul Awal" },
    { soal: "Sebutan bagi penduduk muslim Madinah yang menerima dan menolong kaum pendatang adalah kaum?", jawaban: "Anshar" },
    { soal: "Sebutan bagi kaum muslimin yang ikut hijrah dari Makkah ke Madinah adalah kaum?", jawaban: "Muhajirin" },
    { soal: "Raja di negeri Habasyah yang berbuat adil dan melindungi kaum muslimin saat hijrah pertama adalah Raja?", jawaban: "Najasyi" },
    { soal: "Paman Nabi yang gugur di perang Uhud dan mendapat gelar Singa Allah adalah?", jawaban: "Hamzah" },
    { soal: "Perempuan pertama dalam sejarah Islam yang mati syahid karena disiksa Abu Jahal adalah?", jawaban: "Sumayyah" },
    { soal: "Perjanjian damai yang disepakati antara kaum muslimin Madinah dan musyrikin Makkah disebut Perjanjian?", jawaban: "Hudaibiyah" },
    { soal: "Nabi yang diberi gelar Kalimullah (yang berbicara langsung dengan Allah) adalah Nabi?", jawaban: "Musa" },
    { soal: "Nabi yang diberi gelar Khalilullah (kesayangan Allah) adalah Nabi?", jawaban: "Ibrahim" },
    { soal: "Nabi yang diberi gelar Ruhullah adalah Nabi?", jawaban: "Isa" },
    { soal: "Kisah pemuda beriman yang tertidur selama 300 tahun di dalam gua disebut kisah Ashabul?", jawaban: "Kahfi" },
    { soal: "Raja zalim yang mengaku Tuhan pada masa Nabi Ibrahim bernama Raja?", jawaban: "Namrud" },
    { soal: "Raja zalim yang menindas Bani Israil pada masa Nabi Musa bernama?", jawaban: "Firaun" },
    { soal: "Orang yang mengumandangkan panggilan shalat disebut?", jawaban: "Muazin" },
    { soal: "Seseorang yang memimpin pelaksanaan shalat berjamaah disebut?", jawaban: "Imam" },
    { soal: "Seseorang yang mengikuti gerakan shalat di belakang pemimpin shalat disebut?", jawaban: "Makmum" },
    { soal: "Di kota manakah letak bangunan Ka'bah berada?", jawaban: "Makkah" },
    { soal: "Satu-satunya agama yang diridhai oleh Allah SWT adalah agama?", jawaban: "Islam" }
];

let handler = async (m, { sock, prefix, command }) => {
    sock.kuisislami = sock.kuisislami ? sock.kuisislami : {};

    if (m.chat in sock.kuisislami) {
        await m.react("⚠️").catch(() => {});
        return sock.sendMessage(m.chat, { text: "❌ *Masih ada kuis yang belum terjawab di grup ini!*\nSelesaikan atau ketik *nyerah* terlebih dahulu." }, { quoted: m });
    }

    await m.react("⏳").catch(() => {});

    // 🚀 CORE: Sedot Acak dari Database 100 Soal Offline (0 Detik Delay)
    let resData = kuisDatabase[Math.floor(Math.random() * kuisDatabase.length)];
    let soal = resData.soal;
    let jawabanAsli = String(resData.jawaban);
    
    // 🔥 FILTER TINGKAT DEWA: Hapus SEMUA spasi, titik, koma, dan simbol khusus (hanya murni huruf & angka)
    let jawabanBersih = jawabanAsli.toLowerCase().replace(/[^a-z0-9]/g, '');

    let user = global.db.users[m.sender];
    if (user) user.limit -= 1;

    let hadiahXP = Math.floor(Math.random() * 200) + 50; 
    let hadiahUang = Math.floor(Math.random() * 5000) + 1000; 

    let teksBuka = `╭───「 *🕌 KUIS ISLAMI VIP* 」\n`;
    teksBuka += `│ ❓ *Soal:* ${soal}\n`;
    teksBuka += `│ 🎁 *Hadiah:* +${hadiahXP} XP & Rp ${hadiahUang.toLocaleString('id-ID')}\n`;
    teksBuka += `│ 🎟️ *Biaya:* -1 Limit\n`;
    teksBuka += `╰──────────────\n\n`;
    teksBuka += `_Waktu: 60 Detik_\n_Ketik jawabanmu di bawah, atau ketik *nyerah* jika tidak tahu._ 🏳️`;

    sock.kuisislami[m.chat] = {
        id: m.chat,
        soal: soal,
        jawaban: jawabanBersih, // Untuk pencocokan sistem super ketat
        jawabanAsli: jawabanAsli, // Untuk ditampilkan di pengumuman (tetap rapi ada spasinya)
        hadiahXP: hadiahXP,
        hadiahUang: hadiahUang,
        timeout: setTimeout(async () => {
            if (sock.kuisislami[m.chat]) {
                let room = sock.kuisislami[m.chat];
                let sisaJawaban = `⏳ *WAKTU HABIS!*\n\nJawaban yang benar adalah:\n*${room.jawabanAsli.toUpperCase()}*`;
                
                await sock.sendMessage(m.chat, { text: sisaJawaban });
                delete sock.kuisislami[m.chat];
            }
        }, 60000)
    };

    await m.react("✅").catch(() => {});
    
    return sock.sendMessage(m.chat, {
        text: teksBuka,
        contextInfo: {
            forwardingScore: 999, isForwarded: true,
            forwardedNewsletterMessageInfo: { newsletterJid: global.idChannel || "1203631@newsletter", newsletterName: "🕌 Assistant X Religi", serverId: 1 }
        }
    }, { quoted: m });
}

handler.before = async (m, { sock }) => {
    sock.kuisislami = sock.kuisislami ? sock.kuisislami : {};
    
    if (!m.chat || !(m.chat in sock.kuisislami) || !m.text) return false;

    let room = sock.kuisislami[m.chat];
    
    // 🔥 FILTER TINGKAT DEWA MEMBER: Hapus semua spasi dan simbol, jadi "Al Fatihah" sama dengan "alfatihah"
    let text = m.text.toLowerCase().replace(/[^a-z0-9]/g, '');
    let normalText = m.text.toLowerCase().trim(); // Khusus untuk deteksi kata "nyerah"

    if (normalText === "nyerah" || normalText === "menyerah") {
        await m.react("🏳️").catch(() => {});
        let ansTeks = `🏳️ *KUIS DIBATALKAN*\n\nJawaban yang benar adalah:\n*${room.jawabanAsli.toUpperCase()}*`;
        await sock.sendMessage(m.chat, { text: ansTeks }, { quoted: m });
        clearTimeout(room.timeout);
        delete sock.kuisislami[m.chat];
        return true;
    }

    if (text === room.jawaban) {
        let user = global.db.users[m.sender];
        if (user) {
            user.balance = (user.balance || 0) + room.hadiahUang;
            user.xp = (user.xp || 0) + room.hadiahXP;
        }

        await m.react("✅").catch(() => {});

        let uangRapi = typeof global.toRupiah === 'function' ? global.toRupiah(room.hadiahUang) : `Rp ${room.hadiahUang.toLocaleString('id-ID')}`;
        
        let teksUpdate = `🎉 *BENAR SEKALI!* 🎉\n\n`;
        teksUpdate += `*@${m.sender.split("@")[0]}* berhasil menjawab Kuis Islami!\n`;
        teksUpdate += `🎁 *Mendapatkan:* +${room.hadiahXP} XP & +${uangRapi}\n\n`;
        teksUpdate += `_Jawaban:_ *${room.jawabanAsli.toUpperCase()}* ✨`; 

        await sock.sendMessage(m.chat, { 
            text: teksUpdate, 
            contextInfo: { 
                mentionedJid: [m.sender],
                forwardingScore: 999, isForwarded: true,
                forwardedNewsletterMessageInfo: { newsletterJid: global.idChannel || "1203631@newsletter", newsletterName: "🕌 Assistant X Religi", serverId: 1 } 
            } 
        }, { quoted: m });
        
        clearTimeout(room.timeout);
        delete sock.kuisislami[m.chat];
        return true; 
    }
    
    return false;
}

handler.command = ["kuisislami"];
handler.tags = ["game"];
handler.help = ["kuisislami"];
handler.limit = true;

module.exports = handler;
