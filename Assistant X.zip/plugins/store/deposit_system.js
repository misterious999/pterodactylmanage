const axios = require('axios');

// ==========================================
// 🏦 ZEROIXDARK - ALL-IN-ONE DEPOSIT SYSTEM
// ⚙️ Ciptaan Pstar7 | Deposit, Konfirmasi, ACC, Reject
// ==========================================

function generateDynamicQRIS(qrisStatic, nominal) {
    let qris = qrisStatic.slice(0, -4);
    qris = qris.replace("010211", "010212");
    let parts = qris.split("5802ID");
    let payload = parts[0] + "54" + nominal.toString().length.toString().padStart(2, '0') + nominal + "5802ID" + parts[1];
    let crc = 0xFFFF;
    for (let i = 0; i < payload.length; i++) {
        crc ^= payload.charCodeAt(i) << 8;
        for (let j = 0; j < 8; j++) {
            if ((crc & 0x8000) !== 0) crc = (crc << 1) ^ 0x1021;
            else crc = crc << 1;
        }
    }
    return payload + (crc & 0xFFFF).toString(16).toUpperCase().padStart(4, '0');
}

let handler = async (m, { sock, conn, text, prefix, command, isOwner }) => {
    let client = sock || conn;

    switch (command) {

        // 🟢 1. FITUR REQUEST DEPOSIT
        case 'deposit': {
            if (!text) return m.reply(`❗ *Sertakan nominal depositnya!*\nContoh: \`${prefix + command} 50000\``);

            let nominalAwal = parseInt(text.replace(/[^0-9]/g, ''));
            if (nominalAwal < 1000) return m.reply("❌ Minimal deposit Rp 1.000");

            await m.react("⏳").catch(() => {});
            let kodeUnik = Math.floor(Math.random() * 500) + 1;
            let totalBayar = nominalAwal + kodeUnik;

            let qrisData = global.qrisStaticPayload;
            if (!qrisData) return m.reply("❌ QRIS_STATIC_PAYLOAD belum diisi di file .env.");
            
            try {
                let dynamicString = generateDynamicQRIS(qrisData, totalBayar);
                let qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${encodeURIComponent(dynamicString)}`;
                
                let caption = `╭──「 *💳 REQUEST DEPOSIT* 」\n`;
                caption += `│\n`;
                caption += `│ 👤 *User:* @${m.sender.split('@')[0]}\n`;
                caption += `│ 💰 *Nominal:* Rp ${nominalAwal.toLocaleString()}\n`;
                caption += `│ 🔢 *Kode Unik:* Rp ${kodeUnik}\n`;
                caption += `│ 💵 *TOTAL BAYAR: Rp ${totalBayar.toLocaleString()}*\n`;
                caption += `│\n`;
                caption += `│ ⚠️ *PENTING:*\n`;
                caption += `│ Wajib bayar sesuai *TOTAL BAYAR*\n`;
                caption += `│ agar saldo bisa masuk otomatis!\n`;
                caption += `│\n`;
                caption += `│ 📌 *LANGKAH SELANJUTNYA:*\n`;
                caption += `│ Jika sudah bayar, balas/kirim foto bukti\n`;
                caption += `│ ke bot ini dengan caption:\n`;
                caption += `│ 👉 \`.konfirmasi ${totalBayar}\`\n`;
                caption += `╰────────────🚀`;

                await client.sendMessage(m.chat, { image: { url: qrImageUrl }, caption, mentions: [m.sender] }, { quoted: m });

                let report = `📢 *INFO DEPOSIT*\nUser @${m.sender.split('@')[0]} request deposit.\nNominal + Kode Unik: *Rp ${totalBayar.toLocaleString()}*`;
                const ownerRaw = Array.isArray(global.owner) ? String(global.owner[0] || "") : String(global.owner || "").split(/[,\s]+/)[0];
                const ownerNumber = ownerRaw ? (ownerRaw.includes("@") ? ownerRaw : `${ownerRaw}@s.whatsapp.net`) : "";
                if (ownerNumber) await client.sendMessage(ownerNumber, { text: report, mentions: [m.sender] });
                await m.react("✅").catch(() => {});
            } catch (e) {
                m.reply("❌ Gagal merakit QRIS.");
            }
            break;
        }

        // 🟡 2. FITUR KONFIRMASI BUKTI TF
        case 'konfirmasi': {
            let q = m.quoted ? m.quoted : m;
            let mime = (q.msg || q).mimetype || q.mediaType || '';

            if (!text) return m.reply(`❗ *Sertakan nominalnya!*\nContoh: kirim foto dengan caption \`.konfirmasi 5436\``);
            if (!/image/.test(mime)) {
                await m.react("❌").catch(() => {});
                return m.reply(`❗ *Mana bukti transfernya?*\nKirim foto bukti transfer dengan pesan/caption \`.konfirmasi 50000\`.`);
            }

            let nominal = parseInt(text.replace(/[^0-9]/g, ''));
            if (isNaN(nominal) || nominal < 1000) return m.reply("❌ Nominal tidak valid!");

            await m.react("⏳").catch(() => {});

            try {
                // 🚀 FIX: Downloader Super Stabil
                let mediaBuffer;
                if (typeof q.download === 'function') {
                    mediaBuffer = await q.download();
                } else {
                    mediaBuffer = await client.downloadMediaMessage(q, 'image');
                }
                if (!mediaBuffer) throw new Error("Buffer kosong");

                let report = `🔔 *REQUEST DEPOSIT MASUK!* 🔔\n\n`;
                report += `👤 *User:* @${m.sender.split('@')[0]}\n`;
                report += `💰 *Nominal:* Rp ${nominal.toLocaleString()}\n\n`;
                report += `*Tindakan Cepat (Ketik/Salin):*\n`;
                report += `✅ ACC: \`.accdepo ${m.sender.split('@')[0]}|${nominal}\`\n`;
                report += `❌ TOLAK: \`.tolakdepo ${m.sender.split('@')[0]}\``;

                const ownerRaw = Array.isArray(global.owner) ? String(global.owner[0] || "") : String(global.owner || "").split(/[,\s]+/)[0];
                const ownerNumber = ownerRaw ? (ownerRaw.includes("@") ? ownerRaw : `${ownerRaw}@s.whatsapp.net`) : "";
                if (!ownerNumber) return m.reply("❌ OWNER_NUMBER belum diisi di file .env.");

                await client.sendMessage(ownerNumber, { image: mediaBuffer, caption: report, mentions: [m.sender] });

                await client.sendMessage(m.chat, { 
                    text: "✅ *Bukti transfer terkirim!*\nTunggu sebentar, saldo akan masuk setelah di-ACC Owner.",
                    contextInfo: {
                        externalAdReply: {
                            title: "BUKTI TF TERKIRIM",
                            body: "ZeroixDark Marketplace",
                            thumbnailUrl: global.thumbnail,
                            sourceUrl: "https://whatsapp.com/channel/0029Vb4TCk52f3EAcMJxOL3I",
                            mediaType: 1,
                            renderLargerThumbnail: true
                        }
                    }
                }, { quoted: m });
                
                await m.react("✅").catch(() => {});
            } catch (e) {
                console.error("[KONFIRMASI ERROR]", e);
                await m.react("❌").catch(() => {});
                m.reply("❌ Gagal memproses gambar. Pastikan file berupa foto dan coba lagi.");
            }
            break;
        }

        // 🟢 3. FITUR ACC DEPOSIT (VERSI INTEGRASI FIREBASE)
        case 'accdepo': {
            if (!isOwner) return m.reply("❌ Akses ditolak. Khusus Owner.");
            if (!text && !m.quoted) return m.reply("Format: `.accdepo @tag|nominal` atau balas foto dengan `.accdepo nominal`.");

            let target, amount;
            if (m.quoted) {
                target = m.quoted.sender;
                amount = parseInt(text.replace(/[^0-9]/g, ''));
            } else {
                let [who, price] = text.split('|');
                if (!who || !price) return m.reply("❌ Format salah.");
                target = who.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
                amount = parseInt(price);
            }

            if (!target || !amount || isNaN(amount)) return m.reply("❌ Data tidak valid.");

            // Ekstrak nomor wa tanpa @s.whatsapp.net untuk pencarian di Firebase
            let waNumber = target.split('@')[0]; 
            
            try {
                // 1. Cari UID user di Firebase berdasarkan nomor WhatsApp
                const usersRef = db.ref('users');
                const snapshot = await usersRef.orderByChild('whatsapp').equalTo(waNumber).once('value');
                
                if (!snapshot.exists()) {
                    return m.reply("❌ Nomor WhatsApp ini belum terdaftar di Web Dashboard ZeroixDark.");
                }

                // 2. Ambil UID dan Saldo Terakhir
                let uid = Object.keys(snapshot.val())[0];
                let userData = snapshot.val()[uid];
                let currentBalance = userData.balance || 0;
                let newBalance = currentBalance + amount;

                // 3. Suntik Saldo Baru ke Firebase
                await db.ref(`users/${uid}`).update({
                    balance: newBalance
                });
                
                // 4. Catat Log Aktivitas di Firebase (Opsional tapi brilian!)
                await db.ref(`activityLogs`).push({
                    uid: uid,
                    username: userData.username,
                    action: 'deposit_auto',
                    detail: `Deposit Rp ${amount.toLocaleString()} disetujui via Bot`,
                    timestamp: Date.now()
                });

                await m.reply(`✅ *DEPOSIT DI-ACC & MASUK WEB!*\n👤 @${target.split('@')[0]}\n💰 Ditambahkan: Rp ${amount.toLocaleString()}\n💳 Total Saldo Web: Rp ${newBalance.toLocaleString()}`, null, { mentions: [target] });

                let userMsg = `✨ *SALDO BERHASIL MASUK!* ✨\n\nHalo @${target.split('@')[0]}, depositmu telah dikonfirmasi!\n➕ *Masuk:* Rp ${amount.toLocaleString()}\n💰 *Saldo Web Sekarang:* Rp ${newBalance.toLocaleString()}\n\nSilakan cek Dashboard Web *ZeroixDark Marketplace* untuk mulai mendeploy server! 🚀`;

                await client.sendMessage(target, { 
                    text: userMsg,
                    contextInfo: {
                        externalAdReply: {
                            title: "DEPOSIT CONFIRMED",
                            body: "Saldo web kamu telah diperbarui!",
                            thumbnailUrl: global.thumbnail,
                            sourceUrl: "https://whatsapp.com/channel/0029Vb4TCk52f3EAcMJxOL3I",
                            mediaType: 1,
                            renderLargerThumbnail: true
                        }
                    }
                });
            } catch (error) {
                console.error("Firebase Update Error:", error);
                m.reply("❌ Terjadi kesalahan saat menyuntikkan saldo ke Database Web.");
            }
            break;
        }


        // 🔴 4. FITUR REJECT DEPOSIT
        case 'tolakdepo': {
            if (!isOwner) return m.reply("❌ Akses ditolak. Khusus Owner.");
            if (!text) return m.reply("Format: `.tolakdepo @tag/nomor`");

            let target = text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
            
            await m.reply(`✅ Request dari @${target.split('@')[0]} berhasil ditolak.`, null, { mentions: [target] });
            
            await client.sendMessage(target, { 
                text: `❌ *DEPOSIT DITOLAK*\n\nMaaf, request deposit kamu ditolak oleh Owner. Pastikan bukti transfer valid, jelas, dan sesuai nominal.` 
            });
            break;
        }
    }
}

handler.command = ['deposit', 'konfirmasi', 'accdepo', 'tolakdepo'];
handler.tags = ['store'];
handler.help = ['deposit <nominal>', 'konfirmasi <nominal>', 'accdepo <nominal>', 'tolakdepo <nomor>'];

module.exports = handler;
