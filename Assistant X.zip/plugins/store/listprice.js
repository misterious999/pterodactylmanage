const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

let handler = async (m, { sock, command, prefix }) => {

    // ==========================================
    // 1. TAMPILAN UTAMA (TOMBOL INTERAKTIF)
    // ==========================================
    if (command === 'listprice') {
        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: `✨ *SEWA BOT ASSISTANT X* ✨\n\nHalo Bosku! Tingkatkan pengalaman grup dan akunmu bersama Assistant X.\n\nSilakan pilih katalog layanan kami di bawah ini untuk melihat detail harga dan keuntungannya:`
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: "© Assistant X Project"
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            title: `*💳 DAFTAR HARGA LAYANAN*`,
                            subtitle: "",
                            hasMediaAttachment: false
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "👥 List Sewa Group",
                                        id: `${prefix}hargagrup` // ID diubah agar tidak bentrok
                                    })
                                },
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "💎 List Premium",
                                        id: `${prefix}hargaprem` // ID diubah agar tidak bentrok
                                    })
                                }
                            ]
                        })
                    })
                }
            }
        }, { quoted: m });

        return await sock.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
    }

    // ==========================================
    // 2. RESPON KETIKA TOMBOL "SEWA GROUP" DIKLIK
    // ==========================================
    if (command === 'hargagrup') {
        let teks = `✨ *SEWA BOT ASSISTANT X* ✨\n\n`;
        teks += `👥 *PAKET SEWA GRUP*\n`;
        teks += `----------------------------------------\n`;
        teks += `📅 1 Minggu   | *Rp 6.000*\n`;
        teks += `📅 2 Minggu   | *Rp 10.000*\n`;
        teks += `📅 3 Minggu   | *Rp 16.000*\n`;
        teks += `📅 1 Bulan    | *Rp 30.000*\n`;
        teks += `📅 2 Bulan    | *Rp 40.000*\n`;
        teks += `----------------------------------------\n\n`;
        
        teks += `🌟 *KEUNGGULAN SEWA GRUP:*\n`;
        teks += `✅ *Auto Welcome & Leave* (Sambut member baru dengan keren)\n`;
        teks += `✅ *Anti Link & Anti Toxic* (Grup aman dari spammer, auto kick!)\n`;
        teks += `✅ *Fitur Admin Lengkap* (Hidetag, Tagall, Kick, Add, Tutup/Buka Grup)\n`;
        teks += `✅ *Ribuan Fitur Hiburan* (AI, Game RPG, Tebak-tebakan, Fun)\n`;
        teks += `✅ *Sistem Siaga 24 Jam Non-Stop* di grup Anda!\n\n`;
        
        teks += `📢 *SEGERA LANGGANAN SEKARANG!*\n\n`;
        teks += `*Group Official Bot :* 🤖\nhttps://chat.whatsapp.com/LE9BXOjPIEy9CebW95H4Ra?s=cl&p=a&ilr=4\n\n`;
        teks += `_Ketik *${prefix}owner* untuk menghubungi admin dan melakukan pembayaran._`;

        return m.reply(teks);
    }

    // ==========================================
    // 3. RESPON KETIKA TOMBOL "LIST PREMIUM" DIKLIK
    // ==========================================
    if (command === 'hargaprem') {
        let teks = `✨ *SEWA BOT ASSISTANT X* ✨\n\n`;
        teks += `💎 *PAKET PREMIUM USER*\n`;
        teks += `----------------------------------------\n`;
        teks += `📅 1 Hari     | *Rp 5.000*\n`;
        teks += `📅 7 Hari     | *Rp 10.000*\n`;
        teks += `📅 15 Hari    | *Rp 24.000*\n`;
        teks += `📅 30 Hari    | *Rp 30.000*\n`;
        teks += `📅 Unlimited  | *Rp 80.000*\n`;
        teks += `----------------------------------------\n\n`;
        
        teks += `🌟 *KEUNGGULAN USER PREMIUM (VVIP):*\n`;
        teks += `✅ *Limit Tanpa Batas* (Unlimited akses bot seharian!)\n`;
        teks += `✅ *Akses Fitur Eksklusif* (Deploy Web Otomatis, AI Image, dll)\n`;
        teks += `✅ *Prioritas Sistem Server* (Bot merespon pesananmu lebih cepat)\n`;
        teks += `✅ *Bebas Limit Download* (Tiktok, IG, YouTube sepuasnya)\n`;
        teks += `✅ *Status VVIP* (Tampil beda dan keren di database)\n\n`;
        
        teks += `📢 *SEGERA LANGGANAN SEKARANG!*\n\n`;
        teks += `*Group Official Bot :* 🤖\nhttps://chat.whatsapp.com/LE9BXOjPIEy9CebW95H4Ra?s=cl&p=a&ilr=4\n\n`;
        teks += `_Ketik *${prefix}owner* untuk menghubungi admin dan melakukan pembayaran._`;

        return m.reply(teks);
    }
}

handler.command = ['listprice', 'hargagrup', 'hargaprem'];
handler.tags = ['main'];
handler.help = ['listprice'];
handler.owner = false; 

module.exports = handler;
