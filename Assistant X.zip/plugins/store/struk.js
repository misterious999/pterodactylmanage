// ==========================================
// 📄 DIGITAL INVOICE GENERATOR
// ⚙️ Ciptaan Pstar7 | Invoice Berkelas & Pro
// ==========================================

let handler = async (m, { sock, conn, text, prefix, command }) => {
    // Dukungan untuk berbagai base (sock atau conn)
    let client = sock || conn; 

    // Input: .struk Nama|Produk|Harga|Status
    if (!text) return m.reply(`❗ *Format Salah!*\nContoh: \`${prefix + command} Budi|Sewa VPS 2GB|50000|LUNAS\``);

    let [name, item, price, status] = text.split('|');
    if (!name || !item || !price) return m.reply("❗ *Data tidak lengkap!* Gunakan pemisah `|` (garis tegak).");

    let invId = "INV-" + Math.random().toString(36).toUpperCase().substring(2, 10);
    let date = new Date().toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });

    let teks = `╭──「 *📄 ZEROIXDARK INVOICE* 」\n`;
    teks += `│\n`;
    teks += `│ 🆔 *ID Order:* \`${invId}\`\n`;
    teks += `│ 📅 *Tanggal:* ${date}\n`;
    teks += `│ 👤 *Pembeli:* ${name.trim()}\n`;
    teks += `│\n`;
    teks += `│ 📝 *Item:* ${item.trim()}\n`;
    teks += `│ 💰 *Harga:* Rp ${parseInt(price).toLocaleString()}\n`;
    teks += `│ 📌 *Status:* ${status ? status.toUpperCase() : 'SUCCESS'}\n`;
    teks += `│\n`;
    teks += `│ _Terima kasih telah berlangganan_\n`;
    teks += `│ _di ZeroixDark Marketplace!_\n`;
    teks += `╰────────────🚀`;

    try {
        // Kirim dengan gambar thumbnail dari config
        await client.sendMessage(m.chat, { 
            text: teks,
            contextInfo: {
                externalAdReply: {
                    title: "TRANSACTION SUCCESSFUL",
                    body: "ZeroixDark Marketplace • Quality Service",
                    thumbnailUrl: global.thumbnail, // Mengambil dari config.js
                    sourceUrl: "https://whatsapp.com/channel/0029Vb4TCk52f3EAcMJxOL3I", // Link web bosku
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m });
    } catch (e) {
        console.error("[INVOICE ERROR]", e);
        // Fallback: Kalau thumbnail di config error/mati, tetep kirim struk teksnya
        await client.sendMessage(m.chat, { text: teks }, { quoted: m });
    }
}

handler.command = ['struk', 'invoice'];
handler.tags = ['store'];
handler.help = ['struk <nama|item|harga>'];

module.exports = handler;
