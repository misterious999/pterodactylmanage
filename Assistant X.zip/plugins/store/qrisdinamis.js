const axios = require('axios');

// ==========================================
// 💳 DYNAMIC QRIS GENERATOR (LOCAL ENGINE)
// ⚙️ Ciptaan Pstar7 | 100% Anti Down/Limit API!
// ==========================================

// Mesin Perakit QRIS Dinamis Lokal
function generateDynamicQRIS(qrisStatic, nominal) {
    // 1. Potong 4 digit kode keamanan lama di ujung
    let qris = qrisStatic.slice(0, -4);
    // 2. Ubah tipe QRIS dari Statis (010211) ke Dinamis (010212)
    qris = qris.replace("010211", "010212");
    
    // 3. Sisipkan Harga/Nominal (Tag 54) sebelum Country Code (5802ID)
    let parts = qris.split("5802ID");
    let nomStr = nominal.toString();
    let nomLen = nomStr.length.toString().padStart(2, '0');
    let payload = parts[0] + "54" + nomLen + nomStr + "5802ID" + parts[1];
    
    // 4. Hitung ulang kode keamanan (Checksum CRC16-CCITT)
    let crc = 0xFFFF;
    for (let i = 0; i < payload.length; i++) {
        crc ^= payload.charCodeAt(i) << 8;
        for (let j = 0; j < 8; j++) {
            if ((crc & 0x8000) !== 0) crc = (crc << 1) ^ 0x1021;
            else crc = crc << 1;
        }
    }
    let hash = (crc & 0xFFFF).toString(16).toUpperCase().padStart(4, '0');
    return payload + hash; // Gabungkan data utuh dengan kunci baru
}

let handler = async (m, { sock, conn, text, prefix, command }) => {
    let client = sock || conn;

    if (!text) return m.reply(`❗ *Mau buat QRIS berapa?*\nContoh: \`${prefix + command} 50000\``);

    let nominal = parseInt(text.replace(/[^0-9]/g, ''));
    if (isNaN(nominal) || nominal < 100) return m.reply("❌ *Nominal tidak valid!* Minimal Rp 100.");

    await m.react("⏳").catch(() => {});

    // Data QRIS statis bosku
    let qrisData = global.qrisStaticPayload;
            if (!qrisData) return m.reply("❌ QRIS_STATIC_PAYLOAD belum diisi di file .env.");
    
    try {
        // Rakit payload QRIS secara lokal (Super Cepat!)
        let dynamicString = generateDynamicQRIS(qrisData, nominal);
        
        // Render ke gambar menggunakan server QR publik berkecepatan tinggi
        let safeUrl = encodeURIComponent(dynamicString);
        let qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${safeUrl}`;
        
        let teks = `╭──「 *💳 PEMBAYARAN QRIS* 」\n`;
        teks += `│\n`;
        teks += `│ 💰 *Total:* Rp ${nominal.toLocaleString()}\n`;
        teks += `│ 🏷️ *Admin:* Rp 0 (FREE)\n`;
        teks += `│\n`;
        teks += `│ _Silakan scan QR di atas menggunakan_\n`;
        teks += `│ _Dana, OVO, GoPay, ShopeePay, atau Bank._\n`;
        teks += `╰────────────🚀`;

        await client.sendMessage(m.chat, { 
            image: { url: qrImageUrl }, 
            caption: teks 
        }, { quoted: m });

        await m.react("✅").catch(() => {});
    } catch (e) {
        console.error("[QRIS ERROR]", e.message);
        m.reply("❌ *Terjadi kesalahan sistem internal.*");
    }
}

handler.command = ['bayar', 'qris'];
handler.tags = ['store'];
handler.help = ['bayar <nominal>'];

module.exports = handler;
