const fetch = require('node-fetch');
const { generateWAMessageFromContent } = require("@whiskeysockets/baileys");

// ==========================================
// 🚀 ASSISTANT X VVIP PTERODACTYL MANAGER
// ⚙️ Features: Create, List, Del, Clear (Robust & Clean)
// ==========================================

let handler = async (m, { sock, text, command, prefix, isOwner, isPrems }) => {
    
    // 🔥 1. KEAMANAN MULTI-ROLE
    let isPremiumUser = isPrems || isOwner || (global.db?.data?.users?.[m.sender]?.premium);
    if (!isPremiumUser) {
        return m.reply("❌ *Akses Ditolak!*\nFitur VVIP Panel ini khusus untuk Owner dan pengguna Premium.");
    }

    let host = global.domain || global.host || "";
    let api = global.apikey || global.plta || "";
    let idNest = global.nestid;
    let idEgg = global.egg;
    let idLoc = global.loc;

    if (!host || !api) return m.reply("❌ *Konfigurasi Error!*\nPastikan domain dan apikey Pterodactyl sudah diatur di file config global.");
    host = host.endsWith('/') ? host.slice(0, -1) : host;

    const headersApp = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": `Bearer ${api}`
    };

    const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

    // ==========================================
    // 🛠️ 1. MAIN MENU: .cpanel (CREATE PANEL)
    // ==========================================
    if (command === 'cpanel') {
        if (!text || !text.includes(",")) {
            return m.reply(`🤖 *Format Salah!*\n\n*Contoh Penggunaan:*\n\`${prefix}cpanel username,62895416479539\``);
        }

        let [users, nom] = text.split(",").map(t => t.trim());
        if (!users || !nom) return m.reply(`❌ *Data tidak lengkap!* Pastikan ada username dan nomor tujuan.`);

        let username = users.toLowerCase().replace(/[^a-z0-9]/g, "");
        if (!username) username = "user" + Math.floor(Math.random() * 10000);
        
        let nomor = nom.replace(/[^0-9]/g, "");

        let teksMenu = `⚙️ *P E M B U A T A N   P A N E L* ⚙️\n\n`;
        teksMenu += `👤 *Calon Username:* ${username}\n`;
        teksMenu += `📱 *Nomor Tujuan:* ${nomor}\n\n`;
        teksMenu += `_Silakan klik tombol di bawah ini dan pilih spesifikasi RAM yang ingin diberikan kepada pembeli._ 🚀`;

        let msg = await generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: { text: teksMenu },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: "single_select",
                                    buttonParamsJson: JSON.stringify({
                                        title: "🖥️ PILIH SPESIFIKASI RAM",
                                        sections: [{
                                            title: "Daftar Paket Server",
                                            rows: [
                                                { header: "", title: "1 GB", id: `${prefix}createpanel_exec 1gb|${username}|${nomor}` },
                                                { header: "", title: "2 GB", id: `${prefix}createpanel_exec 2gb|${username}|${nomor}` },
                                                { header: "", title: "3 GB", id: `${prefix}createpanel_exec 3gb|${username}|${nomor}` },
                                                { header: "", title: "4 GB", id: `${prefix}createpanel_exec 4gb|${username}|${nomor}` },
                                                { header: "", title: "5 GB", id: `${prefix}createpanel_exec 5gb|${username}|${nomor}` },
                                                { header: "", title: "6 GB", id: `${prefix}createpanel_exec 6gb|${username}|${nomor}` },
                                                { header: "", title: "7 GB", id: `${prefix}createpanel_exec 7gb|${username}|${nomor}` },
                                                { header: "", title: "8 GB", id: `${prefix}createpanel_exec 8gb|${username}|${nomor}` },
                                                { header: "", title: "9 GB", id: `${prefix}createpanel_exec 9gb|${username}|${nomor}` },
                                                { header: "", title: "10 GB", id: `${prefix}createpanel_exec 10gb|${username}|${nomor}` },
                                                { header: "", title: "Unlimited", id: `${prefix}createpanel_exec unlimited|${username}|${nomor}` }
                                            ]
                                        }]
                                    })
                                }
                            ]
                        }
                    }
                }
            }
        }, { userJid: m.sender, quoted: m });

        return sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    }

    // ==========================================
    // ⚙️ EKSEKUSI: CREATE PANEL
    // ==========================================
    if (command === 'createpanel_exec') {
        const parts = text.split("|");
        if (parts.length < 3) return m.reply("❌ Data eksekusi panel korup!");

        let plan = parts[0];
        let username = parts[1];
        let nomor = parts[2];
        let targetJid = nomor + "@s.whatsapp.net";

        const resourceMap = {
            "1gb": { ram: "1000", disk: "1000", cpu: "40" },
            "2gb": { ram: "2000", disk: "1000", cpu: "60" },
            "3gb": { ram: "3000", disk: "2000", cpu: "80" },
            "4gb": { ram: "4000", disk: "2000", cpu: "100" },
            "5gb": { ram: "5000", disk: "3000", cpu: "120" },
            "6gb": { ram: "6000", disk: "3000", cpu: "140" },
            "7gb": { ram: "7000", disk: "4000", cpu: "160" },
            "8gb": { ram: "8000", disk: "4000", cpu: "180" },
            "9gb": { ram: "9000", disk: "5000", cpu: "200" },
            "10gb": { ram: "10000", disk: "5000", cpu: "220" },
            "unlimited": { ram: "0", disk: "0", cpu: "0" }
        };

        let { ram, disk, cpu } = resourceMap[plan] || { ram: "0", disk: "0", cpu: "0" };
        
        let email = username + "@gmail.com";
        let name = username.charAt(0).toUpperCase() + username.slice(1) + " Server";
        let password = username + "001";
        let tglBuat = new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });

        await m.react('⏳');
        try {
            let reqUser = await fetch(host + "/api/application/users", {
                method: "POST", headers: headersApp,
                body: JSON.stringify({ email, username, first_name: name, last_name: "Server", language: "en", password })
            });
            let dataUser = await reqUser.json();
            if (dataUser.errors) return m.reply("❌ *Gagal Buat User:*\n" + JSON.stringify(dataUser.errors[0]));
            let user = dataUser.attributes;

            let reqEgg = await fetch(host + `/api/application/nests/${idNest}/eggs/${idEgg}`, { method: "GET", headers: headersApp });
            let dataEgg = await reqEgg.json();
            let startup_cmd = dataEgg.attributes.startup;

            let reqServer = await fetch(host + "/api/application/servers", {
                method: "POST", headers: headersApp,
                body: JSON.stringify({
                    name, description: tglBuat, user: user.id, egg: parseInt(idEgg),
                    docker_image: "ghcr.io/parkervcp/yolks:nodejs_20", startup: startup_cmd,
                    environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" },
                    limits: { memory: ram, swap: 0, disk, io: 500, cpu },
                    feature_limits: { databases: 5, backups: 5, allocations: 5 },
                    deploy: { locations: [parseInt(idLoc)], dedicated_ip: false, port_range: [] }
                })
            });
            let dataServer = await reqServer.json();
            if (dataServer.errors) return m.reply("❌ *Gagal Buat Server:*\n" + JSON.stringify(dataServer.errors[0]));
            let server = dataServer.attributes;

            let teksKirim = `✨ *B E R H A S I L   M E M B U A T   P A N E L* ✨\n\n`;
            teksKirim += `📡 *Server ID:* ${server.id}\n`;
            teksKirim += `👤 *Username:* ${user.username}\n`;
            teksKirim += `🔐 *Password:* ${password}\n`;
            teksKirim += `🗓️ *Tanggal:* ${tglBuat}\n\n`;
            teksKirim += `⚙️ *Spesifikasi Server*\n`;
            teksKirim += `- RAM: ${ram == "0" ? "Unlimited" : ram / 1000 + " GB"}\n`;
            teksKirim += `- Disk: ${disk == "0" ? "Unlimited" : disk / 1000 + " GB"}\n`;
            teksKirim += `- CPU: ${cpu == "0" ? "Unlimited" : cpu + "%"}\n`;
            teksKirim += `- Login: ${host}`;

            let msgPembeli = await generateWAMessageFromContent(targetJid, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: teksKirim },
                            nativeFlowMessage: {
                                buttons: [
                                    { name: "cta_copy", buttonParamsJson: `{"display_text":"Salin Username","copy_code":"${user.username}"}` },
                                    { name: "cta_copy", buttonParamsJson: `{"display_text":"Salin Password","copy_code":"${password}"}` },
                                    { name: "cta_url", buttonParamsJson: `{"display_text":"🌐 Login Web Panel","url":"${host}"}` }
                                ]
                            }
                        }
                    }
                }
            }, { userJid: sock.user.id });

            await sock.relayMessage(targetJid, msgPembeli.message, { messageId: msgPembeli.key.id });
            
            await m.react('✅');
            return m.reply(`✅ *Panel Sukses Dibuat!*\nDetail login berhasil dikirim ke private chat pembeli (@${nomor})`);
        } catch (e) {
            await m.react('❌');
            return m.reply("❌ *Sistem Gagal:*\n" + e.message);
        }
    }

    // ==========================================
    // 🛠️ 2. MAIN MENU: .listpanel
    // ==========================================
    if (command === 'listpanel') {
        let msg = await generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: { text: `📋 *P U S A T   D A T A   P A N E L*\n\n_Silakan pilih database yang ingin bosku lihat:_` },
                        nativeFlowMessage: {
                            buttons: [
                                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "👤 List Semua User", id: `${prefix}listpanel_exec user` }) },
                                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🖥️ List Semua Server", id: `${prefix}listpanel_exec server` }) }
                            ]
                        }
                    }
                }
            }
        }, { userJid: m.sender, quoted: m });
        return sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    }

    // ==========================================
    // ⚙️ EKSEKUSI: LIST PANEL
    // ==========================================
    if (command === 'listpanel_exec') {
        let type = text.trim();
        await m.react('⏳');

        if (type === 'user') {
            try {
                let res = await fetch(`${host}/api/application/users`, { method: "GET", headers: headersApp });
                let rawText = await res.text();
                
                let data;
                try {
                    data = JSON.parse(rawText);
                } catch (err) {
                    throw new Error(`Respons Server Pterodactyl BUKAN format JSON.\n\n*Status Kode:* ${res.status}\n*Bukti Respons:* ${rawText.substring(0, 150)}...`);
                }

                if (data.errors) throw new Error(data.errors[0].detail || JSON.stringify(data.errors));
                
                let users = data.data;
                if (!users || users.length === 0) return m.reply("📭 Tidak ada user terdaftar.");

                let teksList = `✨ *D A F T A R   U S E R* ✨\nTotal: ${users.length} Akun\n\n`;
                for (let u of users) {
                    let a = u.attributes;
                    let badge = a.root_admin ? "👑 (Admin)" : "👤 (Member)";
                    teksList += `*${badge} ${a.username}*\n`;
                    teksList += `└ ID: ${a.id} | Email: ${a.email}\n\n`;
                }
                
                await m.react('✅');
                return m.reply(teksList);
            } catch (e) { 
                await m.react('❌');
                return m.reply(`❌ *Gagal mengambil data user:*\n${e.message}`); 
            }
        }
        
        if (type === 'server') {
            try {
                let res = await fetch(`${host}/api/application/servers`, { method: "GET", headers: headersApp });
                let rawText = await res.text();
                
                let data;
                try {
                    data = JSON.parse(rawText);
                } catch (err) {
                    throw new Error(`Respons Server Pterodactyl BUKAN format JSON.\n\n*Status Kode:* ${res.status}\n*Bukti Respons:* ${rawText.substring(0, 150)}...`);
                }

                if (data.errors) throw new Error(data.errors[0].detail || JSON.stringify(data.errors));

                let servers = data.data;
                if (!servers || servers.length === 0) return m.reply("📭 Tidak ada server terdaftar.");

                let teksList = `✨ *D A F T A R   S E R V E R* ✨\nTotal: ${servers.length} Server\n\n`;
                for (let s of servers) {
                    let a = s.attributes;
                    let ram = a.limits.memory === 0 ? "Unlimited" : (a.limits.memory >= 1024 ? `${Math.floor(a.limits.memory / 1024)} GB` : `${a.limits.memory} MB`);
                    let status = a.suspended ? "🔴 Suspended" : "🟢 Active";
                    
                    teksList += `*🖥️ ${a.name}*\n`;
                    teksList += `└ ID: ${a.id} | RAM: ${ram} | Status: ${status}\n\n`;
                }
                
                await m.react('✅');
                return m.reply(teksList);
            } catch (e) { 
                await m.react('❌');
                return m.reply(`❌ *Gagal mengambil data server:*\n${e.message}`); 
            }
        }
    }

    // ==========================================
    // 🛠️ 3. MAIN MENU: .delpanel
    // ==========================================
    if (command === 'delpanel') {
        if (!text) return m.reply(`🤖 *Format Salah!*\nKetik ID dari user/server yang ingin dihapus.\n\nContoh: \`${prefix}delpanel 15\``);
        let targetId = text.trim();

        let msg = await generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: { text: `🗑️ *P A N E L   E K S E K U S I*\n\nTarget ID: *${targetId}*\n\n_Pastikan ID sudah benar. Apakah ini ID dari User atau ID dari Server?_` },
                        nativeFlowMessage: {
                            buttons: [
                                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🗑️ Hapus User", id: `${prefix}delpanel_exec user|${targetId}` }) },
                                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🗑️ Hapus Server", id: `${prefix}delpanel_exec server|${targetId}` }) }
                            ]
                        }
                    }
                }
            }
        }, { userJid: m.sender, quoted: m });
        return sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    }

    // ==========================================
    // ⚙️ EKSEKUSI: DEL PANEL
    // ==========================================
    if (command === 'delpanel_exec') {
        const parts = text.split("|");
        let type = parts[0];
        let targetId = parts[1];

        await m.react('⏳');
        try {
            if (type === 'user') {
                let req = await fetch(`${host}/api/application/users/${targetId}`, { method: "DELETE", headers: headersApp });
                if (!req.ok) throw new Error("ID User tidak ditemukan atau API Key tidak memiliki akses penghapusan.");
                await m.react('✅');
                return m.reply(`✅ *Sukses Dihapus!*\nAkun Panel dengan ID User *${targetId}* telah musnah.`);
            } 
            if (type === 'server') {
                let req = await fetch(`${host}/api/application/servers/${targetId}/force`, { method: "DELETE", headers: headersApp });
                if (!req.ok) throw new Error("ID Server tidak ditemukan atau gagal di-force delete.");
                await m.react('✅');
                return m.reply(`💥 *SERVER DIBASMI!*\nServer dengan ID *${targetId}* telah dihapus permanen dari muka bumi Panel!`);
            }
        } catch (e) {
            await m.react('❌');
            return m.reply(`❌ *Gagal Menghapus:*\n${e.message}`);
        }
    }

    // ==========================================
    // 🛠️ 4. MAIN MENU: .clearpanel
    // ==========================================
    if (command === 'clearpanel') {
        let msg = await generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: { text: `⚠️ *W A R N I N G :   M A S S   D E S T R U C T I O N* ⚠️\n\n_Tindakan ini akan menghapus data secara massal dan permanen. Pilih dengan hati-hati:_` },
                        nativeFlowMessage: {
                            buttons: [
                                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔥 Hapus Semua Server", id: `${prefix}clearpanel_exec server` }) },
                                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔥 Hapus Semua User", id: `${prefix}clearpanel_exec user` }) },
                                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "☢️ Hapus SEMUANYA (Kiamat)", id: `${prefix}clearpanel_exec all` }) }
                            ]
                        }
                    }
                }
            }
        }, { userJid: m.sender, quoted: m });
        return sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    }

    // ==========================================
    // ⚙️ EKSEKUSI: CLEAR PANEL
    // ==========================================
    if (command === 'clearpanel_exec') {
        let type = text.trim();
        await m.reply("☢️ *PROSES PEMUSNAHAN DIMULAI...*\n_Mohon tunggu, bot sedang menembak API Pterodactyl satu per satu..._");
        
        let deletedServers = 0;
        let deletedUsers = 0;

        try {
            if (type === 'server' || type === 'all') {
                let resSrv = await fetch(`${host}/api/application/servers`, { method: "GET", headers: headersApp });
                let dataSrv = await resSrv.json();
                let servers = dataSrv.data || [];

                for (let s of servers) {
                    try {
                        await fetch(`${host}/api/application/servers/${s.attributes.id}/force`, { method: "DELETE", headers: headersApp });
                        deletedServers++;
                        await sleep(300);
                    } catch (err) {}
                }
            }

            if (type === 'user' || type === 'all') {
                let resUsr = await fetch(`${host}/api/application/users`, { method: "GET", headers: headersApp });
                let dataUsr = await resUsr.json();
                let users = dataUsr.data || [];

                for (let u of users) {
                    if (u.attributes.root_admin) continue;
                    
                    try {
                        await fetch(`${host}/api/application/users/${u.attributes.id}`, { method: "DELETE", headers: headersApp });
                        deletedUsers++;
                        await sleep(300);
                    } catch (err) {}
                }
            }

            let teksAkhir = `☢️ *P E M U S N A H A N   S E L E S A I* ☢️\n\n`;
            if (type === 'server' || type === 'all') teksAkhir += `🖥️ Server Hancur: *${deletedServers}*\n`;
            if (type === 'user' || type === 'all') teksAkhir += `👤 User Terhapus: *${deletedUsers}* (Admin Root diabaikan)\n`;
            
            return m.reply(teksAkhir);

        } catch (e) {
            return m.reply(`❌ *Sistem Pemusnahan Gagal di Tengah Jalan:*\n${e.message}`);
        }
    }
}

handler.help = ['cpanel', 'listpanel', 'delpanel', 'clearpanel'];
handler.tags = ['pterodactyl'];
handler.command = [
    'cpanel', 'listpanel', 'delpanel', 'clearpanel', 
    'createpanel_exec', 'listpanel_exec', 'delpanel_exec', 'clearpanel_exec'
];
handler.premium = true; 

module.exports = handler;
