const axios = require('axios');

let handler = async (m, { sock, prefix, command, text }) => {
    let apiKey = global.btc;
    
    if (!apiKey) {
        return m.reply(`❌ *Sistem API Terkunci!*\nAPI Key BOTCAHX belum diatur di \`config.js\` (global.btc).`);
    }

    // 🛡️ Filter: Pastikan member memasukkan teks yang mau diubah jadi suara
    if (!text) {
        return m.reply(`❓ *Cara Penggunaan:*\nKetik ${prefix}${command} <teks>\n\n*Contoh:*\n${prefix}${command} halo semuanya selamat malam`);
    }

    // Efek ngerekam suara
    await sock.sendMessage(m.chat, { react: { text: "🎙️", key: m.key } });
    await m.reply('⏳ _Sedang rekaman suara di studio anime..._');

    try {
        const apiUrl = global.botcahxUrl('/api/sound/textanime', { text });
        
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' }).catch(e => e.response);
        const contentType = response.headers['content-type'];

        let audioData = "";

        if (contentType && contentType.includes('application/json')) {
            let dataObj = JSON.parse(Buffer.from(response.data).toString('utf-8'));
            console.log("\n[ 🔍 DATA ASLI API TEXT ANIME ]\n", JSON.stringify(dataObj, null, 2), "\n");
            
            let extractUrl = dataObj.data || dataObj.result || dataObj.url || dataObj.audio;
            if (!extractUrl) {
                return m.reply("❌ API merespon JSON, tapi link audio tidak ditemukan. Cek konsol Pterodactyl bosku!");
            }
            audioData = { url: extractUrl };
        } 
        else {
            audioData = { url: apiUrl }; 
        }

        await sock.sendMessage(m.chat, { 
            audio: audioData, 
            mimetype: 'audio/mp4', 
            ptt: true 
        }, { quoted: m });

    } catch (err) {
        console.error("[ TEXT ANIME API ERROR ]", err.message);
        m.reply("❌ Terjadi masalah koneksi ke server BOTCAHX atau teks terlalu panjang.");
    }
}

handler.tags = ['fun'];
handler.help = ['textanime <teks>'];
// ✅ COMMAND DIPANGKAS JADI 1 AJA BIAR RAPI DAN ANTI TABRAKAN
handler.command = ['textanime'];

module.exports = handler;
