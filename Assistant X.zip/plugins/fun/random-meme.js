const axios = require('axios');

let handler = async (m, { sock, prefix, command }) => {
    let apiKey = global.btc;
    
    if (!apiKey) {
        return m.reply(`❌ *Sistem API Terkunci!*\nAPI Key BOTCAHX belum diatur di \`config.js\` (global.btc).`);
    }

    await sock.sendMessage(m.chat, { react: { text: "🤣", key: m.key } });
    await m.reply('⏳ _Menggali meme paling receh dari server..._');

    try {
        const apiUrl = global.botcahxUrl('/api/random/meme');
        const { data } = await axios.get(apiUrl);

        console.log("\n[ 🔍 DATA ASLI API MEME ]\n", JSON.stringify(data, null, 2), "\n");

        // 🎯 SUPER EXTRACTOR V3 (MATA ELANG)
        // Karena dari konsol sudah ketahuan letak gambarnya ada di "data.data"
        let memeUrl = data.data || data.result || data.url || data.image;

        if (!memeUrl || typeof memeUrl !== 'string' || !memeUrl.startsWith('http')) {
            return m.reply("❌ API merespon, tapi link gambar tidak valid. Cek konsol Pterodactyl bosku!");
        }

        let captionMeme = `╭───┈ *「 🤣 RANDOM MEME 」*\n│\n│ ⚡ *Powered by Assistant X*\n│\n╰───────────────┈ ⳹`;

        await sock.sendMessage(m.chat, { 
            image: { url: memeUrl }, 
            caption: captionMeme 
        }, { quoted: m });

    } catch (err) {
        console.error("[ MEME API ERROR ]", err.message);
        m.reply("❌ Terjadi masalah koneksi ke server BOTCAHX.");
    }
}

handler.tags = ['fun'];
handler.help = ['meme'];
handler.command = ['meme'];

module.exports = handler;
