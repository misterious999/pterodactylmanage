const axios = require('axios');

let handler = async (m, { sock, prefix, command }) => {
    let apiKey = global.btc;
    
    if (!apiKey) {
        return m.reply(`❌ *Sistem API Terkunci!*\nAPI Key BOTCAHX belum diatur di \`config.js\` (global.btc).`);
    }

    // Kasih reaction biar kelihatan botnya lagi mikir keras
    await sock.sendMessage(m.chat, { react: { text: "🤭", key: m.key } });
    await m.reply('⏳ _Mencari lelucon bapak-bapak paling garing..._');

    try {
        const apiUrl = global.botcahxUrl('/api/random/jokes');
        const { data } = await axios.get(apiUrl);

        // 🔍 DEBUG SYSTEM: Biar bosku tetep bisa pantau struktur aslinya di Pterodactyl
        console.log("\n[ 🔍 DATA ASLI API JOKES ]\n", JSON.stringify(data, null, 2), "\n");

        // 🎯 SUPER EXTRACTOR V4 (KHUSUS TEKS)
        let jokeText = "";
        
        if (typeof data.data === 'string') {
            jokeText = data.data; // Kalau formatnya persis kayak meme tadi
        } else if (typeof data.result === 'string') {
            jokeText = data.result;
        } else if (data.data && typeof data.data === 'object') {
            jokeText = data.data.joke || data.data.text || data.data.result;
        } else if (data.result && typeof data.result === 'object') {
            jokeText = data.result.joke || data.result.text;
        } else {
            jokeText = data.joke || data.text;
        }

        if (!jokeText) {
            return m.reply("❌ API merespon, tapi teks jokes tidak ditemukan. Cek konsol Pterodactyl bosku!");
        }

        // Bikin bingkai estetik khas Assistant X
        let captionJoke = `╭───┈ *「 🤣 RANDOM JOKES 」*\n│\n│ ${jokeText}\n│\n│ ⚡ *Powered by Assistant X*\n╰───────────────┈ ⳹`;

        // Kirim sebagai teks balasan (nggak butuh image)
        await m.reply(captionJoke);

    } catch (err) {
        console.error("[ JOKES API ERROR ]", err.message);
        m.reply("❌ Terjadi masalah koneksi ke server BOTCAHX.");
    }
}

handler.tags = ['fun'];
handler.help = ['joke'];
handler.command = ['joke'];

module.exports = handler;
