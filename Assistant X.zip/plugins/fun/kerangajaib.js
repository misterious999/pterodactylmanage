// ==========================================
// KERANG AJAIB (BOTCAHX AI EDITION V2)
// ==========================================

const axios = require('axios');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

let handler = async (m, { sock, text, command, prefix }) => {
    let user = global.db.users[m.sender];
    if (!user) return m.reply("Eh, kamu belum terdaftar di database nih. Daftar dulu ya!");

    let apikey = global.btc;
    if (!apikey) return m.reply("Waduh, BOTCAHX_APIKEY belum diisi nih di .env kamu.");

    if (!text) {
        return m.reply(`Mau tanya apa ke Kerang Ajaib?\nContoh: ${prefix}${command} apakah besok aku libur?`);
    }

    if (user.limit < 1) {
        return m.reply(`Limit kamu habis nih buat manggil Kerang Ajaib. (Sisa: ${user.limit})`);
    }

    await m.react('⏳');
    await sock.sendPresenceUpdate('composing', m.chat);

    try {
        // PROMPT BARU: Aturan mutlak anti-AI dan anti-basa-basi
        let systemPrompt = `Kamu adalah Kerang Ajaib dari Spongebob versi sangat hiperaktif dan ngegas! 
ATURAN MUTLAK:
1. JANGAN PERNAH bertanya balik atau mengajak user ngobrol.
2. JANGAN PERNAH memberikan alasan panjang lebar.
3. Berikan KEPUTUSAN FINAL yang sangat singkat (MAKSIMAL 1-6 KATA SAJA).
4. Gunakan huruf KAPITAL semua dan emoji heboh.
Contoh jawaban: "TIDAK AKAN PERNAH! 🙅‍♀️", "GAS TERUS! 🚀", "MIMPI AJA SANA! 🫵", "TENTU SAJA IYA! 💥", "COBA TANYA LAGI TAHUN DEPAN! 🏃‍♂️".`;
        
        let messagesArray = [
            { role: "system", content: systemPrompt },
            { role: "user", content: text }
        ];

        let response = await axios.post('https://api.botcahx.eu.org/api/search/openai-custom-v2', {
            apikey: apikey,
            message: messagesArray
        });

        let data = response.data;
        let aiAnswer = "";

        if (data && data.status && data.result) {
            aiAnswer = data.result;
        } else {
            aiAnswer = "SINYAL KERANG PUTUS! 📡💥";
        }

        await delay(1500); 

        // Tampilan santai tapi tetap rapi
        let responseText = `🐚 *KERANG AJAIB*\n\n` +
                           `🗣️ *Kamu:* ${text}\n` +
                           `🔊 *Kerang:* ${aiAnswer.trim()}`;

        await sock.sendMessage(m.chat, { text: responseText }, { quoted: m });
        
        user.limit -= 1;
        await m.react('✅');

    } catch (error) {
        console.error("[KERANG AI ERROR]", error);
        await m.react('❌');
        m.reply("Yah gagal, API-nya kayaknya lagi pusing deh. Coba lagi nanti ya!");
    }
}

handler.command = ['kerang'];
handler.tags = ['fun'];
handler.help = ['kerang <pertanyaan>'];

module.exports = handler;
