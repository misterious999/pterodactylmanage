// ==========================================
// 📊 FITUR RATE MULTIFUNGSI (ALL IN ONE)
// ⚙️ FIX: Karakteristik Respon Spesifik per Fitur
// ==========================================

let handler = async (m, { sock, text, command }) => {
    await m.react("📊");

    // Sistem Target & Tag (Anti Kaku)
    let rawName = text ? text.trim() : (m.pushName || "Kamu");
    let nameTarget = rawName;
    let targetMentions = [];

    if (m.mentionedJid && m.mentionedJid.length > 0) {
        rawName = m.mentionedJid[0].split('@')[0];
        nameTarget = `@${rawName}`;
        targetMentions.push(m.mentionedJid[0]);
    } else if (m.quoted && m.quoted.sender) {
        if (!text) {
            rawName = m.quoted.sender.split('@')[0];
            nameTarget = `@${rawName}`;
            targetMentions.push(m.quoted.sender);
        }
    }

    // Mesin RNG (Random Number Generator) 0-100%
    let persentase = Math.floor(Math.random() * 101);
    
    // Format Judul Rate
    let jenisRate = command.replace('rate', '').toUpperCase();
    
    // 🧠 KONFIGURASI KARAKTERISTIK SPESIFIK (EMOJI & PUNCHLINE)
    const rateConfig = {
        ratecantik: {
            emoji: '💅',
            high: "_MashaAllah cantik banget! Bidadari nyasar dari kayangan mana nih?_ 😍✨",
            med: "_Cantiknya natural, pas lah buat dipandangin lama-lama. Manis!_ 😊",
            low: "_Inner beauty itu yang utama! Btw, jangan lupa pake bedak dikit ya._ 🤭"
        },
        rategay: {
            emoji: '🏳️‍🌈',
            high: "_Waduh bahaya! Mending lu buruan ruqyah deh, radarnya kuat banget ini!_ 🏳️‍🌈🏃‍♂️💨",
            med: "_Agak sus nih... masih aman sih, tapi jangan suka peluk-peluk temen cowok lu!_ 🤨",
            low: "_Aman! Seratus persen straight sejati tanpa belokan!_ 🗿👍"
        },
        ratewibu: {
            emoji: '🎌',
            high: "_Bau bawangnya kerasa sampe sini! Udah berapa anime yang lu tonton season ini?_ 🎌🧅",
            med: "_Nonton anime sekadarnya doang nih, masih bisa berbaur sama masyarakat normal._ 😌",
            low: "_Wah, ini mah fix normies sejati. Gak tau apa-apa soal jejepangan!_ 👏"
        },
        rateganteng: {
            emoji: '😎',
            high: "_Silau banget Bosku! Kadar kegantengan lu udah over limit, pesonanya parah!_ 😎✨",
            med: "_Masih masuk standar SNI lah, rajin-rajin cuci muka aja biar makin bersinar._ 😏",
            low: "_Waduh... butuh banyak doa dan skincare ekstra nih kayanya. Sabar ya!_ 😭🙏"
        },
        rategila: {
            emoji: '🤪',
            high: "_Fix RSJ mana yang kebobolan nih?! Udah stadium akhir gilanya, tolong diamankan!_ 🤪🏥",
            med: "_Stress dikit doang efek kurang piknik atau beban hidup. Masih waras lah!_ 🥴",
            low: "_Warasss pol! Mental aman, jiwa tenang, fix orang paling normal di grup ini._ 😇"
        },
        rategambar: {
            emoji: '🎨',
            high: "_Masterpiece! Level dewa ini mah, udah cocok buka komisi art luar negeri!_ 🎨🔥",
            med: "_Bagus kok, potensi senimannya udah keliatan. Tinggal diasah lagi aja!_ 🖌️✨",
            low: "_Ini gambar apa sandi rumput? Kayaknya mending fokus hobi lain aja deh..._ 📉💀"
        },
        ratesuara: {
            emoji: '🎤',
            high: "_Merdu banget! Suara lu bikin adem, udah cocok ikut audisi Indonesian Idol nih!_ 🎤🎶",
            med: "_Not bad lah, lumayan buat nyanyi di kamar mandi biar ga sepi._ 🚿🎵",
            low: "_Tolong... telingaku berdarah! Mending puasa nyanyi dulu aja ya._ 😭🙉"
        }
    };

    // Ambil konfigurasi (jika command tidak ada di list, pakai default fallback)
    let config = rateConfig[command] || {
        emoji: '🔮',
        high: "_Wah, skor kamu tinggi banget! Udah mendarah daging ini mah..._ 🔥",
        med: "_Yaa lumayan lah, masih dalam batas normal orang biasa._ 😌",
        low: "_Aman! Kamu terbukti bersih dari indikasi ini!_ 😇"
    };

    // Meracik Pesan Aesthetic
    let teksHasil = `╭───┈ *「 ${config.emoji} CEK ${jenisRate} 」*\n`;
    teksHasil += `│ 👤 *Target:* ${nameTarget}\n`;
    teksHasil += `│ 📊 *Hasil:* ${persentase}%\n`;
    teksHasil += `╰───────────────┈ ⳹\n\n`;

    // Eksekusi Penilaian Kocak berdasarkan persentase
    if (persentase > 80) {
        teksHasil += config.high;
    } else if (persentase > 40) {
        teksHasil += config.med;
    } else {
        teksHasil += config.low;
    }

    // Kirim Pesan
    await sock.sendMessage(m.chat, { 
        text: teksHasil, 
        mentions: targetMentions 
    }, { quoted: m });
}

handler.command = ["ratecantik", "rategay", "ratewibu", "rateganteng", "rategila", "rategambar", "ratesuara"];
handler.tags = ["fun"];

module.exports = handler;
