const axios = require('axios');

let handler = async (m, { sock, prefix, command }) => {
    let apiKey = global.btc;
    
    if (!apiKey) {
        return m.reply(`❌ *Sistem API Terkunci!*\nAPI Key BOTCAHX belum diatur di \`config.js\` (global.btc).`);
    }

    // Efek mikir keras ala wibu
    await sock.sendMessage(m.chat, { react: { text: "💬", key: m.key } });
    await m.reply('⏳ _Menarik kata-kata bijak dari dimensi anime..._');

    try {
        const apiUrl = global.botcahxUrl('/api/random/animequotes');
        const { data } = await axios.get(apiUrl);

        // 🔍 DEBUG SYSTEM: Intip jeroan API di Pterodactyl
        console.log("\n[ 🔍 DATA ASLI API ANIME QUOTES ]\n", JSON.stringify(data, null, 2), "\n");

        // 🎯 SUPER EXTRACTOR V5 (KHUSUS MULTI-DATA)
        // Masuk ke kamar utama dulu
        let quoteObj = data.data || data.result || data;
        
        // Jaga-jaga kalau API cuma ngasih teks mentahan tanpa nama karakter
        if (typeof quoteObj === 'string') {
             return m.reply(`╭───┈ *「 🎌 ANIME QUOTES 」*\n│\n│ "${quoteObj}"\n│\n│ ⚡ *Powered by Assistant X*\n╰───────────────┈ ⳹`);
        }

        // Ekstrak Teks, Karakter, dan Anime (Deteksi otomatis berbagai nama variabel)
        let quoteText = quoteObj.quote || quoteObj.quotes || quoteObj.text || quoteObj.kata;
        let charName = quoteObj.character || quoteObj.char || quoteObj.tokoh || "Unknown Character";
        let animeName = quoteObj.anime || quoteObj.title || "Unknown Anime";

        if (!quoteText) {
            return m.reply("❌ API merespon, tapi teks quotes tidak ditemukan. Cek konsol Pterodactyl bosku!");
        }

        // Bingkai estetik khas Assistant X
        let captionQuote = `╭───┈ *「 🎌 ANIME QUOTES 」*\n│\n│ 💬 "${quoteText}"\n│\n│ 👤 *Character:* ${charName}\n│ 🎬 *Anime:* ${animeName}\n│\n│ ⚡ *Powered by Assistant X*\n╰───────────────┈ ⳹`;

        await m.reply(captionQuote);

    } catch (err) {
        console.error("[ ANIME QUOTES API ERROR ]", err.message);
        m.reply("❌ Terjadi masalah koneksi ke server BOTCAHX.");
    }
}

handler.tags = ['fun'];
handler.help = ['animequote', 'quotesanime'];
handler.command = ['animequote', 'quotesanime', 'kataanime'];

module.exports = handler;
