// ==========================================
// 💤 FITUR AFK (CHILL & ELEGANT STYLE)
// ==========================================

let handler = async (m, { sock, text }) => {
    let user = global.db.users[m.sender];
    if (!user) return m.reply("❌ *Waduh!*\nKakak belum terdaftar di database nih, daftar dulu yuk!");

    // Filter alasan agar rapi dan tidak terlalu panjang
    let alasan = text ? (text.length > 100 ? text.slice(0, 100) + "..." : text) : "Lagi ada urusan / Sibuk";

    user.afk = +new Date(); 
    user.afkReason = alasan;

    // 💄 BINGKAI MEWAH TAPI BAHASA SANTAI
    let teks = `💤 *M O D E   A F K   O N* 💤\n\n`;
    teks += `╭───「 *INFO STATUS* 」\n`;
    teks += `│ ◦ 👤 Kak: *@${m.sender.split('@')[0]}*\n`;
    teks += `│ ◦ 📌 Alasan: *${alasan}*\n`;
    teks += `╰──────────────\n\n`;
    teks += `_Siapp! Kakak santai aja dulu, kalau ada yang tag, biar aku yang hadepin dan kasih tau mereka!_ 🛡️✨`;

    await sock.sendMessage(m.chat, { 
        text: teks, 
        mentions: [m.sender],
        contextInfo: {
            mentionedJid: [m.sender],
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: global.idChannelDaftar || "120363425560678349@newsletter", 
                newsletterName: "Assistant X Auto-Responder 📡",
                serverId: 1
            }
        }
    }, { quoted: m });
}

// ==========================================
// 📡 MESIN PENDETEKSI AFK (AUTO-WAKE & MENTION DETECT)
// ==========================================
handler.before = async (m, { sock }) => {
    let user = global.db.users[m.sender];
    let now = +new Date();
    
    if (!m.text || m.isBaileys) return false;

    // 1️⃣ SKENARIO: ORANG YANG AFK NGETIK LAGI (AUTO-WAKE)
    if (user && user.afk > 1000000000000 && (now - user.afk) > 3000) {
        let durasi = clockString(now - user.afk);
        
        user.afk = -1;
        user.afkReason = '';

        // 💄 BAHASA WELCOME BACK YANG ASIK
        let teksBalik = `🎉 *W E L C O M E   B A C K !* 🎉\n\n`;
        teksBalik += `╭───「 *STATUS UPDATE* 」\n`;
        teksBalik += `│ ◦ 👤 Kak: *@${m.sender.split('@')[0]}*\n`;
        teksBalik += `│ ◦ ⏱️ Ngilang selama: *${durasi}*\n`;
        teksBalik += `╰──────────────\n\n`;
        teksBalik += `_Akhirnya balik juga! Mode AFK udah aku matiin ya, selamat beraktivitas lagi!_ 🚀✨`;

        await sock.sendMessage(m.chat, { 
            text: teksBalik, 
            mentions: [m.sender],
            contextInfo: {
                mentionedJid: [m.sender],
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: global.idChannelDaftar || "120363425560678349@newsletter",
                    newsletterName: "Assistant X System 📡",
                    serverId: 1
                }
            }
        }, { quoted: m });
    }

    // 2️⃣ SKENARIO: ADA YANG MENTION / ME-REPLY ORANG YANG LAGI AFK
    let jids = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])];
    for (let jid of jids) {
        let afkUser = global.db.users[jid];
        
        if (!afkUser || !afkUser.afk || afkUser.afk < 1000000000000) continue;
        
        let reason = afkUser.afkReason || 'Tanpa Alasan';
        let durasi = clockString(now - afkUser.afk);
        let pushNameTarget = jid.split('@')[0];

        // 💄 BAHASA NGELARANG ORANG NGGANGGU YANG LAGI AFK
        let teksTag = `🤫 *Ssssttt! Jangan berisik...* 🤫\n\n`;
        teksTag += `Kak *@${pushNameTarget}* lagi mode AFK nih. Jangan diganggu dulu ya!\n\n`;
        teksTag += `╭───「 *INFO TARGET* 」\n`;
        teksTag += `│ ◦ 📌 Alasan: *${reason}*\n`;
        teksTag += `│ ◦ ⏱️ Sejak: *${durasi} yang lalu*\n`;
        teksTag += `╰──────────────\n\n`;
        teksTag += `_Pesan kamu udah aku catet kok, nanti pasti dibaca pas orangnya balik!_ 📝✨`;

        await sock.sendMessage(m.chat, { 
            text: teksTag, 
            mentions: [jid],
            contextInfo: {
                mentionedJid: [jid],
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: global.idChannelDaftar || "120363425560678349@newsletter",
                    newsletterName: "Assistant X Security 📡",
                    serverId: 1
                }
            }
        }, { quoted: m });
    }
    
    // Memastikan bot tidak mati suri
    return false; 
}

// ==========================================
// ⏰ FUNGSI PENGHITUNG WAKTU
// ==========================================
function clockString(ms) {
    let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000);
    let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24;
    let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60;
    let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60;
    
    let res = '';
    if (d > 0) res += d + ' hari ';
    if (h > 0) res += h + ' jam ';
    if (m > 0) res += m + ' menit ';
    if (s > 0) res += s + ' detik';
    return res.trim() || 'Baru saja';
}

handler.command = ['afk'];
handler.tags = ['fun'];
handler.help = ['afk <alasan>'];

module.exports = handler;
