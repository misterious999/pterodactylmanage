const fetch = require('node-fetch');

// ==========================================
// 🔠 FITUR SAMBUNG SUKU KATA (MULTIPLAYER)
// 🧠 OTAK KBBI (30.000+ KATA) & TAG FIX
// ==========================================

let kamus = [];

// ⚙️ MESIN PENYEDOT 30.000+ KATA DASAR
(async () => {
    try {
        console.log("⏳ [SK MULTI] Sedang menyedot puluhan ribu kosakata KBBI...");
        let res = await fetch("https://raw.githubusercontent.com/sastrawi/sastrawi/master/data/kata-dasar.txt");
        let text = await res.text();
        
        kamus = text.split('\n').map(v => v.trim().toLowerCase()).filter(v => v.length > 2 && !v.includes('-') && !v.includes(' '));
        console.log(`✅ [SK MULTI] Sukses! Otak bot sekarang memiliki ${kamus.length} kosakata baku!`);
    } catch (e) {
        console.error("❌ [SK MULTI] Gagal menyedot kamus dari internet.", e);
        kamus = ["apel", "awan", "botol", "cinta", "dunia", "elang", "gajah", "harimau", "ikan", "jalan", "saku", "kurang", "kantor"]; 
    }
})();

// ✂️ MESIN PEMOTONG SUKU KATA TERAKHIR
function getSukuKataTerakhir(kata) {
    const vokal = "aeiou";
    let lastVokalIdx = -1;
    
    for (let i = kata.length - 1; i >= 0; i--) {
        if (vokal.includes(kata[i])) {
            lastVokalIdx = i;
            break;
        }
    }
    
    if (lastVokalIdx === -1) return kata; 

    if (lastVokalIdx > 0 && !vokal.includes(kata[lastVokalIdx - 1])) {
        let start = lastVokalIdx - 1;
        if (start > 0 && !vokal.includes(kata[start - 1])) {
            let gabungan = kata[start - 1] + kata[start];
            if (['ng', 'ny', 'sy', 'kh', 'pr', 'tr', 'gr', 'kl', 'kr', 'pl'].includes(gabungan)) {
                start = start - 1;
            }
        }
        return kata.slice(start);
    } else {
        return kata.slice(lastVokalIdx); 
    }
}

let handler = async (m, { sock, args, prefix, command }) => {
    sock.skmulti = sock.skmulti || {};
    let room = sock.skmulti[m.chat];

    let action = args[0] ? args[0].toLowerCase() : '';

    // 💡 TAMPILAN PANDUAN UTAMA
    if (!action) {
        let panduan = `╭───┈ *「 ⚔️ SK MULTIPLAYER 」*\n`;
        panduan += `│ Main Sambung *Suku Kata*\n`;
        panduan += `│ bareng grup! (Battle Royale)\n`;
        panduan += `├───────────────┈ ⳹\n`;
        panduan += `│ *🎮 CARA MAIN:*\n`;
        panduan += `│ ◦ \`${prefix + command} create\` : Bikin Room\n`;
        panduan += `│ ◦ \`${prefix + command} join\` : Masuk ke Room\n`;
        panduan += `│ ◦ \`${prefix + command} start\` : Mulai Pertandingan\n`;
        panduan += `│ ◦ \`${prefix + command} leave\` : Keluar dari Room\n`;
        panduan += `╰───────────────┈ ⳹\n\n`;
        panduan += `> _Bot telah menghafal ${kamus.length > 1000 ? '30.000+' : kamus.length} kosakata KBBI!_`;
        return m.reply(panduan);
    }

    // 🛠️ MEMBUAT ROOM
    if (action === 'create') {
        if (room) return m.reply("❌ Udah ada Room yang aktif di grup ini bosku! Ketik `.sk join` aja.");
        
        sock.skmulti[m.chat] = {
            id: m.chat,
            state: 'WAITING',
            host: m.sender,
            players: [m.sender],
            usedWords: [],
            turnIndex: 0,
            lastSyllable: '',
            timer: null
        };
        
        let teksCreate = `✅ *Room Berhasil Dibuat!*\n\nAyo yang lain ketik \`${prefix + command} join\` untuk ikut bermain!\n\n*(Pemain: 1)*\n1. @${m.sender.split('@')[0]}`;
        // 🔥 FIX TAG: Menggunakan sock.sendMessage
        return sock.sendMessage(m.chat, { text: teksCreate, mentions: [m.sender] }, { quoted: m });
    }

    // 🙋‍♂️ MASUK KE ROOM
    if (action === 'join') {
        if (!room) return m.reply(`❌ Belum ada Room nih. Bikin dulu pakai \`${prefix + command} create\``);
        if (room.state === 'PLAYING') return m.reply("❌ Yah, gamenya udah keburu mulai bosku. Tunggu ronde depan ya!");
        if (room.players.includes(m.sender)) return m.reply("❌ Kamu kan udah di dalem Room bosku!");

        room.players.push(m.sender);
        
        // 🔥 UPDATE DAFTAR PEMAIN OTOMATIS
        let listPemain = room.players.map((v, i) => `${i + 1}. @${v.split('@')[0]}`).join('\n');
        
        let teksJoin = `✅ *Berhasil Bergabung!*\n\n*Daftar Pemain (${room.players.length}):*\n${listPemain}\n\nSilakan Host (@${room.host.split('@')[0]}) ketik \`${prefix + command} start\` kalau udah siap!`;
        
        // 🔥 FIX TAG: Semua pemain ter-tag dengan rapi
        return sock.sendMessage(m.chat, { text: teksJoin, mentions: room.players }, { quoted: m });
    }

    // 🏃‍♂️ KELUAR ROOM
    if (action === 'leave') {
        if (!room) return m.reply("❌ Nggak ada Room yang aktif.");
        if (!room.players.includes(m.sender)) return m.reply("❌ Kamu aja belum join bosku.");
        
        if (room.state === 'PLAYING') {
            return m.reply("❌ Dilarang kabur pas game udah mulai! Cemen lu!");
        }

        room.players = room.players.filter(p => p !== m.sender);
        
        let teksLeave = `👋 @${m.sender.split('@')[0]} keluar dari Room.`;
        sock.sendMessage(m.chat, { text: teksLeave, mentions: [m.sender] }, { quoted: m });

        if (room.players.length === 0 || m.sender === room.host) {
            delete sock.skmulti[m.chat];
            sock.sendMessage(m.chat, { text: "⚠️ Karena Host keluar atau Room kosong, Room otomatis dibubarkan!" });
        }
        return;
    }

    // 🚀 MEMULAI PERTANDINGAN
    if (action === 'start') {
        if (!room) return m.reply("❌ Bikin room dulu woy!");
        if (room.host !== m.sender) return m.reply("❌ Cuma Host (Pembuat Room) yang bisa mulai gamenya!");
        if (room.players.length < 2) return m.reply("❌ Minimal 2 orang bosku biar seru! Ajak temenmu dulu.");
        if (room.state === 'PLAYING') return m.reply("❌ Gamenya udah jalan kocak.");

        if (kamus.length === 0) kamus = ["botol", "cinta", "dunia", "saku", "kurang"];

        room.state = 'PLAYING';
        let startWord = kamus[Math.floor(Math.random() * kamus.length)];
        room.usedWords.push(startWord);
        room.lastSyllable = getSukuKataTerakhir(startWord);
        
        room.players = room.players.sort(() => Math.random() - 0.5);
        room.turnIndex = 0;

        let teksStart = `🔥 *GAME DIMULAI!* 🔥\n\nKata pertama dari Bot:\n💬 *${startWord.toUpperCase()}*\n\nGiliran pertama adalah @${room.players[room.turnIndex].split('@')[0]}\nSilakan balas dengan kata berawalan: *${room.lastSyllable.toUpperCase()}*\n\n*(Waktu: 30 Detik)*`;
        
        // 🔥 FIX TAG
        await sock.sendMessage(m.chat, { text: teksStart, mentions: [room.players[room.turnIndex]] }, { quoted: m });

        mulaiTimerEliminasi(sock, m.chat, room);
    }
}

// ⏱️ SISTEM TIMER MAUT & ELIMINASI
function mulaiTimerEliminasi(sock, chatId, room) {
    clearTimeout(room.timer);
    room.timer = setTimeout(async () => {
        let pemainGagal = room.players[room.turnIndex];
        
        room.players.splice(room.turnIndex, 1);
        
        let teksEliminasi = `💀 *TENG TENG TENG! WAKTU HABIS!*\n\n@${pemainGagal.split('@')[0]} tereliminasi karena lambat mikir! 😂\n\n`;

        if (room.players.length === 1) {
            let pemenang = room.players[0];
            
            let userDb = global.db?.users?.[pemenang];
            if (userDb) {
                userDb.balance = (userDb.balance || 0) + 5000;
                userDb.xp = (userDb.xp || 0) + 2000;
            }

            teksEliminasi += `🏆 *WINNER WINNER CHICKEN DINNER!* 🏆\nSelamat @${pemenang.split('@')[0]} berhasil memenangkan game ini!\n\n🎁 *Hadiah Jackpot:*\n🪙 +5.000 Saldo\n✨ +2.000 EXP`;
            delete sock.skmulti[chatId];
            return sock.sendMessage(chatId, { text: teksEliminasi, mentions: [pemainGagal, pemenang] });
        }

        if (room.turnIndex >= room.players.length) room.turnIndex = 0; 
        let nextPlayer = room.players[room.turnIndex];

        teksEliminasi += `Giliran berpindah ke @${nextPlayer.split('@')[0]}\nLanjutkan dengan awalan suku kata: *${room.lastSyllable.toUpperCase()}*!`;
        
        await sock.sendMessage(chatId, { text: teksEliminasi, mentions: [pemainGagal, nextPlayer] });
        mulaiTimerEliminasi(sock, chatId, room);

    }, 30000); 
}

// 📡 LISTENER: Menangkap balasan
handler.before = async (m, { sock }) => {
    sock.skmulti = sock.skmulti || {};
    let room = sock.skmulti[m.chat];

    if (!room || room.state !== 'PLAYING' || m.isBaileys || !m.text) return;

    let currentPlayer = room.players[room.turnIndex];
    let jawaban = m.text.toLowerCase().trim();

    if (m.sender !== currentPlayer) return;
    if (jawaban.includes(' ')) return;

    if (!jawaban.startsWith(room.lastSyllable)) {
        return m.reply(`❌ Salah woy! Harus berawalan suku kata *${room.lastSyllable.toUpperCase()}*`);
    }

    if (room.usedWords.includes(jawaban)) {
        return m.reply("❌ Kata itu udah dipakai tadi! Cari kata lain bosku.");
    }

    if (!kamus.includes(jawaban)) {
        return m.reply("❌ Kata itu nggak ada di kamus bot! Jangan ngarang bahasa alien 😂");
    }

    // ✅ JAWABAN BENAR!
    room.usedWords.push(jawaban);
    room.lastSyllable = getSukuKataTerakhir(jawaban);
    
    room.turnIndex++;
    if (room.turnIndex >= room.players.length) room.turnIndex = 0;
    
    let nextPlayer = room.players[room.turnIndex];

    mulaiTimerEliminasi(sock, m.chat, room);

    let teksBenar = `✅ *BENAR!*\n\nSelanjutnya @${nextPlayer.split('@')[0]}\nBalas kata dengan awalan: *${room.lastSyllable.toUpperCase()}*! ⏱️ (30 Detik)`;
    
    sock.sendMessage(m.chat, { text: teksBenar, mentions: [nextPlayer] });
}

handler.command = ["sk"];
handler.tags = ["game"];
handler.help = ["sk"];

module.exports = handler;
