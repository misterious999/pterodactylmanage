// ==========================================
// 🎙️ FITUR TEXT TO SPEECH (VOICE NOTE GOOGLE)
// ==========================================

let handler = async (m, { sock, args, text, prefix, command }) => {
    // 💡 JIKA USER HANYA MENGETIK PERINTAH .TTS TANPA TEKS
    if (!text) {
        await m.react("⚠️");
        let contoh = `╭───『 🎙️ *TEXT TO SPEECH* 』\n`;
        contoh += `│ ❌ Teksnya mana bosku?\n`;
        contoh += `├──────────────── ⳹\n`;
        contoh += `│ *💡 Contoh Penggunaan:*\n`;
        contoh += `│ ◦ Default (ID): \`${prefix + command} Halo bosku!\`\n`;
        contoh += `│ ◦ Bahasa Lain: \`${prefix + command} ja arigatou\`\n`;
        contoh += `├──────────────── ⳹\n`;
        contoh += `│ *🌐 Daftar Kode Bahasa VIP:*\n`;
        contoh += `│ 🇮🇩 \`id\` : Indonesia\n`;
        contoh += `│ 🇬🇧 \`en\` : Inggris\n`;
        contoh += `│ 🇯🇵 \`ja\` : Jepang\n`;
        contoh += `│ 🇰🇷 \`ko\` : Korea\n`;
        contoh += `│ 🇸🇦 \`ar\` : Arab\n`;
        contoh += `│ 🇨🇳 \`zh\` : Cina/Mandarin\n`;
        contoh += `│ 🇫🇷 \`fr\` : Prancis\n`;
        contoh += `│ 🇪🇸 \`es\` : Spanyol\n`;
        contoh += `│ 🇷🇺 \`ru\` : Rusia\n`;
        contoh += `│ 🇹🇭 \`th\` : Thailand\n`;
        contoh += `│ 🗺️ \`jv\` : Jawa  |  \`su\` : Sunda\n`;
        contoh += `╰──────────────── ⳹\n`;
        contoh += `> _Ketik kode bahasa di awal kalimat jika ingin mengubah logat suara._`;
        return m.reply(contoh);
    }

    await m.react("⏳");

    try {
        let lang = 'id'; // Default menggunakan bahasa Indonesia
        let teksToSpeak = text;

        // 🧠 MESIN PENDETEKSI KODE BAHASA
        const langPattern = /^[a-z]{2}$/i;
        if (args.length >= 2 && langPattern.test(args[0])) {
            lang = args[0].toLowerCase();
            teksToSpeak = text.substring(args[0].length).trim(); 
        }

        // 🛡️ LIMITASI KARAKTER 
        if (teksToSpeak.length > 250) {
            await m.react("⚠️");
            return m.reply("❌ Teks kepanjangan bosku! Maksimal 250 karakter saja ya.");
        }

        // 🌐 GENERATOR API URL GOOGLE TTS
        let ttsUrl = `https://translate.googleapis.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(teksToSpeak)}&tl=${lang}&client=tw-ob`;

        // 📤 KIRIM SEBAGAI VOICE NOTE (VN)
        await sock.sendMessage(m.chat, {
            audio: { url: ttsUrl },
            mimetype: 'audio/mp4',
            ptt: true // Dikirim layaknya Voice Note asli
        }, { quoted: m });

        await m.react("✅");

    } catch (err) {
        console.error("[ ERROR TTS ]", err.message);
        await m.react("❌");
        m.reply("❌ Gagal memproses suara. Server Google mungkin sedang memblokir permintaan kita.");
    }
}

// 🔐 SETTINGAN REGISTER HANDLER UTAMA
handler.command = ["tts"];
handler.tags = ["fun"];
handler.help = ["tts <kode_bahasa> <teks>"];
handler.limit = true; 

module.exports = handler;
