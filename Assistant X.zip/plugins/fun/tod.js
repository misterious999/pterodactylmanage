// ==========================================
// 🎭 FITUR TRUTH OR DARE (MEGA DATABASE)
// ==========================================

let handler = async (m, { sock, command }) => {
    await m.react("🎭");

    // 🤫 DATABASE TRUTH (55 PERTANYAAN JUJUR)
    const truthList = [
        "Siapa orang di grup ini yang diem-diem sering kamu stalking sosmednya?",
        "Apa aib terbesar kamu yang nggak ada satu pun orang di grup ini tau?",
        "Sebutkan satu nama orang di grup ini yang sifatnya paling bikin kamu kesel!",
        "Pernah nggak naksir sama pacar temen sendiri? Jujur!",
        "Apa kebohongan terbesar yang pernah kamu ceritain ke orang tua?",
        "Kalau kamu harus pacaran sama satu orang di grup ini, kamu pilih siapa?",
        "Pernah nangis gara-gara hal sepele nggak? Gara-gara apa?",
        "Siapa orang terakhir yang kamu chat sebelum buka grup ini?",
        "Sebutkan satu hal yang bikin kamu ngerasa *insecure* sampai sekarang!",
        "Pernah pura-pura tidur pas dichat sama seseorang? Siapa orangnya?",
        "Apa riwayat pencarian (history) paling aneh di Google kamu hari ini?",
        "Siapa mantan yang paling susah kamu lupain sampai sekarang?",
        "Pernah nggak ketahuan ngomongin orang dari belakang? Gimana rasanya?",
        "Kalau dikasih uang 10 juta, hal bodoh apa yang bakal kamu lakuin pertama kali?",
        "Sebutkan 3 sifat jelek kamu yang susah banget diubah!",
        "Siapa orang di grup ini yang menurutmu paling caper (cari perhatian)?",
        "Pernah nggak mandi berhari-hari tapi bilangnya udah mandi?",
        "Apa mimpi paling aneh atau memalukan yang pernah kamu alami?",
        "Pernah ngirim chat salah kamar ke grup keluarga? Ceritain detailnya!",
        "Siapa orang di grup ini yang paling sering bikin kamu ketawa?",
        "Kalau dunia kiamat besok, siapa satu orang di grup ini yang mau kamu peluk?",
        "Pernah nggak nyolong uang orang tua meski cuma seribu perak?",
        "Apa alasan paling konyol yang pernah kamu pake buat putus sama pacar?",
        "Sebutkan kontak WA yang namanya kamu kasih emot paling alay!",
        "Pernah nggak ngerasa paling pinter di antara temen-temen tongkrongan?",
        "Siapa orang di grup ini yang mukanya paling beda sama foto profilnya?",
        "Apa hal paling memalukan yang pernah kamu lakuin di depan gebetan?",
        "Pernah nggak sengaja kentut bunyi di tempat umum? Di mana?",
        "Berapa kali kamu ditolak sama orang yang kamu suka?",
        "Siapa member grup ini yang pengen banget kamu kick kalau kamu jadi admin?",
        "Pernah nggak nangis pas dengerin lagu galau padahal lagi nggak patah hati?",
        "Apa rahasia temen kamu yang sampai sekarang masih kamu simpen rapat?",
        "Sebutkan satu barang aneh yang ada di kamar kamu sekarang!",
        "Pernah kepikiran buat selingkuh dari pacar kamu yang sekarang/dulu?",
        "Siapa orang di grup ini yang menurutmu paling cakep/cantik?",
        "Pernah nggak nge-stalk mantan pakai akun *fake*?",
        "Apa nama panggilan paling alay yang pernah dikasih mantan ke kamu?",
        "Pernah ngiler pas tidur sampai bantalnya basah kuyup? Kapan terakhir kali?",
        "Sebutkan hal yang paling bikin kamu ilfil sama lawan jenis!",
        "Pernah nggak ketahuan nyontek pas ujian? Terus gimana kelanjutannya?",
        "Siapa orang di grup ini yang paling sering ngutang / minta traktir?",
        "Pernah nggak nge-block orang tanpa alasan yang jelas? Siapa?",
        "Apa hal paling berani yang pernah kamu lakuin demi cinta?",
        "Pernah nggak ngerasa iri banget sama pencapaian temen sendiri?",
        "Sebutkan satu kebiasaan jorok kamu pas lagi sendirian di kamar!",
        "Siapa orang di grup ini yang paling enak diajak curhat?",
        "Pernah nggak bikin akun *roleplay* atau pakai foto *fake* di sosmed?",
        "Apa penyesalan terbesar kamu di masa lalu yang masih keinget terus?",
        "Kalau bisa tukar nasib selama sehari sama orang di grup ini, kamu pilih siapa?",
        "Pernah ketiduran di tempat yang nggak wajar? Di mana?",
        "Siapa orang yang diam-diam kamu benci tapi di depan sok akrab?",
        "Pernah ngerasa dijauhin tongkrongan nggak? Kenapa?",
        "Apa hal yang paling kamu takutin kalau sampai ketahuan orang tua?",
        "Sebutkan satu kebohongan yang masih kamu pertahankan sampai detik ini!",
        "Pernah nggak berantem fisik sama temen sendiri gara-gara hal sepele?"
    ];

    // 😈 DATABASE DARE (55 TANTANGAN GILA)
    const dareList = [
        "Kirim VN (Voice Note) nyanyi lagu Balonku Ada Lima tapi vokalnya diganti huruf 'O' semua!",
        "Tag satu orang di grup ini dan bilang 'Aku naksir kamu dari dulu' tanpa penjelasan apa-apa!",
        "Jadikan foto profil WA kamu jadi foto paling aib/jelek selama 1 jam dari sekarang!",
        "Ketik dan kirim chat 'Aku sayang kalian semua' ke grup keluarga kamu, lalu screenshot kirim ke sini!",
        "Ganti nama WA kamu jadi 'Anak Pungut' selama sehari!",
        "Spam emot 🐒 ke 3 kontak teratas di WA kamu sekarang! Screenshot buktinya!",
        "Kirim foto terakhir yang ada di galeri HP kamu ke grup ini (dilarang hapus/sensor)!",
        "Kirim VN neriakin nama mantan kamu sekeras-kerasnya!",
        "Tag member grup ke-3 dan bilang 'Kamu jelek banget hari ini'.",
        "Tulis status WA 'Aku butuh belaian' dan biarkan selama 1 jam! Screenshot buktinya!",
        "Kirim VN baca teks Pancasila tapi pakai nada nangis bombay!",
        "Chat salah satu dosen/guru kamu nanya 'Bapak/Ibu udah makan belum?'. Screenshot balasannya!",
        "Ganti bio WA kamu jadi 'Aku jomblo ngenes, tolong nikahi aku' selama sehari!",
        "Kirim foto muka kamu dari angle bawah (double chin kelihatan) ke grup ini sekarang!",
        "Tag admin grup dan gombalin dia pakai kata-kata paling *cringe* yang kamu tau!",
        "Kirim VN niruin suara tokek selama 10 detik tanpa ketawa!",
        "Chat mantan kamu (atau gebetan lama) bilang 'Kangen'. Screenshot kirim sini!",
        "Ketik pesan ini dengan mata tertutup: 'Saya berjanji akan traktir semua orang di grup ini'.",
        "Kirim emot 😭💔 ke chat terakhir di WA kamu, siapapun itu orangnya!",
        "Kirim VN ngomong 'Halo ayang, selamat malam' pakai suara paling imut/sok imut!",
        "Bikin polling di grup ini dengan pertanyaan 'Siapa yang paling jelek?' dan isi opsinya nama kamu sendiri semua!",
        "SS (Screenshot) chat WA kamu sama pacar/gebetan, kirim ke grup ini sekarang!",
        "Tag orang yang paling sering spam di grup ini dan suruh dia diam!",
        "Ganti PP WA pakai foto artis India paling *random* yang kamu temuin di Google selama 2 jam!",
        "Kirim VN nyanyi reff lagu dangdut kesukaan ibu kamu!",
        "Chat teman beda lawan jenis bilang 'Sebenarnya aku udah lama mendam perasaan sama kamu'. SS kirim sini!",
        "Kirim foto isi saldo rekening/e-wallet kamu sekarang (boleh sensor nominalnya, tapi riwayat transaksinya jangan)!",
        "Kirim VN ketawa jahat ala psikopat selama 15 detik!",
        "Balas story WA orang pertama yang muncul di beranda kamu dengan kata 'Jelek banget woy'.",
        "Tag orang paling cakep di grup ini dan minta foto selfie dia sekarang juga!",
        "Kirim 10 stiker paling absurd/random yang ada di HP kamu ke grup ini berturut-turut!",
        "Kirim VN curhat nangis-nangis gara-gara semut mati keinjek!",
        "Ubah nama WA kamu jadi nama mantan/gebetan kamu selama 12 jam!",
        "Spam chat P (Ping) ke orang yang terakhir kali chat kamu sebanyak 20 kali!",
        "Buat status WA foto langit gelap kasih lagu galau, tulis caption 'Semuanya berakhir...'.",
        "Kirim VN perkenalan diri pakai bahasa daerah dengan nada ngegas/marah-marah!",
        "Tag 5 orang secara acak di grup ini dan bilang 'Kalian semua punya utang sama aku!'.",
        "Chat 'Aku lagi hamil/Aku ngehamilin anak orang' ke sahabat terdekat kamu. Tunggu balasannya lalu SS!",
        "Pencet nomor kontak ke-7 di WA kamu, lalu telpon dan matiin saat mulai berdering (Missed Call)!",
        "Kirim VN niruin suara operator jualan kuota/provider!",
        "Ganti wallpaper chat WA kamu pakai foto orang tua, lalu SS salah satu room chat kirim ke sini!",
        "Tag semua admin grup dan bilang 'Kalian kerjaannya ngapain aja sih?'.",
        "Kirim meme paling receh/garing yang ada di galeri kamu, dan paksa semua orang ketawa!",
        "Kirim VN ngomong pakai bahasa Inggris belepotan kayak anak TK!",
        "Chat orang tua/keluarga bilang 'Ma/Pa, aku mau nikah bulan depan'. SS kirim ke sini!",
        "Foto kondisi kaki kamu sekarang juga dan kirim ke grup tanpa editan!",
        "Kirim teks panjang menceritakan betapa bersyukurnya kamu masuk grup ini (minimal 5 baris)!",
        "Kirim VN nge-rap lagu Balonku Ada Lima dengan beatbox sendiri!",
        "SS riwayat tontonan YouTube kamu yang paling atas dan kirim ke grup!",
        "Tag member grup paling pendiam dan kasih dia 1 pertanyaan aneh bebas!",
        "Bikin pantun buat orang terakhir yang ngechat di grup ini sebelum kamu!",
        "Kirim foto wallpaper *homescreen* HP kamu sekarang juga ke grup!",
        "Chat gebetan/mantan pakai teks *Capslock* semua bilang 'KITA HARUS KETEMU SEKARANG!'.",
        "Kirim VN pura-pura jadi reporter yang lagi ngeliput berita banjir pakai gaya heboh!",
        "Tag 1 orang di grup ini yang pengen banget kamu ajak gelut, lalu kasih emot 🥊!"
    ];

    let isTruth = command === "truth" || command === "jujur";
    let arrayPilihan = isTruth ? truthList : dareList;
    let hasilRandom = arrayPilihan[Math.floor(Math.random() * arrayPilihan.length)];
    
    let emojiTipe = isTruth ? '🤫' : '😈';
    let judulTipe = isTruth ? 'TRUTH (JUJUR)' : 'DARE (TANTANGAN)';

    let teksHasil = `╭───┈ *「 ${emojiTipe} ${judulTipe} 」*\n`;
    teksHasil += `│ 👤 *Player:* ${m.pushName || "Kamu"}\n`;
    teksHasil += `├───────────────┈ ⳹\n`;
    teksHasil += `│ *Tugasmu:* \n`;
    teksHasil += `│ "${hasilRandom}"\n`;
    teksHasil += `╰───────────────┈ ⳹\n\n`;
    
    teksHasil += isTruth ? `_Awas kalau bohong, dosa ditanggung sendiri!_ ⚡` : `_Laksanakan sekarang atau kamu penakut!_ 🔥`;

    await sock.sendMessage(m.chat, { text: teksHasil }, { quoted: m });
}

handler.command = ["truth", "dare", "tod"];
handler.tags = ["fun"];
handler.help = ["tod"];

module.exports = handler;
