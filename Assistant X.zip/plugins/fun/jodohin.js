// ==========================================
// 💘 FITUR BIRO JODOH GRUP
// ==========================================

let handler = async (m, { sock, participants }) => {
    // Validasi: Harus di dalam grup
    if (!m.isGroup) {
        await m.react("❌");
        return m.reply("❌ Fitur biro jodoh ini cuma bisa dipakai di dalam grup bosku!");
    }

    await m.react("💘");

    // Ambil semua member grup
    let member = participants.map(u => u.id);
    
    // Pilih 2 orang secara acak
    let jodoh1 = member[Math.floor(Math.random() * member.length)];
    let jodoh2 = member[Math.floor(Math.random() * member.length)];
    
    // Pastikan jodoh1 dan jodoh2 tidak sama (masa nikah sama diri sendiri)
    while (jodoh1 === jodoh2) {
        jodoh2 = member[Math.floor(Math.random() * member.length)];
    }

    let persentase = Math.floor(Math.random() * 101);
    
    let teksHasil = `╭───┈ *「 💘 BIRO JODOH 」*\n`;
    teksHasil += `│ ✨ @${jodoh1.split('@')[0]}\n`;
    teksHasil += `│ ❤️ *DIJODOHKAN DENGAN* ❤️\n`;
    teksHasil += `│ ✨ @${jodoh2.split('@')[0]}\n`;
    teksHasil += `├───────────────┈ ⳹\n`;
    teksHasil += `│ 📊 *Kecocokan:* ${persentase}%\n`;
    teksHasil += `╰───────────────┈ ⳹\n\n`;

    if (persentase > 80) {
        teksHasil += `_Cieee! Udah fix ini mah jodoh dari langit, buruan sebar undangan!_ 🥳`;
    } else if (persentase > 40) {
        teksHasil += `_Boleh juga nih dicoba, siapa tau beneran nyaman kan?_ 😏`;
    } else {
        teksHasil += `_Sabar ya, kayaknya kalian lebih cocok jadi teman berantem aja..._ 🤣`;
    }

    await sock.sendMessage(m.chat, { 
        text: teksHasil, 
        mentions: [jodoh1, jodoh2] 
    }, { quoted: m });
}

handler.command = ["jodohin"];
handler.tags = ["fun"];

module.exports = handler;
