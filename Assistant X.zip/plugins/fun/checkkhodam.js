const fetch = require('node-fetch');

// ==========================================
// 👻 FITUR CEK KHODAM (VERSI TEKS & TAG FIX)
// ==========================================

let handler = async (m, { sock, text }) => {
    try {
        await m.react("👻");

        // 1. 🎯 SISTEM TARGET & TAGGING YANG BENAR
        let rawName = text ? text.trim() : (m.pushName || "Hamba Allah");
        let nameCekodam = rawName;
        let targetMentions = [];

        // Deteksi jika ngetag orang atau reply pesan
        if (m.mentionedJid && m.mentionedJid.length > 0) {
            rawName = m.mentionedJid[0].split('@')[0]; 
            nameCekodam = `@${rawName}`; // Format biar teksnya biru
            targetMentions.push(m.mentionedJid[0]);
        } else if (m.quoted && m.quoted.sender) {
            if (!text) {
                rawName = m.quoted.sender.split('@')[0];
                nameCekodam = `@${rawName}`;
                targetMentions.push(m.quoted.sender);
            }
        }

        // 2. Ambil API Key
        let apikey = global.btc;
        if (!apikey) return m.reply("❌ BOTCAHX_APIKEY belum diisi di file .env!");

        // 3. Tarik data Khodam dari API
        let apiUrl = global.botcahxUrl('/api/game/kodam');
        let res = await fetch(apiUrl);
        if (!res.ok) throw new Error("API Sedang Down");
        let json = await res.json();

        // 4. 🧲 FIX EKSTRAKSI DATA (Anti Sayur Rebus)
        let kodam = "Khodam Kosong";
        if (typeof json.data === 'string') {
            kodam = json.data; 
        } else if (json.data && json.data.nama) {
            kodam = json.data.nama;
        } else if (typeof json.kodam === 'string') {
            kodam = json.kodam;
        }

        // 5. Rakit Teks Estetik
        let teksHasil = `╭───┈ *「 👻 TERAWANGAN KHODAM 」*\n`;
        teksHasil += `│ 👤 *Nama:* ${nameCekodam}\n`;
        teksHasil += `│ 👹 *Khodam:* ${kodam}\n`;
        teksHasil += `╰───────────────┈ ⳹\n\n`;
        teksHasil += `_Bisikan gaib telah diterima dari dimensi lain..._ ✨`;

        // 📤 KIRIM HASIL TEKS SAJA (Dengan Mentions)
        await sock.sendMessage(m.chat, { 
            text: teksHasil, 
            mentions: targetMentions 
        }, { quoted: m });

        await m.react("✅");

    } catch (e) {
        console.error("[ ERROR KHODAM ]", e.message);
        await m.react("❌");
        m.reply("❌ Waduh, gagal menerawang Khodam. Dukunnya lagi istirahat!");
    }
}

handler.command = ["cekkodam"];
handler.tags = ["fun"];
handler.help = ["cekkodam <nama/@tag>"];

module.exports = handler;
