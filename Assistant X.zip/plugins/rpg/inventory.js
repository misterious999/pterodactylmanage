const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

// ==========================================
// 🎒 INVENTORY & STATS - XENORIA CHRONICLES
// ⚙️ Ciptaan Pstar7 | Minimalist UI & Anti-Drop Fix
// ==========================================

let handler = async (m, { sock, prefix, command }) => {
    let user = global.db.users[m.sender];
    
    if (!user || !user.registered) return m.reply(`❌ Kamu belum menginjakkan kaki di Benua Xenoria!\nKetik \`${prefix}daftar nama.umur\` untuk memulai takdirmu!`);
    
    if (!user.rpg || user.rpg.role === 'Novice') {
        return m.reply(`⚠️ Kamu masih seorang *Novice* tanpa perlengkapan.\nSilakan pilih kekuatanmu dulu dengan ketik: \`${prefix}awaken\``);
    }

    let rpg = user.rpg;
    let inv = rpg.inventory || {};

    // ==========================================
    // 🛡️ FUNGSI BANTUAN PENGIRIM TOMBOL ANTI-DROP
    // ==========================================
    async function sendRPGButton(teks, arrayTombol) {
        let pesan = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: { 
                message: { 
                    interactiveMessage: proto.Message.InteractiveMessage.create({ 
                        body: proto.Message.InteractiveMessage.Body.create({ text: teks }), 
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: "© Xenoria Inventory" }), 
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons: arrayTombol }),
                        contextInfo: { 
                            mentionedJid: [m.sender],
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: global.idChannel || "1203631@newsletter", 
                                newsletterName: "Xenoria Server", 
                                serverId: 1 
                            }
                        }
                    }) 
                } 
            }
        }, { quoted: m }); // Quoted M untuk menjamin pesan terkoneksi dan tidak di-spam WA
        return sock.relayMessage(m.chat, pesan.message, { messageId: pesan.key.id });
    }

    let teks = `🎒 *TAS PETUALANG*\n\n`;
    teks += `👤 *Pahlawan:* ${user.name}\n`;
    teks += `🔰 *Role:* ${rpg.role}\n`;
    teks += `⚔️ *Senjata:* ${rpg.weapon}\n`;
    teks += `🛡️ *Armor:* ${rpg.armor}\n\n`;

    teks += `❤️ *STATUS VITAL*\n`;
    teks += `❤️ HP: ${rpg.hp}/${rpg.max_hp} | 💙 MP: ${rpg.mp}/${rpg.max_mp}\n`;
    teks += `🗡️ ATK: ${rpg.attack} | 🛡️ DEF: ${rpg.defense}\n`;
    teks += `🔮 MAG: ${rpg.magic || 0}\n\n`;

    // ==========================================
    // 📦 FILTER & KATEGORISASI ITEM (SYNCED)
    // ==========================================
    
    // 1. Consumables & Gacha (Barang Pakai & Jarahan)
    let consumables = {
        '📦 Peti Harta': inv.crate || 0,
        '🥤 HP Potion': inv.potion || 0,
        '🧪 Mana Potion': inv.mana || 0,
        '🦴 Monster Loot': inv.monster_loot || 0
    };

    // 2. Valuables (Barang Berharga untuk Bank)
    let valuables = {
        '🪙 Gold Ore': inv.gold || 0,
        '💎 Diamond': inv.diamond || 0,
        '🔮 Boss Core': inv.boss_core || 0
    };

    // 3. Basic Materials (Bahan Crafting Biasa)
    let basicMats = {
        '🪵 Wood': inv.wood || 0,
        '⛓️ Iron Ore': inv.iron || 0,
        '🕸️ String': inv.string || 0,
        '💠 Crystal': inv.crystal || 0
    };

    // 4. Epic Materials (Bahan Crafting Khusus Role)
    let epicMats = {
        '🐉 Dragon Bone': inv.dragon_bone || 0,
        '🪄 Mana Crystal': inv.mana_crystal || 0,
        '🥷 Shadow Essence': inv.shadow_essence || 0,
        '🏹 Enchanted Wood': inv.enchanted_wood || 0,
        '💀 Cursed Soul': inv.cursed_soul || 0,
        '✨ Divine Steel': inv.divine_steel || 0
    };

    // FUNGSI BUILDER TEKS KATEGORI
    let totalItems = 0;
    const buildCategory = (title, itemGroup) => {
        let catText = `*${title}*\n`;
        let hasItem = false;
        for (let [name, total] of Object.entries(itemGroup)) {
            if (total > 0) {
                catText += `◦ ${name}: ${total}\n`;
                hasItem = true;
                totalItems++;
            }
        }
        if (!hasItem) catText += `_(Kosong)_\n`;
        return catText + `\n`; // Jarak spasi antar kategori
    };

    teks += buildCategory("🎒 PERBEKALAN & LOOT", consumables);
    teks += buildCategory("💎 ASET BERHARGA", valuables);
    teks += buildCategory("🔨 BAHAN MATERIAL", basicMats);
    teks += buildCategory("🌟 MATERIAL EPIC", epicMats);

    if (totalItems === 0) teks += `_Tasmu benar-benar kosong melompong. Pergilah berburu!_ 🍃\n\n`;

    // ==========================================
    // 🎮 TOMBOL INTERAKTIF (SHORTCUT)
    // ==========================================
    let arrayTombol = [
        { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "⚔️ Berburu", id: `${prefix}adventure` }) },
        { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🛒 Buka Toko", id: `${prefix}shop` }) },
        { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🏦 Ke Bank", id: `${prefix}bank` }) }
    ];

    await m.react('🎒');
    return sendRPGButton(teks.trim(), arrayTombol);
}

handler.command = ["inv", "inventory"];
handler.tags = ["rpg"];
handler.help = ["inventory"];

module.exports = handler;
