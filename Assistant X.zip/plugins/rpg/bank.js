const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

// ==========================================
// 🏦 BANK XENORIA (PLAY TO EARN SYSTEM)
// ⚙️ Ciptaan Pstar7 | Premium Bank UI & Anti-Drop
// ==========================================

let handler = async (m, { sock, args, prefix, command }) => {
    let user = global.db.users[m.sender];
    
    if (!user || !user.registered) return m.reply(`❌ Kamu belum menginjakkan kaki di Benua Xenoria!`);
    let rpg = user.rpg;
    if (!rpg || rpg.role === 'Novice') return m.reply(`⚠️ Bank hanya melayani Pahlawan resmi. Lakukan Awakening dulu!`);
    
    rpg.inventory = rpg.inventory || {};
    let inv = rpg.inventory;
    
    let action = args[0] ? args[0].toLowerCase() : '';
    let itemTukar = args[1] ? args[1].toLowerCase() : '';
    let jumlah = args[2] ? parseInt(args[2]) : 1;

    if (jumlah < 1 || isNaN(jumlah)) jumlah = 1;

    const exchangeRates = {
        'gold': { name: '🪙 Gold Ore', rate: 5000 },
        'diamond': { name: '💎 Diamond', rate: 50000 },
        'boss_core': { name: '🔮 Boss Core', rate: 250000 }
    };

    const botName = global.botname || "Assistant X Project";

    // 🛡️ FUNGSI BANTUAN PENGIRIM TOMBOL ANTI-DROP
    async function sendRPGButton(teks, arrayTombol) {
        let pesan = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: `© ${botName} Bank` }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons: arrayTombol }),
                        contextInfo: { 
                            participant: "0@s.whatsapp.net",
                            remoteJid: "status@broadcast",
                            quotedMessage: {
                                imageMessage: {
                                    caption: `Sistem Perbankan Pusat | ${botName}`
                                }
                            }
                        }
                    })
                }
            }
        }, {});
        return sock.relayMessage(m.chat, pesan.message, { messageId: pesan.key.id });
    }

    // HANDLER TRANSAKSI (TUKAR BARANG)
    if (action === 'tukar' || action === 'exchange') {
        if (!itemTukar || !exchangeRates[itemTukar]) {
            return m.reply(`❌ Bank hanya menerima: Gold, Diamond, dan Boss Core!`);
        }

        let currentItem = inv[itemTukar] || 0;
        if (currentItem < jumlah) {
            return m.reply(`⚠️ Transaksi Ditolak! Saldo brankasmu hanya memiliki ${currentItem}x ${exchangeRates[itemTukar].name}.`);
        }

        let totalDapat = exchangeRates[itemTukar].rate * jumlah;
        inv[itemTukar] -= jumlah;
        user.balance += totalDapat;

        await m.react('💸').catch(() => {});
        
        let struk = `🧾 ＴＲＡＮＳＡＣＴＩＯＮ\n`;
        struk += `───────────────\n`;
        struk += `✅ *EXCHANGE SUCCESSFUL*\n\n`;
        struk += `◈ ＤＥＴＡＩＬＳ ◈\n`;
        struk += `📦 *Item:* ${jumlah}x ${exchangeRates[itemTukar].name}\n`;
        struk += `📉 *Rate:* Rp ${exchangeRates[itemTukar].rate.toLocaleString('id-ID')} / item\n`;
        struk += `💵 *Cair:* +Rp ${totalDapat.toLocaleString('id-ID')}\n\n`;
        struk += `◈ ＢＡＬＡＮＣＥ ◈\n`;
        struk += `💳 *Saldo Akhir:* Rp ${user.balance.toLocaleString('id-ID')}\n\n`;
        struk += `_"Dana telah masuk ke vault utamamu."_`;

        return sendRPGButton(struk, [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "💼 Cek Tas", id: `${prefix}inv` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🏦 Menu Bank", id: `${prefix}${command}` }) }
        ]);
    }

    // TAMPILAN MENU UTAMA BANK
    let teksMenu = `🏦 ＢＡＮＫ  ＸＥＮＯＲＩＡ\n`;
    teksMenu += `───────────────\n`;
    teksMenu += `👤 *Nasabah :* ${user.name || m.pushName || 'Pahlawan'}\n`;
    teksMenu += `💳 *Rekening:* ${rpg.role}\n`;
    teksMenu += `💰 *Saldo   :* Rp ${user.balance.toLocaleString('id-ID')}\n\n`;
    
    teksMenu += `◈ ＡＳＳＥＴ  ＶＡＵＬＴ ◈\n`;
    teksMenu += `◦ 🪙 *Gold Ore*  : ${inv.gold || 0}\n`;
    teksMenu += `◦ 💎 *Diamond*   : ${inv.diamond || 0}\n`;
    teksMenu += `◦ 🔮 *Boss Core* : ${inv.boss_core || 0}\n\n`;
    
    teksMenu += `◈ ＥＸＣＨＡＮＧＥ  ＲＡＴＥ ◈\n`;
    teksMenu += `📈 1 Gold Ore  = Rp 5.000\n`;
    teksMenu += `📈 1 Diamond   = Rp 50.000\n`;
    teksMenu += `📈 1 Boss Core = Rp 250.000\n\n`;
    teksMenu += `_"Investasi terbaik untuk bertahan hidup di Dungeon..."_\n`;
    teksMenu += `───────────────\n`;
    teksMenu += `💡 _Manual: \`${prefix}${command} tukar <item> <jumlah>\`_`;

    let arrayTombol = [
        { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "💸 Tukar 1 Gold", id: `${prefix}${command} tukar gold 1` }) },
        { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "💎 Tukar 1 Diamond", id: `${prefix}${command} tukar diamond 1` }) },
        { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔮 Tukar 1 Boss Core", id: `${prefix}${command} tukar boss_core 1` }) }
    ];

    return sendRPGButton(teksMenu, arrayTombol);
}

// RULES #3: HANDLER HANYA BOLEH 1
handler.command = ["bank"];
handler.tags = ["rpg"];
module.exports = handler;
