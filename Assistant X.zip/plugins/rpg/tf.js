let handler = async (m, { sock, args, prefix, command }) => {
  let user = global.db.users[m.sender]
  
  if (!user || !user.registered) {
    await m.react("⚠️")
    return m.replyPremium("❌ Kamu belum terdaftar di database!")
  }

  // Tentukan target dan jumlah transfer (Support Reply & Tag)
  let target;
  let amount;

  if (m.quoted) {
      // 🔄 METODE BARU: Membalas (Reply) pesan target
      target = m.quoted.sender;
      amount = parseInt(args[0]);
  } else {
      // 🏷️ METODE LAMA: Menggunakan Tag atau Nomor
      if (args.length < 2) {
          await m.react("⚠️")
          let teksFormat = `❌ *Format salah!*\n\n`
          teksFormat += `*💡 Cara Paling Mudah (Baru):*\nBalas pesan orangnya lalu ketik: \`${prefix + command} 1000\`\n\n`
          teksFormat += `*📌 Cara Manual (Tag/Nomor):*\n\`${prefix + command} @tag 1000\`\n\`${prefix + command} 628xxx 1000\``
          return m.replyPremium(teksFormat)
      }
      target = m.mentionedJid[0] ? m.mentionedJid[0] : (args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net');
      amount = parseInt(args[1]);
  }

  // Validasi keamanan target dan jumlah
  if (!target) return m.replyPremium("❌ Target tidak valid!");
  if (!global.db.users[target]) return m.replyPremium("❌ Pengguna tujuan tidak ditemukan di database.\nSuruh dia mengirim pesan apa saja dulu di grup ini agar terdaftar di sistem.");
  if (target === m.sender) return m.replyPremium("❌ Kamu tidak bisa transfer ke dirimu sendiri!");
  if (isNaN(amount) || amount < 1) return m.replyPremium("❌ Jumlah transfer harus berupa angka lebih dari 0!");

  // 🔥 Sistem Pajak Merakyat (0.03%)
  let pajak = Math.ceil(amount * 0.0003) 
  let totalPotongan = amount + pajak

  // Cek kecukupan saldo termasuk pajak
  if (user.balance < totalPotongan) {
    await m.react("❌")
    return m.replyPremium(`❌ Balance kamu tidak cukup!\n\nBiaya transfer: ${amount}\nPajak Server (0.03%): ${pajak}\n*Total Dibutuhkan:* ${totalPotongan}\n*Balance Kamu:* ${user.balance}`)
  }

  await m.react("⏳")

  // Eksekusi pemindahan dana
  user.balance -= totalPotongan
  global.db.users[target].balance = (global.db.users[target].balance || 0) + amount

  await m.react("✅")
  
  // Struk Transfer Aesthetic
  let teks = `╭───┈ *「 💸 TRANSFER BERHASIL 」*\n`
  teks += `│ 👤 *Penerima:* @${target.split('@')[0]}\n`
  teks += `│ 💰 *Jumlah:* ${amount} Balance\n`
  teks += `│ 📉 *Pajak (0.03%):* ${pajak} Balance\n`
  teks += `╰───────────────┈ ⳹\n\n`
  teks += `_Sisa Balance kamu saat ini: ${user.balance}_`

  sock.sendMessage(m.chat, { text: teks, mentions: [target] }, { quoted: m })
}

handler.command = ["tf"]
handler.tags = ["rpg"]
handler.help = ["transfer <reply/tag> <jumlah>"]

module.exports = handler
