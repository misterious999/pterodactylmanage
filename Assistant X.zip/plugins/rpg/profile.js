'use strict';

const { generateWAMessageFromContent } = require('@whiskeysockets/baileys');

// ==========================================
// 🌸 HANDLER PROFIL (AESTHETIC PREMIUM EDITION)
// ==========================================
let handler = async (m, { sock, isOwner }) => {
    try {
        let user = global.db.users[m.sender];
        if (!user) return m.reply("❌ Ihh, kamu belum terdaftar di *database* Mini! Daftar dulu ya~");

        await m.react('⏳').catch(() => {});

        // Inisialisasi Data Default
        user.level = user.level || 0;
        user.xp = user.xp || 0;
        user.balance = user.balance || 0;
        user.limit = user.limit || 0;
        user.rpg = user.rpg || {};

        let rpg = user.rpg;
        let roleName = rpg.role || 'Novice';

        // Logika Auto Level Up
        let isLevelUp = false;
        let xpNeeded = 50 * Math.pow(user.level, 2) + 50 * user.level + 100;

        while (user.xp >= xpNeeded) {
            user.level++;
            user.xp -= xpNeeded;
            isLevelUp = true;

            if (roleName !== 'Novice') {
                let growth = { hp: 20, mp: 20, magic: 10 };
                rpg.max_hp = (rpg.max_hp || 500) + growth.hp;
                rpg.max_mp = (rpg.max_mp || 400) + growth.mp;
                rpg.max_magic = (rpg.max_magic || 100) + growth.magic;
                rpg.hp = rpg.max_hp;
                rpg.mp = rpg.max_mp;
                rpg.magic = rpg.max_magic;
            }
            xpNeeded = 50 * Math.pow(user.level, 2) + 50 * user.level + 100;
        }

        let role = user.level >= 100 ? 'Mythic 👑' : 
                   user.level >= 50 ? 'Epic' : 
                   user.level >= 30 ? 'Master' : 
                   user.level >= 20 ? 'Elite' : 
                   user.level >= 10 ? 'Amateur' : 
                   user.level >= 5 ? 'Trainee' : 'Beginner';

        let statusAkses = isOwner ? 'Developer 👑' : (user.premium ? 'Premium 🌟' : 'Member');
        let userName = user.name || m.pushName || 'Pahlawan';

        // --- SISTEM EQUIPMENT & BONUS STATS ---
        let equipped = rpg.equipped || { weapon: null, armor: null };
        let weaponObj = equipped.weapon;
        let armorObj = equipped.armor;

        let weaponName = weaponObj ? `${weaponObj.name} [Lv.${weaponObj.level || 1}]` : 'Tangan Kosong';
        let armorName = armorObj ? `${armorObj.name} [Lv.${armorObj.level || 1}]` : 'Pakaian Pemula';

        let baseAtk = rpg.attack || 0;
        let baseDef = rpg.defense || 0;
        
        let bonusAtk = weaponObj && weaponObj.stat ? (weaponObj.stat.attack || 0) : 0;
        let bonusDef = armorObj && armorObj.stat ? (armorObj.stat.defense || 0) : 0;

        let totalAtk = baseAtk + bonusAtk;
        let totalDef = baseDef + bonusDef;
        // ------------------------------------------------

        // Perhitungan Persentase Status
        let maxHP = rpg.max_hp || 500;
        let maxMP = rpg.max_mp || 400;
        let persentaseXP = Math.min(100, Math.max(0, (user.xp / xpNeeded) * 100));
        let persentaseHP = maxHP > 0 ? Math.min(100, Math.max(0, ((rpg.hp || 0) / maxHP) * 100)) : 0;
        let persentaseMP = maxMP > 0 ? Math.min(100, Math.max(0, ((rpg.mp || 0) / maxMP) * 100)) : 0;

        // Visual Progress Bar (Blok Klasik)
        function makeBar(percent) {
            const totalBlocks = 10;
            const filledBlocks = Math.round((percent / 100) * totalBlocks);
            const emptyBlocks = totalBlocks - filledBlocks;
            return '■'.repeat(filledBlocks) + '□'.repeat(emptyBlocks);
        }

        const botName = global.botname || "Assistant X Project";
        const levelUpMsg = isLevelUp ? `> 🎊 *L E V E L  U P ! (Lv.${user.level})*\n\n` : '';

        // Merakit UI Aesthetic Premium Edition
        const textOutput = `> ✧ ─── ＰＲＯＦＩＬＥ ─── ✧

${levelUpMsg}> 👤 *NAMA :* ${userName}
> ⚚ *CLASS:* ${roleName} [Lv.${user.level}]
> 👑 *RANK :* ${role}
> 💎 *TIER :* ${statusAkses}

> ◈ ─ ＶＩＴＡＬＩＴＹ ─ ◈
> ❤️ *HP* [${makeBar(persentaseHP)}] ${rpg.hp || 0}/${maxHP}
> 💙 *MP* [${makeBar(persentaseMP)}] ${rpg.mp || 0}/${maxMP}
> 🌟 *XP* [${makeBar(persentaseXP)}] ${persentaseXP.toFixed(1)}%

> ◈ ─ ＡＴＴＲＩＢＵＴＥ ─ ◈
> ⚔️ *ATK :* ${totalAtk} ${bonusAtk ? `(+${bonusAtk})` : ''}
> 🛡️ *DEF :* ${totalDef} ${bonusDef ? `(+${bonusDef})` : ''}
> 🔮 *MAG :* ${rpg.magic || 0}/${rpg.max_magic || 100}
> 🎒 *WPN :* ${weaponName}
> 🦺 *AMR :* ${armorName}

> ◈ ─ ＥＣＯＮＯＭＹ ─ ◈
> 🪙 *Koin :* Rp ${Number(user.balance).toLocaleString('id-ID')}
> 🎫 *Limit:* ${user.limit}

> ▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
> ✦ 𝗦𝗬𝗦𝗧𝗘𝗠 𝗦𝗬𝗡𝗖𝗛𝗥𝗢𝗡𝗜𝗭𝗘𝗗 ✦`;

        // Eksekusi ke WA dengan Quoted Status & Button Petualangan
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: { text: textOutput },
                        footer: { text: `© ${botName}` },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "⚔️ Mulai Petualangan",
                                        id: ".adventure"
                                    })
                                }
                            ]
                        },
                        contextInfo: {
                            participant: "0@s.whatsapp.net",
                            remoteJid: "status@broadcast",
                            quotedMessage: {
                                imageMessage: {
                                    caption: `Pusat Informasi Sistem | ${botName}`
                                }
                            }
                        }
                    }
                }
            }
        }, {}); 

        await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        
        if (isLevelUp) await m.react('🎉').catch(() => {});
        else await m.react('✅').catch(() => {});

    } catch (e) {
        console.error(e);
        await m.react('❌').catch(() => {});
        m.reply(`[System Error]: Gagal memuat profil pemain.\nDetail: ${e.message}`);
    }
};

// ==========================================
// ⚙️ KONFIGURASI PLUGIN (STRICTLY SATU COMMAND)
// ==========================================
handler.command = ['profile', 'me'];
handler.tags = ['rpg'];
handler.help = ['profile'];

module.exports = handler;
