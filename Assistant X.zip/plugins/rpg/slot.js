// ==========================================
// 🎰 RPG SLOT MACHINE (MANIPULATIVE CASINO)
// ==========================================

let handler = async (m, { sock, args, prefix, command }) => {
    let user = global.db.users[m.sender];
    if (!user) return m.reply("❌ Kamu belum terdaftar di database bot!");

    if (typeof user.balance !== 'number') user.balance = 0;

    if (!args[0]) {
        let petunjuk = `╭──「 *🎰 PSTAR7 CASINO* 」\n`;
        petunjuk += `│ 💰 Saldo kamu: Rp ${user.balance.toLocaleString('id-ID')}\n`;
        petunjuk += `│\n`;
        petunjuk += `│ *Tingkat Taruhan (Multiplier):*\n`;
        petunjuk += `│ 🟢 Mental Pengecut (< 50k): Hadiah x3\n`;
        petunjuk += `│ 🟡 Mental Berani (< 500k): Hadiah x5\n`;
        petunjuk += `│ 🔴 High Roller (< 5M): Hadiah x10\n`;
        petunjuk += `│ 💀 SULTAN GILA (> 5M): MAXWIN x50!!\n`;
        petunjuk += `╰────────────\n\n`;
        petunjuk += `*Cara Main:*\n> \`${prefix + command} <jumlah>\`\n_Berani taruhan gede biar cepat kaya, atau mending pulang aja?_ 🗿`;
        return m.reply(petunjuk);
    }

    let bet = parseInt(args[0]);

    if (isNaN(bet) || bet < 500) return m.reply("❌ *Minimal taruhan adalah 500!*\nBawa uang receh dilarang masuk kasino!");
    if (user.balance < bet) return m.reply(`❌ *Saldo kamu tidak cukup!*\nSisa saldo: Rp ${user.balance.toLocaleString('id-ID')}\n_Silakan cari modal lagi sana!_`);

    // ==========================================
    // 🧠 DYNAMIC RNG SYSTEM (TETAP DIAM-DIAM SUSAH)
    // ==========================================
    let winRate = 0;
    let multiplier = 0;
    let tier = "";

    // Winrate asli tetap kejam di belakang layar, tapi rahasia!
    if (bet <= 50000) {
        winRate = 0.40;
        multiplier = 3;
        tier = "🟢 PENGECUT";
    } else if (bet <= 500000) {
        winRate = 0.15;
        multiplier = 5;
        tier = "🟡 BERANI";
    } else if (bet <= 5000000) {
        winRate = 0.05;
        multiplier = 10;
        tier = "🔴 HIGH ROLLER";
    } else {
        winRate = 0.01;
        multiplier = 50;
        tier = "💀 SULTAN";
    }

    let isWin = Math.random() < winRate;

    // ==========================================
    // 🎨 VISUAL SLOT
    // ==========================================
    let emojis = ['🍒', '🍋', '🔔', '💎', '7️⃣', '🍉'];
    let res1, res2, res3;

    if (isWin) {
        let luckyEmoji = emojis[Math.floor(Math.random() * emojis.length)];
        res1 = luckyEmoji;
        res2 = luckyEmoji;
        res3 = luckyEmoji;
    } else {
        res1 = emojis[Math.floor(Math.random() * emojis.length)];
        res2 = emojis[Math.floor(Math.random() * emojis.length)];
        res3 = emojis[Math.floor(Math.random() * emojis.length)];

        while (res1 === res2 && res2 === res3) {
            res3 = emojis[Math.floor(Math.random() * emojis.length)];
        }
    }

    // Potong saldo di awal
    user.balance -= bet;

    // ==========================================
    // 🎬 ANIMASI
    // ==========================================
    let animMsg = await sock.sendMessage(m.chat, {
        text: `🎰 *MENGUNDI SLOT...* 🎰\n\n> ⬛ | ⬛ | ⬛ <\n\n_Taruhan: Rp ${bet.toLocaleString('id-ID')} [${tier}]_`
    }, { quoted: m });

    await new Promise(resolve => setTimeout(resolve, 800));
    await sock.sendMessage(m.chat, {
        text: `🎰 *MENGUNDI SLOT...* 🎰\n\n> ${res1} | ⬛ | ⬛ <\n\n_Taruhan: Rp ${bet.toLocaleString('id-ID')} [${tier}]_`,
        edit: animMsg.key
    });

    await new Promise(resolve => setTimeout(resolve, 800));
    await sock.sendMessage(m.chat, {
        text: `🎰 *MENGUNDI SLOT...* 🎰\n\n> ${res1} | ${res2} | ⬛ <\n\n_Taruhan: Rp ${bet.toLocaleString('id-ID')} [${tier}]_`,
        edit: animMsg.key
    });

    await new Promise(resolve => setTimeout(resolve, 800));

    // ==========================================
    // 🏆 HASIL & PROVOKASI
    // ==========================================
    let finalTeks = `╭──「 *🎰 PSTAR7 CASINO* 」\n`;
    finalTeks += `│\n`;
    finalTeks += `│   > [ ${res1} | ${res2} | ${res3} ] <\n`;
    finalTeks += `│\n`;

    if (isWin) {
        let prize = bet * multiplier;
        user.balance += prize;

        finalTeks += `│ 🎉 *JACKPOT MAXWIN!!* 🎉\n`;
        finalTeks += `│ + Rp ${prize.toLocaleString('id-ID')}\n`;
        finalTeks += `│ Saldo sekarang: Rp ${user.balance.toLocaleString('id-ID')}\n`;
        finalTeks += `╰────────────\n\n`;
        
        if (bet < 50000) {
            finalTeks += `_Cuma menang receh? Coba naikin taruhannya kalau berani nguras bandar!_ 🤑`;
        } else {
            finalTeks += `_GILA! Hoki lu lagi bagus, gas spin lagi mumpung mesinnya lagi panas!_ 🔥`;
        }
    } else {
        finalTeks += `│ 💀 *ANDA RUNGKAD!* 💀\n`;
        finalTeks += `│ - Rp ${bet.toLocaleString('id-ID')}\n`;
        finalTeks += `│ Sisa saldo: Rp ${user.balance.toLocaleString('id-ID')}\n`;
        finalTeks += `╰────────────\n\n`;

        // Provokasi kekalahan
        if (bet <= 50000) {
            finalTeks += `_Makanya jangan main receh! Mesinnya ogah ngasih jackpot ke mental pengecut! Naikin betnya!_ 🤣`;
        } else if (bet <= 500000) {
            finalTeks += `_Aduh dikit lagi tuh! Jangan nyerah sekarang bos, spin lagi pasti dapet!_ ✊🔥`;
        } else {
            finalTeks += `_NYARIS BANGET MAXWIN! Bandar udah ketar-ketir nih, ayo gas terus sampai bandar bangkrut!_ 💸🤬`;
        }

        // Kalau saldonya habis sampai 0
        if (user.balance <= 0) {
            finalTeks += `\n\n📉 *MAMPUS RUNGKAD TOTAL!* Saldo lu ludes ditarik bandar! Silakan ngemis/berburu lagi sana! 🗿`;
        }
    }

    await sock.sendMessage(m.chat, { text: finalTeks, edit: animMsg.key });
}

handler.command = ["slot"];
handler.tags = ["rpg"];
handler.help = ["slot <jumlah>"];

module.exports = handler;
