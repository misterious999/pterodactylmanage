const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

// ==========================================
// 🛒 TOKO RPG V2 (SYNCED & MINIMALIST UI)
// ==========================================

let handler = async (m, { sock, args, prefix, command }) => {
    let user = global.db.users[m.sender];
    if (!user || !user.registered) return m.reply(`❌ Kamu belum menginjakkan kaki di Benua Xenoria!`);
    
    let rpg = user.rpg;
    if (!rpg || rpg.role === 'Novice') return m.reply(`⚠️ Pedagang hanya melayani Pahlawan resmi. Pilih kekuatanmu dulu!`);
    rpg.inventory = rpg.inventory || {};

    // 🛡️ FUNGSI BANTUAN PENGIRIM TOMBOL ANTI-DROP
    async function sendRPGButton(teks, arrayTombol) {
        let pesan = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: "© Xenoria Shop ⛺" }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons: arrayTombol }),
                        contextInfo: { 
                            mentionedJid: [m.sender],
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: global.idChannel || "1203631@newsletter", 
                                newsletterName: "Xenoria Server", 
                                serverId: 1 
                            }
                        }
                    })
                }
            }
        }, { quoted: m }); 
        return sock.relayMessage(m.chat, pesan.message, { messageId: pesan.key.id });
    }

    const shopItems = {
        potion: { name: '🥤 HP Potion', price_buy: 500, price_sell: 250, desc: 'Memulihkan 200 HP' },
        mana: { name: '🧪 Mana Potion', price_buy: 800, price_sell: 400, desc: 'Memulihkan 100 MP' },
        crystal: { name: '💠 Crystal', price_buy: 3000, price_sell: 1500, desc: 'Bahan Sihir' },
        iron: { name: '⛓️ Iron', price_buy: 1500, price_sell: 800, desc: 'Bahan Tempa Senjata' },
        wood: { name: '🪵 Wood', price_buy: 1000, price_sell: 500, desc: 'Bahan Tempa Senjata' },
        string: { name: '🕸️ String', price_buy: 1200, price_sell: 600, desc: 'Bahan Tempa Armor' },
        monster_loot: { name: '🦴 Monster Loot', price_buy: null, price_sell: 1000, desc: 'Item Jarahan' },
        gold: { name: '🪙 Gold Ore', price_buy: null, price_sell: 5000, desc: 'Aset Bank' }
    };

    let action = args[0] ? args[0].toLowerCase() : '';
    let itemBuySell = args[1] ? args[1].toLowerCase() : '';
    let count = args[2] ? parseInt(args[2]) : 1;

    if (count < 1 || isNaN(count)) count = 1;

    if (action === 'buy' || action === 'beli') {
        if (!itemBuySell || !shopItems[itemBuySell] || shopItems[itemBuySell].price_buy === null) {
            return sendRPGButton(`❌ Barang *${itemBuySell}* tidak dijual di sini!\n_(Bahan Epic khusus Role hanya drop dari Boss/Monster)_`, [
                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔙 Ke Toko", id: `${prefix}${command}` }) }
            ]);
        }

        let totalCost = shopItems[itemBuySell].price_buy * count;
        if (user.balance < totalCost) {
            return sendRPGButton(`💸 *UANGMU KURANG!*\nKamu butuh *${totalCost} Saldo* untuk membeli ${count} ${shopItems[itemBuySell].name}.`, [
                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "⚔️ Cari Uang", id: `${prefix}adventure` }) },
                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔙 Kembali", id: `${prefix}${command}` }) }
            ]);
        }

        user.balance -= totalCost;
        rpg.inventory[itemBuySell] = (rpg.inventory[itemBuySell] || 0) + count;

        await m.react('🛒').catch(() => {});
        let struk = `🧾 *STRUK PEMBELIAN*\n\n`;
        struk += `🛍️ *Item:* ${count}x ${shopItems[itemBuySell].name}\n`;
        struk += `💸 *Total Biaya:* -${totalCost} 🪙\n`;
        struk += `💰 *Sisa Saldo:* ${user.balance} 🪙\n\n`;
        struk += `_Barang telah dilempar ke dalam tasmu._`;
        
        return sendRPGButton(struk, [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🛒 Beli Lagi", id: `${prefix}${command}` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🎒 Cek Tas", id: `${prefix}inv` }) }
        ]);
    }

    if (action === 'sell' || action === 'jual') {
        if (!itemBuySell || !shopItems[itemBuySell]) {
            return sendRPGButton(`❌ Pedagang menolak barang itu!`, [
                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔙 Ke Toko", id: `${prefix}${command}` }) }
            ]);
        }

        let owned = rpg.inventory[itemBuySell] || 0;
        if (owned < count) {
            return sendRPGButton(`🎒 Kamu hanya punya *${owned}* ${shopItems[itemBuySell].name}!`, [
                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🎒 Cek Tas", id: `${prefix}inv` }) }
            ]);
        }

        let totalRevenue = shopItems[itemBuySell].price_sell * count;
        rpg.inventory[itemBuySell] -= count;
        user.balance += totalRevenue;

        await m.react('🪙').catch(() => {});
        let struk = `🧾 *STRUK PENJUALAN*\n\n`;
        struk += `📦 *Item Terjual:* ${count}x ${shopItems[itemBuySell].name}\n`;
        struk += `📈 *Pendapatan:* +${totalRevenue} 🪙\n`;
        struk += `💰 *Total Saldo:* ${user.balance} 🪙\n\n`;
        struk += `_"Senang berbisnis denganmu, Pahlawan!"_`;
        
        return sendRPGButton(struk, [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "💰 Jual Lainnya", id: `${prefix}${command}` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "⚔️ Berburu Lagi", id: `${prefix}adventure` }) }
        ]);
    }

    let menu = `⛺ *PEDAGANG PENGEMBARA*\n\n`;
    menu += `👤 *Petualang:* ${m.pushName || 'Anonim'}\n`;
    menu += `💰 *Saldo:* ${user.balance} 🪙\n\n`;

    menu += `🛍️ *KATALOG BARANG*\n`;
    for (let key in shopItems) {
        let item = shopItems[key];
        if (item.price_buy !== null) {
            menu += `◦ *${item.name}* (\`${key}\`)\n`;
            menu += `  🏷️ Beli: ${item.price_buy} | 💰 Jual: ${item.price_sell}\n`;
        }
    }
    menu += `\n`;

    menu += `🦴 *PENGECUL LOOT*\n`;
    menu += `◦ *Monster Loot* (\`monster_loot\`)\n`;
    menu += `  💰 Harga Jual: 1000 🪙/pcs\n\n`;

    menu += `*TRANSAKSI MANUAL:*\n`;
    menu += `◦ Beli: \`${prefix}${command} buy <id> <jumlah>\`\n`;
    menu += `◦ Jual: \`${prefix}${command} sell <id> <jumlah>\`\n`;
    menu += `_Contoh:_ \`.shop buy crystal 5\``;

    let mainButtons = [
        { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🥤 Beli Potion (500)", id: `${prefix}${command} buy potion 1` }) },
        { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "💰 Jual 1 Loot (1000)", id: `${prefix}${command} sell monster_loot 1` }) },
        { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🎒 Buka Tas", id: `${prefix}inv` }) }
    ];

    return sendRPGButton(menu, mainButtons);
}

handler.command = ["shop", "toko", "pasar", "beli", "jual"];
handler.tags = ["rpg"];
module.exports = handler;
