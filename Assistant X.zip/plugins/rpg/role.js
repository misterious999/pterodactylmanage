// ==========================================
// 🌟 SISTEM AWAKENING (GACHA ROLE)
// ⚙️ Ciptaan Pstar7 | Rarity System & Animation
// ==========================================

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

let handler = async (m, { sock, prefix, command }) => {
    let user = global.db.users[m.sender];
    
    // Syarat Wajib: Harus terdaftar di Database Utama
    if (!user || !user.registered) return m.reply(`❌ Kamu belum terdaftar di dunia ini!\nKetik \`${prefix}daftar nama.umur\``);

    // 1. INJEKSI PONDASI DATABASE RPG
    if (!user.rpg) {
        user.rpg = {
            role: 'Novice',     
            hp: 100, mp: 50, attack: 10, magic: 0, defense: 10,
            weapon: 'Tangan Kosong', armor: 'Baju Kaos', skill: 'Pukulan Polos',
            inventory: { potion: 0, monster_loot: 0, iron: 0, gold: 0 }
        };
    }

    // 2. SISTEM LOCK (ANTI-GANTI ROLE)
    if (user.rpg.role !== 'Novice') {
        return m.reply(`⚠️ Takdirmu sudah tersegel sebagai *${user.rpg.role}*!\nSistem hanya memberikan satu kali Kebangkitan.`);
    }

    // 3. ANIMASI LOADING (DEG-DEGAN MODE)
    let animMsg = await sock.sendMessage(m.chat, { text: `╭───┈ *「 🌟 AWAKENING SYSTEM 」*\n│ Mencari resonansi jiwamu dengan kristal sihir...\n╰───────────────┈ ⳹` }, { quoted: m });
    await delay(1500);
    await sock.sendMessage(m.chat, { text: `╭───┈ *「 🌟 AWAKENING SYSTEM 」*\n│ ⬛⬛⬛⬜⬜ 60%\n│ Membaca takdir dari garis darahmu...\n╰───────────────┈ ⳹`, edit: animMsg.key });
    await delay(1500);
    await sock.sendMessage(m.chat, { text: `╭───┈ *「 🌟 AWAKENING SYSTEM 」*\n│ ⬛⬛⬛⬛⬛ 100%\n│ Energi bergejolak! Kelasmu telah ditentukan!\n╰───────────────┈ ⳹`, edit: animMsg.key });
    await delay(1500);

    // 4. MESIN GACHA RARITY (0 - 100)
    let gachaRoll = Math.random() * 100;
    let selectedClass = '';
    let rarity = '';

    if (gachaRoll <= 0.1) {
        // 👑 MYTHIC (0.1%) - Sangat Mustahil
        let mythicClasses = ['Dragon Slayer 🐉', 'Demon Lord 👿'];
        selectedClass = mythicClasses[Math.floor(Math.random() * mythicClasses.length)];
        rarity = '👑 MYTHIC (0.1%)';
    } 
    else if (gachaRoll <= 5) {
        // 🔴 LEGENDARY (4.9%) - Super Langka
        let legendClasses = ['Necromancer 💀', 'Paladin 🛡️✨'];
        selectedClass = legendClasses[Math.floor(Math.random() * legendClasses.length)];
        rarity = '🔴 LEGENDARY (4.9%)';
    } 
    else if (gachaRoll <= 30) {
        // 🔵 RARE (25%) - Langka
        let rareClasses = ['Mage 🪄', 'Assassin 🥷'];
        selectedClass = rareClasses[Math.floor(Math.random() * rareClasses.length)];
        rarity = '🔵 RARE (25%)';
    } 
    else {
        // 🟢 COMMON (70%) - Sering Muncul
        let commonClasses = ['Warrior 🗡️', 'Archer 🏹'];
        selectedClass = commonClasses[Math.floor(Math.random() * commonClasses.length)];
        rarity = '🟢 COMMON (70%)';
    }

    // 5. PENETAPAN STATUS BERDASARKAN KELAS
    user.rpg.role = selectedClass;

    if (selectedClass === 'Warrior 🗡️') {
        user.rpg.hp = 500; user.rpg.mp = 100; user.rpg.attack = 40; user.rpg.defense = 60;
        user.rpg.skill = 'Earthquake Smash 💥'; user.rpg.weapon = 'Pedang Karatan';
    } else if (selectedClass === 'Archer 🏹') {
        user.rpg.hp = 300; user.rpg.mp = 200; user.rpg.attack = 55; user.rpg.defense = 25;
        user.rpg.skill = 'Piercing Arrow 🎯'; user.rpg.weapon = 'Busur Panah Pemula';
    } else if (selectedClass === 'Mage 🪄') {
        user.rpg.hp = 200; user.rpg.mp = 400; user.rpg.magic = 70; user.rpg.defense = 20;
        user.rpg.skill = 'Meteor Strike ☄️'; user.rpg.weapon = 'Tongkat Sihir Kayu';
    } else if (selectedClass === 'Assassin 🥷') {
        user.rpg.hp = 250; user.rpg.mp = 150; user.rpg.attack = 70; user.rpg.defense = 15;
        user.rpg.skill = 'Shadow Assassination 🗡️💨'; user.rpg.weapon = 'Belati Tumpul';
    } else if (selectedClass === 'Necromancer 💀') {
        user.rpg.hp = 350; user.rpg.mp = 350; user.rpg.magic = 60; user.rpg.defense = 30;
        user.rpg.skill = 'Soul Extraction 👻'; user.rpg.weapon = 'Buku Kematian Kuno';
    } else if (selectedClass === 'Paladin 🛡️✨') {
        user.rpg.hp = 600; user.rpg.mp = 200; user.rpg.attack = 50; user.rpg.defense = 80;
        user.rpg.skill = 'Divine Judgment ⚔️✨'; user.rpg.weapon = 'Palu Suci Pemula';
    } else if (selectedClass === 'Dragon Slayer 🐉') {
        user.rpg.hp = 1000; user.rpg.mp = 500; user.rpg.attack = 150; user.rpg.defense = 100;
        user.rpg.skill = 'Dragons Breath 🔥'; user.rpg.weapon = 'Dragon Buster';
    } else if (selectedClass === 'Demon Lord 👿') {
        user.rpg.hp = 800; user.rpg.mp = 1000; user.rpg.magic = 200; user.rpg.defense = 80;
        user.rpg.skill = 'Hellfire Annihilation 🌋'; user.rpg.weapon = 'Sabit Malapetaka';
    }

    // 6. PENGUMUMAN HASIL GACHA
    let sukses = `╭───┈ *「 🎉 AWAKENING BERHASIL 」*\n`;
    sukses += `│ Cahaya terang menyelimuti tubuhmu!\n│\n`;
    sukses += `│ 👤 *Pahlawan:* ${user.name}\n`;
    sukses += `│ 🔰 *Class:* ${user.rpg.role}\n`;
    sukses += `│ 💠 *Rarity:* ${rarity}\n│\n`;
    sukses += `│ *Status Awal (Base Stats):*\n`;
    sukses += `│ ❤️ HP: ${user.rpg.hp} | 💙 MP: ${user.rpg.mp}\n`;
    sukses += `│ 🗡️ ATK: ${user.rpg.attack} | 🔮 MAG: ${user.rpg.magic || 0}\n`;
    sukses += `│ 🛡️ DEF: ${user.rpg.defense}\n`;
    sukses += `│\n`;
    sukses += `│ ⚔️ *Senjata Awal:* ${user.rpg.weapon}\n`;
    sukses += `│ ✨ *Skill Unik:* ${user.rpg.skill}\n`;
    sukses += `╰───────────────┈ ⳹\n\n`;
    sukses += `Gerbang menuju *Benua Xenoria* telah terbuka. Bertahan hiduplah dengan takdirmu yang baru! ⚔️🌌`;

    await sock.sendMessage(m.chat, { text: sukses, mentions: [m.sender], edit: animMsg.key });
}

handler.command = ["awaken", "role", "class"];
handler.tags = ["rpg"];
handler.help = ["awaken"];

module.exports = handler;
