// ==========================================
// 🔄 RESET ROLE (REINKARNASI PAKSA)
// ⚙️ Ciptaan Pstar7 | Khusus Owner (Single & Mass Reset)
// ==========================================

let handler = async (m, { sock, text, prefix, command, isOwner }) => {
    // Keamanan tingkat dewa: Cuma bosku yang bisa pakai!
    if (!isOwner) return m.reply("❌ Berani-beraninya! Fitur ini cuma buat Dewa (Owner)!");

    let users = global.db.users;

    // 🌍 1. FITUR MASS RESET (RESET SELURUH DUNIA)
    if (text && text.toLowerCase() === 'all') {
        let count = 0;
        for (let jid in users) {
            // Loop semua user, dan reset HANYA data RPG-nya (Saldo utama aman!)
            if (users[jid].rpg) {
                users[jid].rpg = {
                    role: 'Novice',     
                    hp: 100, mp: 50, attack: 10, magic: 0, defense: 10,
                    weapon: 'Tangan Kosong', armor: 'Baju Kaos', skill: 'Pukulan Polos',
                    inventory: { potion: 0, monster_loot: 0, iron: 0, gold: 0 }
                };
                count++;
            }
        }
        
        let teksAll = `╭───┈ *「 🌍 MASS REINCARNATION 」*\n`;
        teksAll += `│ Sistem dunia telah direset ulang oleh Dewa!\n`;
        teksAll += `│ 👥 *Total Player Direset:* ${count} Orang\n`;
        teksAll += `╰───────────────┈ ⳹\n\n`;
        teksAll += `_Era baru RPG Xenoria Chronicles telah dimulai. Semua pahlawan kini kembali menjadi Novice dan siap melakukan Awakening!_`;
        
        return sock.sendMessage(m.chat, { text: teksAll }, { quoted: m });
    }

    // 👤 2. FITUR SINGLE RESET (SATU ORANG)
    let target;
    if (m.quoted) {
        target = m.quoted.sender;
    } else if (m.mentionedJid && m.mentionedJid[0]) {
        target = m.mentionedJid[0];
    } else {
        target = m.sender; // Reset diri sendiri
    }

    let user = users[target];

    if (!user || !user.rpg) {
        return m.reply("⚠️ Orang ini belum punya data RPG sama sekali bosku.");
    }

    let roleLama = user.rpg.role;

    // Proses Reset 1 Orang
    user.rpg = {
        role: 'Novice',     
        hp: 100, mp: 50, attack: 10, magic: 0, defense: 10,
        weapon: 'Tangan Kosong', armor: 'Baju Kaos', skill: 'Pukulan Polos',
        inventory: { potion: 0, monster_loot: 0, iron: 0, gold: 0 }
    };

    let teks = `╭───┈ *「 🔄 REINKARNASI PAKSA 」*\n`;
    teks += `│ 👤 *Target:* @${target.split('@')[0]}\n`;
    teks += `│ 🔰 *Role Lama:* ${roleLama}\n`;
    teks += `│ 🔄 *Status Sekarang:* Novice (Direset)\n`;
    teks += `╰───────────────┈ ⳹\n\n`;
    teks += `_Seluruh kekuatan target telah dilenyapkan. Target sekarang bisa melakukan Gacha Role lagi!_`;

    await sock.sendMessage(m.chat, { text: teks, mentions: [target] }, { quoted: m });
}

handler.command = ["resetrole", "resetrpg", "reinkarnasi"];
handler.tags = ["owner"];
handler.help = ["resetrole <all/@tag>"];
handler.owner = true;

module.exports = handler;
