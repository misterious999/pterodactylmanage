const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

// ==========================================
// 🔨 XENORIA MASTER Forge (REAL-TIME CRAFTING)
// ⚙️ Ciptaan Pstar7 | Mobile-First UI & Anti-Drop
// ==========================================

function msToTime(duration) {
    let seconds = Math.floor((duration / 1000) % 60);
    let minutes = Math.floor((duration / (1000 * 60)) % 60);
    let hours = Math.floor((duration / (1000 * 60 * 60)) % 24);
    
    let timeStr = "";
    if (hours > 0) timeStr += `${hours} Jam `;
    if (minutes > 0) timeStr += `${minutes} Menit `;
    if (seconds > 0) timeStr += `${seconds} Detik`;
    return timeStr.trim();
}

let handler = async (m, { sock, args, prefix, command }) => {
    let user = global.db.users[m.sender];
    if (!user || !user.registered) return m.reply(`❌ Kamu belum terdaftar di Xenoria Chronicles!`);
    
    let rpg = user.rpg;
    if (!rpg || rpg.role === 'Novice') return m.reply(`⚠️ Pandai besi hanya melayani pahlawan yang sudah Awakening!`);

    rpg.inventory = rpg.inventory || {};
    let inv = rpg.inventory;
    const botName = global.botname || "Assistant X Project";

    // ==========================================
    // 🛡️ FUNGSI PENGIRIM TOMBOL NATIVE
    // ==========================================
    async function sendRPGButton(teks, arrayTombol) {
        let pesan = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: `© ${botName} Forge` }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons: arrayTombol }),
                        contextInfo: { 
                            participant: "0@s.whatsapp.net",
                            remoteJid: "status@broadcast",
                            quotedMessage: {
                                imageMessage: {
                                    caption: `Master Forge & Blacksmith | ${botName}`
                                }
                            }
                        }
                    })
                }
            }
        }, {}); 
        return sock.relayMessage(m.chat, pesan.message, { messageId: pesan.key.id });
    }

    const recipes = {
        'Warrior 🗡️': {
            weapon: { name: 'Dragon Slayer Blade', req: { iron: 50, dragon_boss_core: 2, money: 20000 }, stat: { attack: 120 }, time: 300000 },
            armor: { name: 'Titanium Plate', req: { iron: 80, dragon_scale: 3, money: 30000 }, stat: { defense: 150 }, time: 600000 },
            accessory: { name: 'Ring of Vitality', req: { gold: 10, ruby: 1, money: 15000 }, stat: { hp: 500 }, time: 180000 }
        },
        'Mage 🪄': {
            weapon: { name: 'Archmage Staff', req: { crystal: 30, mana_crystal: 2, money: 20000 }, stat: { attack: 150 }, time: 300000 },
            armor: { name: 'Robe of Stars', req: { string: 50, star_dust: 3, money: 30000 }, stat: { defense: 80 }, time: 600000 },
            accessory: { name: 'Amulet of Wisdom', req: { gold: 10, sapphire: 1, money: 15000 }, stat: { mana: 300 }, time: 180000 }
        },
        'Assassin 🥷': {
            weapon: { name: 'Void Dagger', req: { iron: 30, shadow_essence: 2, money: 20000 }, stat: { attack: 140 }, time: 300000 },
            armor: { name: 'Shadow Cloak', req: { leather: 50, shadow_essence: 3, money: 30000 }, stat: { defense: 100 }, time: 600000 },
            accessory: { name: 'Band of Haste', req: { silver: 15, emerald: 1, money: 15000 }, stat: { speed: 30 }, time: 180000 }
        }
    };

    let role = rpg.role;
    let recipeData = recipes[role] || recipes['Warrior 🗡️']; // Fallback aman
    let action = args[0] ? args[0].toLowerCase() : '';
    let targetItem = args[1] ? args[1].toLowerCase() : '';

    // ==========================================
    // ⚔️ LOGIKA KLAIM BARANG (CLAIM)
    // ==========================================
    if (action === 'claim') {
        if (!rpg.forgeProcess) return m.reply("❌ Kamu tidak sedang menempa barang apapun di bengkel ini!");
        
        let now = Date.now();
        let finishTime = rpg.forgeProcess.finishTime;

        if (now < finishTime) {
            let sisaWaktu = msToTime(finishTime - now);
            return m.reply(`⏳ *SABAR BOSKU!* Pandai besi masih bekerja.\n\nItem: *${rpg.forgeProcess.itemName}*\nSisa Waktu: *${sisaWaktu}*`);
        }

        let itemCategory = rpg.forgeProcess.category; 
        let itemData = rpg.forgeProcess.data;

        let suksesTeks = `🌋 ＦＯＲＧＥ  ＣＯＭＰＬＥＴＥＤ\n`;
        suksesTeks += `───────────────\n`;
        suksesTeks += `🎉 *Pandai besi selesai menempa!* teknologinya menyatu dengan senjatamu.\n\n`;
        suksesTeks += `🎁 *Item Didapat:* ${itemData.name}\n`;

        if (itemCategory === 'weapon') {
            rpg.weapon = itemData.name;
            rpg.attack += itemData.stat.attack;
            suksesTeks += `🗡️ *Attack Permanen:* +${itemData.stat.attack}\n`;
        } else if (itemCategory === 'armor') {
            rpg.armor = itemData.name;
            rpg.defense = (rpg.defense || 0) + itemData.stat.defense;
            suksesTeks += `🛡️ *Defense Permanen:* +${itemData.stat.defense}\n`;
        } else if (itemCategory === 'accessory') {
            rpg.accessory = itemData.name;
            let buffName = Object.keys(itemData.stat)[0];
            rpg[buffName] = (rpg[buffName] || 0) + itemData.stat[buffName];
            suksesTeks += `💍 *Bonus Stat:* +${itemData.stat[buffName]}\n`;
        }

        delete rpg.forgeProcess;

        return sendRPGButton(suksesTeks, [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "⚔️ Berburu", id: `${prefix}adventure` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "👤 Cek Profil", id: `${prefix}profile` }) }
        ]);
    }

    // ==========================================
    // ⚔️ LOGIKA MEMULAI TEMPA (CRAFT)
    // ==========================================
    if (action === 'craft') {
        if (!recipeData) return m.reply("❌ Role milikmu belum memiliki resep khusus!");
        if (rpg.forgeProcess) return m.reply(`⚠️ Kamu masih menempa *${rpg.forgeProcess.itemName}*! Ketik *${prefix}${command} claim* untuk mengeceknya.`);
        if (!['weapon', 'armor', 'accessory'].includes(targetItem)) return m.reply(`⚠️ Harap tentukan kategori! Contoh: *${prefix}${command} craft weapon*`);

        let selectedItem = recipeData[targetItem];
        let r = selectedItem.req;
        let isEnough = true;
        let kekuranganTeks = `❌ ＢＡＨＡＮ  ＴＩＤＡＫ  ＣＵＫＵＰ\n`;
        kekuranganTeks += `───────────────\n`;
        kekuranganTeks += `Resep *${selectedItem.name}*:\n\n`;

        for (let mat in r) {
            if (mat === 'money') {
                if (user.balance < r[mat]) isEnough = false;
                kekuranganTeks += `◦ Saldo: Rp ${user.balance.toLocaleString('id-ID')} / Rp ${r[mat].toLocaleString('id-ID')}\n`;
            } else {
                let userMat = inv[mat] || 0;
                if (userMat < r[mat]) isEnough = false;
                kekuranganTeks += `◦ ${mat.toUpperCase()}: ${userMat} / ${r[mat]}\n`;
            }
        }

        if (!isEnough) return m.reply(kekuranganTeks.trim());

        // Potong bahan & uang
        for (let mat in r) {
            if (mat === 'money') user.balance -= r[mat];
            else inv[mat] -= r[mat];
        }

        rpg.forgeProcess = {
            category: targetItem,
            itemName: selectedItem.name,
            data: selectedItem,
            finishTime: Date.now() + selectedItem.time
        };

        let durasiTeks = msToTime(selectedItem.time);
        let mulaiTeks = `🌋 ＦＯＲＧＥ  ＰＲＯＣＥＳＳ\n`;
        mulaiTeks += `───────────────\n`;
        mulaiTeks += `🔥 *Tungku api menyala!* Pandai besi mulai menempa perlengkapanmu.\n\n`;
        mulaiTeks += `🎁 *Item:* ${selectedItem.name}\n`;
        mulaiTeks += `⏱️ *Estimasi:* ${durasiTeks}\n\n`;
        mulaiTeks += `_"Kembalilah setelah proses penempaan selesai."_`;

        return sendRPGButton(mulaiTeks, [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "📦 Klaim Barang", id: `${prefix}${command} claim` }) }
        ]);
    }

    // ==========================================
    // 📜 MENU UTAMA FORGE
    // ==========================================
    let teks = `🌋 ＭＡＳＴＥＲ  ＦＯＲＧＥ\n`;
    teks += `───────────────\n`;
    teks += `👤 *Pahlawan :* ${user.name || m.pushName || 'Pahlawan'}\n`;
    teks += `🔰 *Role     :* ${role}\n\n`;
    
    if (rpg.forgeProcess) {
        let now = Date.now();
        let sisa = rpg.forgeProcess.finishTime - now;
        if (sisa > 0) {
            teks += `◈ ＳＴＡＴＵＳ : ＰＲＯＧＲＥＳＳ ◈\n`;
            teks += `🛠️ *Item:* ${rpg.forgeProcess.itemName}\n`;
            teks += `⏱️ *Sisa:* ${msToTime(sisa)}\n\n`;
        } else {
            teks += `◈ ＳＴＡＴＵＳ : ＲＥＡＤＹ ◈\n`;
            teks += `✅ *${rpg.forgeProcess.itemName}* sudah selesai ditempa!\nSilakan klik tombol klaim di bawah.\n\n`;
        }
    } else {
        teks += `◈ ＲＥＣＩＰＥＳ  ＡＶＡＩＬＡＢＬＥ ◈\n`;
        teks += `⚔️ *1. ${recipeData.weapon.name}*\n`;
        teks += `   └ Atk: +${recipeData.weapon.stat.attack} | ⏱️ 5 Menit\n`;
        teks += `🛡️ *2. ${recipeData.armor.name}*\n`;
        teks += `   └ Def: +${recipeData.armor.stat.defense} | ⏱️ 10 Menit\n`;
        
        let accStatName = Object.keys(recipeData.accessory.stat)[0];
        teks += `💍 *3. ${recipeData.accessory.name}*\n`;
        teks += `   └ ${accStatName.toUpperCase()}: +${recipeData.accessory.stat[accStatName]} | ⏱️ 3 Menit\n\n`;
    }

    let buttons = [];
    if (rpg.forgeProcess) {
        buttons.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "📦 Klaim Barang", id: `${prefix}${command} claim` }) });
    } else {
        buttons.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔨 Buat Senjata", id: `${prefix}${command} craft weapon` }) });
        buttons.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🛡️ Buat Armor", id: `${prefix}${command} craft armor` }) });
        buttons.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "💍 Buat Aksesoris", id: `${prefix}${command} craft accessory` }) });
    }

    return sendRPGButton(teks, buttons);
}

// RULES #3: HANDLER HANYA BOLEH 1
handler.command = ["forge"]; 
handler.tags = ["rpg"];
handler.help = ["forge"];

module.exports = handler;
