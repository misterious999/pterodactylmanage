// ==========================================
// 🎁 SISTEM GACHA V2 - VISUAL OVERHAUL
// ⚙️ Ciptaan Pstar7 | Dynamic Frame Animation
// ==========================================

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

let handler = async (m, { sock, args, prefix, command, isOwner }) => {
    let user = global.db.users[m.sender];
    if (!user || !user.registered) return m.reply(`❌ Kamu belum terdaftar di Xenoria Chronicles!`);
    
    let rpg = user.rpg;
    if (!rpg || rpg.role === 'Novice') return m.reply(`⚠️ Lakukan Awakening dulu di \`${prefix}awaken\``);
    rpg.inventory = rpg.inventory || {};

    // 🛠️ FITUR CHEAT KHUSUS OWNER
    if (command === 'addcrate') {
        if (!isOwner) return m.reply("❌ Akses ditolak oleh sistem Xenoria!");
        let jumlah = parseInt(args[0]) || 1;
        rpg.inventory.crate = (rpg.inventory.crate || 0) + jumlah;
        return m.reply(`🎁 Berhasil menambahkan ${jumlah} Peti Harta!`);
    }

    if (command === 'gacha') {
        if (!rpg.inventory.crate || rpg.inventory.crate < 1) return m.reply("❌ Kamu tidak memiliki Peti Harta di tasmu!");

        rpg.inventory.crate -= 1;

        // ==========================================
        // 🎭 FRAME ANIMASI (GARIS & GETARAN)
        // ==========================================
        
        // Frame 1: Persiapan
        let f1 = `┌────────────────────┐\n│      [ 📦 ]        │\n│  MEMBUKA KUNCI...  │\n└────────────────────┘`;
        
        // Frame 2: Getar Kiri
        let f2 = ` ┌───────────────────┐\n │     [ 📦 ]        │\n │  PETI BERGETAR!   │\n └───────────────────┘`;
        
        // Frame 3: Getar Kanan
        let f3 = `   ┌─────────────────┐\n   │    [ 📦 ]       │\n   │  PETI BERGETAR! │\n   └─────────────────┘`;
        
        // Frame 4: Cahaya Keluar (Explosion effect)
        let f4 = `✨  .  •  ⚡  •  .  ✨\n    > [ 💥 ] <     \n✨  •  .  ⚡  •  .  ✨`;

        // 🎬 EKSEKUSI ANIMASI EDIT CHAT
        let animMsg = await sock.sendMessage(m.chat, { text: f1 }, { quoted: m });
        await delay(1000);
        await sock.sendMessage(m.chat, { text: f2, edit: animMsg.key });
        await delay(500);
        await sock.sendMessage(m.chat, { text: f3, edit: animMsg.key });
        await delay(500);
        await sock.sendMessage(m.chat, { text: f2, edit: animMsg.key });
        await delay(500);
        await sock.sendMessage(m.chat, { text: f4, edit: animMsg.key });
        await delay(1200);

        // 🎲 MESIN RNG (HADIAH)
        let roll = Math.random() * 100;
        let hadiahTeks = '', rarity = '';

        if (roll <= 1) {
            rarity = '👑 MYTHIC JACKPOT';
            let saldo = 100000;
            user.balance += saldo;
            hadiahTeks = `│ 💰 Saldo: +Rp ${saldo.toLocaleString()}\n│ 💎 Diamond: +5`;
            rpg.inventory.diamond = (rpg.inventory.diamond || 0) + 5;
        } else if (roll <= 15) {
            rarity = '🔴 LEGENDARY';
            let saldo = 25000;
            user.balance += saldo;
            hadiahTeks = `│ 💰 Saldo: +Rp ${saldo.toLocaleString()}\n│ 🧪 Potion: +3`;
            rpg.inventory.potion = (rpg.inventory.potion || 0) + 3;
        } else if (roll <= 50) {
            rarity = '🔵 RARE';
            let iron = Math.floor(Math.random() * 10) + 5;
            rpg.inventory.iron = (rpg.inventory.iron || 0) + iron;
            hadiahTeks = `│ ⛓️ Iron: +${iron}\n│ 🪵 Wood: +10`;
            rpg.inventory.wood = (rpg.inventory.wood || 0) + 10;
        } else {
            rarity = '🟢 COMMON';
            let koin = Math.floor(Math.random() * 2000) + 1000;
            user.balance += koin;
            hadiahTeks = `│ 💰 Saldo: +Rp ${koin.toLocaleString()}\n│ 🦴 Loot: +2`;
            rpg.inventory.monster_loot = (rpg.inventory.monster_loot || 0) + 2;
        }

        // 🎉 TAMPILAN FINAL
        let res = `╭───┈ *「 🎉 GACHA RESULT 」*\n`;
        res += `│ ✨ *Status:* ${rarity}\n`;
        res += `│\n${hadiahTeks}\n│\n`;
        res += `│ 📦 Sisa Peti: ${rpg.inventory.crate}\n`;
        res += `╰───────────────┈ ⳹`;

        await sock.sendMessage(m.chat, { text: res, edit: animMsg.key });
    }
}

handler.command = ["gacha", "addcrate"];
handler.tags = ["rpg"];
module.exports = handler;
