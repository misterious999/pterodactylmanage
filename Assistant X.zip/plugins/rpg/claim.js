const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

// ==========================================
// 🎁 DAILY CLAIM & STREAK SYSTEM (VIP RPG UI)
// ⚙️ Ciptaan Pstar7 | Mobile-First UI & Anti-Drop
// ==========================================

let handler = async (m, { sock, prefix, command }) => {
    let user = global.db.users[m.sender];
    if (!user) return m.reply(`❌ Kamu belum terdaftar di database!`);

    await m.react("⏳").catch(() => {});

    let now = new Date() * 1;
    let lastClaim = user.lastclaim || 0;
    let cooldown = 86400000; // 24 Jam
    let timeout = cooldown * 2; // 48 Jam (Batas streak)
    let timeDiff = now - lastClaim;
    const botName = global.botname || "Assistant X Project";

    // 📊 FUNGSI PEMBUAT VISUAL BAR (10 BLOK KLASIK)
    function makeBar(current, total) {
        const totalBlocks = 10;
        const filledBlocks = Math.round((current / total) * totalBlocks);
        const emptyBlocks = totalBlocks - filledBlocks;
        return '■'.repeat(filledBlocks) + '□'.repeat(emptyBlocks);
    }

    // 🛡️ FUNGSI BANTUAN PENGIRIM TOMBOL
    async function sendRPGButton(teks, arrayTombol) {
        let pesan = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: `© ${botName} System` }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons: arrayTombol }),
                        contextInfo: { 
                            participant: "0@s.whatsapp.net",
                            remoteJid: "status@broadcast",
                            quotedMessage: {
                                imageMessage: {
                                    caption: `Sistem Penghargaan Harian | ${botName}`
                                }
                            }
                        }
                    })
                }
            }
        }, {});
        return sock.relayMessage(m.chat, pesan.message, { messageId: pesan.key.id });
    }

    // ==========================================
    // 1. GERBANG COOLDOWN (PENAHAN WAKTU)
    // ==========================================
    if (timeDiff < cooldown) {
        let ms = cooldown - timeDiff;
        let h = Math.floor(ms / 3600000);
        let mnt = Math.floor((ms % 3600000) / 60000);
        
        await m.react("⚠️").catch(() => {});
        
        let teksTolak = `⏳ ＣＯＯＬＤＯＷＮ\n`;
        teksTolak += `───────────────\n`;
        teksTolak += `⚠️ *Jatah logistik harianmu sudah diambil!*\n\n`;
        teksTolak += `Kembalilah dalam waktu:\n`;
        teksTolak += `⏱️ *${h} Jam ${mnt} Menit*\n\n`;
        teksTolak += `_"Seorang pahlawan tahu kapan harus beristirahat dan kapan harus berburu..."_`;

        return sendRPGButton(teksTolak, [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "💼 Cek Profil", id: `${prefix}profile` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "⚔️ Berburu", id: `${prefix}adventure` }) }
        ]);
    }

    // ==========================================
    // 2. LOGIKA STREAK BERUNTUN
    // ==========================================
    if (timeDiff > timeout) {
        user.claimstreak = 1; // Telat absen, reset ke 1
    } else {
        user.claimstreak = (user.claimstreak || 0) + 1; // Absen tepat waktu
    }

    let streak = user.claimstreak;
    let isJackpot = false;

    // ==========================================
    // 3. LOGIKA HADIAH DINAMIS
    // ==========================================
    let limitReward = 10 + (streak * 2); 
    let balanceReward = 5000 + (streak * 1000);

    // JACKPOT HARI KE-7
    if (streak === 7) {
        limitReward = 100;
        balanceReward = 50000;
        isJackpot = true;
        user.claimstreak = 0; // Reset siklus
    }

    // Suntik ke database
    user.limit = (user.limit || 0) + limitReward;
    user.balance = (user.balance || 0) + balanceReward;
    user.lastclaim = now; 

    await m.react(isJackpot ? "🎉" : "✅").catch(() => {});

    // ==========================================
    // 4. MERAKIT PAPAN PENGUMUMAN (AESTHETIC UI)
    // ==========================================
    let teks = `🎁 ＤＡＩＬＹ  ＲＥＷＡＲＤ\n`;
    teks += `───────────────\n`;
    
    if (isJackpot) {
        teks += `🎊 *M E G A  J A C K P O T !* 🎊\n`;
        teks += `Dedikasi tanpa henti selama 7 hari membuahkan hasil!\n\n`;
    }

    let displayStreak = isJackpot ? 7 : streak;
    
    teks += `◈ ＳＴＲＥＡＫ ◈\n`;
    teks += `🔥 *Hari Ke:* ${displayStreak}/7\n`;
    teks += `└ [${makeBar(displayStreak, 7)}]\n\n`;
    
    teks += `◈ ＲＥＣＥＩＶＥＤ ◈\n`;
    teks += `⚡ *Limit :* +${limitReward}\n`;
    teks += `🪙 *Saldo :* +Rp ${balanceReward.toLocaleString('id-ID')}\n\n`;
    
    teks += `◈ ＷＡＬＬＥＴ ◈\n`;
    teks += `⚡ *Total Limit:* ${user.limit}\n`;
    teks += `💳 *Total Saldo:* Rp ${user.balance.toLocaleString('id-ID')}\n\n`;
    
    if (!isJackpot) {
        teks += `_"Pertahankan streak-mu sampai hari ke-7 untuk membuka Mega Jackpot!"_`;
    } else {
        teks += `_"Siklus selesai. Logistik baru akan disiapkan esok hari."_`;
    }

    // Kirim pesan dengan tombol interaktif
    return sendRPGButton(teks, [
        { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "💼 Cek Profil", id: `${prefix}profile` }) },
        { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🏦 Cek Bank", id: `${prefix}bank` }) }
    ]);
};

// RULES #3: HANDLER HANYA BOLEH 1
handler.command = ["claim"];
handler.tags = ["rpg"];
handler.help = ["claim"];

module.exports = handler;
