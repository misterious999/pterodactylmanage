// ==========================================
// 🏆 VIP LEADERBOARD (SYNC & ANTI-GHOST DATA)
// ==========================================

let handler = async (m, { sock, prefix, command }) => {
  await m.react("⏳")

  // 1. Ekstraksi Data: Ambil Nama Asli & Paksa Saldo jadi Angka
  let users = Object.entries(global.db.users).map(([jid, data]) => ({
    jid,
    name: data.name || data.registeredName || "Unknown",
    balance: Number(data.balance) || 0, 
    limit: Number(data.limit) || 0,
    registered: data.registered || false
  }))
  // 🛡️ FILTER DEWA: 
  // 1. Hanya ID WhatsApp asli (@s.whatsapp.net) yang dibaca (Mencegah akun hantu/grup masuk)
  // 2. Hanya pengguna yang terdaftar atau memiliki nama yang masuk papan peringkat
  .filter(v => v.jid.endsWith('@s.whatsapp.net') && (v.registered || v.name !== "Unknown"))

  // 2. Mengurutkan berdasarkan Balance paling banyak (Descending)
  users.sort((a, b) => b.balance - a.balance)

  // 3. Mengambil 10 Peringkat Teratas
  let top10 = users.slice(0, 10)
  
  // 4. Mencari peringkat pengguna yang mengetik perintah ini
  let userRank = users.findIndex(v => v.jid === m.sender) + 1

  // 5. Merakit Papan Pengumuman VVIP
  let teks = `╭───┈ *「 🏆 LEADERBOARD GLOBAL 」*\n`
  teks += `│ 💰 *Kategori:* Top Balance\n`
  teks += `╰───────────────┈ ⳹\n\n`

  if (top10.length === 0) {
    teks += `_Belum ada pemain aktif yang terdaftar._\n`
  } else {
    top10.forEach((user, index) => {
      let rank = index + 1
      let medal = rank === 1 ? "🥇" : rank === 2 ? "🥈" : rank === 3 ? "🥉" : `🏅 ${rank}.`
      let isMe = user.jid === m.sender ? " *(Kamu)*" : ""
      
      // Menggunakan NAMA (Username) agar rapi, elegan, dan sedap dipandang
      teks += `${medal} *${user.name}*${isMe}\n`
      
      // Keamanan format Rupiah
      let saldoRapi = typeof global.toRupiah === 'function' 
          ? global.toRupiah(user.balance) 
          : `Rp ${user.balance.toLocaleString('id-ID')}`
          
      teks += `   └ 💰 Balance: ${saldoRapi} | ⚡ Limit: ${user.limit}\n\n`
    })
  }

  // Menampilkan peringkat personal di bagian bawah
  let rankText = userRank > 0 ? `#${userRank}` : "Belum Terdaftar"
  teks += `\n_👤 Peringkat Kamu: *${rankText}* dari ${users.length} Pengguna Aktif_`
  
  await m.react("✅")
  
  // 6. Eksekusi Pengiriman
  return sock.sendMessage(m.chat, { 
      text: teks, 
      contextInfo: {
          forwardingScore: 999,
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
              newsletterJid: global.idChannel || "1203631@newsletter",
              newsletterName: "🏆 Assistant X Global Rank",
              serverId: 1
          }
      }
  }, { quoted: m })
}

handler.command = ["leaderboard"]
handler.tags = ["rpg"]
handler.help = ["leaderboard"]

module.exports = handler
