const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

// ==========================================
// 🏅 XENORIA RANKING SYSTEM
// ⚙️ Ciptaan Pstar7 | Minimalist UI & Tracker
// ==========================================

let handler = async (m, { sock, prefix }) => {
    let user = global.db.users[m.sender];
    if (!user || !user.registered) return m.reply(`❌ Kamu belum terdaftar di Xenoria!`);
    
    let lvl = user.level || 0;
    
    // 🛡️ FUNGSI BANTUAN PENGIRIM TOMBOL ANTI-DROP
    async function sendRPGButton(teks, arrayTombol) {
        let pesan = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: "© Xenoria Rank Tracker 🏅" }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons: arrayTombol }),
                        contextInfo: { 
                            mentionedJid: [m.sender],
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: global.idChannel || "1203631@newsletter", 
                                newsletterName: "Xenoria Server", 
                                serverId: 1 
                            }
                        }
                    })
                }
            }
        }, { quoted: m });
        return sock.relayMessage(m.chat, pesan.message, { messageId: pesan.key.id });
    }

    // ==========================================
    // 📊 DEFINISI RANKING & TARGET LEVEL
    // ==========================================
    const rankLadder = [
        { name: 'Beginner', min: 0, max: 4, icon: '🌱' },
        { name: 'Trainee', min: 5, max: 9, icon: '🪵' },
        { name: 'Amateur', min: 10, max: 19, icon: '🥉' },
        { name: 'Elite', min: 20, max: 29, icon: '🥈' },
        { name: 'Master', min: 30, max: 49, icon: '🥇' },
        { name: 'Epic', min: 50, max: 99, icon: '🌟' },
        { name: 'Mythic', min: 100, max: 9999, icon: '👑' }
    ];

    let currentRank = rankLadder.find(r => lvl >= r.min && lvl <= r.max);
    let nextRank = rankLadder.find(r => r.min > lvl); // Cari rank selanjutnya

    let teks = `🏅 *XENORIA RANKING LADDER*\n\n`;
    teks += `Kasta kekuatan diukur dari akumulasi pengalaman tempur (XP) dan Level. Tingkatkan terus levelmu untuk dihormati di seluruh benua!\n\n`;

    teks += `👤 *Pahlawan:* ${user.name}\n`;
    teks += `⭐ *Level Saat Ini:* ${lvl}\n`;
    teks += `💠 *Rank Kamu:* ${currentRank.icon} ${currentRank.name}\n`;
    
    if (nextRank) {
        teks += `📈 *Target Rank Naik:* ${nextRank.min - lvl} Level lagi menuju ${nextRank.icon} *${nextRank.name}*\n\n`;
    } else {
        teks += `📈 *Target Rank Naik:* Kamu telah mencapai puncak kekuatan kosmik! (MAX RANK)\n\n`;
    }

    teks += `*HIRARKI KEKUATAN XENORIA:*\n`;
    rankLadder.forEach(r => {
        let isHere = (currentRank.name === r.name) ? ' ⬅️ *(Kamu)*' : '';
        if (r.name === 'Mythic') {
            teks += `◦ ${r.icon} *${r.name}* (Lv. 100+)${isHere}\n`;
        } else {
            teks += `◦ ${r.icon} *${r.name}* (Lv. ${r.min} - ${r.max})${isHere}\n`;
        }
    });

    teks += `\n_Catatan: Pahlawan dengan Rank Master ke atas akan mendapatkan akses ke material dan drop monster yang lebih mewah di Dungeon._`;

    let arrayTombol = [
        { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🌟 Cek Profil Status", id: `${prefix}profil` }) },
        { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "⚔️ Grinding XP (Hunt)", id: `${prefix}adventure` }) }
    ];

    return sendRPGButton(teks, arrayTombol);
}

handler.command = ["rank", "pangkat", "tier"];
handler.tags = ["rpg"];
handler.help = ["rank"];

module.exports = handler;
