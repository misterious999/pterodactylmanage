// ==========================================
// 🎁 FITUR REDEEM CODE & CHANNEL BROADCAST
// ⚙️ CREATED BY: PSTAR7 | ASSISTANT X PROJECT
// ==========================================

const { generateWAMessageFromContent, proto } = require("@whiskeysockets/baileys");

let handler = async (m, { sock, args, command, isOwner, prefix }) => {
    global.db.redeem = global.db.redeem || {};
    let user = global.db.users[m.sender];
    
    const channelJid = global.idChannel; 
    const linkChannel = global.linkChannel;

    switch (command) {
        case 'addcode': {
            if (!isOwner) return m.reply("❌ Khusus Developer!");
            
            if (args.length < 3) {
                let usage = `🎁 *PEMBUATAN KODE REDEEM*\n`;
                usage += `───────────────────\n`;
                usage += `› *Format:* ${prefix}addcode <tipe> <nilai> <kuota> [kode]\n`;
                usage += `› *Tipe:* uang / limit / premium / sewa\n`;
                usage += `› *Contoh 1:* ${prefix}addcode limit 100 50 XENORIA24\n`;
                usage += `› *Contoh 2:* ${prefix}addcode premium 3 10 PSTARVIP\n`;
                usage += `───────────────────`;
                return m.reply(usage);
            }

            let type = args[0].toLowerCase();
            let value = parseInt(args[1]);
            let quota = parseInt(args[2]);
            let code = args[3] ? args.slice(3).join("").toUpperCase() : `XENORIA-${Math.random().toString(36).substr(2, 5).toUpperCase()}`;

            if (isNaN(value) || isNaN(quota)) return m.reply("❌ Nilai hadiah dan kuota harus berupa angka!");
            if (global.db.redeem[code]) return m.reply("❌ Kode tersebut sudah ada! Gunakan nama kode lain.");

            global.db.redeem[code] = {
                type: type,
                value: value,
                quota: quota,
                users: []
            };

            // ==========================================================
            // 1. NOTIFIKASI KE CHANNEL (PURE TEXT - ANTI ERROR & MUDAH DISALIN)
            // ==========================================================
            let chMsgText = `🎉 *KODE REDEEM BARU TERSEDIA!* 🎉\n`;
            chMsgText += `───────────────────\n`;
            chMsgText += `🎁 *Hadiah:* ${value} ${type.toUpperCase()}\n`;
            chMsgText += `👥 *Kuota:* Hanya untuk ${quota} Orang Tercepat!\n`;
            chMsgText += `───────────────────\n`;
            chMsgText += `Tahan (Long-press) pesan di bawah ini untuk menyalin kode, lalu ketik *.redeem <kode>* di grup! 🚀`;

            try {
                if (!channelJid) throw new Error("ID Channel belum disetting di config.js");
                await sock.sendMessage(channelJid, { text: chMsgText });
                await sock.sendMessage(channelJid, { text: code }); // Kode dikirim terpisah
            } catch (e) {
                console.log("[CHANNEL BROADCAST ERROR]", e);
                return m.reply("⚠️ Gagal mengirim ke Channel. Pastikan Bot sudah menjadi Admin di Saluran tersebut!");
            }

            // ==========================================================
            // 2. BACKGROUND AUTO-BROADCAST GRUP (NATIVE FLOW BUTTONS)
            // ==========================================================
            (async () => {
                try {
                    let groups = await sock.groupFetchAllParticipating();
                    let groupJids = Object.keys(groups);
                    
                    let bcMsg = `📢 *KABAR GEMBIRA DARI ASSISTANT X!* 🎉\n`;
                    bcMsg += `───────────────────\n`;
                    bcMsg += `Ada *Kode Redeem Spesial* berisi hadiah *${value} ${type.toUpperCase()}* yang baru saja dibagikan!\n\n`;
                    bcMsg += `🔒 *Kodenya rahasia!* Hanya dibagikan secara eksklusif di Saluran Resmi kami.\n\n`;
                    bcMsg += `Buruan follow, salin kodenya di channel, lalu redeem di sini sebelum kehabisan (kuota sangat terbatas!) 🚀`;

                    for (let jid of groupJids) {
                        try {
                            const msg = generateWAMessageFromContent(jid, {
                                viewOnceMessage: {
                                    message: {
                                        interactiveMessage: proto.Message.InteractiveMessage.create({
                                            body: proto.Message.InteractiveMessage.Body.create({ text: bcMsg }),
                                            footer: proto.Message.InteractiveMessage.Footer.create({ text: "© Assistant X Project" }),
                                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                                buttons: [{
                                                    name: "cta_url",
                                                    buttonParamsJson: JSON.stringify({
                                                        display_text: "🌐 Buka Channel Official",
                                                        url: linkChannel
                                                    })
                                                }]
                                            })
                                        })
                                    }
                                }
                            }, {});

                            await sock.relayMessage(jid, msg.message, { messageId: msg.key.id });
                            await new Promise(resolve => setTimeout(resolve, 20000)); // Jeda 20 detik
                        } catch (e) {
                            console.log(`[BROADCAST GROUP ERROR] pada ${jid}:`, e.message);
                        }
                    }
                } catch (err) {
                    console.log("[AUTO BROADCAST GRUP ERROR]", err);
                }
            })(); 

            // ==========================================================
            // 3. PESAN KONFIRMASI KE OWNER
            // ==========================================================
            let repMsg = `✅ *KODE BERHASIL DIBUAT & DISIARKAN!*\n`;
            repMsg += `───────────────────\n`;
            repMsg += `› *Kode:* ${code}\n`;
            repMsg += `› *Hadiah:* ${value} ${type}\n`;
            repMsg += `› *Kuota:* ${quota} User\n\n`;
            repMsg += `🚀 *Status Sistem:*\n`;
            repMsg += `1. Pengumuman Channel (Teks) berhasil dikirim.\n`;
            repMsg += `2. Mesin Auto-Broadcast (Tombol Interaktif) sedang berjalan ke seluruh Grup. 😎`;
            
            return m.reply(repMsg);
        }

        case 'listcode': {
            if (!isOwner) return m.reply("❌ Khusus Developer!");
            let codes = Object.keys(global.db.redeem);
            
            if (codes.length === 0) return m.reply("📭 Belum ada kode redeem yang aktif.");

            let txt = `📋 *DAFTAR KODE REDEEM AKTIF*\n`;
            txt += `───────────────────\n`;
            codes.forEach((c, i) => {
                let data = global.db.redeem[c];
                txt += `› *${i + 1}. ${c}*\n`;
                txt += `  Hadiah: ${data.value} ${data.type.toUpperCase()}\n`;
                txt += `  Sisa Kuota: ${data.quota} User\n\n`;
            });
            txt += `───────────────────`;
            return m.reply(txt);
        }

        case 'delcode': {
            if (!isOwner) return m.reply("❌ Khusus Developer!");
            if (!args[0]) return m.reply(`❌ Masukkan kodenya!\nContoh: *${prefix}delcode XENORIA24*`);
            
            let code = args[0].toUpperCase();
            if (!global.db.redeem[code]) return m.reply("❌ Kode tersebut tidak ditemukan di database.");

            delete global.db.redeem[code];
            return m.reply(`✅ Kode redeem *${code}* berhasil dihapus!`);
        }

        case 'redeem': {
            if (!user) return m.reply("❌ Kamu belum terdaftar di database bot!");
            if (!args[0]) {
                let usage = `🎁 *KLAIM KODE REDEEM*\n`;
                usage += `───────────────────\n`;
                usage += `› *Format:* ${prefix}redeem <kode>\n`;
                usage += `› Belum punya kode? Pantau terus Saluran Resmi kita untuk kode gratis!\n`;
                usage += `🌐 ${linkChannel}`;
                return m.reply(usage);
            }

            let code = args[0].toUpperCase();
            let data = global.db.redeem[code];

            if (!data) return m.reply("❌ Kode redeem tidak valid atau sudah kedaluwarsa!");
            if (data.quota <= 0) {
                delete global.db.redeem[code]; 
                return m.reply("❌ Yah, kuota untuk kode ini sudah habis ditebus orang lain! 😭");
            }
            if (data.users.includes(m.sender)) return m.reply("❌ Kamu sudah pernah menebus kode ini! Tunggu event berikutnya ya.");

            let claimText = "";
            switch (data.type) {
                case 'limit':
                    user.limit += data.value;
                    claimText = `${data.value} Limit`;
                    break;
                case 'uang':
                    user.balance += data.value;
                    claimText = `Rp ${data.value.toLocaleString('id-ID')} Saldo`;
                    break;
                case 'premium':
                    let msPrem = data.value * 24 * 60 * 60 * 1000;
                    user.premium = true;
                    user.premiumTime = (user.premiumTime || Date.now()) + msPrem;
                    claimText = `Akses Premium ${data.value} Hari`;
                    break;
                case 'sewa':
                    if (!m.isGroup) return m.reply("❌ Hadiah tipe 'sewa' hanya bisa ditebus di dalam Grup!");
                    let chat = global.db.chats[m.chat];
                    let msSewa = data.value * 24 * 60 * 60 * 1000;
                    chat.expired = (chat.expired || Date.now()) + msSewa;
                    claimText = `Perpanjangan Sewa Grup ${data.value} Hari`;
                    break;
                default:
                    return m.reply("❌ Tipe hadiah pada kode ini tidak dikenali sistem.");
            }

            // Kurangi kuota dan catat pengklaim
            data.quota -= 1;
            data.users.push(m.sender);
            
            let sisaKuota = data.quota;

            if (sisaKuota === 0) {
                delete global.db.redeem[code]; // Hapus kode jika kuota habis
            }

            // ==========================================================
            // 🆕 NOTIFIKASI SISA KUOTA KE CHANNEL
            // ==========================================================
            try {
                if (channelJid) {
                    let updateMsg = "";
                    if (sisaKuota > 0) {
                        updateMsg = `🔔 *UPDATE KODE REDEEM* 🔔\n\n`;
                        updateMsg += `Seseorang baru saja menebus hadiah!\n`;
                        updateMsg += `› *Kode:* ${code}\n`;
                        updateMsg += `› *Sisa Kuota:* Tersisa *${sisaKuota}* orang lagi!\n\n`;
                        updateMsg += `Gas tebus di bot sekarang sebelum ludes! 🏃‍♂️💨`;
                    } else {
                        updateMsg = `❌ *KODE REDEEM SOLD OUT!* ❌\n\n`;
                        updateMsg += `Wah, kode *${code}* sudah ludes ditebus oleh para player tercepat! (Kuota 0)\n\n`;
                        updateMsg += `Buat yang belum dapet, jangan sedih ya. Pantau terus channel ini untuk kode kejutan selanjutnya! 😎🎉`;
                    }
                    await sock.sendMessage(channelJid, { text: updateMsg });
                }
            } catch (e) {
                console.log("[UPDATE CHANNEL ERROR]", e);
            }

            let txt = `🎉 *REDEEM BERHASIL!* 🎉\n`;
            txt += `───────────────────\n`;
            txt += `› *Selamat!* Kamu mendapatkan:\n`;
            txt += `› 🎁 *${claimText}*\n`;
            txt += `───────────────────\n`;
            txt += `Tetap pantau channel resmi kami untuk kode menarik lainnya! 😎`;

            return m.reply(txt);
        }
    }
}

handler.command = ["addcode", "listcode", "delcode", "redeem"];
handler.tags = ["rpg"];
handler.help = ["redeem"];

module.exports = handler;
