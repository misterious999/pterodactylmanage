const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

// ==========================================
// 📜 XENORIA GUILD QUESTS (MISI ALIANSI)
// ⚙️ Ciptaan Pstar7 | Minimalist UI & Anti-Trash DB
// ==========================================

let handler = async (m, { sock, args, prefix, command }) => {
    let user = global.db.users[m.sender];
    if (!user || !user.registered) return m.reply(`❌ Kamu belum terdaftar di Xenoria!`);
    
    let rpg = user.rpg;
    if (!rpg || !rpg.guild) return m.reply(`⚠️ Fitur ini eksklusif untuk anggota Guild! Masuk atau buat Guild terlebih dahulu menggunakan perintah \`${prefix}guild\`.`);

    let guilds = global.db.guilds;
    let myGuild = guilds[rpg.guild];
    if (!myGuild) return m.reply(`❌ Guild-mu tidak ditemukan di sistem!`);

    // Injeksi Database Misi
    rpg.guild_quest = rpg.guild_quest || { status: 'none', type: '', target: 0, progress: 0, desc: '', reward: 0 };
    let gq = rpg.guild_quest;

    let action = args[0] ? args[0].toLowerCase() : '';

    // 🛡️ FUNGSI BANTUAN PENGIRIM TOMBOL ANTI-DROP
    async function sendRPGButton(teks, arrayTombol) {
        let pesan = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: "© Xenoria Guild Association 📜" }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons: arrayTombol }),
                        contextInfo: { 
                            mentionedJid: [m.sender],
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: { newsletterJid: global.idChannel || "1203631@newsletter", newsletterName: "Xenoria Server", serverId: 1 }
                        }
                    })
                }
            }
        }, { quoted: m });
        return sock.relayMessage(m.chat, pesan.message, { messageId: pesan.key.id });
    }

    // ==========================================
    // ❌ BATALKAN MISI (ANTI-TRASH DB)
    // ==========================================
    if (action === 'batal' || action === 'abort') {
        if (gq.status === 'none') return m.reply(`⚠️ Kamu tidak sedang menjalankan misi apapun!`);
        
        // Membersihkan DB dari sampah
        user.rpg.guild_quest = { status: 'none', type: '', target: 0, progress: 0, desc: '', reward: 0 };
        return sendRPGButton(`🛑 *MISI DIBATALKAN*\n\nKamu telah menyerah dan merobek kertas misimu. Data sampah di sistem telah dibersihkan!`, [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "📜 Cek Papan Misi", id: `${prefix}${command}` }) }
        ]);
    }

    // ==========================================
    // ✅ SELESAIKAN MISI (KLAIM REWARD)
    // ==========================================
    if (action === 'klaim' || action === 'selesai') {
        if (gq.status === 'none') return m.reply(`⚠️ Kamu tidak sedang menjalankan misi!`);
        if (gq.progress < gq.target) return m.reply(`❌ Misimu belum selesai!\nProgress saat ini: ${gq.progress} / ${gq.target}`);

        // Distribusi Hadiah
        let rewardSaldo = gq.reward;
        let rewardGuild = Math.floor(gq.reward * 0.2); // Bonus 20% masuk otomatis ke kas guild
        
        user.balance += rewardSaldo;
        myGuild.balance += rewardGuild;
        
        rpg.inventory = rpg.inventory || {};
        rpg.inventory.crate = (rpg.inventory.crate || 0) + 1; // Bonus 1 peti harta

        // Pembersihan Database (Reset)
        user.rpg.guild_quest = { status: 'none', type: '', target: 0, progress: 0, desc: '', reward: 0 };

        let teksSukses = `🎉 *MISI GUILD SELESAI!*\n\n`;
        teksSukses += `Kerja bagus, Pahlawan! Aliansi sangat menghargai kerja kerasmu.\n\n`;
        teksSukses += `🎁 *REWARD PRIBADI:*\n`;
        teksSukses += `◦ Saldo: +Rp ${rewardSaldo.toLocaleString('id-ID')}\n`;
        teksSukses += `◦ Item: +1 📦 Peti Harta\n\n`;
        teksSukses += `🏰 *REWARD GUILD:*\n`;
        teksSukses += `◦ Kas Guild: +Rp ${rewardGuild.toLocaleString('id-ID')}\n`;

        return sendRPGButton(teksSukses, [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "📜 Ambil Misi Baru", id: `${prefix}${command} ambil` }) }
        ]);
    }

    // ==========================================
    // 📝 AMBIL MISI BARU
    // ==========================================
    if (action === 'ambil') {
        // SISTEM WARNING JIKA ADA MISI MENGGANTUNG
        if (gq.status === 'active') {
            let peringatan = `⚠️ *MISI MASIH AKTIF!*\n\n`;
            peringatan += `Tuan, kamu masih memiliki misi yang tertunda. Tolong selesaikan atau batalkan misi tersebut agar sistem database tidak menumpuk!\n\n`;
            peringatan += `📜 *Tugas:* ${gq.desc}\n`;
            peringatan += `📈 *Progress:* ${gq.progress} / ${gq.target}\n`;

            let warningTombol = [];
            if (gq.progress >= gq.target) {
                warningTombol.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "✅ Selesaikan Misi", id: `${prefix}${command} klaim` }) });
            }
            warningTombol.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🛑 Batalkan Misi", id: `${prefix}${command} batal` }) });

            return sendRPGButton(peringatan, warningTombol);
        }

        // Generate RNG Misi Baru
        const misiList = [
            { type: 'hunt', target: 10, desc: 'Kalahkan 10 Monster di Dungeon', reward: 50000 },
            { type: 'hunt', target: 25, desc: 'Kalahkan 25 Monster di Dungeon', reward: 150000 },
            { type: 'donate', target: 50000, desc: 'Donasi Rp 50.000 ke Kas Guild', reward: 100000 }
        ];

        let randomMisi = misiList[Math.floor(Math.random() * misiList.length)];
        
        user.rpg.guild_quest = {
            status: 'active',
            type: randomMisi.type,
            target: randomMisi.target,
            progress: 0,
            desc: randomMisi.desc,
            reward: randomMisi.reward
        };

        let teksAmbil = `📝 *MISI DITERIMA!*\n\n`;
        teksAmbil += `Kamu telah menyobek kertas misi dari Papan Pengumuman Guild.\n\n`;
        teksAmbil += `📜 *Tugas:* ${randomMisi.desc}\n`;
        teksAmbil += `🎁 *Imbalan:* Rp ${randomMisi.reward.toLocaleString('id-ID')} & 1 Peti Harta\n\n`;
        teksAmbil += `_Jika kamu menyerah di tengah jalan, segera batalkan misi ini agar database kembali bersih!_`;

        return sendRPGButton(teksAmbil, [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🛡️ Cek Status Misi", id: `${prefix}${command}` }) }
        ]);
    }

    // ==========================================
    // 🏰 PAPAN PENGUMUMAN (DASBOR UTAMA)
    // ==========================================
    if (gq.status === 'active') {
        let teksStatus = `📜 *STATUS MISI GUILD*\n\n`;
        teksStatus += `Halo @${m.sender.split('@')[0]}, ini laporan misimu saat ini:\n\n`;
        teksStatus += `🎯 *Tugas:* ${gq.desc}\n`;
        teksStatus += `📈 *Progress:* ${gq.progress} / ${gq.target}\n`;
        teksStatus += `🎁 *Imbalan:* Rp ${gq.reward.toLocaleString('id-ID')}\n\n`;
        
        let arrayTombol = [];
        if (gq.progress >= gq.target) {
            teksStatus += `✅ _Misi Selesai! Silakan klaim imbalanmu._`;
            arrayTombol.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🎁 Klaim Reward", id: `${prefix}${command} klaim` }) });
        } else {
            teksStatus += `_Ayo semangat! Selesaikan agar tidak menjadi beban server!_`;
            if (gq.type === 'hunt') arrayTombol.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "⚔️ Berburu Monster", id: `${prefix}adventure` }) });
        }
        arrayTombol.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🛑 Batalkan Misi", id: `${prefix}${command} batal` }) });

        return sendRPGButton(teksStatus, arrayTombol);
    } else {
        let teksPapan = `📋 *PAPAN MISI GUILD*\n\n`;
        teksPapan += `Selamat datang di Aula Guild, @${m.sender.split('@')[0]}!\n`;
        teksPapan += `Ada banyak permintaan dari warga yang butuh bantuan Pahlawan Aliansi.\n\n`;
        teksPapan += `Ambil selembar misi acak sekarang untuk menambah pundi-pundi pribadi dan Kas Guild-mu!`;

        return sendRPGButton(teksPapan, [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "📝 Ambil Misi Acak", id: `${prefix}${command} ambil` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🏰 Dasbor Guild", id: `${prefix}guild` }) }
        ]);
    }
}

handler.command = ["gquest", "guildquest", "misiguild"];
handler.tags = ["rpg"];
module.exports = handler;
