const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

// ==========================================
// 🏰 XENORIA GUILD SYSTEM (ALIANSI PAHLAWAN)
// ⚙️ Ciptaan Pstar7 | Minimalist UI & Vault System
// ==========================================

let handler = async (m, { sock, args, prefix, command }) => {
    let user = global.db.users[m.sender];
    if (!user || !user.registered) return m.reply(`❌ Kamu belum terdaftar di Xenoria!`);
    
    let rpg = user.rpg;
    if (!rpg || rpg.role === 'Novice') return m.reply(`⚠️ Pahlawan pemula belum boleh masuk politik. \`${prefix}awaken\` dulu!`);

    global.db.guilds = global.db.guilds || {};
    let guilds = global.db.guilds;

    // 🛡️ FUNGSI BANTUAN PENGIRIM TOMBOL ANTI-DROP
    async function sendRPGButton(teks, arrayTombol) {
        let pesan = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: "© Xenoria Guild Association 🏰" }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons: arrayTombol }),
                        contextInfo: { 
                            mentionedJid: [m.sender],
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: global.idChannel || "1203631@newsletter", 
                                newsletterName: "Xenoria Server", 
                                serverId: 1 
                            }
                        }
                    })
                }
            }
        }, { quoted: m });
        return sock.relayMessage(m.chat, pesan.message, { messageId: pesan.key.id });
    }

    let action = args[0] ? args[0].toLowerCase() : '';
    let targetArg = args.slice(1).join(' ');

    // ==========================================
    // 📝 MEMBUAT GUILD BARU
    // ==========================================
    if (action === 'create' || action === 'buat') {
        if (rpg.guild) return m.reply(`❌ Kamu sudah bergabung dengan Guild *${guilds[rpg.guild].name}*! Keluar dulu jika ingin membuat yang baru.`);
        if (!targetArg) return m.reply(`❌ Masukkan nama Guild yang ingin dibuat!\nContoh: \`${prefix}${command} create Black Bulls\``);
        if (targetArg.length > 20) return m.reply(`❌ Nama Guild maksimal 20 karakter!`);

        let cost = 500000; 
        if (user.balance < cost) return m.reply(`💸 Saldo tidak cukup! Membangun Guild butuh biaya administrasi Rp ${cost.toLocaleString('id-ID')}.`);

        let guildId = 'GLD-' + Math.random().toString(36).substr(2, 6).toUpperCase();
        
        user.balance -= cost;
        guilds[guildId] = {
            id: guildId,
            name: targetArg,
            leader: m.sender,
            members: [m.sender],
            balance: 0,
            level: 1,
            maxMembers: 15,
            created: Date.now()
        };
        rpg.guild = guildId;

        let teksSukses = `🎉 *GUILD RESMI DIDIRIKAN!*\n\n`;
        teksSukses += `Selamat, kamu kini adalah Ketua dari *${targetArg}*.\n\n`;
        teksSukses += `ID Guild: \`${guildId}\`\n`;
        teksSukses += `_Bagikan ID ini kepada temanmu agar mereka bisa bergabung melalui perintah \`${prefix}guild join <ID>\`_\n\n`;
        teksSukses += `💰 Biaya Pendirian: -Rp ${cost.toLocaleString('id-ID')}`;

        return sendRPGButton(teksSukses, [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🏰 Dasbor Guild", id: `${prefix}${command}` }) }
        ]);
    }

    // ==========================================
    // 🤝 BERGABUNG KE GUILD
    // ==========================================
    if (action === 'join' || action === 'masuk') {
        if (rpg.guild) return m.reply(`❌ Kamu sudah menjadi anggota Guild! Keluar dulu dari Guild lama.`);
        if (!targetArg) return m.reply(`❌ Masukkan ID Guild tujuan!\nContoh: \`${prefix}${command} join GLD-XXXXXX\``);

        let guildId = targetArg.toUpperCase();
        let targetGuild = guilds[guildId];

        if (!targetGuild) return m.reply(`❌ Guild dengan ID *${guildId}* tidak ditemukan!`);
        if (targetGuild.members.length >= targetGuild.maxMembers) return m.reply(`⚠️ Guild *${targetGuild.name}* sudah penuh (${targetGuild.maxMembers} Anggota)!`);

        targetGuild.members.push(m.sender);
        rpg.guild = guildId;

        return sendRPGButton(`🤝 *BERHASIL BERGABUNG!*\n\nKamu telah resmi menjadi anggota Guild *${targetGuild.name}*.\nMari berjuang bersama demi kejayaan Aliansi!`, [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🏰 Dasbor Guild", id: `${prefix}${command}` }) }
        ]);
    }

    // ==========================================
    // 🚪 KELUAR DARI GUILD
    // ==========================================
    if (action === 'leave' || action === 'keluar') {
        if (!rpg.guild) return m.reply(`⚠️ Kamu bukan anggota Guild mana pun.`);
        
        let myGuild = guilds[rpg.guild];
        
        if (myGuild.leader === m.sender) {
            return m.reply(`👑 Kamu adalah Ketua Guild! Jika kamu ingin keluar, berikan jabatan ketua ke orang lain, atau bubarkan Guild ini dengan \`${prefix}${command} disband\`.`);
        }

        myGuild.members = myGuild.members.filter(id => id !== m.sender);
        rpg.guild = '';

        return m.reply(`🚪 Kamu telah mengemasi barang-barangmu dan keluar dari Guild *${myGuild.name}*.`);
    }

    // ==========================================
    // 💸 DONASI KAS GUILD
    // ==========================================
    if (action === 'donate' || action === 'donasi') {
        if (!rpg.guild) return m.reply(`⚠️ Kamu harus masuk Guild dulu sebelum berdonasi.`);
        let amount = parseInt(args[1]);
        
        if (isNaN(amount) || amount < 1000) return m.reply(`❌ Minimal donasi adalah Rp 1.000!\nContoh: \`${prefix}${command} donate 50000\``);
        if (user.balance < amount) return m.reply(`💸 Saldo utamamu tidak cukup untuk berdonasi sebesar itu.`);

        user.balance -= amount;
        guilds[rpg.guild].balance += amount;

        // 🌟 SINKRONISASI MISI DONASI DI SINI
        if (rpg.guild_quest && rpg.guild_quest.status === 'active' && rpg.guild_quest.type === 'donate') {
            rpg.guild_quest.progress += amount;
        }

        return sendRPGButton(`💰 *DONASI BERHASIL!*\n\nTerima kasih atas kontribusimu sebesar *Rp ${amount.toLocaleString('id-ID')}*.\nDana ini dimasukkan ke dalam Kas (Vault) Guild *${guilds[rpg.guild].name}*.`, [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🏰 Cek Kas Guild", id: `${prefix}${command}` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "📜 Cek Misi", id: `${prefix}guildquest` }) }
        ]);
    }

    // ==========================================
    // 🏰 DASBOR UTAMA GUILD (INFO)
    // ==========================================
    if (!rpg.guild || !guilds[rpg.guild]) {
        let teksKosong = `🏰 *GUILD ASSOCIATION*\n\n`;
        teksKosong += `Kamu saat ini adalah petualang independen (Tidak memiliki Guild).\n\n`;
        teksKosong += `*Perintah Aliansi:*\n`;
        teksKosong += `◦ \`${prefix}${command} create <nama>\` - Buat Guild (Biaya 500k)\n`;
        teksKosong += `◦ \`${prefix}${command} join <ID>\` - Masuk Guild teman\n`;
        
        return sendRPGButton(teksKosong, [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🌟 Cek Profilku", id: `${prefix}profil` }) }
        ]);
    }

    let myGuild = guilds[rpg.guild];
    let leaderObj = global.db.users[myGuild.leader];
    let leaderName = leaderObj ? leaderObj.name : 'Unknown';

    let teksInfo = `🏰 *GUILD DASHBOARD*\n\n`;
    teksInfo += `🛡️ *Nama Aliansi:* ${myGuild.name}\n`;
    teksInfo += `🔑 *ID Guild:* \`${myGuild.id}\`\n`;
    teksInfo += `👑 *Ketua:* ${leaderName}\n`;
    teksInfo += `📈 *Level:* ${myGuild.level}\n`;
    teksInfo += `💰 *Kas (Vault):* Rp ${myGuild.balance.toLocaleString('id-ID')}\n`;
    teksInfo += `👥 *Kapasitas:* ${myGuild.members.length} / ${myGuild.maxMembers}\n\n`;

    teksInfo += `*DAFTAR ANGGOTA:*\n`;
    myGuild.members.forEach((memberJid, i) => {
        let memberName = global.db.users[memberJid] ? global.db.users[memberJid].name : 'Unknown';
        let tanda = memberJid === myGuild.leader ? '👑' : '👤';
        teksInfo += `◦ ${tanda} ${memberName}\n`;
    });
    
    teksInfo += `\n_Donasi kas: \`${prefix}${command} donate <jumlah>\`_`;

    let arrayTombol = [
        { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "📜 Papan Misi Guild", id: `${prefix}guildquest` }) },
        { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🚪 Keluar Guild", id: `${prefix}${command} leave` }) }
    ];

    return sendRPGButton(teksInfo, arrayTombol);
}

handler.command = ["guild", "aliansi"];
handler.tags = ["rpg"];
module.exports = handler;
