const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

// ==========================================
// ⚔️ XENORIA CHRONICLES: ADVENTURE ENGINE
// ⚙️ Ciptaan Pstar7 | Economy Synced, Visual Bar & Anti-Drop
// ==========================================

global.adventure = global.adventure || {}; 
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const petData = {
    'slime': { name: '🫧 Slime', atk: 0, def: 5, hp: 50 },
    'serigala': { name: '🐺 Serigala', atk: 15, def: 10, hp: 0 },
    'phoenix': { name: '🦅 Phoenix', atk: 30, def: 0, hp: 100 },
    'naga': { name: '🐉 Naga', atk: 50, def: 20, hp: 200 }
};

let handler = async (m, { sock, args, prefix, command }) => {
    let user = global.db.users[m.sender];
    if (!user || !user.registered) return m.reply(`❌ Daftar dulu di Xenoria!`);
    
    let rpg = user.rpg;
    if (!rpg || rpg.role === 'Novice') return m.reply(`⚠️ Gunakan \`${prefix}awaken\` untuk memilih kekuatanmu!`);
    if (rpg.isHealing) return m.reply(`🧘 Kamu masih bermeditasi. Ketik .heal batal untuk stop.`);
    
    rpg.inventory = rpg.inventory || {}; 
    rpg.lantai = rpg.lantai || 1;
    rpg.max_hp = rpg.max_hp || 500;
    rpg.max_mp = rpg.max_mp || 400;
    
    if (rpg.hp === undefined) rpg.hp = rpg.max_hp;
    if (rpg.mp === undefined) rpg.mp = rpg.max_mp;
    if (rpg.defense === undefined) rpg.defense = 10;
    if (rpg.attack === undefined) rpg.attack = 10;

    let activePet = rpg.active_pet ? petData[rpg.active_pet] : { name: '', atk: 0, def: 0, hp: 0 };
    if (!activePet) activePet = { name: '', atk: 0, def: 0, hp: 0 };
    
    let totalAtk = rpg.attack + activePet.atk;
    let totalDef = rpg.defense + activePet.def;
    let totalMaxHp = rpg.max_hp + activePet.hp;

    let action = args[0] ? args[0].toLowerCase() : '';
    let targetArg = args[1] || '';
    let room = global.adventure[m.sender];

    // ==========================================
    // 📊 FUNGSI PEMBUAT VISUAL BAR (10 BLOK KLASIK)
    // ==========================================
    function makeBar(percent) {
        const totalBlocks = 10;
        const filledBlocks = Math.round((Math.max(0, Math.min(100, percent)) / 100) * totalBlocks);
        const emptyBlocks = totalBlocks - filledBlocks;
        return '■'.repeat(filledBlocks) + '□'.repeat(emptyBlocks);
    }
    
    let xpNeeded = 50 * Math.pow(user.level || 0, 2) + 50 * (user.level || 0) + 100;

    // ==========================================
    // 🛡️ FUNGSI BANTUAN PENGIRIM TOMBOL ANTI-DROP
    // ==========================================
    async function sendRPGButton(teks, arrayTombol) {
        let pesan = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: { 
                message: { 
                    interactiveMessage: proto.Message.InteractiveMessage.create({ 
                        body: proto.Message.InteractiveMessage.Body.create({ text: teks }), 
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: "© Xenoria Adventure" }), 
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons: arrayTombol }),
                        contextInfo: { 
                            mentionedJid: [m.sender],
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: global.idChannel || "1203631@newsletter", 
                                newsletterName: "Xenoria Server", 
                                serverId: 1 
                            }
                        }
                    }) 
                } 
            }
        }, { quoted: m }); 
        return sock.relayMessage(m.chat, pesan.message, { messageId: pesan.key.id });
    }

    async function renderSafeZone(targetLantai, extraMsg = '') {
        let percHP = (rpg.hp / totalMaxHp) * 100;
        let percMP = (rpg.mp / rpg.max_mp) * 100;

        let teks = `🏕️ ＳＡＦＥ  ＺＯＮＥ\n`;
        teks += `───────────────\n`;
        teks += `📍 *Lantai:* ${targetLantai}\n\n`;
        if (extraMsg) teks += `🔔 _${extraMsg}_\n\n`;
        teks += `◈ ＣＯＮＤＩＴＩＯＮ ◈\n`;
        teks += `❤️ *HP:* ${rpg.hp}/${totalMaxHp}\n`;
        teks += `└ [${makeBar(percHP)}]\n`;
        teks += `💙 *MP:* ${rpg.mp}/${rpg.max_mp}\n`;
        teks += `└ [${makeBar(percMP)}]\n`;
        teks += `🥤 *Pot:* ${rpg.inventory.potion || 0}\n\n`;
        teks += `_"Api unggun menenangkan jiwamu sebelum kembali ke kegelapan..."_`;

        let arrayTombol = [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: `➡️ Gas Lantai ${targetLantai}`, id: `${prefix}${command} konfirmasi_lantai ${targetLantai}` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🥤 Minum Potion", id: `${prefix}${command} heal_potion ${targetLantai}` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🧘‍♂️ Meditasi", id: `${prefix}meditasi` }) },
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🛑 Stay", id: `${prefix}${command} batal_lantai` }) }
        ];

        return sendRPGButton(teks, arrayTombol);
    }

    // HANDLER SAFE ZONE & HEAL
    if (action === 'heal_potion') {
        let targetLantai = parseInt(targetArg);
        if (!rpg.inventory.potion || rpg.inventory.potion < 1) return renderSafeZone(targetLantai, '❌ Tas kosong! Beli di .shop');
        if (rpg.hp >= totalMaxHp && rpg.mp >= rpg.max_mp) return renderSafeZone(targetLantai, '✅ Kondisi sudah prima!');
        
        rpg.inventory.potion -= 1;
        rpg.hp = Math.min(totalMaxHp, rpg.hp + 200); 
        rpg.mp = Math.min(rpg.max_mp, rpg.mp + 100); 
        return renderSafeZone(targetLantai, '✨ Segar! +200 HP & +100 MP');
    }

    if (action === 'konfirmasi_lantai') {
        let targetLantai = parseInt(targetArg);
        if (targetLantai) rpg.lantai = targetLantai;
        return m.reply(`⚔️ *GERBANG TERBUKA!*\nKamu melangkah masuk ke *Lantai ${rpg.lantai}*. Ketik \`${prefix}${command}\` untuk berburu!`);
    }

    if (action === 'batal_lantai') {
        return m.reply(`🏕️ Kamu memutuskan untuk menetap di *Lantai ${rpg.lantai}*. Ketik \`${prefix}${command}\` untuk kembali berburu.`);
    }

    if (action === 'lantai' || (action !== '' && !isNaN(action))) {
        if (room) return m.reply("⚠️ Fokus pahlawan! Habisi dulu monstermu saat ini!");
        let targetLantai = parseInt(action === 'lantai' ? args[1] : action);
        if (!targetLantai || targetLantai < 1 || targetLantai > 10) return m.reply(`❌ Celah lantai hanya tersedia dari 1 hingga 10!`);
        
        if (targetLantai > rpg.lantai) {
            let reqLevel = targetLantai * 3;
            if ((user.level || 0) < reqLevel || totalMaxHp < (targetLantai * 100) || rpg.max_mp < (targetLantai * 50)) {
                return m.reply(`🛑 *SEGEL LANTAI ${targetLantai} MENOLAKMU!*\n\nSyarat Belum Terpenuhi:\nLevel: ${user.level || 0}/${reqLevel} | HP: ${totalMaxHp}/${targetLantai * 100} | MP: ${rpg.max_mp}/${targetLantai * 50}`);
            }
        }
        return renderSafeZone(targetLantai);
    }

    // HANDLER KABUR DARI PERTARUNGAN
    if (action === 'run' || action === 'kabur') {
        if (!room || !room.monster) return m.reply(`⚠️ Kesunyian malam menyelimutimu. Tidak ada musuh di sekitarmu!`);
        
        let isSuccess = Math.random() * 100 > 40; 
        let teksRun = `💨 ＥＳＣＡＰＥ\n`;
        teksRun += `───────────────\n`;

        if (isSuccess) {
            teksRun += `✅ *KABUR BERHASIL!*\nKamu berhasil bersembunyi dalam bayangan dan meloloskan diri dari *${room.monster}*.\n`;
        } else {
            let penalty = Math.floor(user.balance * 0.05); 
            user.balance -= penalty;
            let damage = Math.max(10, 50 - Math.floor(totalDef / 2)); 
            rpg.hp -= damage; 
            if (rpg.hp < 0) rpg.hp = 0;
            
            let percHP = (rpg.hp / totalMaxHp) * 100;
            teksRun += `💥 *GAGAL KABUR!*\n*${room.monster}* mengejarmu dan mendaratkan serangan telak dari belakang!\n\n`;
            teksRun += `◈ ＰＥＮＡＬＴＹ ◈\n`;
            teksRun += `❤️ *HP:* -${damage}\n`;
            teksRun += `└ [${makeBar(percHP)}]\n`;
            teksRun += `💸 *Rp:* -${penalty}\n`;
            
            if (rpg.hp === 0) teksRun += `\n💀 *KAMU TEWAS DI DUNGEON!*\n`;
        }
        
        delete global.adventure[m.sender];
        
        let arrayTombolRun = [];
        if (rpg.hp > 0) {
            arrayTombolRun.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "⚔️ Cari Musuh", id: `${prefix}${command}` }) });
            arrayTombolRun.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🏕️ Safe Zone", id: `${prefix}${command} lantai ${rpg.lantai}` }) });
        } else {
            arrayTombolRun.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🏥 Bangkit", id: `.heal` }) });
        }
        
        return sendRPGButton(teksRun, arrayTombolRun);
    }

    // HANDLER SERANG (BASIC/ULTI/HIDDEN/POTION)
    if (action === 'basic' || action === 'ulti' || action === 'hidden' || action === 'potion') {
        if (!room || typeof room.monster !== 'string') {
            delete global.adventure[m.sender]; 
            return m.reply(`⚠️ Fokus pahlawan! Tidak ada monster di depanmu.\nKetik *${prefix}${command}* untuk mencari musuh.`);
        }

        let isBossFloor = rpg.lantai === 10;
        let isWin = false, isCritical = false, isBlunder = false;
        let damageTaken = 0, costMP = 0;
        let titleMode = '', teksFinal = '', skillName = 'Serangan Biasa';

        if (action === 'potion') {
            if (!rpg.inventory.potion || rpg.inventory.potion < 1) return m.reply(`❌ Botol Potionmu kosong!`);
            
            rpg.inventory.potion -= 1;
            rpg.hp = Math.min(totalMaxHp, rpg.hp + 200);
            rpg.mp = Math.min(rpg.max_mp, rpg.mp + 100);
            
            titleMode = '🧪 MINUM POTION'; 
            skillName = 'Item (Potion)'; 
            isWin = false; 
            
            let rawDmg = Math.floor(Math.random() * 40 * rpg.lantai) + 20;
            damageTaken = Math.max(5, rawDmg - Math.floor(totalDef * 0.8)); 
            
            teksFinal = `*${room.monster}* menerjang saat kamu sedang meminum Potion!`;
        } 
        else {
            let isUlti = action === 'ulti'; 
            let isHidden = action === 'hidden';
            
            const hiddenSkills = { 
                'Warrior 🗡️': 'Wrath of Xenoria', 'Mage 🪄': 'Meteor Strike', 
                'Assassin 🥷': 'Phantom Execution', 'Archer 🏹': 'Arrow of Apollo', 
                'Necromancer 💀': 'Army of The Dead', 'Paladin 🛡️✨': 'Divine Retribution', 
                'Dragon Slayer 🐉': 'Dragon Force', 'Demon Lord 👿': 'Cataclysm Burst' 
            };

            costMP = isHidden ? 150 : (isUlti ? 60 : 0);
            if ((isUlti || isHidden) && rpg.mp < costMP) return m.reply(`❌ Mana tidak cukup! (Butuh ${costMP} MP)`);
            if (isHidden) { 
                if (room.hidden_used) return m.reply(`🚫 Secret Art sangat menguras energi. Hanya 1x per monster!`); 
                room.hidden_used = true; 
            }

            skillName = isHidden ? (hiddenSkills[rpg.role] || 'Secret Arts') : (isUlti ? rpg.skill : 'Serangan Biasa');

            let baseAccuracy = 70 + Math.floor(totalAtk / 5) - (rpg.lantai * 2); 
            if (room.weather === 'Holy Light ✨') baseAccuracy += 20;

            let roll = Math.random() * 100;
            isCritical = roll <= 15 && action !== 'basic'; 
            isBlunder = roll >= 90 && action === 'basic'; 
            isWin = isCritical ? true : (isBlunder ? false : ((isUlti || isHidden) ? true : (Math.random() * 100 <= baseAccuracy)));
            
            let damageMultiplier = isBossFloor ? (rpg.lantai * 4) : rpg.lantai;
            if (room.weather === 'Blood Moon 🌑') damageMultiplier *= 1.5; 

            let rawMonsterDamage = isWin ? Math.floor(Math.random() * 10 * damageMultiplier) : Math.floor(Math.random() * 40 * damageMultiplier) + 50;
            damageTaken = Math.max(0, rawMonsterDamage - totalDef); 

            if (isCritical) damageTaken = 0; 
            if (isBlunder) damageTaken = Math.floor(rawMonsterDamage * 1.5); 

            titleMode = isCritical ? '🔥 CRITICAL HIT' : (isHidden ? '🌟 SECRET ART' : (isUlti ? '💥 ULTIMATE' : '🗡️ BERHASIL'));
            
            if (isWin) {
                teksFinal = `Pertarungan usai. *${room.monster}* hancur berkeping-keping!`;
            } else {
                titleMode = isBlunder ? '🤡 BLUNDER' : '💀 DITANGKIS';
                teksFinal = isBlunder ? `Kuda-kudamu goyah! Kamu terpeleset saat menyerang.` : `*${room.monster}* menangkis serangan dan membalas dengan brutal!`;
            }
        }

        let xpGained = 0, dropTeks = '';

        if (isWin) {
            // XP Calculation
            xpGained = (Math.floor(Math.random() * 200) + 100) * rpg.lantai;
            
            // Base Economy Item (GOLD ORE) - Menggantikan drop Uang langsung
            let goldDrop = Math.floor(Math.random() * 3) + rpg.lantai;
            
            // Multipliers
            if (room.weather === 'Blood Moon 🌑') { xpGained *= 2; goldDrop *= 2; } 
            if (action === 'hidden') { goldDrop *= 3; xpGained *= 2; } 
            else if (action === 'ulti') { goldDrop *= 2; }

            if (rpg.guild_quest && rpg.guild_quest.status === 'active' && rpg.guild_quest.type === 'hunt') {
                rpg.guild_quest.progress += 1;
            }

            // Memasukkan item inti ke Inventory
            rpg.inventory['gold'] = (rpg.inventory['gold'] || 0) + Math.floor(goldDrop);
            dropTeks += `🪙 +${Math.floor(goldDrop)} GOLD ORE\n`;

            let safeMonsterName = String(room.monster).toLowerCase();
            let epicDrop = '';
            
            // Monster Specific Drops
            if (safeMonsterName.includes('serigala')) epicDrop = 'shadow_essence';
            else if (safeMonsterName.includes('tengkorak')) epicDrop = 'cursed_soul';
            else if (safeMonsterName.includes('golem')) epicDrop = 'divine_steel';
            else if (safeMonsterName.includes('troll')) epicDrop = 'enchanted_wood';
            else if (safeMonsterName.includes('penyihir')) epicDrop = 'mana_crystal';
            else if (safeMonsterName.includes('naga')) epicDrop = 'dragon_bone';

            if (epicDrop && Math.random() <= (isBossFloor ? 0.8 : 0.3)) {
                rpg.inventory[epicDrop] = (rpg.inventory[epicDrop] || 0) + 1;
                dropTeks += `🌟 +1 ${epicDrop.toUpperCase()}\n`;
            }

            // Boss & Diamond Drops (High Value items for Bank)
            if (isBossFloor) {
                let bossDrops = ['diamond', 'diamond', 'boss_core']; // Diamond lebih sering drop di bos
                let gotBoss = bossDrops[Math.floor(Math.random() * bossDrops.length)];
                rpg.inventory[gotBoss] = (rpg.inventory[gotBoss] || 0) + 1;
                dropTeks += `👑 +1 ${gotBoss.toUpperCase().replace('_', ' ')}\n`;
            } else if (rpg.lantai >= 5 && Math.random() <= 0.15) {
                // Peluang drop diamond di lantai tengah ke atas
                rpg.inventory['diamond'] = (rpg.inventory['diamond'] || 0) + 1;
                dropTeks += `💎 +1 DIAMOND\n`;
            }

            // Basic Drops (dikurangi karena Gold sudah jadi drop utama)
            let basicDrops = rpg.lantai >= 6 ? ['iron', 'monster_loot'] : ['wood', 'string', 'monster_loot'];
            let gotBasic = basicDrops[Math.floor(Math.random() * basicDrops.length)];
            let jmlBasic = Math.floor(Math.random() * 3) + 1;
            if (isCritical) jmlBasic *= 2;
            rpg.inventory[gotBasic] = (rpg.inventory[gotBasic] || 0) + jmlBasic;
            dropTeks += `📦 +${jmlBasic} ${gotBasic.toUpperCase()}\n`;

            if (Math.random() <= 0.10) { 
                let shopDrops = ['potion', 'mana', 'crystal'];
                let gotShop = shopDrops[Math.floor(Math.random() * shopDrops.length)];
                rpg.inventory[gotShop] = (rpg.inventory[gotShop] || 0) + 1;
                dropTeks += `🛍️ +1 ${gotShop.toUpperCase()}\n`;
            }

            // Update user experience only
            user.xp = (user.xp || 0) + Math.floor(xpGained);
        }

        rpg.hp -= damageTaken; 
        if (costMP > 0) rpg.mp -= costMP;

        // Hitung persentase untuk bar visual akhir
        let percHP = (rpg.hp / totalMaxHp) * 100;
        let percDef = (totalDef / 100) * 100; 
        let percXP = (user.xp / xpNeeded) * 100;

        let resText = `⚔️ ＢＡＴＴＬＥ\n`;
        resText += `───────────────\n`;
        resText += `🎯 *Aksi :* ${skillName}\n`;
        resText += `⚡ *Mode :* ${titleMode}\n\n`;
        resText += `_"${teksFinal}"_\n\n`;
        
        resText += `◈ ＤＡＭＡＧＥ ◈\n`;
        resText += `🛡️ *Block:* ${totalDef}\n`;
        resText += `└ [${makeBar(percDef)}]\n`;
        resText += `❤️ *HP:* -${Math.floor(damageTaken)} (Sisa: ${rpg.hp})\n`;
        resText += `└ [${makeBar(percHP)}]\n`;
        
        if (costMP > 0) {
            let percMP = (rpg.mp / rpg.max_mp) * 100;
            resText += `💙 *MP:* -${costMP}\n`;
            resText += `└ [${makeBar(percMP)}]\n`;
        }

        if (isWin) {
            resText += `\n◈ ＬＯＯＴ ＤＲＯＰＳ ◈\n`;
            resText += `✨ *XP :* +${Math.floor(xpGained)}\n`;
            resText += `└ [${makeBar(percXP)}] ${percXP.toFixed(1)}%\n`;
            if (dropTeks) resText += dropTeks;
            resText += `\n💡 _Tukarkan Ore & Core di .bank_`;
        }
        
        if (rpg.hp <= 0) { 
            rpg.hp = 0; 
            resText += `\n💀 *KAMU TEWAS DI DUNGEON!*\n`; 
        }

        let arrayTombolPost = [];
        if (rpg.hp > 0) {
            if (isWin || action === 'potion') {
                arrayTombolPost.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "⚔️ Jelajah Lagi", id: `${prefix}${command}` }) });
                if (rpg.guild_quest && rpg.guild_quest.status === 'active') {
                    arrayTombolPost.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "📜 Cek Misi", id: `${prefix}guildquest` }) });
                }
            }
            if (!isWin && action !== 'potion') {
                arrayTombolPost.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "⚔️ Serang Balik", id: `${prefix}${command} basic` }) });
                arrayTombolPost.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🥤 Minum Potion", id: `${prefix}${command} potion` }) });
                arrayTombolPost.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🏃‍♂️ Kabur", id: `${prefix}${command} run` }) });
            } else {
                arrayTombolPost.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🏕️ Safe Zone", id: `${prefix}${command} lantai ${rpg.lantai}` }) });
            }
        } else {
            arrayTombolPost.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🏥 Bangkit", id: `.heal` }) });
        }

        if (isWin || rpg.hp <= 0) delete global.adventure[m.sender]; 
        return sendRPGButton(resText.trim(), arrayTombolPost);
    }

    // HANDLER MENCARI MUSUH
    if (action === '' || action === 'cari' || action === 'hunt') {
        if (room && typeof room.monster === 'string') return m.reply("⚠️ Aroma darah masih kuat! Habisi dulu monstermu saat ini.");
        if (rpg.hp < 50) return m.reply(`🏥 Visimu mengabur (HP: ${rpg.hp}). Ketik .heal sebelum kau mati di kegelapan!`);

        let activeWeather = ['Normal ☁️', 'Normal ☁️', 'Normal ☁️', 'Blood Moon 🌑', 'Acid Rain 🌧️', 'Holy Light ✨'][Math.floor(Math.random() * 6)];
        
        let monster = '';
        if (rpg.lantai <= 3) monster = ['Slime 🫧', 'Kelinci 🐇', 'Kelelawar 🦇'][Math.floor(Math.random() * 3)];
        else if (rpg.lantai <= 6) monster = ['Serigala 🐺', 'Goblin 👺', 'Tengkorak 💀'][Math.floor(Math.random() * 3)];
        else if (rpg.lantai <= 9) monster = ['Orc 👹', 'Golem 🪨', 'Troll 🧟‍♂️', 'Penyihir 🧙‍♀️'][Math.floor(Math.random() * 4)];
        else monster = ['NAGA HITAM 🐉', 'RAJA IBLIS 👿'][Math.floor(Math.random() * 2)];

        let msg = await sock.sendMessage(m.chat, { text: `👣 _Menelusuri lorong gelap di Lantai ${rpg.lantai}..._` }, { quoted: m });
        await delay(1200);

        if (activeWeather === 'Acid Rain 🌧️') {
            rpg.hp -= 30;
            await sock.sendMessage(m.chat, { text: `🌧️ ☠️ *ACID RAIN!* Tetesan hujan melelehkan armor dan kulitmu (HP -30).`, edit: msg.key }); 
            await delay(1200);
        }

        if ((rpg.lantai >= 5) && (Math.random() < 0.35)) {
            let ambushDamage = Math.max(5, (Math.floor(Math.random() * 15 * rpg.lantai) + 20) - Math.floor(totalDef * 0.5)); 
            rpg.hp -= ambushDamage;
            
            await sock.sendMessage(m.chat, { text: `🩸 ⚠️ *AMBUSH!* ${monster} melompat dari kegelapan dan melukaimu (HP -${ambushDamage}).`, edit: msg.key }); 
            await delay(1200);
            
            if (rpg.hp <= 0) { 
                rpg.hp = 0; 
                delete global.adventure[m.sender]; 
                return sock.sendMessage(m.chat, { text: `💀 _Pandanganmu memudar... Kamu tewas di dalam Dungeon._`, edit: msg.key }); 
            }
        } else {
            await sock.sendMessage(m.chat, { text: `⚠️ 👁️ _Sesuatu bergerak di dalam bayangan... Target ditemukan!_`, edit: msg.key }); 
            await delay(1000);
        }

        let percHP = (rpg.hp / totalMaxHp) * 100;

        let teksOpsi = `⚠️ ＥＮＣＯＵＮＴＥＲ\n`;
        teksOpsi += `───────────────\n`;
        teksOpsi += `👾 *Target :* ${monster}\n`;
        teksOpsi += `🌦️ *Cuaca  :* ${activeWeather}\n\n`;
        teksOpsi += `◈ ＣＯＮＤＩＴＩＯＮ ◈\n`;
        teksOpsi += `❤️ *HP:* ${rpg.hp}/${totalMaxHp}\n`;
        teksOpsi += `└ [${makeBar(percHP)}]\n`;
        if (activePet.name) teksOpsi += `🐾 *Pet:* ${activePet.name}\n\n`;
        teksOpsi += `_"Makhluk itu menatapmu dengan insting membunuh..."_`;

        let arrayTombol = [ 
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "⚔️ Serang (Basic)", id: `${prefix}${command} basic` }) }, 
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "💥 Skill Ultimate", id: `${prefix}${command} ulti` }) } 
        ];
        
        if ((rpg.inventory.potion || 0) > 0) {
            arrayTombol.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🥤 Potion", id: `${prefix}${command} potion` }) });
        }
        if (user.level >= 20 || rpg.role.includes('Mythic')) {
            arrayTombol.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🌟 Hidden Art", id: `${prefix}${command} hidden` }) });
        }
        arrayTombol.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🏃‍♂️ Kabur", id: `${prefix}${command} run` }) });

        global.adventure[m.sender] = { monster: monster, weather: activeWeather, chatId: m.chat, hidden_used: false };
        return sendRPGButton(teksOpsi, arrayTombol);
    }
}

// RULES #3: HANDLER HANYA BOLEH 1
handler.command = ["adventure"];
handler.tags = ["rpg"];
module.exports = handler;
