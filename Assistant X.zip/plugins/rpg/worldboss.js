const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

// ==========================================
// 🐉 WORLD BOSS RAID SYSTEM V2
// ⚙️ Ciptaan Pstar7 | Interactive Buttons & Minimalist UI
// ==========================================

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
global.world_boss = global.world_boss || {};

let handler = async (m, { sock, args, prefix, command, isOwner }) => {
    let users = global.db.users;
    let groupId = m.chat; 

    // 🛡️ FUNGSI BANTUAN PENGIRIM TOMBOL ANTI-DROP
    async function sendRPGButton(teks, arrayTombol, extraMentions = []) {
        let pesan = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: "© Xenoria Boss Raid 🐉" }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons: arrayTombol }),
                        contextInfo: { 
                            mentionedJid: [m.sender, ...extraMentions],
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: global.idChannel || "1203631@newsletter", 
                                newsletterName: "Xenoria Server", 
                                serverId: 1 
                            }
                        }
                    })
                }
            }
        }, { quoted: m });
        return sock.relayMessage(m.chat, pesan.message, { messageId: pesan.key.id });
    }

    if (command === 'summonboss') {
        if (!isOwner) return m.reply("❌ Hanya Dewa Xenoria (Owner) yang bisa memanggil Bencana!");
        if (global.world_boss[groupId]) return m.reply("⚠️ Masih ada World Boss yang mengamuk di grup ini! Kalahkan dulu!");

        let bossHp = 50000;
        global.world_boss[groupId] = {
            name: "🐉 NAGA BENCANA XENORIA",
            hp: bossHp,
            max_hp: bossHp,
            participants: {}, 
            status: 'active'
        };

        let teks = `⚠️ *WARNING! WORLD BOSS MUNCUL!* ⚠️\n\n`;
        teks += `Langit menggelap dan bumi bergetar...\n`;
        teks += `*${global.world_boss[groupId].name}* telah turun ke grup ini!\n\n`;
        teks += `❤️ *HP BOSS:* ${bossHp.toLocaleString()}\n\n`;
        teks += `_Semua Pahlawan, segera bersatu! Hati-hati, naga ini bisa membalas seranganmu!_`;

        return sendRPGButton(teks, [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "⚔️ SERANG BOSS!", id: `${prefix}attackboss` }) }
        ]);
    }

    if (command === 'cekboss') {
        let boss = global.world_boss[groupId];
        if (!boss) return m.reply(`💤 Dunia sedang damai. Tidak ada World Boss saat ini.`);

        let sortedMvp = Object.entries(boss.participants).sort((a, b) => b[1] - a[1]).slice(0, 5); 
        
        let teksInfo = `🐉 *INFO WORLD BOSS*\n\n`;
        teksInfo += `🐲 *Nama:* ${boss.name}\n`;
        teksInfo += `❤️ *Sisa HP:* ${boss.hp.toLocaleString()} / ${boss.max_hp.toLocaleString()}\n\n`;
        teksInfo += `🏆 *TOP 5 KONTRIBUTOR DAMAGE:*\n`;
        
        if (sortedMvp.length === 0) {
            teksInfo += `_(Belum ada yang berani menyerang...)_\n`;
        } else {
            sortedMvp.forEach((p, i) => {
                teksInfo += `◦ ${i+1}. @${p[0].split('@')[0]} - ${p[1]} DMG\n`;
            });
        }

        let mentions = sortedMvp.map(p => p[0]);
        return sendRPGButton(teksInfo, [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "⚔️ Ikut Menyerang", id: `${prefix}attackboss` }) }
        ], mentions);
    }

    if (command === 'attackboss' || command === 'atkboss') {
        let boss = global.world_boss[groupId];
        if (!boss) return m.reply(`💤 Dunia sedang damai. Tunggu Dewa memanggil bossnya!`);

        let user = users[m.sender];
        if (!user || !user.registered) return m.reply(`❌ Kamu belum terdaftar di Xenoria!`);
        let rpg = user.rpg;
        if (!rpg || rpg.role === 'Novice') return m.reply(`⚠️ Levelmu terlalu rendah! \`${prefix}awaken\` dulu!`);
        if (rpg.hp < 50) return m.reply(`🏥 Darahmu kritis (${rpg.hp} HP). Jangan bunuh diri, \`${prefix}heal\` dulu!`);
        if (rpg.isHealing) return m.reply(`🧘 Batalkan meditasimu jika ingin ikut Raid!`);

        let cdw = 10000; 
        let lastAtk = user.last_boss_atk || 0;
        if (Date.now() - lastAtk < cdw) {
            return m.reply(`⏳ Tunggu ${Math.ceil((cdw - (Date.now() - lastAtk))/1000)} detik lagi untuk menyerang.`);
        }
        user.last_boss_atk = Date.now();

        let animMsg = await sock.sendMessage(m.chat, { text: `⚔️ *RAID STRIKE*\n\nMelesat ke arah *${boss.name}*...` }, { quoted: m });
        await delay(800);
        await sock.sendMessage(m.chat, { text: `⚔️ *RAID STRIKE*\n\n👁️ Boss menyadari pergerakanmu!`, edit: animMsg.key });
        await delay(800);

        let isCritical = Math.random() < 0.20; 
        let rawDmg = Math.floor(Math.random() * 50) + (rpg.attack * 3); 
        let finalDmg = isCritical ? rawDmg * 2 : rawDmg;
        let bossDmg = Math.max(10, Math.floor(Math.random() * 200) - Math.floor(rpg.defense * 1.5));

        let rollBoss = Math.random() * 100;
        let mekanikTeks = '';

        if (rollBoss <= 15) {
            finalDmg = 0; 
            bossDmg = Math.floor(bossDmg * 0.5); 
            mekanikTeks = `💨 *BOSS MENGHINDAR!*\nNaga terbang tinggi! Seranganmu meleset!`;
        } 
        else if (rollBoss <= 30) {
            bossDmg *= 3; 
            mekanikTeks = `🔥 *SERANGAN KEJUTAN!*\nBoss MENGAMUK! Semburan api raksasa melahapmu!`;
        } 
        else {
            mekanikTeks = `${isCritical ? '⚡ *CRITICAL STRIKE!*' : '🗡️ *TELAK!*'}\nSenjatamu berhasil menembus sisik naga!`;
        }

        rpg.hp -= bossDmg;
        if (rpg.hp < 0) rpg.hp = 0;

        boss.hp -= finalDmg;
        if (boss.hp < 0) boss.hp = 0;
        if (finalDmg > 0) boss.participants[m.sender] = (boss.participants[m.sender] || 0) + finalDmg;

        let miniGold = Math.floor(Math.random() * 800) + 200;
        user.balance += miniGold;
        user.xp = (user.xp || 0) + 100;

        // JIKA BOSS MATI
        if (boss.hp === 0 && boss.status === 'active') {
            boss.status = 'dead'; 

            let sortedMvp = Object.entries(boss.participants).sort((a, b) => b[1] - a[1]);
            let mvpJid = sortedMvp[0][0]; 
            let mvpDmg = sortedMvp[0][1];
            let lastHitJid = m.sender;    

            let userMvp = users[mvpJid];
            if (userMvp) {
                userMvp.balance += 1000000; 
                userMvp.rpg.inventory = userMvp.rpg.inventory || {};
                userMvp.rpg.inventory.crate = (userMvp.rpg.inventory.crate || 0) + 5; 
                userMvp.rpg.inventory.boss_core = (userMvp.rpg.inventory.boss_core || 0) + 3;
            }

            let userLastHit = users[lastHitJid];
            if (userLastHit) {
                userLastHit.balance += 500000; 
                userLastHit.rpg.inventory.crate = (userLastHit.rpg.inventory.crate || 0) + 2;
            }

            let teksMati = `🎉 *WORLD BOSS DEFEATED!* 🎉\n\n`;
            teksMati += `*${boss.name}* akhirnya tumbang!\n\n`;
            teksMati += `🏆 *MVP (Damage Terbesar):*\n`;
            teksMati += `👤 @${mvpJid.split('@')[0]}\n`;
            teksMati += `💥 Total Damage: ${mvpDmg.toLocaleString()}\n`;
            teksMati += `🎁 Reward: Rp 1 Juta, 5 Crate, 3 Boss Core\n\n`;
            teksMati += `🗡️ *LAST HITTER (Pembunuh):*\n`;
            teksMati += `👤 @${lastHitJid.split('@')[0]}\n`;
            teksMati += `🎁 Reward: Rp 500 Ribu, 2 Crate\n\n`;
            teksMati += `_Terima kasih atas perjuangan kalian, Pahlawan Xenoria!_`;

            delete global.world_boss[groupId]; 
            
            // Delete Animasi dan kirim Pengumuman Kemenangan
            await sock.sendMessage(m.chat, { delete: animMsg.key }).catch(() => {});
            return sock.sendMessage(m.chat, { text: teksMati, mentions: [mvpJid, lastHitJid] });
        }

        // JIKA BOSS BELUM MATI
        let teksHit = `⚔️ *BATTLE RESULT*\n\n`;
        teksHit += `${mekanikTeks}\n\n`;
        teksHit += `💥 Damage Diberikan: ${finalDmg}\n`;
        teksHit += `💢 Damage Diterima: -${bossDmg} HP\n\n`;
        teksHit += `📉 *Sisa HP Boss:* ${boss.hp.toLocaleString()} / ${boss.max_hp.toLocaleString()}\n`;
        
        if (rpg.hp === 0) teksHit += `\n_⚠️ Kamu tewas tercabik-cabik dan butuh .heal!_`;

        let arrayTombolAtk = [];
        if (rpg.hp > 0) {
            arrayTombolAtk.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "⚔️ Serang Lagi", id: `${prefix}${command}` }) });
            arrayTombolAtk.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🏥 Mundur & Heal", id: `.heal` }) });
        } else {
            arrayTombolAtk.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🏥 Bangkit", id: `.heal` }) });
        }

        await sock.sendMessage(m.chat, { delete: animMsg.key }).catch(() => {});
        return sendRPGButton(teksHit, arrayTombolAtk);
    }
}

handler.command = ["summonboss", "attackboss", "atkboss", "cekboss"];
handler.tags = ["rpg"];
handler.owner = false; 

module.exports = handler;
