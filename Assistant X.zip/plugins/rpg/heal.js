const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

// ==========================================
// 🏥 SISTEM PEMULIHAN - XENORIA CHRONICLES
// ⚙️ Ciptaan Pstar7 | Minimalist UI & Anti-Drop Fix
// ==========================================

global.healing = global.healing || {}; 

let handler = async (m, { sock, args, prefix, command }) => {
    let user = global.db.users[m.sender];
    if (!user || !user.registered) return m.reply(`❌ Kamu belum menginjakkan kaki di Benua Xenoria!`);
    
    let rpg = user.rpg;
    if (!rpg || rpg.role === 'Novice') return m.reply(`⚠️ Kamu belum punya kekuatan untuk di-heal!`);

    rpg.max_hp = rpg.max_hp || 500;
    rpg.max_mp = rpg.max_mp || 400;

    let action = args[0] ? args[0].toLowerCase() : '';

    // ==========================================
    // 🛡️ FUNGSI BANTUAN PENGIRIM TOMBOL ANTI-DROP
    // ==========================================
    async function sendRPGButton(teks, arrayTombol) {
        let pesan = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: { 
                message: { 
                    interactiveMessage: proto.Message.InteractiveMessage.create({ 
                        body: proto.Message.InteractiveMessage.Body.create({ text: teks }), 
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: "© Xenoria Hospital" }), 
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons: arrayTombol }),
                        contextInfo: { 
                            mentionedJid: [m.sender],
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: global.idChannel || "1203631@newsletter", 
                                newsletterName: "Xenoria Server", 
                                serverId: 1 
                            }
                        }
                    }) 
                } 
            }
        }, { quoted: m }); // Quoted M untuk menjamin pesan terkoneksi dan tidak di-spam filter
        return sock.relayMessage(m.chat, pesan.message, { messageId: pesan.key.id });
    }

    // ==========================================
    // 🛑 1. BATAL MEDITASI
    // ==========================================
    if (action === 'batal' || action === 'stop') {
        if (!rpg.isHealing) return m.reply(`⚠️ Kamu sedang tidak bermeditasi!`);
        
        rpg.isHealing = false;
        if (global.healing[m.sender]) {
            clearTimeout(global.healing[m.sender]);
            delete global.healing[m.sender];
        }
        
        return m.reply(`🛑 *MEDITASI DIBATALKAN*\nKamu bangkit dan memutus aliran energi secara paksa. Pemulihan dibatalkan!`);
    }

    // 🛡️ BLOKIR AKSES JIKA SEDANG MEDITASI
    if (rpg.isHealing) {
        return m.reply(`🧘 Kamu sedang fokus bermeditasi menyerap energi alam!\nKetik \`${prefix}heal batal\` jika ingin membatalkannya.`);
    }

    // ==========================================
    // ⚡ 2. HEAL INSTAN (BAYAR & CEPAT)
    // ==========================================
    if (action === 'instan') {
        let kategori = args[1] ? args[1].toLowerCase() : '';
        let cost = 1500; 

        if (user.balance < cost) return m.reply(`💸 Saldomu kurang! Butuh ${cost} Saldo.`);

        if (kategori === 'hp') {
            if (rpg.hp >= rpg.max_hp) return m.reply(`❤️ HP kamu sudah penuh!`);
            rpg.hp = rpg.max_hp;
            user.balance -= cost;
            return m.reply(`✨ *INSTANT HEAL BERHASIL!*\n❤️ Darah (HP) pulih sepenuhnya.\n💰 Biaya: -${cost} Saldo`);
        } else if (kategori === 'mp') {
            if (rpg.mp >= rpg.max_mp) return m.reply(`💙 MP kamu sudah penuh!`);
            rpg.mp = rpg.max_mp;
            user.balance -= cost;
            return m.reply(`✨ *INSTANT HEAL BERHASIL!*\n💙 Mana (MP) pulih sepenuhnya.\n💰 Biaya: -${cost} Saldo`);
        }
    }

    // ==========================================
    // 🧘‍♂️ 3. EKSEKUSI MEDITASI LANGSUNG
    // ==========================================
    if (command === 'meditasi' || action === 'meditasi') {
        if (rpg.hp >= rpg.max_hp && rpg.mp >= rpg.max_mp) {
            return m.reply(`🌟 Energimu sudah penuh, tidak perlu membuang waktu untuk meditasi.`);
        }

        let butuhHp = rpg.max_hp - rpg.hp;
        let butuhMp = rpg.max_mp - rpg.mp;
        
        let waktuHp = (butuhHp / 100) * 30; 
        let waktuMp = (butuhMp / 50) * 30;  
        
        let totalDetik = Math.max(waktuHp, waktuMp);
        totalDetik = Math.floor(totalDetik); 
        if (totalDetik < 10) totalDetik = 10; 
        
        let menit = Math.floor(totalDetik / 60);
        let detik = totalDetik % 60;
        let waktuTeks = menit > 0 ? `${menit} Menit ${detik} Detik` : `${detik} Detik`;

        rpg.isHealing = true; 

        let teksMulai = `🧘‍♂️ *MEDITASI DIMULAI*\n\n`;
        teksMulai += `Kamu mencari tempat aman, duduk bersila, dan menutup mata...\n\n`;
        teksMulai += `📉 *Kekurangan Energi:* ${butuhHp} HP | ${butuhMp} MP\n`;
        teksMulai += `⏳ *Estimasi Waktu:* ${waktuTeks}\n\n`;
        teksMulai += `_Ketik \`${prefix}heal batal\` jika ingin bangkit secara paksa._`;

        await sock.sendMessage(m.chat, { text: teksMulai, mentions: [m.sender] }, { quoted: m });

        global.healing[m.sender] = setTimeout(async () => {
            let userSekarang = global.db.users[m.sender];
            if (!userSekarang || !userSekarang.rpg.isHealing) return; 

            userSekarang.rpg.hp = userSekarang.rpg.max_hp;
            userSekarang.rpg.mp = userSekarang.rpg.max_mp;
            userSekarang.rpg.isHealing = false; 
            delete global.healing[m.sender]; 

            let teksSelesai = `✅ *MEDITASI SELESAI*\n\n`;
            teksSelesai += `Sihir Xenoria telah memulihkan tubuhmu sepenuhnya!\n\n`;
            teksSelesai += `👤 *Pahlawan:* ${userSekarang.name}\n`;
            teksSelesai += `❤️ *HP:* ${userSekarang.rpg.hp} / ${userSekarang.rpg.max_hp}\n`;
            teksSelesai += `💙 *MP:* ${userSekarang.rpg.mp} / ${userSekarang.rpg.max_mp}\n\n`;
            teksSelesai += `_Energi penuh! Saatnya kembali berburu! ⚔️_`;
            
            await sock.sendMessage(m.chat, { text: teksSelesai, mentions: [m.sender] });
        }, totalDetik * 1000);
        
        return; 
    }

    // ==========================================
    // 🏥 4. MENU UTAMA HEAL (UI TOMBOL)
    // ==========================================
    let teksMenu = `🏥 *PUSAT PEMULIHAN*\n\n`;
    teksMenu += `👤 *Pahlawan:* ${user.name}\n`;
    teksMenu += `❤️ *HP:* ${rpg.hp}/${rpg.max_hp}\n`;
    teksMenu += `💙 *MP:* ${rpg.mp}/${rpg.max_mp}\n`;
    teksMenu += `💰 *Saldo:* Rp ${user.balance.toLocaleString('id-ID')}\n\n`;
    teksMenu += `_Pilih metode pemulihanmu:_`;

    let arrayTombol = [
        { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "⚡ Heal HP (1500)", id: `${prefix}heal instan hp` }) },
        { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "⚡ Heal MP (1500)", id: `${prefix}heal instan mp` }) },
        { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🧘‍♂️ Meditasi Gratis", id: `${prefix}meditasi` }) }
    ];

    return sendRPGButton(teksMenu, arrayTombol);
}

handler.command = ["heal", "pulih", "meditasi"];
handler.tags = ["rpg"];
handler.help = ["heal"];

module.exports = handler;
