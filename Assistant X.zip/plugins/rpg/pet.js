const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

// ==========================================
// 🦅 XENORIA COMPANION (PET SYSTEM)
// ⚙️ Ciptaan Pstar7 | Minimalist UI & Anti-Drop Fix
// ==========================================

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

let handler = async (m, { sock, args, prefix, command }) => {
    let user = global.db.users[m.sender];
    
    if (!user || !user.registered) return m.reply(`❌ Kamu belum terdaftar di Xenoria!`);
    let rpg = user.rpg;
    if (!rpg || rpg.role === 'Novice') return m.reply(`⚠️ Pahlawan pemula belum diizinkan memelihara monster. \`${prefix}awaken\` dulu!`);

    if (Array.isArray(rpg.pets)) {
        let newPets = {};
        rpg.pets.forEach(p => newPets[p] = (newPets[p] || 0) + 1);
        rpg.pets = newPets;
    } else {
        rpg.pets = rpg.pets || {};
    }
    rpg.active_pet = rpg.active_pet || ''; 

    const petData = {
        'slime': { name: '🫧 Slime', rarity: '🟢 Common', atk: 0, def: 5, hp: 50, price: 30000 },
        'serigala': { name: '🐺 Serigala', rarity: '🔵 Rare', atk: 15, def: 10, hp: 0, price: 75000 },
        'phoenix': { name: '🦅 Phoenix', rarity: '🔴 Legendary', atk: 30, def: 0, hp: 100, price: 200000 },
        'naga': { name: '🐉 Naga Hitam', rarity: '👑 Mythic', atk: 50, def: 20, hp: 200, price: 1000000 }
    };

    let action = args[0] ? args[0].toLowerCase() : '';
    let targetPet = args[1] ? args[1].toLowerCase() : '';
    let jumlah = args[2] ? parseInt(args[2]) : 1;
    if (isNaN(jumlah) || jumlah < 1) jumlah = 1;

    // 🛡️ FUNGSI BANTUAN PENGIRIM TOMBOL ANTI-DROP
    async function sendRPGButton(teks, arrayTombol) {
        let pesan = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: "© Xenoria Pet Sanctuary 🐾" }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons: arrayTombol }),
                        contextInfo: { 
                            mentionedJid: [m.sender],
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: global.idChannel || "1203631@newsletter", 
                                newsletterName: "Xenoria Server", 
                                serverId: 1 
                            }
                        }
                    })
                }
            }
        }, { quoted: m });
        return sock.relayMessage(m.chat, pesan.message, { messageId: pesan.key.id });
    }

    if (action === 'gacha' || action === 'hatch') {
        let cost = 100000; 
        if (user.balance < cost) return m.reply(`💸 Saldomu kurang! Butuh Rp ${cost.toLocaleString()} untuk menetaskan telur.`);

        user.balance -= cost;

        let animMsg = await sock.sendMessage(m.chat, { text: `🥚 *HATCHING EGG*\n\nMenghangatkan telur misterius...` }, { quoted: m });
        await delay(1200);
        await sock.sendMessage(m.chat, { text: `🥚 *HATCHING EGG*\n\nTelurnya mulai retak! Krek... krek... ⚡`, edit: animMsg.key });
        await delay(1200);

        let roll = Math.random() * 100;
        let petId = '';

        if (roll <= 3) petId = 'naga';        
        else if (roll <= 15) petId = 'phoenix'; 
        else if (roll <= 45) petId = 'serigala'; 
        else petId = 'slime';                 

        let dapetPet = petData[petId];
        rpg.pets[petId] = (rpg.pets[petId] || 0) + 1;
        
        let teksHasil = `🎉 *TELUR MENETAS!*\n\n`;
        teksHasil += `✨ *Rarity:* ${dapetPet.rarity}\n`;
        teksHasil += `🐾 *Pet:* ${dapetPet.name}\n\n`;
        teksHasil += `📈 *Bonus Stat (Jika Dipakai):*\n`;
        teksHasil += `⚔️ +${dapetPet.atk} ATK | 🛡️ +${dapetPet.def} DEF | ❤️ +${dapetPet.hp} HP\n\n`;
        teksHasil += `✅ _Berhasil dimasukkan ke kandang!_\n`;
        teksHasil += `📦 _Total ${dapetPet.name} milikmu: ${rpg.pets[petId]}_\n\n`;
        teksHasil += `_Ketik .pet equip <id_pet> untuk memakainya!_`;

        return sock.sendMessage(m.chat, { text: teksHasil, edit: animMsg.key });
    }

    if (action === 'jual' || action === 'sell') {
        if (!targetPet || !petData[targetPet]) return m.reply(`❌ Masukkan ID Pet yang valid!\nContoh: \`${prefix}${command} jual slime 2\``);
        
        let stokPet = rpg.pets[targetPet] || 0;
        if (stokPet < jumlah) return m.reply(`⚠️ Tuan, kandangmu hanya berisi ${stokPet} ekor *${petData[targetPet].name}*!`);

        let totalHarga = petData[targetPet].price * jumlah;
        rpg.pets[targetPet] -= jumlah;
        user.balance += totalHarga;

        if (rpg.active_pet === targetPet && rpg.pets[targetPet] === 0) {
            rpg.active_pet = '';
        }

        return sendRPGButton(`🤝 *TRANSAKSI BERHASIL!*\n\nKamu menjual ${jumlah}x *${petData[targetPet].name}* kepada saudagar hewan.\n💰 Keuntungan: +Rp ${totalHarga.toLocaleString()}`, [
            { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🐾 Cek Kandang", id: `${prefix}${command}` }) }
        ]);
    }

    if (action === 'equip' || action === 'pakai') {
        if (!targetPet) return m.reply(`❌ Masukkan ID Pet!\nContoh: \`${prefix}${command} equip serigala\``);
        if (!rpg.pets[targetPet] || rpg.pets[targetPet] < 1) return m.reply(`❌ Kamu tidak memiliki pet tersebut di kandangmu!`);
        if (rpg.active_pet === targetPet) return m.reply(`⚠️ Pet ini sudah menemanimu saat ini!`);

        rpg.active_pet = targetPet;
        let p = petData[targetPet];
        return m.reply(`✨ Berhasil memakai *${p.name}*!\nSihir pendamping aktif: +${p.atk} ATK, +${p.def} DEF, +${p.hp} HP.`);
    }

    if (action === 'lepas' || action === 'unequip') {
        if (!rpg.active_pet) return m.reply(`⚠️ Kamu tidak sedang membawa pet apa-apa.`);
        let oldPet = petData[rpg.active_pet].name;
        rpg.active_pet = '';
        return m.reply(`💤 Kamu memasukkan *${oldPet}* kembali ke kandang. Bonus stat menghilang.`);
    }

    let teksMenu = `🐾 *PET SANCTUARY*\n\n`;
    teksMenu += `👤 *Tuan:* ${user.name}\n`;
    
    if (rpg.active_pet && petData[rpg.active_pet]) {
        let active = petData[rpg.active_pet];
        teksMenu += `🦅 *Pet Aktif:* ${active.name}\n`;
        teksMenu += `📈 *Buff:* +${active.atk} ATK | +${active.def} DEF | +${active.hp} HP\n\n`;
    } else {
        teksMenu += `🦅 *Pet Aktif:* _Tidak ada_\n\n`;
    }

    teksMenu += `*KANDANG MILIKMU:*\n`;
    
    let hasPets = false;
    for (let [id, count] of Object.entries(rpg.pets)) {
        if (count > 0) {
            hasPets = true;
            let p = petData[id];
            let isDipakai = rpg.active_pet === id ? ' ✅ (Dipakai)' : '';
            teksMenu += `◦ ${p.name} [${p.rarity}] ➔ *x${count}*${isDipakai}\n`;
        }
    }

    if (!hasPets) {
        teksMenu += `_(Kandang masih kosong. Segera gacha telur!)_\n\n`;
    } else {
        teksMenu += `\n_Cara pakai: \`${prefix}${command} equip <id_pet>\`_\n`;
        teksMenu += `_Cara jual: \`${prefix}${command} jual <id_pet> <jumlah>\`_\n\n`;
        teksMenu += `*HARGA JUAL PUSAT:*\n`;
        teksMenu += `◦ Slime: 30K | Serigala: 75K\n`;
        teksMenu += `◦ Phoenix: 200K | Naga: 1 Juta\n\n`;
    }

    let arrayTombol = [
        { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🥚 Gacha Telur (100K)", id: `${prefix}${command} gacha` }) }
    ];
    
    if (rpg.active_pet) {
        arrayTombol.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "💤 Lepas Pet", id: `${prefix}${command} lepas` }) });
    }

    return sendRPGButton(teksMenu, arrayTombol);
}

handler.command = ["pet", "companion", "gachapet"];
handler.tags = ["rpg"];
module.exports = handler;
