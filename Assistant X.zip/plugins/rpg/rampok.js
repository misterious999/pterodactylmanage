// ==========================================
// ⚔️ XENORIA PVP: STREET CLASH (ANIMATED)
// ⚙️ Ciptaan Pstar7 | Clean Code, Pet Stat & Draw Fix
// ==========================================

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
global.pvp_cd = global.pvp_cd || {};

// 🐾 DATABASE PET UNTUK KALKULASI STAT
const petData = {
    'slime': { name: '🫧', atk: 0, def: 5, hp: 50 },
    'serigala': { name: '🐺', atk: 15, def: 10, hp: 0 },
    'phoenix': { name: '🦅', atk: 30, def: 0, hp: 100 },
    'naga': { name: '🐉', atk: 50, def: 20, hp: 200 }
};

let handler = async (m, { sock, args, prefix, command }) => {
    let users = global.db.users;
    let penyerangJid = m.sender;
    let userPenyerang = users[penyerangJid];

    // ================== VALIDASI PENYERANG ==================
    if (!userPenyerang || !userPenyerang.registered) return m.reply(`❌ Kamu belum terdaftar di Xenoria!`);
    if (!userPenyerang.rpg || userPenyerang.rpg.role === 'Novice') return m.reply(`⚠️ Pengecut sepertimu belum layak bertarung! Lakukan \`${prefix}awaken\` dulu!`);
    if (userPenyerang.rpg.hp < 50) return m.reply(`🏥 Darahmu terlalu kritis (${userPenyerang.rpg.hp} HP) untuk tawuran! \`${prefix}heal\` dulu sana!`);
    if (userPenyerang.rpg.isHealing) return m.reply(`🧘 Kamu sedang fokus bermeditasi! Batalkan meditasi jika ingin bertarung.`);

    let cdTime = 300000; // 5 Menit
    let lastPvP = global.pvp_cd[penyerangJid] || 0;
    if (Date.now() - lastPvP < cdTime) {
        let sisaMdt = Math.ceil((cdTime - (Date.now() - lastPvP)) / 1000 / 60);
        return m.reply(`⏳ Kamu masih buronan penjaga kota! Sembunyi dulu selama *${sisaMdt} Menit* sebelum merampok lagi.`);
    }

    // ================== VALIDASI TARGET ==================
    let targetJid;
    if (m.quoted) {
        targetJid = m.quoted.sender;
    } else if (m.mentionedJid && m.mentionedJid[0]) {
        targetJid = m.mentionedJid[0];
    } else {
        return m.reply(`❌ Tandai orang yang mau kamu rampok!\nContoh: \`${prefix}${command} @tag\` atau balas chatnya.`);
    }

    if (targetJid === penyerangJid) return m.reply(`🤡 Lu sehat bang? Masa mau ngerampok diri sendiri?`);
    if (targetJid === sock.user.id.split(':')[0] + '@s.whatsapp.net') return m.reply(`🛑 Berani-beraninya kamu menyerang Sistem Dewa Xenoria!`);

    let userTarget = users[targetJid];
    
    if (!userTarget || !userTarget.registered) return m.reply(`❌ Orang ini hanya warga sipil (Belum daftar), jangan diganggu!`);
    if (!userTarget.rpg || userTarget.rpg.role === 'Novice') return m.reply(`⚠️ Jangan menindas pemula! Target belum Awakening.`);
    if (userTarget.rpg.hp < 50) return m.reply(`🏥 Jangan kejam! Target sedang sekarat (${userTarget.rpg.hp} HP). Cari lawan yang sepadan!`);

    let rpgA = userPenyerang.rpg; 
    let rpgB = userTarget.rpg;    

    // ================== KALKULASI STAT GABUNGAN PET ==================
    let petA = rpgA.active_pet ? petData[rpgA.active_pet] : { name: '', atk: 0, def: 0 };
    if (!petA) petA = { name: '', atk: 0, def: 0 };
    let atkA = rpgA.attack + petA.atk;
    let defA = rpgA.defense + petA.def;

    let petB = rpgB.active_pet ? petData[rpgB.active_pet] : { name: '', atk: 0, def: 0 };
    if (!petB) petB = { name: '', atk: 0, def: 0 };
    let atkB = rpgB.attack + petB.atk;
    let defB = rpgB.defense + petB.def;

    global.pvp_cd[penyerangJid] = Date.now();

    // ================== 🎬 ANIMASI BATTLE ==================
    let animMsg = await sock.sendMessage(m.chat, { text: `╭───┈ *「 ⚔️ STREET CLASH 」*\n│ 🥷 Mengendap-endap di belakang target...\n╰───────────────┈ ⳹` }, { quoted: m });
    await delay(1200);
    await sock.sendMessage(m.chat, { text: `╭───┈ *「 ⚔️ STREET CLASH 」*\n│ 💥 DAAARRR! Kamu menyerang, tapi target menyadarinya!\n╰───────────────┈ ⳹`, edit: animMsg.key });
    await delay(1200);
    await sock.sendMessage(m.chat, { text: `╭───┈ *「 ⚔️ STREET CLASH 」*\n│ 🗡️🛡️ Terjadi adu senjata dan pertahanan yang sengit!\n╰───────────────┈ ⳹`, edit: animMsg.key });
    await delay(1500);
    await sock.sendMessage(m.chat, { text: `╭───┈ *「 ⚔️ STREET CLASH 」*\n│ 🌪️ Debu mengepul tebal... Siapa yang tumbang?!\n╰───────────────┈ ⳹`, edit: animMsg.key });
    await delay(1500);

    // ================== ⚔️ KALKULASI DAMAGE ==================
    let rawDmgA = Math.floor(Math.random() * 40) + atkA;
    let finalDmgA = Math.max(5, rawDmgA - defB); 
    
    let rawDmgB = Math.floor(Math.random() * 40) + atkB;
    let finalDmgB = Math.max(5, rawDmgB - defA);

    rpgB.hp -= finalDmgA;
    rpgA.hp -= finalDmgB;
    if (rpgB.hp < 0) rpgB.hp = 0;
    if (rpgA.hp < 0) rpgA.hp = 0;

    let isAttackerWin = finalDmgA > finalDmgB;
    let isDraw = finalDmgA === finalDmgB; // ⚖️ KONDISI SERI

    let uangDicuri = 0;
    let teksHasil = '';

    if (isDraw) {
        teksHasil += `╭───┈ *「 ⚖️ PERTARUNGAN SERI! 」*\n`;
        teksHasil += `│ Kekuatan kalian seimbang!\n`;
        teksHasil += `│ Kalian berdua saling pukul hingga babak\n`;
        teksHasil += `│ belur, tapi tidak ada yang berhasil merampas uang!\n│\n`;
    } else if (isAttackerWin) {
        let persentase = (Math.floor(Math.random() * 10) + 5) / 100;
        uangDicuri = Math.floor(userTarget.balance * persentase);
        if (uangDicuri < 1) uangDicuri = Math.floor(Math.random() * 500) + 100; 

        userTarget.balance -= uangDicuri;
        userPenyerang.balance += uangDicuri;

        teksHasil += `╭───┈ *「 💸 PERAMPOKAN SUKSES! 」*\n`;
        teksHasil += `│ Kamu berhasil menjebol pertahanan target\n`;
        teksHasil += `│ dan merampas hartanya!\n│\n`;
        teksHasil += `│ 💰 *Loot:* +Rp ${uangDicuri.toLocaleString()}\n`;
    } else {
        let denda = Math.floor(userPenyerang.balance * 0.10); 
        if (denda < 1) denda = Math.floor(Math.random() * 500) + 100;

        userPenyerang.balance -= denda;
        userTarget.balance += denda;

        teksHasil += `╭───┈ *「 💥 PERAMPOKAN GAGAL! 」*\n`;
        teksHasil += `│ Target membalas dengan sangat brutal!\n`;
        teksHasil += `│ Kamu dihajar habis-habisan dan\n`;
        teksHasil += `│ dompetmu dirampas balik!\n│\n`;
        teksHasil += `│ 💸 *Denda Hilang:* -Rp ${denda.toLocaleString()}\n`;
    }

    // ================== 📜 LAPORAN KERUSAKAN ==================
    teksHasil += `├───────────────┈ ⳹\n`;
    teksHasil += `│ ⚔️ *BATTLE LOG:*\n`;
    teksHasil += `│ 👤 *${userPenyerang.name}* (${rpgA.role} ${petA.name})\n`;
    teksHasil += `│ 🗡️ Kekuatan Serangan: ${rawDmgA}\n`;
    teksHasil += `│ 💥 Damage Masuk: ${finalDmgA} DMG\n`;
    teksHasil += `│ ❤️ Sisa HP Kamu: ${rpgA.hp}\n`;
    teksHasil += `│\n`;
    teksHasil += `│ 👤 *${userTarget.name}* (${rpgB.role} ${petB.name})\n`;
    teksHasil += `│ 🛡️ Daya Tahan Armor: ${defB}\n`;
    teksHasil += `│ 💥 Counter Damage: ${finalDmgB} DMG\n`;
    teksHasil += `│ ❤️ Sisa HP Target: ${rpgB.hp}\n`;
    teksHasil += `╰───────────────┈ ⳹\n\n`;

    if (rpgA.hp === 0) teksHasil += `_⚠️ Kamu tewas dalam duel ini dan butuh .heal!_\n`;
    if (rpgB.hp === 0) teksHasil += `_💀 Kamu membunuh target tanpa ampun!_`;

    return sock.sendMessage(m.chat, { text: teksHasil, mentions: [penyerangJid, targetJid], edit: animMsg.key });
}

handler.command = ["rampok"];
handler.tags = ["rpg"];

module.exports = handler;
