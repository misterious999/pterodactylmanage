const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

// ==========================================
// 💳 DOMPET DIGITAL (VIP RPG UI)
// ⚙️ Ciptaan Pstar7 | Mobile-First UI & Synced Ecosystem
// ==========================================

let handler = async (m, { sock, prefix, command }) => {
    // Deteksi target (Diri sendiri, Tag, atau Reply)
    let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : (m.quoted ? m.quoted.sender : m.sender);
    let user = global.db.users[who];

    if (!user) {
        if (who === m.sender) return m.reply("❌ Kamu belum terdaftar di database Xenoria!");
        else return m.reply("❌ Target yang kamu intip belum terdaftar di database!");
    }

    await m.react('💳').catch(() => {});

    // Ambil data balance dan limit
    let limit = user.limit || 0;
    let saldo = user.balance || 0;
    let userName = user.name || (who === m.sender ? m.pushName : 'Pahlawan');
    const botName = global.botname || "Assistant X Project";

    // 🛡️ FUNGSI BANTUAN PENGIRIM TOMBOL NATIVE
    async function sendRPGButton(teks, arrayTombol) {
        let pesan = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: `© ${botName} Wallet` }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons: arrayTombol }),
                        contextInfo: {
                            mentionedJid: [who],
                            participant: "0@s.whatsapp.net",
                            remoteJid: "status@broadcast",
                            quotedMessage: {
                                imageMessage: {
                                    caption: `Sistem Keuangan Player | ${botName}`
                                }
                            }
                        }
                    })
                }
            }
        }, {});
        return sock.relayMessage(m.chat, pesan.message, { messageId: pesan.key.id });
    }

    // Merakit UI Vertical Minimalist (Anti-Gepeng di Layar HP)
    let teks = `💳 ＤＯＭＰＥＴ  ＤＩＧＩＴＡＬ\n`;
    teks += `──────────────────────\n`;
    teks += `👤 *User:* @${who.split('@')[0]}\n\n`;
    
    teks += `◈ ＡＳＳＥＴ ◈\n`;
    teks += `🪙 *Saldo :* Rp ${saldo.toLocaleString('id-ID')}\n`;
    teks += `⚡ *Limit :* ${limit}\n\n`;
    
    // Pesan dinamis berdasarkan siapa yang dicek
    if (who === m.sender) {
        teks += `_"Kekayaan sejati ditempa dari kerasnya pertarungan di Dungeon..."_\n`;
    } else {
        teks += `_"Ssstt! Mengintip pundi-pundi emas milik pahlawan lain..."_\n`;
    }

    // Tombol Dinamis
    let arrayTombol = [];
    if (who === m.sender) {
        // Kalau cek dompet sendiri, arahkan ke Bank dan Claim
        arrayTombol.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🏦 Buka Bank", id: `${prefix}bank` }) });
        arrayTombol.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🎁 Klaim Harian", id: `${prefix}claim` }) });
        arrayTombol.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "💼 Cek Profil", id: `${prefix}profile` }) });
    } else {
        // Kalau cek dompet orang lain, arahkan buat cek dompet sendiri atau berburu
        arrayTombol.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "💼 Cek Dompetku", id: `${prefix}${command}` }) });
        arrayTombol.push({ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "⚔️ Berburu", id: `${prefix}adventure` }) });
    }

    return sendRPGButton(teks, arrayTombol);
}

// RULES #3: HANDLER HANYA BOLEH 1
handler.command = ['dompet'];
handler.tags = ['rpg'];
handler.help = ['dompet'];

module.exports = handler;
