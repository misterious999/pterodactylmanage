const util = require("util")
const { exec } = require("child_process")

let handler = async (m) => m

handler.before = async function (m, { sock, isOwner }) {
  if (!isOwner) return false

  let body = m.body || ""

  if (body.toLowerCase().startsWith("xx ")) {
    try {
      let code = body.slice(3)
      let r = await eval(`(async()=>{${code}})()`)
      await sock.sendMessage(
        m.chat,
        { text: util.format(typeof r === "string" ? r : util.inspect(r)) },
        { quoted: m }
      )
    } catch (e) {
      await sock.sendMessage(
        m.chat,
        { text: util.format(e) },
        { quoted: m }
      )
    }
    return true
  }

  if (body.toLowerCase().startsWith("x ")) {
    try {
      let code = body.slice(2)
      let r = await eval(code)
      await sock.sendMessage(
        m.chat,
        { text: util.format(typeof r === "string" ? r : util.inspect(r)) },
        { quoted: m }
      )
    } catch (e) {
      await sock.sendMessage(
        m.chat,
        { text: util.format(e) },
        { quoted: m }
      )
    }
    return true
  }

  if (body.startsWith("$ ")) {
    exec(body.slice(2), async (e, out) => {
      await sock.sendMessage(
        m.chat,
        { text: util.format(e ? e : out) },
        { quoted: m }
      )
    })
    return true
  }

  return false
}

handler.owner = true

module.exports = handler