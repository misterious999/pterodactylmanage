const axios = require('axios');
const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

// ==========================================
// 🧠 ASSISTANT X CORE: ELEGANT AI ENGINE
// ⚙️ Powered by: https://api.botcahx.eu.org
// ==========================================

// ------------------------------------------
// 1. PUSAT IDENTITAS AI (SYSTEM PROMPT)
// ------------------------------------------
function getSystemPrompt(userName) {
    let waktu = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
    return `Kamu adalah Assistant X, asisten virtual cerdas ciptaan Pstar7. Sifatmu: Elegan, ramah, solutif, dan profesional. 
Aturan menjawab:
- Jawab pertanyaan biasa dengan singkat dan jelas.
- JIKA menjelaskan konsep/rencana/kode, jawab dengan padat, rinci, dan terstruktur.
- DILARANG menggunakan format heading markdown berlebihan seperti ### atau ##. Gunakan "✦" atau ">" untuk poin penting.
Waktu server: ${waktu}. Lawan bicaramu saat ini adalah: ${userName}.`;
}

// ------------------------------------------
// 2. MESIN TEKS (GROQ COMPOUND)
// ------------------------------------------
async function groqCompoundQuery(systemPrompt, userPrompt, historyTeks = "") {
    if (!global.btc) throw new Error("BOTCAHX_APIKEY belum terdeteksi di server.");

    const fullContent = historyTeks
        ? `[Riwayat Obrolan]\n${historyTeks}\n\n[Pesan Baru]\n${userPrompt}`
        : userPrompt;

    const messages = [
        { role: "system", content: systemPrompt },
        { role: "user", content: fullContent }
    ];

    try {
        const { data } = await axios.post(
            `${global.botcahxBaseUrl}/api/search/openai-custom-v2`,
            { message: messages, apikey: global.btc },
            { timeout: 45000 }
        );

        const hasil = data?.result || data?.data?.result || data?.message || data?.data || "";
        if (!hasil || typeof hasil !== "string") throw new Error("Respons AI hampa.");

        // Membersihkan format bold ganda yang sering bocor dari AI
        return hasil.replace(/\*\*(.+?)\*\*/g, "*$1*").replace(/\*\*/g, "*").trim();
    } catch (e) {
        throw new Error("Gagal menyelaraskan gelombang dengan satelit BOTCAHX.");
    }
}

// ------------------------------------------
// 3. MESIN VISUAL (POLLINATIONS)
// ------------------------------------------
const STYLES = {
    flataipro: "High Quality Masterpiece", flatai: "Standard Output", runware_quality: "High Definition",
    realistic: "Hyper Realistic Photography", photo_skin: "Realistic Skin Texture Photography",
    cinema: "Cinematic Lighting", retro_anime: "90s Retro Anime", "ghibli-style": "Studio Ghibli Artstyle",
    midjourney_art: "Midjourney Style Concept Art", fantasy_armor: "Fantasy RPG Armor Design", 
    robot_cyborg: "Cyberpunk Mecha Cyborg", disney_princess: "Disney 3D Animation Style", 
    pixel_art: "16-bit Pixel Art", watercolor_painting: "Beautiful Watercolor Painting",
    flat_anime: "Flat Color Anime", mystical_realms: "Mystical Dark Fantasy", cinema_style: "Movie Scene"
};

async function generateImage(prompt, style = "flataipro", aspect_ratio = "1:1", seed) {
    if (!global.btc) throw new Error("Token API Visual tidak ditemukan.");

    let finalStyle = STYLES[style] || STYLES["flataipro"];
    let finalSeed = seed || Math.floor(Math.random() * 999999999);
    let finalPrompt = `${prompt}, detailed, ${finalStyle}, aspect ratio ${aspect_ratio}, seed ${finalSeed}`;

    let imgUrl = global.botcahxUrl('/api/search/openai-image', { text: finalPrompt });
    return { url: imgUrl, prompt: prompt, style: finalStyle, ratio: aspect_ratio, seed: finalSeed };
}

// 🛠️ PARSER ARGUMEN GAMBAR 
function parseImgArgs(raw = "") {
    let text = (raw || "").trim();
    const out = { prompt: text, style: "flataipro", aspect_ratio: "1:1", seed: undefined };
    
    const styleMatch = text.match(/--style\s+([a-z0-9_-]+)/i);
    if (styleMatch?.[1]) out.style = styleMatch[1];
    
    const arMatch = text.match(/--ar\s+([0-9]+\s*:\s*[0-9]+)/i);
    if (arMatch?.[1]) out.aspect_ratio = arMatch[1].replace(/\s+/g, "");
    
    const seedMatch = text.match(/--seed\s+(\d+)/i);
    if (seedMatch?.[1]) out.seed = Number(seedMatch[1]);
    
    out.prompt = text.replace(/--style\s+[a-z0-9_-]+/gi, "").replace(/--ar\s+[0-9]+\s*:\s*[0-9]+/gi, "").replace(/--seed\s+\d+/gi, "").trim();
    return out;
}

function isImageRequest(text = "") {
    const t = (text || "").toLowerCase().trim();
    const triggerWords = [/^gambar\b/, /^foto\b/, /^image\b/, /^ilustrasi\b/, /^lukis\b/, /^draw\b/];
    const triggerPhrases = ["buatkan gambar", "bikinin gambar", "buat gambar", "generate gambar", "buatkan foto", "buat foto", "generate image", "buat ilustrasi"];
    
    return triggerWords.some((re) => re.test(t)) || triggerPhrases.some((p) => t.includes(p));
}

function stripImagePrefix(text = "") {
    return (text || "").trim().replace(/^(tolong|coba|please)?\s*/i, "").replace(/^(buatkan|bikinin|buat|generate|create)?\s*/i, "").replace(/^(gambar|foto|image|ilustrasi|lukis|draw)\s*/i, "").trim();
}

// ==========================================
// 🚀 HANDLER UTAMA (COMMAND ENTRY)
// ==========================================
let handler = async (m, { sock, text, q, prefix, command, args, isAdmin, isOwner }) => {
    
    // 🎛️ SAKLAR AUTO AI
    if (command === 'autoai') {
        if (!m.isGroup) return m.reply("❌ _Saklar ini hanya berfungsi di dimensi grup._");
        if (!isAdmin && !isOwner) return m.reply("🛡️ _Otoritas ditolak. Hanya Admin yang memegang kunci._");
        if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
        
        let chat = global.db.groups[m.chat];
        if (args[0] === 'on') {
            chat.autoai = true;
            return m.reply("✦ *AUTO-AI AKTIF* ✦\nAssistant X kini memantau resonansi pesan grup.");
        } else if (args[0] === 'off') {
            chat.autoai = false;
            return m.reply("✧ *AUTO-AI NONAKTIF* ✧\nAssistant X memasuki mode tidur.");
        } else {
            return m.reply(`*Konfigurasi Auto-AI*\nGunakan: *${prefix}${command} on* atau *${prefix}${command} off*`);
        }
    }

    if (!q && !text) return m.reply(`✦ _Sistem sedia. Ada yang bisa saya bantu hari ini?_`);
    let finalQuery = q || text;
    let userName = m.pushName || m.sender.split('@')[0] || "User";
    
    await m.react("⏳").catch(() => {});

    try {
        // =====================
        // 🎨 CABANG 1: GENERASI VISUAL
        // =====================
        if (isImageRequest(finalQuery)) {
            const imgArgs = parseImgArgs(finalQuery);
            imgArgs.prompt = stripImagePrefix(imgArgs.prompt);

            if (!imgArgs.prompt) throw new Error(`Deskripsi visual kosong.\nContoh: *${prefix + command} buatkan gambar ksatria naga --style fantasy_armor*`);

            const result = await generateImage(imgArgs.prompt, imgArgs.style, imgArgs.aspect_ratio, imgArgs.seed);

            // UI Minimalis Tanpa Garis Kaku
            let caption = `✦ *V I S U A L  E N G I N E* ✦\n\n`;
            caption += `✨ *Prompt:* ${result.prompt}\n`;
            caption += `🎨 *Style:* ${result.style}\n`;
            caption += `📐 *Ratio:* ${result.ratio}\n\n`;
            caption += `> ⚙️ _Assistant X Image Render_`;

            await sock.sendMessage(m.chat, { image: { url: result.url }, caption: caption }, { quoted: m });
            await m.react("✅").catch(() => {});
            return;
        }

        // =====================
        // 💬 CABANG 2: GENERASI TEKS
        // =====================
        let user = global.db.users[m.sender];
        if (!user.ai_history) user.ai_history = [];
        if (user.ai_history.length > 4) user.ai_history = user.ai_history.slice(-4);

        let systemPrompt = getSystemPrompt(userName);
        let historyTeks = user.ai_history.join("\n");
        if (historyTeks.length > 1000) { user.ai_history = []; historyTeks = ""; }

        let aiResponseText = await groqCompoundQuery(systemPrompt, finalQuery, historyTeks);
        user.ai_history.push(`${userName}: ${finalQuery}`, `Assistant X: ${aiResponseText}`);

        let konteksInfo = {
            forwardingScore: 999, isForwarded: true,
            forwardedNewsletterMessageInfo: { newsletterJid: global.idChannel || "1203631@newsletter", newsletterName: `✨ Assistant X Intelligence`, serverId: 1 }
        };

        // UI Teks Interaktif
        if (aiResponseText.length > 850) {
            await sock.sendMessage(m.chat, { text: `✦ *A S S I S T A N T   X*\n\n${aiResponseText}`, contextInfo: konteksInfo }, { quoted: m });
        } else {
            let msg = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            body: proto.Message.InteractiveMessage.Body.create({ text: `✦ *A S S I S T A N T   X*\n\n${aiResponseText}` }),
                            footer: proto.Message.InteractiveMessage.Footer.create({ text: `© Neural Core Engine 📡` }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                buttons: [{ name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "✦ Menu Utama", id: `${prefix}menu` }) }]
                            }),
                            contextInfo: konteksInfo
                        })
                    }
                }
            }, { quoted: m });
            await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        }
        await m.react("✅").catch(() => {});

    } catch (e) {
        await m.react("❌").catch(() => {});
        return m.reply(`✦ *Sistem Terganggu:*\n_${e.message}_`);
    }
}

// ==========================================
// 🚀 FITUR AUTO-REPLY CERDAS
// ==========================================
handler.before = async (m, { sock }) => {
    try {
        if (!m.isGroup || !m.quoted || !m.text) return false;

        let chat = global.db.groups[m.chat] || {};
        if (!chat.autoai) return false;

        let botNumber = sock.user?.id ? sock.user.id.split(':')[0] + '@s.whatsapp.net' : m.botNumber;
        let quotedSender = m.quoted.sender || m.quoted.key?.participant || m.quoted.participant || '';
        let quotedFromBot = m.quoted.fromMe || quotedSender === botNumber || quotedSender?.includes(botNumber?.split('@')[0]);

        if (!quotedFromBot) return false;

        if (!global.db.users[m.sender]) global.db.users[m.sender] = {};
        let user = global.db.users[m.sender];
        if (!Array.isArray(user.ai_history)) user.ai_history = [];

        await m.react("💬").catch(() => {});

        let userName = m.pushName || m.sender.split('@')[0] || "User";
        let systemPrompt = getSystemPrompt(userName); // Menggunakan identitas terpusat yang sama

        if (user.ai_history.length > 4) user.ai_history = user.ai_history.slice(-4);
        let historyTeks = user.ai_history.join("\n");
        if (historyTeks.length > 1000) { user.ai_history = []; historyTeks = ""; }

        let aiResponseText = await groqCompoundQuery(systemPrompt, m.text, historyTeks);
        
        user.ai_history.push(`${userName}: ${m.text}`, `Assistant X: ${aiResponseText}`);
        await m.react("✅").catch(() => {});

        await sock.sendMessage(m.chat, {
            text: aiResponseText,
            contextInfo: {
                forwardingScore: 999, isForwarded: true,
                forwardedNewsletterMessageInfo: { newsletterJid: global.idChannel || "1203631@newsletter", newsletterName: `✨ Assistant X Intelligence`, serverId: 1 }
            }
        }, { quoted: m });

        return true;

    } catch (e) {
        await m.react("❌").catch(() => {});
        return false;
    }
};

handler.command = ["ai", "autoai"];
handler.tags = ["ai"];
handler.help = ["ai <tanya>", "ai buatkan gambar <prompt>", "autoai <on/off>"];

module.exports = handler;
