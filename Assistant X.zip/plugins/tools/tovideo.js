const axios = require('axios');
const FormData = require('form-data');

// ==========================================
// 🎥 STICKER TO VIDEO (SMART EXTRACTOR & EDIT UI)
// ⚙️ Ciptaan Pstar7 | Anti-Spam Chat!
// ==========================================

async function uploadToCloud(buffer) {
    try {
        const form = new FormData();
        form.append('files[]', buffer, 'sticker.webp');
        const { data } = await axios.post('https://uguu.se/upload.php', form, {
            headers: form.getHeaders()
        });
        return data.files[0].url;
    } catch (err1) {
        const form2 = new FormData();
        form2.append('reqtype', 'fileupload');
        form2.append('fileToUpload', buffer, 'sticker.webp');
        const { data } = await axios.post('https://catbox.moe/user/api.php', form2, {
            headers: form2.getHeaders()
        });
        return data.trim();
    }
}

let handler = async (m, { sock, prefix, command }) => {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || q.mediaType || '';

    if (!/webp/.test(mime)) {
        await m.react("❌").catch(() => {});
        return m.reply(`❌ *Format Salah!*\nSilakan balas/reply stiker bergerak (animasi) dengan perintah:\n> \`${prefix + command}\``);
    }

    await m.react("⏳").catch(() => {});

    try {
        let mediaBuffer = await sock.downloadMediaMessage(q, 'image');
        if (!mediaBuffer) throw new Error("Gagal mengunduh stiker.");

        // 🚀 UI UPDATE: Kirim pesan pertama dan amankan "Kunci Pesan"-nya
        let statusMsg = await sock.sendMessage(m.chat, { text: "⏳ _[1/3] Mengunggah stiker ke Cloud..._" }, { quoted: m });

        let imageUrl = await uploadToCloud(mediaBuffer);
        console.log(`[+] TOVIDEO: Cloud URL -> ${imageUrl}`);

        // 🚀 UI UPDATE: Edit pesan pertama menggunakan kunci tadi
        await sock.sendMessage(m.chat, { text: "⏳ _[2/3] Merender Video MP4..._", edit: statusMsg.key });
        
        let videoUrl = "";

        // ENGINE UTAMA: BOTCAHX
        try {
            let { data } = await axios.get(global.botcahxUrl('/api/tools/webp2mp4', { url: imageUrl }), { timeout: 60000 });
            let result = data?.result || data?.data || data;
            if (typeof result === 'string') videoUrl = result;
            else if (result && typeof result === 'object') videoUrl = result.url || result.video || result.mp4;
        } catch (e) {
            throw new Error("Server BOTCAHX gagal mengubah stiker ke video.");
        }

        if (!videoUrl || !videoUrl.includes('http')) {
            throw new Error("Sistem gagal mengekstrak link MP4 dari server.");
        }

        // 🚀 UI UPDATE: Konfirmasi Selesai
        await sock.sendMessage(m.chat, { text: "✅ _[3/3] Render Selesai! Mengirim video..._", edit: statusMsg.key });

        // 5. Kirim Hasil Video MP4 ke WhatsApp
        await sock.sendMessage(m.chat, { 
            video: { url: videoUrl }, 
            caption: "✅ *Assistant X • Sticker to Video*",
            mimetype: 'video/mp4'
        }, { quoted: m });

        await m.react("✅").catch(() => {});

    } catch (e) {
        console.error("[TOVIDEO ERROR]", e.message);
        await m.react("❌").catch(() => {});
        m.reply(`❌ *Terjadi Kesalahan!*\n_Pesan Sistem: ${e.message}_`);
    }
}

handler.command = ['tovideo', 'tovid'];
handler.tags = ['tools'];
handler.help = ['tovideo (reply stiker)'];
handler.limit = true; 

module.exports = handler;
