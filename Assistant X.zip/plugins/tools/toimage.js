const fs = require("fs");
const { exec } = require("child_process");

// ==========================================
// 🖼️ VIP TO-IMAGE CONVERTER 
// ⚙️ GOD-MODE FFMPEG & EXTENSION BYPASS TRICK
// ==========================================

let handler = async (m, { sock }) => {
  try {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || "";

    if (!/webp/.test(mime)) {
      await m.react("⚠️").catch(() => {});
      return m.reply("❌ Kirim atau balas sebuah stiker dengan perintah `.toimg`!");
    }

    let isAnimated = q.msg?.isAnimated || q.isAnimated || false;
    if (isAnimated) {
      await m.react("⚠️").catch(() => {});
      return m.reply("❌ *Stiker Bergerak Terdeteksi!*\n\nSistem saat ini tidak mendukung konversi stiker animasi menjadi gambar statis.");
    }

    await m.react("⏳").catch(() => {});

    let media = await sock.downloadAndSaveMediaMessage(q);
    let outputImg = `temp_img_${Date.now()}_${Math.floor(Math.random() * 1000)}.png`;

    // 🚀 ENGINE 1: FFmpeg God-Mode (Abaikan semua error struktur file dan paksa ekstrak)
    let cmd = `ffmpeg -err_detect ignore_err -i "${media}" -vframes 1 -c:v png -y "${outputImg}"`;
    
    exec(cmd, async (err) => {
      
      // Jika FFmpeg tetap menolak (Biasanya karena ini bukan WebP asli)
      if (err) {
        console.log("🔴 [TOIMG] FFmpeg gagal. Menggunakan trik Bypass Ekstensi...");
        
        // 🚀 ENGINE 2: Trick Bypass (Salin mentahan stiker dan ubah langsung jadi PNG)
        fs.copyFileSync(media, outputImg);
        
        try {
            await kirimGambar(sock, m, outputImg, media);
        } catch (e) {
            // Jika WhatsApp juga menolak mengirimnya, berarti file ini 100% korup total
            if (fs.existsSync(media)) fs.unlinkSync(media);
            if (fs.existsSync(outputImg)) fs.unlinkSync(outputImg);
            await m.react("❌").catch(() => {});
            return m.reply("❌ *Gagal Total!*\n\nStiker ini adalah 'Stiker Siluman' dengan struktur data yang rusak parah dari pembuatnya. Server Pterodactyl menolak memprosesnya demi keamanan memori.");
        }
        return; 
      }

      // Jika Engine 1 (FFmpeg) berhasil
      await kirimGambar(sock, m, outputImg, media);
    });

    // ⚙️ HELPER: Fungsi Pengirim Gambar VVIP
    async function kirimGambar(sock, m, fileGambar, fileAsli) {
      // Hapus file mentah stiker agar VPS tidak penuh
      if (fs.existsSync(fileAsli)) fs.unlinkSync(fileAsli); 

      if (!fs.existsSync(fileGambar)) {
        await m.react("❌").catch(() => {});
        return m.reply("❌ *Sistem Error:* File PNG gagal dibuat.");
      }

      let buffer = fs.readFileSync(fileGambar);
      let botName = global.botname || "Assistant X";
      let watermark = botName.toLowerCase().includes("project") ? botName : `${botName} Project`;

      await sock.sendMessage(m.chat, { 
        image: buffer, 
        caption: `✅ *Stiker Berhasil Dikonversi!*\n\n_© ${watermark}_` 
      }, { quoted: m });
      
      // Bersihkan file hasil konversi
      if (fs.existsSync(fileGambar)) fs.unlinkSync(fileGambar);
      await m.react("✅").catch(() => {});
    }

  } catch (error) {
    console.error("🔴 [SYSTEM ERROR]", error);
    await m.react("❌").catch(() => {});
    m.reply("❌ Terjadi kegagalan sistem internal saat mengunduh stiker.");
  }
}

handler.help = ["toimage", "toimg"];
handler.command = ["toimage", "toimg"];
handler.tags = ["tools"];

module.exports = handler;
