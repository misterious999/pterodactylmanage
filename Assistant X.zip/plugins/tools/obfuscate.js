const JavaScriptObfuscator = require('javascript-obfuscator');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

let handler = async (m, { sock, text, prefix, command }) => {
    let codeToObfuscate = text;

    try {
        if (m.quoted && m.quoted.mtype === 'documentMessage') {
            await m.react('⏳').catch(() => {});
            let { key } = await sock.sendMessage(m.chat, { text: "✦ _Mengunduh dokumen dan menyandikan kode sumber... Mohon tunggu._" }, { quoted: m });
            
            const stream = await downloadContentFromMessage(m.quoted, 'document');
            let buffer = Buffer.from([]);
            for await(const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }
            codeToObfuscate = buffer.toString('utf-8');

            await sock.sendMessage(m.chat, { delete: key }).catch(() => {});
        } 
        else if (m.quoted && m.quoted.text) {
            codeToObfuscate = m.quoted.text;
        }

        if (!codeToObfuscate) {
            return m.reply(`✦ *Format Tidak Lengkap*\n\nBalas sebuah *File Dokumen (.js)* dengan perintah *${prefix}${command}*`);
        }

        if (!m.quoted || m.quoted.mtype !== 'documentMessage') {
             await m.react('⏳').catch(() => {});
        }

        // ⚙️ PENGATURAN BARU: compact diubah menjadi FALSE agar panel tidak memotong kode
        let obfuscationResult = JavaScriptObfuscator.obfuscate(codeToObfuscate, {
            compact: false, 
            controlFlowFlattening: true,
            controlFlowFlatteningThreshold: 0.5,
            numbersToExpressions: true,
            simplify: true,
            stringArrayShuffle: true,
            splitStrings: true,
            stringArrayThreshold: 0.75
        });

        let obfuscatedCode = obfuscationResult.getObfuscatedCode();
        let bufferResult = Buffer.from(obfuscatedCode, 'utf-8');

        let teksSukses = `✦ *O B F U S C A T O R   E N G I N E* ✦\n\n`;
        teksSukses += `🔐 *Status:* Berkas Multi-line berhasil dibuat!\n`;
        teksSukses += `> 🔗 _Source: Native JS Obfuscator_`;

        await sock.sendMessage(m.chat, {
            document: bufferResult,
            fileName: 'core.enc.js',
            mimetype: 'application/javascript',
            caption: teksSukses
        }, { quoted: m });

        await m.react('✅').catch(() => {});

    } catch (e) {
        console.error('[OBFUSCATE ERROR]', e);
        await m.react('❌').catch(() => {});
        m.reply(`✦ *Sistem Mengalami Kendala*\n\n_${e.message || "Gagal mengenkripsi kode."}_`);
    }
};

handler.help = ['obfuscate <reply dokumen>'];
handler.tags = ['tools'];
handler.command = ['obfuscate'];
handler.owner = true; 

module.exports = handler;
