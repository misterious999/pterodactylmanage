const { downloadContentFromMessage, generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');
const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');
const os = require('os');
const path = require('path');

const REQUEST_TIMEOUT = 180000;
const MAX_UPLOAD_BYTES = 12 * 1024 * 1024;
const SESSION_TTL = 10 * 60 * 1000;

global.tofigureSessions = global.tofigureSessions || {};

function buildBotcahxUrl(endpoint, params = {}) {
    if (typeof global.botcahxUrl === 'function') {
        return global.botcahxUrl(endpoint, params);
    }

    const base = String(
        global.botcahxBaseUrl ||
        process.env.BOTCAHX_BASE_URL ||
        'https://api.botcahx.eu.org'
    ).replace(/\/$/, '');

    const apikey =
        global.btc ||
        global.botcahxKey ||
        process.env.BOTCAHX_APIKEY;

    if (!apikey) {
        throw new Error('BOTCAHX_APIKEY belum diatur di .env / Environment Variables panel.');
    }

    const url = new URL(`${base}${endpoint.startsWith('/') ? endpoint : `/${endpoint}`}`);

    for (const [key, value] of Object.entries(params || {})) {
        if (value !== undefined && value !== null && value !== '') {
            url.searchParams.set(key, String(value));
        }
    }

    url.searchParams.set('apikey', apikey);
    return url.toString();
}

function getVersionFromCommand(command = '', text = '') {
    const cmd = String(command || '').toLowerCase();
    const input = String(text || '').toLowerCase().trim();

    if (cmd.includes('v1') || input === '1' || input === 'v1') return 'v1';
    if (cmd.includes('v2') || input === '2' || input === 'v2') return 'v2';
    if (cmd.includes('v3') || input === '3' || input === 'v3') return 'v3';

    return null;
}

function getEndpointCandidates(version = 'v1') {
    const map = {
        v1: [
            '/api/maker/tofigure',
            '/api/tools/tofigure',
            '/api/ai/tofigure',
            '/api/maker/tofigure-v1',
            '/api/tools/tofigure-v1',
            '/api/ai/tofigure-v1'
        ],
        v2: [
            '/api/maker/tofigure2',
            '/api/maker/tofigure-v2',
            '/api/tools/tofigure2',
            '/api/tools/tofigure-v2',
            '/api/ai/tofigure2',
            '/api/ai/tofigure-v2'
        ],
        v3: [
            '/api/maker/tofigure3',
            '/api/maker/tofigure-v3',
            '/api/tools/tofigure3',
            '/api/tools/tofigure-v3',
            '/api/ai/tofigure3',
            '/api/ai/tofigure-v3'
        ]
    };

    return map[version] || map.v1;
}

function cleanExpiredSessions() {
    const now = Date.now();

    for (const [sender, session] of Object.entries(global.tofigureSessions || {})) {
        if (!session || now - Number(session.createdAt || 0) > SESSION_TTL) {
            delete global.tofigureSessions[sender];
        }
    }
}

async function downloadQuotedImage(q, sock) {
    if (typeof q.download === 'function') {
        const buffer = await q.download();
        if (Buffer.isBuffer(buffer) && buffer.length) return buffer;
    }

    if (sock && typeof sock.downloadMediaMessage === 'function') {
        try {
            const buffer = await sock.downloadMediaMessage(q, 'image');
            if (Buffer.isBuffer(buffer) && buffer.length) return buffer;
        } catch (_) {}
    }

    const msg =
        q.msg ||
        q.message?.imageMessage ||
        q.message?.viewOnceMessageV2?.message?.imageMessage ||
        q.message?.viewOnceMessage?.message?.imageMessage ||
        q;

    const stream = await downloadContentFromMessage(msg, 'image');

    let buffer = Buffer.alloc(0);
    for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
    }

    if (!buffer.length) {
        throw new Error('Gagal mengunduh gambar dari WhatsApp.');
    }

    return buffer;
}

async function uploadToCatbox(buffer) {
    const tmp = path.join(os.tmpdir(), `tofigure_${Date.now()}_${Math.random().toString(16).slice(2)}.jpg`);
    fs.writeFileSync(tmp, buffer);

    try {
        const form = new FormData();
        form.append('reqtype', 'fileupload');
        form.append('fileToUpload', fs.createReadStream(tmp));

        const { data } = await axios.post('https://catbox.moe/user/api.php', form, {
            headers: form.getHeaders(),
            timeout: 60000,
            maxBodyLength: Infinity,
            maxContentLength: Infinity,
            validateStatus: () => true
        });

        const url = String(data || '').trim();

        if (url.startsWith('http')) return url;

        throw new Error(`Catbox menolak upload: ${url.slice(0, 120)}`);
    } finally {
        fs.unlink(tmp, () => {});
    }
}

async function uploadToUguu(buffer) {
    const form = new FormData();

    form.append('files[]', buffer, {
        filename: 'image.jpg',
        contentType: 'image/jpeg'
    });

    const { data } = await axios.post('https://uguu.se/upload.php', form, {
        headers: {
            ...form.getHeaders(),
            'User-Agent': 'Mozilla/5.0'
        },
        timeout: 60000,
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
        validateStatus: () => true
    });

    const url = data?.files?.[0]?.url;

    if (url && String(url).startsWith('http')) return url;

    throw new Error('Uguu tidak mengembalikan URL upload.');
}

async function uploadToTelegraph(buffer) {
    const form = new FormData();

    form.append('file', buffer, {
        filename: 'image.jpg',
        contentType: 'image/jpeg'
    });

    const { data } = await axios.post('https://telegra.ph/upload', form, {
        headers: {
            ...form.getHeaders(),
            'Content-Length': form.getLengthSync()
        },
        timeout: 60000,
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
        validateStatus: () => true
    });

    const src = data?.[0]?.src;

    if (src) return `https://telegra.ph${src}`;

    throw new Error('Telegraph tidak mengembalikan URL upload.');
}

async function uploadImage(buffer) {
    const errors = [];

    for (const uploader of [uploadToCatbox, uploadToUguu, uploadToTelegraph]) {
        try {
            return await uploader(buffer);
        } catch (error) {
            errors.push(error.message);
        }
    }

    throw new Error(`Gagal upload gambar sementara. Detail: ${errors.join(' | ')}`);
}

function tryParseJson(buffer) {
    try {
        return JSON.parse(Buffer.from(buffer).toString('utf8'));
    } catch {
        return null;
    }
}

function findResultValue(input, depth = 0) {
    if (!input || depth > 8) return null;

    if (typeof input === 'string') {
        const value = input.trim();

        if (value.startsWith('http')) return value;
        if (/^data:image\//i.test(value)) return value;
        if (/^[A-Za-z0-9+/=]{500,}$/.test(value)) return value;

        return null;
    }

    if (Buffer.isBuffer(input)) return input;

    if (Array.isArray(input)) {
        for (const item of input) {
            const found = findResultValue(item, depth + 1);
            if (found) return found;
        }

        return null;
    }

    if (typeof input === 'object') {
        const preferredKeys = [
            'result',
            'data',
            'url',
            'image',
            'img',
            'output',
            'buffer',
            'base64',
            'media',
            'file',
            'download',
            'link',
            'response'
        ];

        for (const key of preferredKeys) {
            const found = findResultValue(input[key], depth + 1);
            if (found) return found;
        }

        for (const value of Object.values(input)) {
            const found = findResultValue(value, depth + 1);
            if (found) return found;
        }
    }

    return null;
}

async function valueToImageBuffer(value) {
    if (Buffer.isBuffer(value)) return value;

    const str = String(value || '').trim();

    if (!str) throw new Error('Hasil gambar kosong.');

    if (str.startsWith('http')) {
        const res = await axios.get(str, {
            responseType: 'arraybuffer',
            timeout: REQUEST_TIMEOUT,
            validateStatus: () => true,
            headers: {
                'User-Agent': 'Mozilla/5.0'
            }
        });

        const type = String(res.headers['content-type'] || '').toLowerCase();

        if (res.status >= 400) {
            throw new Error(`URL hasil gagal diunduh. HTTP ${res.status}`);
        }

        if (!type.includes('image')) {
            const json = tryParseJson(res.data);
            throw new Error(json?.message || json?.error || 'URL hasil bukan gambar.');
        }

        return Buffer.from(res.data);
    }

    const base64 = str.replace(/^data:image\/\w+;base64,/i, '');
    return Buffer.from(base64, 'base64');
}

async function callBotcahxTofigure(imageUrl, version = 'v1') {
    const endpoints = getEndpointCandidates(version);
    const errors = [];

    for (const endpoint of endpoints) {
        try {
            const apiUrl = buildBotcahxUrl(endpoint, {
                url: imageUrl
            });

            const res = await axios.get(apiUrl, {
                responseType: 'arraybuffer',
                timeout: REQUEST_TIMEOUT,
                validateStatus: () => true,
                headers: {
                    'User-Agent': 'Mozilla/5.0'
                }
            });

            const buffer = Buffer.from(res.data);
            const type = String(res.headers['content-type'] || '').toLowerCase();

            if (res.status >= 500) {
                errors.push(`${endpoint}: server error ${res.status}`);
                continue;
            }

            if (res.status >= 400) {
                const json = tryParseJson(buffer);
                errors.push(`${endpoint}: ${json?.message || json?.error || `HTTP ${res.status}`}`);
                continue;
            }

            if (type.includes('image')) {
                return buffer;
            }

            const json = tryParseJson(buffer);

            if (!json) {
                errors.push(`${endpoint}: response bukan JSON/gambar`);
                continue;
            }

            if (json.status === false || json.success === false) {
                errors.push(`${endpoint}: ${json.message || json.error || 'request gagal'}`);
                continue;
            }

            const value = findResultValue(json);

            if (!value) {
                console.log(`[TOFIGURE RAW ${version}]`, JSON.stringify(json, null, 2));
                errors.push(`${endpoint}: field hasil gambar tidak ditemukan`);
                continue;
            }

            return await valueToImageBuffer(value);
        } catch (error) {
            errors.push(`${endpoint}: ${error.message}`);
        }
    }

    throw new Error(errors.join(' | '));
}

async function sendVersionButtons(sock, m, prefix, imageUrl) {
    global.tofigureSessions[m.sender] = {
        imageUrl,
        chat: m.chat,
        createdAt: Date.now()
    };

    const teks = `╭──「 *TO FIGURE AI* 」
│ Foto berhasil disiapkan.
│ Pilih versi ToFigure di bawah ini.
╰────────────

*V1* = style standar
*V2* = style alternatif
*V3* = style detail/eksperimental

Sesi berlaku 10 menit.`;

    const buttons = [
    {
        name: 'quick_reply',
        buttonParamsJson: JSON.stringify({
            display_text: '🧸 ToFigure V1',
            id: `${prefix}tofigure v1`
        })
    },
    {
        name: 'quick_reply',
        buttonParamsJson: JSON.stringify({
            display_text: '🎎 ToFigure V2',
            id: `${prefix}tofigure v2`
        })
    },
    {
        name: 'quick_reply',
        buttonParamsJson: JSON.stringify({
            display_text: '🪆 ToFigure V3',
            id: `${prefix}tofigure v3`
        })
    }
];

    try {
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: teks
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: `© ${global.botname || 'Assistant X Project'}`
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            title: '',
                            hasMediaAttachment: false
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons
                        })
                    })
                }
            }
        }, {
            quoted: m
        });

        await sock.relayMessage(m.chat, msg.message, {
            messageId: msg.key.id
        });
    } catch (error) {
        console.error('[TOFIGURE BUTTON ERROR]', error);

        await sock.sendMessage(m.chat, {
            text: `${teks}

Jika tombol tidak muncul, pakai manual:
${prefix}tofigurev1
${prefix}tofigurev2
${prefix}tofigurev3`
        }, {
            quoted: m
        });
    }
}

async function processTofigure(sock, m, imageUrl, version) {
    await m.react('⏳').catch(() => {});

    await sock.sendMessage(m.chat, {
        text: `⏳ *Bentar ya...*
Foto sedang diproses menjadi figure AI *${version.toUpperCase()}*.

Proses bisa memakan waktu 30-120 detik.`
    }, {
        quoted: m
    });

    const outputBuffer = await callBotcahxTofigure(imageUrl, version);

    if (!Buffer.isBuffer(outputBuffer) || !outputBuffer.length) {
        throw new Error('Output gambar ToFigure kosong.');
    }

    await sock.sendMessage(m.chat, {
        image: outputBuffer,
        caption: `✅ *TO FIGURE ${version.toUpperCase()} SELESAI*

👤 Request: @${m.sender.split('@')[0]}
⚙️ Mode: ${version.toUpperCase()}
🤖 Engine: BOTCAHX ToFigure`,
        mentions: [m.sender]
    }, {
        quoted: m
    });

    await m.react('✅').catch(() => {});
}

let handler = async (m, { sock, text, args, prefix, command }) => {
    cleanExpiredSessions();

    const input = String(text || (args || []).join(' ') || '').trim();
    const version = getVersionFromCommand(command, input);
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || q.mimetype || q.mediaType || '';

    try {
        if (!version) {
            if (!String(mime).includes('image')) {
                return m.reply(`Kirim atau reply foto dengan perintah *${prefix}${command}*

Contoh:
${prefix}${command}

Atau langsung:
${prefix}${command} v1
${prefix}${command} v2
${prefix}${command} v3`);
            }

            await m.react('⏳').catch(() => {});

            const inputBuffer = await downloadQuotedImage(q, sock);

            if (!inputBuffer.length) {
                throw new Error('Buffer gambar kosong.');
            }

            if (inputBuffer.length > MAX_UPLOAD_BYTES) {
                throw new Error('Ukuran gambar terlalu besar. Maksimal sekitar 12 MB.');
            }

            await sock.sendMessage(m.chat, {
                text: '⏳ *Bentar ya...*\nFoto sedang diupload, setelah itu kamu bisa pilih versi ToFigure.'
            }, {
                quoted: m
            });

            const imageUrl = await uploadImage(inputBuffer);

            await sendVersionButtons(sock, m, prefix, imageUrl);
            await m.react('✅').catch(() => {});
            return;
        }

        let imageUrl = null;

        if (String(mime).includes('image')) {
            const inputBuffer = await downloadQuotedImage(q, sock);

            if (!inputBuffer.length) {
                throw new Error('Buffer gambar kosong.');
            }

            if (inputBuffer.length > MAX_UPLOAD_BYTES) {
                throw new Error('Ukuran gambar terlalu besar. Maksimal sekitar 12 MB.');
            }

            imageUrl = await uploadImage(inputBuffer);
        } else {
            const session = global.tofigureSessions[m.sender];

            if (!session || !session.imageUrl || Date.now() - Number(session.createdAt || 0) > SESSION_TTL) {
                return m.reply(`❌ *Sesi ToFigure tidak ditemukan atau sudah expired.*

Reply foto lalu ketik:
${prefix}tofigure

Atau langsung:
${prefix}tofigure v1
${prefix}tofigure v2
${prefix}tofigure v3`);
            }

            imageUrl = session.imageUrl;
        }

        await processTofigure(sock, m, imageUrl, version);

        if (global.tofigureSessions[m.sender]) {
            delete global.tofigureSessions[m.sender];
        }
    } catch (error) {
        console.error('[TOFIGURE ERROR]', error);
        await m.react('❌').catch(() => {});

        return m.reply(`❌ *Gagal memproses ToFigure.*

Penyebab:
${error.message || error}

Catatan:
Pastikan foto jelas dan endpoint BOTCAHX ToFigure sedang aktif.`);
    }
};

handler.help = [
    'tofigure <reply foto>',
    'tofigure v1 <reply foto>',
    'tofigure v2 <reply foto>',
    'tofigure v3 <reply foto>'
];

handler.command = ['tofigure'];

handler.tags = ['tools'];
handler.limit = true;

module.exports = handler;