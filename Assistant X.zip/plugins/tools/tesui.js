const { generateWAMessageFromContent } = require('@whiskeysockets/baileys');
const axios = require('axios');
const Jimp = require('jimp');

const handler = async (m, { sock }) => {
    m.reply("⏳ *Membobol firewall gambar dan merakit UI...*");

    try {
        const urlGambar = process.env.THUMBNAIL_URL || "https://files.catbox.moe/xevp3k.jpg";

        // 1. Sedot gambar pakai Axios dan nyamar jadi browser
        const res = await axios.get(urlGambar, { 
            responseType: 'arraybuffer',
            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' } 
        });
        const rawBuffer = Buffer.from(res.data);

        // 2. Lempar buffer mentahnya ke Jimp buat di-resize & kompres
        const image = await Jimp.read(rawBuffer);
        const imageBuffer = await new Promise((resolve, reject) => {
            image.resize(300, Jimp.AUTO)
                 .quality(50)
                 .getBuffer(Jimp.MIME_JPEG, (err, buffer) => {
                     if (err) reject(err);
                     else resolve(buffer);
                 });
        });

        // 3. Rakit JSON Location Message
        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    buttonsMessage: {
                        contentText: "👋 *Halo bosku!*\nMental baja! Akhirnya tembus juga ini gambar peta sialan! 🚀",
                        footerText: "© ZeroixDark Project",
                        buttons: [
                            { buttonId: '.allmenu', buttonText: { displayText: '📚 All Menu' }, type: 1 },
                            { buttonId: '.owner', buttonText: { displayText: '👑 Owner' }, type: 1 },
                            { buttonId: '.catur', buttonText: { displayText: '♟️ Main Catur' }, type: 1 }
                        ],
                        headerType: 6, 
                        locationMessage: {
                            degreesLatitude: -6.200000, 
                            degreesLongitude: 106.816666,
                            name: '📍 ZeroixDark • Server',
                            address: 'Jakarta, Indonesia',
                            jpegThumbnail: imageBuffer 
                        }
                    }
                }
            }
        }, { quoted: m });

        await sock.relayMessage(msg.key.remoteJid, msg.message, { 
            messageId: msg.key.id 
        });

    } catch (e) {
        console.error(e);
        m.reply("❌ Masih kena mental gagal render bosku! Cek log.");
    }
};

handler.help = ['tesui'];
handler.tags = ['tools', 'owner'];
handler.command = ['tesui'];

module.exports = handler;
