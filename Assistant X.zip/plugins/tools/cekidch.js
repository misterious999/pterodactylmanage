const {
    generateWAMessageFromContent,
    proto
} = require('@whiskeysockets/baileys');

function cleanText(text = '') {
    return String(text)
        .replace(/[<>`]/g, '')
        .replace(/\u200e|\u200f|\u202a|\u202b|\u202c/g, '')
        .trim();
}

function parseChannelInput(input = '') {
    const text = cleanText(input);

    const jidMatch = text.match(/(120363\d{5,50}@newsletter)/i);
    if (jidMatch) {
        return {
            type: 'jid',
            key: jidMatch[1],
            invite: null,
            url: null
        };
    }

    const linkMatch = text.match(/(?:https?:\/\/)?(?:www\.)?(?:whatsapp\.com|wa\.me)\/channel\/([A-Za-z0-9_-]{8,150})/i);
    if (linkMatch) {
        const invite = decodeURIComponent(linkMatch[1])
            .split(/[?#/&\s]/)[0]
            .trim();

        return {
            type: 'invite',
            key: invite,
            invite,
            url: `https://whatsapp.com/channel/${invite}`
        };
    }

    const codeMatch = text.match(/^([A-Za-z0-9_-]{8,150})$/);
    if (codeMatch) {
        return {
            type: 'invite',
            key: codeMatch[1],
            invite: codeMatch[1],
            url: `https://whatsapp.com/channel/${codeMatch[1]}`
        };
    }

    return null;
}

function decodeHtml(text = '') {
    return String(text)
        .replace(/&#x([0-9a-fA-F]+);/g, (_, hex) => {
            try {
                return String.fromCodePoint(parseInt(hex, 16));
            } catch {
                return _;
            }
        })
        .replace(/&#([0-9]+);/g, (_, num) => {
            try {
                return String.fromCodePoint(parseInt(num, 10));
            } catch {
                return _;
            }
        })
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&#x27;/g, "'")
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&nbsp;/g, ' ')
        .trim();
}

function pick(value, fallback = '-') {
    if (value === undefined || value === null) return fallback;

    if (typeof value === 'string' || typeof value === 'number') {
        const result = decodeHtml(String(value)).trim();
        return result || fallback;
    }

    if (typeof value === 'object') {
        if (value.text !== undefined) return pick(value.text, fallback);
        if (value.name !== undefined) return pick(value.name, fallback);
        if (value.value !== undefined) return pick(value.value, fallback);
        if (value.title !== undefined) return pick(value.title, fallback);
        if (value.description !== undefined) return pick(value.description, fallback);
    }

    return fallback;
}

function extractNewsletterId(value = '') {
    const raw = String(value || '');

    const direct = raw.match(/(120363\d{5,50}@newsletter)/i);
    if (direct) return direct[1];

    const zQuoted = raw.match(/["'`]?z?(120363\d{5,50})["'`]?\s*,?/i);
    if (zQuoted) return `${zQuoted[1]}@newsletter`;

    const plain = raw.match(/\b(120363\d{5,50})\b/i);
    if (plain) return `${plain[1]}@newsletter`;

    return null;
}

function normalizeNewsletter(raw = {}, parsed = {}) {
    const thread = raw.thread_metadata || raw.threadMetadata || raw.metadata || {};
    const viewer = raw.viewer_metadata || raw.viewerMetadata || {};

    let id = pick(
        raw.id ||
        raw.jid ||
        raw.newsletterJid ||
        raw.newsletter_jid ||
        raw.newsletter_id ||
        thread.id ||
        thread.jid ||
        thread.newsletterJid ||
        thread.newsletter_jid,
        '-'
    );

    const extracted = extractNewsletterId(JSON.stringify(raw));
    if ((id === '-' || !id.includes('@newsletter')) && extracted) {
        id = extracted;
    }

    if (id !== '-' && !id.includes('@newsletter') && /^120363\d{5,50}$/i.test(id)) {
        id = `${id}@newsletter`;
    }

    const name = pick(
        raw.name ||
        raw.subject ||
        raw.title ||
        thread.name ||
        thread.subject ||
        thread.title,
        'Tidak diketahui'
    );

    const description = pick(
        raw.description ||
        raw.desc ||
        raw.about ||
        thread.description ||
        thread.desc ||
        thread.about,
        'Tidak ada deskripsi.'
    );

    const subscribersRaw =
        raw.subscribers ||
        raw.subscribers_count ||
        raw.subscribersCount ||
        raw.followers ||
        raw.followers_count ||
        thread.subscribers ||
        thread.subscribers_count ||
        thread.subscribersCount ||
        thread.followers ||
        viewer.subscribers ||
        viewer.subscribers_count ||
        0;

    const subscribers = Number(subscribersRaw || 0);

    return {
        id,
        name,
        description,
        subscribers: Number.isFinite(subscribers) ? subscribers : 0,
        invite: parsed.invite || pick(raw.invite || thread.invite, '-'),
        url: parsed.url || (parsed.invite ? `https://whatsapp.com/channel/${parsed.invite}` : '-')
    };
}

async function getChannelMetadata(sock, parsed) {
    if (!sock || typeof sock.newsletterMetadata !== 'function') {
        throw new Error('Fungsi sock.newsletterMetadata tidak tersedia. Baileys perlu diupdate.');
    }

    const attempts = [];

    if (parsed.type === 'invite') {
        attempts.push(['invite', parsed.key]);
        attempts.push(['invite', parsed.key, 'GUEST']);
        attempts.push(['invite', parsed.key, 'SUBSCRIBER']);
    }

    if (parsed.type === 'jid') {
        attempts.push(['jid', parsed.key]);
        attempts.push(['jid', parsed.key, 'GUEST']);
        attempts.push(['jid', parsed.key, 'SUBSCRIBER']);
    }

    let lastError = null;

    for (const item of attempts) {
        const [type, key, role] = item;

        try {
            const raw = role
                ? await sock.newsletterMetadata(type, key, role)
                : await sock.newsletterMetadata(type, key);

            console.log('[CEKIDCH RAW]', JSON.stringify(raw, null, 2));

            if (raw && typeof raw === 'object') {
                const data = normalizeNewsletter(raw, parsed);

                if (data.id !== '-' || data.name !== 'Tidak diketahui') {
                    return data;
                }
            }
        } catch (error) {
            lastError = error;

            const errText = String(error?.stack || error?.message || error || '');
            console.log('[CEKIDCH NEWSLETTER ERROR]', errText);

            const extractedId = extractNewsletterId(errText);

            if (extractedId) {
                return {
                    id: extractedId,
                    name: 'Berhasil ekstrak ID dari response Baileys',
                    description: 'Metadata lengkap gagal diparse, tetapi ID channel berhasil ditemukan dari response error.',
                    subscribers: 0,
                    invite: parsed.invite || '-',
                    url: parsed.url || '-',
                    partial: true
                };
            }
        }
    }

    throw lastError || new Error('Metadata channel kosong.');
}

function extractPreview(m) {
    const msg = m.message || {};
    const ext = msg.extendedTextMessage || {};
    const ctx = ext.contextInfo || {};
    const ad = ctx.externalAdReply || {};

    return {
        title: pick(ad.title, '-'),
        body: pick(ad.body, '-'),
        sourceUrl: pick(ad.sourceUrl, '-')
    };
}

function trimDescription(text = '', max = 350) {
    const clean = pick(text, 'Tidak ada deskripsi.');

    if (clean.length <= max) return clean;

    return clean.slice(0, max).trim() + '...';
}

function makeResultText(data = {}, preview = {}) {
    const name = data.name === 'Berhasil ekstrak ID dari response Baileys'
        ? preview.title !== '-' ? preview.title : data.name
        : data.name;

    const desc = trimDescription(data.description, 350);
    const subscribers = Number(data.subscribers || 0).toLocaleString('id-ID');

    let teks = `╭──「 *🔎 CEK ID CHANNEL* 」\n`;
    teks += `│ 🏷️ *Nama Channel:* ${name}\n`;
    teks += `│ 🆔 *ID Channel:* \`${data.id}\`\n`;
    teks += `│ 👥 *Pengikut:* ${subscribers}\n`;
    teks += `│ 🔗 *Kode Invite:* ${data.invite || '-'}\n`;
    teks += `│ 📝 *Deskripsi:* ${desc}\n`;
    teks += `╰────────────\n`;

    if (data.url && data.url !== '-') {
        teks += `\n🌐 *Link:* ${data.url}`;
    }

    if (data.partial) {
        teks += `\n\n⚠️ Metadata lengkap gagal diparse, tapi ID channel berhasil diekstrak.`;
    }

    return teks.trim();
}

async function sendResultWithButton(sock, m, teks, data = {}) {
    const buttons = [];

    if (data.id && data.id !== '-') {
        buttons.push({
            name: 'cta_copy',
            buttonParamsJson: JSON.stringify({
                display_text: '📋 Salin ID Channel',
                copy_code: data.id
            })
        });
    }

    if (data.url && data.url !== '-') {
        buttons.push({
            name: 'cta_url',
            buttonParamsJson: JSON.stringify({
                display_text: '🌐 Buka Channel',
                url: data.url,
                merchant_url: data.url
            })
        });
    }

    if (!buttons.length) {
        return sock.sendMessage(m.chat, {
            text: teks
        }, {
            quoted: m
        });
    }

    try {
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: teks
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: `© ${global.botname || 'Assistant X Project'}`
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            title: '',
                            hasMediaAttachment: false
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons
                        })
                    })
                }
            }
        }, {
            quoted: m
        });

        return sock.relayMessage(m.chat, msg.message, {
            messageId: msg.key.id
        });
    } catch (error) {
        console.log('[CEKIDCH BUTTON ERROR]', error.message);

        return sock.sendMessage(m.chat, {
            text: `${teks}\n\n📋 *Salin ID Channel:*\n${data.id || '-'}`
        }, {
            quoted: m
        });
    }
}

let handler = async (m, { sock, conn, text, args, prefix, command }) => {
    const socket = sock || conn || global.conn;
    const input = cleanText(text || (args || []).join(' '));

    if (!socket) {
        return m.reply('❌ Socket bot tidak ditemukan.');
    }

    if (!input) {
        return m.reply(`❌ *Format salah!*

Contoh:
${prefix}${command} https://whatsapp.com/channel/0029xxxxxxxx

Atau:
${prefix}${command} 120363xxxxxxxx@newsletter`);
    }

    const parsed = parseChannelInput(input);

    if (!parsed) {
        return m.reply(`❌ *Link channel tidak valid!*

Gunakan format:
${prefix}${command} https://whatsapp.com/channel/0029xxxxxxxx`);
    }

    await m.react('⏳').catch(() => {});

    try {
        const preview = extractPreview(m);
        const data = await getChannelMetadata(socket, parsed);
        const teks = makeResultText(data, preview);

        await sendResultWithButton(socket, m, teks, data);

        await m.react('✅').catch(() => {});
    } catch (error) {
        console.error('[CEKIDCH FINAL ERROR]', error);
        await m.react('❌').catch(() => {});

        return m.reply(`❌ *Gagal mengambil ID Channel.*

Penyebab paling mungkin:
Baileys kamu gagal parse metadata channel dari WhatsApp.

Detail:
${error.message || error}

Solusi teknis:
1. Cek console panel, cari log: [CEKIDCH NEWSLETTER ERROR]
2. Kalau di log ada angka z120363..., kirimkan log itu ke saya.
3. Kalau tidak ada, berarti versi Baileys wajib diupdate.`);
    }
};

handler.help = ['cekidch <link channel>', 'idch <link channel>'];
handler.command = ['cekidch', 'idch', 'cekch'];
handler.tags = ['tools'];
handler.limit = false;

module.exports = handler;