// ==========================================
// 📱 FITUR IQC - IPHONE QUOTE CHAT
// ⚙️ VERSION: API BOTCAHX (SIMPLE & LIGHT)
// ==========================================
const axios = require('axios');

let handler = async (m, { sock, text, prefix, command }) => {
    let chatText = "";

    // Mengambil teks dari reply atau teks langsung
    if (m.quoted) {
        chatText = m.quoted.text || m.quoted.caption || text || "";
    } else {
        chatText = text;
    }

    if (!chatText) {
        await m.react("⚠️").catch(() => {});
        return m.reply(`❌ *Format Salah!*\n\nContoh:\n\`${prefix + command} Halo bro\`\n\nAtau reply chat orang lain lalu ketik \`${prefix + command}\``);
    }

    await m.react("⏳").catch(() => {});

    try {
        // Merakit URL API (Hanya mengirim teks sesuai standar Botcahx)
        const apiUrl = global.botcahxUrl('/api/maker/iqc', { 
            text: chatText
        });

        // Eksekusi Sedot Gambar
        let res = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        let contentType = res.headers['content-type'];
        
        let imageBuffer;
        
        if (contentType && contentType.includes('application/json')) {
            let json = JSON.parse(res.data.toString('utf-8'));
            if (!json.status) throw new Error(json.message || "API mereturn status false.");
            
            if (json.result && typeof json.result === 'string' && json.result.startsWith('http')) {
                let imgRes = await axios.get(json.result, { responseType: 'arraybuffer' });
                imageBuffer = Buffer.from(imgRes.data);
            } else {
                throw new Error("Format result JSON API tidak dikenali.");
            }
        } else {
            imageBuffer = Buffer.from(res.data);
        }

        // Kirim Buffer Mentah ke WA
        await sock.sendMessage(m.chat, {
            image: imageBuffer,
            caption: `✅ *Quote berhasil dibuat!*`
        }, { quoted: m });

        await m.react("✅").catch(() => {});

    } catch (error) {
        console.error("[IQC API ERROR]", error);
        await m.react("❌").catch(() => {});
        return m.reply(`❌ *Gagal membuat quote!*\n\n📝 _Log:_ ${error.message}`);
    }
};

handler.help = ["iqc <teks>"];
handler.command = ["iqc", "fakechat"];
handler.tags = ["tools"];
handler.limit = true;

module.exports = handler;
