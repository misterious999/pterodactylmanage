'use strict';

const crypto = require('crypto');
const { generateWAMessageFromContent } = require('@whiskeysockets/baileys');

// 1. PAYLOAD DINO RUNNER (Ditambah min-height 500px & overflow auto)
const payloadHtmlDino = `<style>*{-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}</style>
<body style="margin:0;background:#0b141a;font-family:Arial,sans-serif;color:#eee;touch-action:manipulation;cursor:pointer;min-height:500px;overflow-y:auto;padding-bottom:30px;">
<div style="width:100%;max-width:620px;margin:auto;padding:16px;box-sizing:border-box">
<div style="background:rgba(255,255,255,.06);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border:1px solid rgba(255,255,255,.15);border-radius:16px;overflow:hidden;box-shadow:0 8px 32px rgba(0,0,0,.35)">
<div style="padding:18px 20px;border-bottom:1px solid rgba(255,255,255,.12);display:flex;justify-content:space-between;align-items:center">
<div><div style="font-size:11px;letter-spacing:1.5px;color:rgba(255,255,255,.45)">GETSUZO DINO</div><div style="font-size:21px;font-weight:bold;color:#fff">Dino Runner</div></div>
<div style="text-align:right"><div id="score" style="font-size:18px;font-weight:bold;color:#fff;text-shadow:0 0 10px rgba(108,92,231,.85);transition:transform .15s">00000</div><div id="best" style="font-size:10px;color:rgba(255,255,255,.4);margin-top:2px">BEST 00000</div></div>
</div>
<div style="padding:18px">
<canvas id="game" width="560" height="190" style="width:100%;height:auto;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.12);border-radius:12px;display:block"></canvas>
<div id="status" style="text-align:center;margin-top:10px;font-size:12px;color:rgba(255,255,255,.55)">Speed 5.0x</div>
</div></div></div>
<script>
const c=document.getElementById('game'),x=c.getContext('2d'),scoreEl=document.getElementById('score'),bestEl=document.getElementById('best'),statusEl=document.getElementById('status');
const GY=170;
let d,o,clouds,particles,ambient,trail,score,best=0,speed,gameOver,last,shake,flash,runT,spawnTimer,milestone,squash;
function loadBest(){
let vals=[];
try{let v=localStorage.getItem('dino_best');if(v)vals.push(parseInt(v,10))}catch(e){}
try{let v=sessionStorage.getItem('dino_best');if(v)vals.push(parseInt(v,10))}catch(e){}
try{let m=document.cookie.match(/(?:^|;\\s*)dino_best=(\\d+)/);if(m)vals.push(parseInt(m[1],10))}catch(e){}
return vals.length?Math.max(...vals.filter(v=>!isNaN(v))):0
}
function saveBest(v){
let val=String(Math.floor(v));
try{localStorage.setItem('dino_best',val)}catch(e){}
try{sessionStorage.setItem('dino_best',val)}catch(e){}
try{document.cookie='dino_best='+val+';max-age=31536000;path=/'}catch(e){}
}
best=loadBest();
function reset(){
d={x:55,y:132,w:27,h:30,vy:0,jumping:false}; o=[];
clouds=[{x:120,y:32,w:44,s:.35},{x:300,y:52,w:60,s:.22},{x:460,y:26,w:36,s:.4},{x:560,y:70,w:50,s:.18}];
particles=[]; trail=[]; ambient=[];
for(let i=0;i<18;i++)ambient.push({x:Math.random()*c.width,y:Math.random()*c.height,r:.5+Math.random()*1.5,vx:.1+Math.random()*.3,ph:Math.random()*10})
score=0;speed=5;gameOver=false;last=0;shake=0;flash=0;runT=0;milestone=0;squash=1;
spawnTimer=70+Math.random()*30;
bestEl.textContent='BEST '+String(Math.floor(best)).padStart(5,'0');
statusEl.textContent='Speed 5.0x'
}
function burst(px,py,n,col,spd){for(let i=0;i<n;i++)particles.push({x:px,y:py,vx:(Math.random()-.5)*spd,vy:-Math.random()*spd,life:1,col,size:2+Math.random()*2})}
function jumpDino(){
if(gameOver){reset();return}
if(!d.jumping){d.jumping=true;d.vy=-13;squash=.7;burst(d.x+13,d.y+30,10,'255,255,255',4)}
}
function cactus(){
let h=24+Math.random()*24;
o.push({x:c.width+20,y:GY-h,w:16+Math.random()*6,h});
if(Math.random()<.22){o.push({x:c.width+20+34+Math.random()*10,y:GY-(20+Math.random()*18),w:16,h:20+Math.random()*18})}
}
function hit(a,b){return a.x+4<b.x+b.w&&a.x+a.w-4>b.x&&a.y+4<b.y+b.h&&a.y+a.h>b.y}
function drawTrail(){
trail.forEach((p,i)=>{x.fillStyle='rgba(108,92,231,'+(.25*(i/trail.length))+')';x.fillRect(p.x,p.y,27,30)})
}
function drawDino(){
x.save(); let cx=d.x+13,cy=d.y+30; x.translate(cx,cy); x.scale(1/squash,squash); x.translate(-cx,-cy);
let legOff=d.jumping?0:Math.sin(runT*.5)*5;
x.fillStyle='#eaeaea'; x.fillRect(d.x,d.y,27,30); x.fillRect(d.x+22,d.y+5,13,18);
x.fillStyle='#6c5ce7'; x.fillRect(d.x+29,d.y+8,4,4);
x.fillStyle='#eaeaea'; x.fillRect(d.x+5,d.y+30,6,8+legOff); x.fillRect(d.x+20,d.y+30,6,8-legOff);
x.restore()
}
function drawCactus(q){
x.save(); x.shadowColor='rgba(255,90,90,.35)';x.shadowBlur=10; x.fillStyle='#e17a7a';
x.fillRect(q.x,q.y,q.w,q.h); x.fillRect(q.x-7,q.y+10,7,6); x.fillRect(q.x-7,q.y+4,6,12); x.fillRect(q.x+q.w,q.y+18,7,6); x.fillRect(q.x+q.w+1,q.y+12,6,12);
x.restore()
}
function draw(){
x.clearRect(0,0,c.width,c.height); x.save();
if(shake>0)x.translate((Math.random()-.5)*shake,(Math.random()-.5)*shake);
ambient.forEach(p=>{let a=.15+Math.sin(runT*.05+p.ph)*.1;x.fillStyle='rgba(180,160,255,'+a+')';x.beginPath();x.arc(p.x,p.y,p.r,0,7);x.fill()})
x.fillStyle='rgba(255,255,255,.35)';
clouds.forEach(q=>{let b=Math.sin(runT*.03+q.x)*2;x.fillRect(q.x,q.y+b,q.w,5);x.fillRect(q.x+10,q.y+b-5,q.w*.45,10)});
x.strokeStyle='rgba(255,255,255,.25)'; x.lineWidth=2; x.setLineDash([10,8]); x.lineDashOffset=-runT*speed*.6;
x.beginPath();x.moveTo(0,GY);x.lineTo(c.width,GY);x.stroke(); x.setLineDash([]);
drawTrail(); drawDino(); o.forEach(drawCactus);
particles.forEach(p=>{x.fillStyle='rgba('+p.col+','+Math.max(p.life,0)+')';x.fillRect(p.x,p.y,p.size,p.size)})
if(flash>0){x.fillStyle='rgba(255,60,60,'+(flash*.35)+')';x.fillRect(0,0,c.width,c.height)}
x.restore();
if(gameOver){
x.fillStyle='rgba(15,15,25,.55)';x.fillRect(0,0,c.width,c.height);
x.fillStyle='#fff';x.textAlign='center';
x.font='bold 24px Arial';x.fillText('GAME OVER',c.width/2,85);
x.font='14px Arial';x.fillText('Tap layar untuk main lagi',c.width/2,112); x.textAlign='left'
}
}
function loop(t){
if(!last)last=t; let dt=Math.min((t-last)/16.67,2); last=t; runT+=dt;
if(!gameOver){
d.y+=d.vy*dt;d.vy+=.75*dt;
if(d.y>=132){if(d.jumping){burst(d.x+13,GY,10,'255,255,255',3.5);squash=1.35} d.y=132;d.vy=0;d.jumping=false}
if(d.jumping)trail.push({x:d.x,y:d.y}); if(trail.length>6)trail.shift(); if(!d.jumping)trail.length=0;
squash+=(1-squash)*.18*dt;
if(!d.jumping&&Math.floor(runT)%8===0&&Math.random()<.4)burst(d.x+6,GY-2,1,'255,255,255',1.5);
ambient.forEach(p=>{p.x-=p.vx*dt;if(p.x<-4)p.x=c.width+4});
spawnTimer-=dt; if(spawnTimer<=0){cactus();spawnTimer=Math.max(38,62-speed*1.4)+Math.random()*30}
o.forEach(q=>q.x-=speed*dt); o=o.filter(q=>q.x>-40);
clouds.forEach(q=>{q.x-=q.s*dt;if(q.x<-80)q.x=c.width+Math.random()*100});
particles.forEach(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=.3*dt;p.life-=.03*dt}); particles=particles.filter(p=>p.life>0);
speed=Math.min(11,speed+.0018*dt); score+=dt*.6;
if(score>best)best=score;
scoreEl.textContent=String(Math.floor(score)).padStart(5,'0'); bestEl.textContent='BEST '+String(Math.floor(best)).padStart(5,'0');
statusEl.textContent='Speed '+speed.toFixed(1)+'x';
for(const q of o)if(hit(d,q)){gameOver=true;shake=14;flash=1;saveBest(best);burst(d.x+13,d.y+15,18,'255,90,90',5)}
}
if(shake>0)shake=Math.max(0,shake-.6*dt); if(flash>0)flash=Math.max(0,flash-.05*dt);
draw(); requestAnimationFrame(loop)
}
document.addEventListener('pointerdown',e=>{e.preventDefault();jumpDino()});
document.addEventListener('keydown',e=>{if(e.code==='Space'){e.preventDefault();jumpDino()}});
reset(); requestAnimationFrame(loop);
</script></body>`;

// 2. PAYLOAD TIC-TAC-TOE (Ditambah min-height 550px, overflow auto, padding bawah)
const payloadHtmlTtt = `<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><style>
:root{--ink:#e9edef;--muted:#8696a0;--accent:#00a884;--line:#2a3942;--line-strong:#374248;--cell-bg:#111b21;--o:#00a884;--x:#e9edef;}
*{margin:0;padding:0;box-sizing:border-box} 
/* PERBAIKAN: Hilangkan overflow:hidden, ganti dengan auto dan tambah tinggi kanvas */
body{background:transparent;color:var(--ink);font-family:sans-serif;min-height:550px;display:flex;justify-content:center;align-items:center;overflow-y:auto;overflow-x:hidden;padding-bottom:40px;}
.card{width:100%;max-width:300px;padding:20px;margin-top:20px;}
.header{display:flex;justify-content:space-between;border-bottom:1px solid var(--line);padding-bottom:10px;margin-bottom:15px;}
.board{width:100%;aspect-ratio:1;display:grid;grid-template-columns:1fr 1fr 1fr;grid-template-rows:1fr 1fr 1fr;background:var(--cell-bg);border-radius:8px;border:1px solid var(--line);}
.cell{position:relative;background:transparent;border:none;cursor:pointer;}
.cell::before{content:'';position:absolute;right:0;top:5%;bottom:5%;width:1px;background:var(--line-strong);} .cell:nth-child(3n)::before{display:none}
.cell::after{content:'';position:absolute;bottom:0;left:5%;right:5%;height:1px;background:var(--line-strong);} .cell:nth-last-child(-n+3)::after{display:none}
.mark{position:absolute;inset:20%;pointer-events:none} .mark svg{width:100%;height:100%} 
.mark path,.mark circle{fill:none;stroke:var(--x);stroke-width:8;stroke-linecap:round;} .mark--o circle{stroke:var(--o)}
.status{display:flex;justify-content:space-between;font-size:14px;margin-bottom:15px;color:var(--muted)}
.footer__reset{width:100%;background:var(--accent);color:#111b21;border:none;padding:12px;border-radius:8px;font-weight:bold;margin-top:20px;box-shadow:0 4px 10px rgba(0,168,132,0.3);}
</style></head><body>
<div class="card">
  <div class="header"><b>Tic-Tac-Toe</b><span style="color:var(--muted);font-size:12px">vs AI Master</span></div>
  <div class="status"><span id="st-txt">Giliranmu</span><span>Skor: <b id="sc-x" style="color:#fff">0</b> - <b id="sc-o" style="color:#fff">0</b></span></div>
  <div class="board" id="board"></div>
  <button class="footer__reset" id="reset">Mulai Ulang</button>
</div>
<script>
let board=Array(9).fill(null), turn='X', over=false, score={X:0,O:0};
const bEl=document.getElementById('board'), stTxt=document.getElementById('st-txt');
const winLines=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
for(let i=0;i<9;i++){let c=document.createElement('button');c.className='cell';c.onclick=()=>play(i);bEl.appendChild(c);}
function draw(i,p){board[i]=p;let m=document.createElement('div');m.className='mark mark--'+p.toLowerCase();
m.innerHTML=p==='X'?'<svg viewBox="0 0 100 100"><path d="M20 20L80 80"/><path d="M80 20L20 80"/></svg>':'<svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="35"/></svg>';
bEl.children[i].appendChild(m); bEl.children[i].disabled=true;}
function play(i){
  if(board[i]||over||turn!=='X')return; draw(i,'X');
  if(chk('X')){end('X');return;} if(!board.includes(null)){end('D');return;}
  turn='O'; stTxt.textContent='AI Berpikir...'; setTimeout(ai,500);
}
function ai(){
  let empty=board.map((v,i)=>v===null?i:-1).filter(i=>i>=0);
  let move=empty[Math.floor(Math.random()*empty.length)]; 
  draw(move,'O');
  if(chk('O'))end('O'); else if(!board.includes(null))end('D'); else{turn='X';stTxt.textContent='Giliranmu';}
}
function chk(p){return winLines.some(l=>l.every(i=>board[i]===p))}
function end(w){
  over=true;
  if(w==='X'){stTxt.textContent='Kamu Menang!';score.X++;document.getElementById('sc-x').innerText=score.X;}
  else if(w==='O'){stTxt.textContent='AI Menang!';score.O++;document.getElementById('sc-o').innerText=score.O;}
  else stTxt.textContent='Seri!';
}
document.getElementById('reset').onclick=()=>{board=Array(9).fill(null);over=false;turn='X';stTxt.textContent='Giliranmu';Array.from(bEl.children).forEach(c=>{c.innerHTML='';c.disabled=false;});};
</script></body></html>`;

// 3. PAYLOAD DOOM FPS (Ditambah min-height 550px & overflow auto)
const payloadHtmlDoom = `<style>*{-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}</style>
<body style="margin:0;background:transparent;font-family:Arial,sans-serif;color:#eee;touch-action:manipulation;cursor:pointer;min-height:550px;overflow-y:auto;padding-bottom:30px;">
<div style="width:100%;max-width:620px;margin:auto;box-sizing:border-box;padding-top:20px;">
<div style="position:relative;width:100%;aspect-ratio:16/9;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.15);border-radius:16px;overflow:hidden;box-shadow:0 8px 32px rgba(0,0,0,.35)">
<canvas id="game" width="480" height="270" style="position:absolute;inset:0;width:100%;height:100%;display:block;background:#000;touch-action:none"></canvas>
<div style="position:absolute;top:8px;left:12px;pointer-events:none;text-shadow:0 1px 4px rgba(0,0,0,.9)">
<div style="font-size:9px;letter-spacing:1.5px;color:rgba(255,255,255,.65)">GETSUZO DOOM</div>
<div style="font-size:14px;font-weight:bold;color:#fff">Mini Doom FPS</div>
</div>
<div id="hp" style="position:absolute;top:8px;right:12px;font-size:16px;font-weight:bold;color:#4ade80;text-shadow:0 1px 4px rgba(0,0,0,.9)">100 HP</div>
<div style="position:absolute;bottom:6px;left:6px;display:flex;gap:5px">
<button id="forward" style="width:44px;height:44px;border:1px solid rgba(255,255,255,.3);border-radius:8px;background:rgba(0,0,0,.6);color:#fff;font-size:18px;">▲</button>
</div>
<div style="position:absolute;bottom:6px;right:6px;display:grid;grid-template-columns:repeat(3,44px);gap:5px">
<button id="strafeL" style="width:44px;height:44px;border:1px solid rgba(255,255,255,.3);border-radius:8px;background:rgba(0,0,0,.6);color:#fff;font-size:18px;">◀</button>
<button id="fire" style="width:44px;height:44px;border:1px solid rgba(230,60,60,.5);border-radius:8px;background:rgba(230,60,60,.5);color:#fff;font-size:18px;">🔥</button>
<button id="strafeR" style="width:44px;height:44px;border:1px solid rgba(255,255,255,.3);border-radius:8px;background:rgba(0,0,0,.6);color:#fff;font-size:18px;">▶</button>
</div>
</div></div>
<script>
const c=document.getElementById('game'),x=c.getContext('2d');
function draw(){
  x.fillStyle="#34302b"; x.fillRect(0,0,c.width,c.height/2);
  x.fillStyle="#111"; x.fillRect(0,c.height/2,c.width,c.height/2);
  // Senjata Dummy
  x.fillStyle="#555"; x.fillRect(c.width/2-20,c.height-60,40,60);
  x.fillStyle="#222"; x.fillRect(c.width/2-10,c.height-60,20,40);
}
setInterval(draw,30);
function bind(id){
  document.getElementById(id).onpointerdown=(e)=>{e.preventDefault();if(id==='fire'){x.fillStyle='rgba(255,200,0,0.5)';x.fillRect(0,0,c.width,c.height);}}
}
['forward','strafeL','strafeR','fire'].forEach(bind);
</script></body>`;


// ==========================================
// 🎮 HANDLER UTAMA (MASTER WRAPPER - TABS)
// ==========================================
const handler = async (m, { sock }) => {
  try {
    await sock.sendMessage(m.chat, { react: { text: '🎮', key: m.key } });

    const unifiedData = {
      response_id: crypto.randomUUID(),
      sections: [
        {
          view_model: {
            primitive: {
              text: '> Assistant X - Gaming Center',
              __typename: 'GenAIMarkdownTextUXPrimitive'
            },
            __typename: 'GenAISingleLayoutViewModel'
          }
        }
      ],
      embedded_screens: [
        {
          title: 'Preview',
          content: [
            {
              __typename: 'FOAIDNixelButtonSheets',
              tabs: [
                {
                  id: 'tab_0',
                  tab_header: 'Dino Runner',
                  sections: [
                    {
                      __typename: 'GenAIUnifiedResponseSection',
                      view_model: {
                        __typename: 'GenAISingleLayoutViewModel',
                        primitive: {
                          __typename: 'FOAHtmlPrimitiveDemoDONOTUSE',
                          payload: payloadHtmlDino,
                          url: 'https://assistant-x.dev',
                          trusted_sources: ['assistant-x.dev']
                        }
                      }
                    }
                  ],
                  step_entries: []
                },
                {
                  id: 'tab_1',
                  tab_header: 'Tic Tac Toe',
                  sections: [
                    {
                      __typename: 'GenAIUnifiedResponseSection',
                      view_model: {
                        __typename: 'GenAISingleLayoutViewModel',
                        primitive: {
                          __typename: 'FOAHtmlPrimitiveDemoDONOTUSE',
                          payload: payloadHtmlTtt,
                          url: 'https://assistant-x.dev',
                          trusted_sources: ['assistant-x.dev']
                        }
                      }
                    }
                  ],
                  step_entries: []
                },
                {
                  id: 'tab_2',
                  tab_header: 'Doom',
                  sections: [
                    {
                      __typename: 'GenAIUnifiedResponseSection',
                      view_model: {
                        __typename: 'GenAISingleLayoutViewModel',
                        primitive: {
                          __typename: 'FOAHtmlPrimitiveDemoDONOTUSE',
                          payload: payloadHtmlDoom,
                          url: 'https://assistant-x.dev',
                          trusted_sources: ['assistant-x.dev']
                        }
                      }
                    }
                  ],
                  step_entries: []
                }
              ]
            }
          ]
        }
      ]
    };

    const forwardContext = {
      forwardingScore: 9999,
      isForwarded: true,
      forwardOrigin: 4,
      forwardedAiBotMessageInfo: {
        botJid: '867051314767696@bot'
      },
      forwardedNewsletterMessageInfo: {
        newsletterName: global.newsletter?.name || 'Xenoria Gaming',
        newsletterJid: global.newsletter?.id || '120363429363092398@newsletter'
      }
    };

    const messagePayload = {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2,
        botMetadata: {
          messageDisclaimerText: '',
          botResponseId: crypto.randomUUID()
        }
      },
      botForwardedMessage: {
        message: {
          richResponseMessage: {
            messageType: 1,
            submessages: [
              {
                messageType: 2,
                messageText: '> Assistant X'
              }
            ],
            unifiedResponse: {
              data: Buffer.from(JSON.stringify(unifiedData)).toString('base64')
            },
            contextInfo: forwardContext
          }
        }
      }
    };

    await sock.relayMessage(m.chat, messagePayload, {});
    await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

  } catch (err) {
    console.error('Plugin dxd error:', err);
    await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    return m.reply(`❌ Gagal mengirim game interactive: ${err.message || err}`);
  }
};

handler.help = ['dxd'];
handler.tags = ['game'];
handler.command = ['dxd'];

module.exports = handler;
