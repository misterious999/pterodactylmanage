const axios = require('axios');

// ==========================================
// 📝 VIP MAKER: NULIS BUKU (HANDWRITING)
// ⚙️ BUG FIX: AUTO STRIP COMMAND
// ==========================================

let handler = async (m, { sock, text, prefix, command }) => {
    // 🔥 FIX: Ambil teks yang sudah difilter (tanpa command) jika tidak ada reply
    let pesan = m.quoted ? (m.quoted.text || m.quoted.caption || m.quoted.description || "") : text;

    if (!pesan) {
        await m.react("⚠️").catch(() => {});
        return m.reply(`❌ *Mau nulis apa Bosku?*\n\nKetik teksnya atau balas pesan orang lain!\n*Contoh:* \`${prefix + command} Assistant X Project emang paling VVIP!\``);
    }

    // 🛡️ LIMITER: Mencegah error gambar rusak karena teks terlalu panjang
    if (pesan.length > 500) {
        await m.react("⚠️").catch(() => {});
        return m.reply(`❌ *Teks kepanjangan Bosku!*\n\nMaksimal 500 karakter saja biar tintanya nggak habis dan muat di buku.`);
    }

    await m.react("⏳").catch(() => {});

    try {
        let apiKey = global.btc;
    if (!apiKey) return m.reply("❌ BOTCAHX_APIKEY belum diisi di file .env.");
        
        // 🚀 RAKIT URL API
        let apiUrl = global.botcahxUrl('/api/maker/nulis', { text: pesan });

        // Eksekusi pengunduhan gambar (dalam bentuk Buffer)
        let response = await axios.get(apiUrl, { 
            responseType: 'arraybuffer', 
            timeout: 20000 
        });

        // 🔥 WATERMARK FILTER
        let botName = global.botname || "Assistant X";
        let watermark = botName.toLowerCase().includes("project") ? botName : `${botName} Project`;

        // Kirim hasil gambar dengan UI elegan
        await sock.sendMessage(m.chat, { 
            image: response.data, 
            caption: `✅ *Catatan berhasil ditulis!*\n\n_© ${watermark}_`
        }, { quoted: m });

        await m.react("✅").catch(() => {});

    } catch (error) {
        console.error("🔴 [ERROR NULIS]", error.message);
        await m.react("❌").catch(() => {});
        return m.reply(`❌ *Sistem Mengalami Gangguan!*\n\nGagal menghubungi server pembuat gambar. Kemungkinan server API sedang penuh atau maintenance.`);
    }
}

handler.help = ["nulis <teks/reply>"];
handler.command = ["nulis", "tulis", "menulis"];
handler.tags = ["tools"]; 
handler.limit = true; 

module.exports = handler;
