const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');
const os = require('os');
const path = require('path');
const Jimp = require('jimp');

const COST_LIMIT = 5;
const REQUEST_TIMEOUT = 120000;
const MAX_UPLOAD_BYTES = 12 * 1024 * 1024;

function getBotcahxUrl(endpoint, params = {}) {
  if (typeof global.botcahxUrl === 'function') return global.botcahxUrl(endpoint, params);

  const base = String(global.botcahxBaseUrl || process.env.BOTCAHX_BASE_URL || 'https://api.botcahx.eu.org').replace(/\/$/, '');
  const key = global.btc || global.botcahxKey || process.env.BOTCAHX_APIKEY;
  if (!key) throw new Error('BOTCAHX_APIKEY belum diatur di .env / Environment Variables panel.');

  const url = new URL(`${base}${endpoint.startsWith('/') ? endpoint : `/${endpoint}`}`);
  for (const [k, v] of Object.entries(params || {})) {
    if (v !== undefined && v !== null && v !== '') url.searchParams.set(k, String(v));
  }
  url.searchParams.set('apikey', key);
  return url.toString();
}

async function downloadQuotedImage(q, sock) {
  if (typeof q.download === 'function') {
    const buffer = await q.download();
    if (Buffer.isBuffer(buffer) && buffer.length) return buffer;
  }

  if (sock && typeof sock.downloadMediaMessage === 'function') {
    try {
      const buffer = await sock.downloadMediaMessage(q, 'image');
      if (Buffer.isBuffer(buffer) && buffer.length) return buffer;
    } catch (_) {}
  }

  const msg = q.msg || q.message?.imageMessage || q.message?.viewOnceMessageV2?.message?.imageMessage || q.message?.viewOnceMessage?.message?.imageMessage || q;
  const stream = await downloadContentFromMessage(msg, 'image');
  let buffer = Buffer.alloc(0);
  for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
  if (!buffer.length) throw new Error('Gagal mengunduh gambar dari WhatsApp.');
  return buffer;
}

async function uploadToCatbox(buffer) {
  const tmp = path.join(os.tmpdir(), `hd_${Date.now()}_${Math.random().toString(16).slice(2)}.jpg`);
  fs.writeFileSync(tmp, buffer);

  try {
    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('fileToUpload', fs.createReadStream(tmp));

    const { data } = await axios.post('https://catbox.moe/user/api.php', form, {
      headers: form.getHeaders(),
      timeout: 60000,
      maxBodyLength: Infinity,
      maxContentLength: Infinity,
      validateStatus: () => true
    });

    const url = String(data || '').trim();
    if (url.startsWith('http')) return url;
    throw new Error(`Catbox menolak upload: ${url.slice(0, 120)}`);
  } finally {
    fs.unlink(tmp, () => {});
  }
}

async function uploadToUguu(buffer) {
  const form = new FormData();
  form.append('files[]', buffer, {
    filename: 'image.jpg',
    contentType: 'image/jpeg'
  });

  const { data } = await axios.post('https://uguu.se/upload.php', form, {
    headers: { ...form.getHeaders(), 'User-Agent': 'Mozilla/5.0' },
    timeout: 60000,
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    validateStatus: () => true
  });

  const url = data?.files?.[0]?.url;
  if (url && String(url).startsWith('http')) return url;
  throw new Error('Uguu tidak mengembalikan URL upload.');
}

async function uploadToTelegraph(buffer) {
  const form = new FormData();
  form.append('file', buffer, {
    filename: 'image.jpg',
    contentType: 'image/jpeg'
  });

  const { data } = await axios.post('https://telegra.ph/upload', form, {
    headers: { ...form.getHeaders(), 'Content-Length': form.getLengthSync() },
    timeout: 60000,
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    validateStatus: () => true
  });

  const src = data?.[0]?.src;
  if (src) return `https://telegra.ph${src}`;
  throw new Error('Telegraph tidak mengembalikan URL upload.');
}

async function uploadImage(buffer) {
  const errors = [];

  for (const uploader of [uploadToCatbox, uploadToUguu, uploadToTelegraph]) {
    try {
      return await uploader(buffer);
    } catch (err) {
      errors.push(err.message);
    }
  }

  throw new Error(`Gagal upload gambar sementara. Detail: ${errors.join(' | ')}`);
}

function tryJsonFromBuffer(buffer) {
  try {
    return JSON.parse(Buffer.from(buffer).toString('utf8'));
  } catch (_) {
    return null;
  }
}

function findResultValue(input, depth = 0) {
  if (!input || depth > 6) return null;

  if (typeof input === 'string') {
    const value = input.trim();
    if (value.startsWith('http')) return value;
    if (/^data:image\//i.test(value)) return value;
    if (/^[A-Za-z0-9+/=]{300,}$/.test(value)) return value;
    return null;
  }

  if (Buffer.isBuffer(input)) return input;

  if (Array.isArray(input)) {
    for (const item of input) {
      const found = findResultValue(item, depth + 1);
      if (found) return found;
    }
    return null;
  }

  if (typeof input === 'object') {
    const preferredKeys = [
      'result',
      'data',
      'url',
      'image',
      'img',
      'output',
      'buffer',
      'base64',
      'media',
      'file',
      'download',
      'link',
      'response'
    ];

    for (const key of preferredKeys) {
      const found = findResultValue(input[key], depth + 1);
      if (found) return found;
    }

    for (const value of Object.values(input)) {
      const found = findResultValue(value, depth + 1);
      if (found) return found;
    }
  }

  return null;
}

async function valueToImageBuffer(value) {
  if (Buffer.isBuffer(value)) return value;

  const str = String(value || '').trim();
  if (!str) throw new Error('Hasil HD kosong.');

  if (str.startsWith('http')) {
    const res = await axios.get(str, {
      responseType: 'arraybuffer',
      timeout: REQUEST_TIMEOUT,
      validateStatus: () => true,
      headers: { 'User-Agent': 'Mozilla/5.0' }
    });

    const type = String(res.headers['content-type'] || '').toLowerCase();
    const headHex = Buffer.from(res.data).slice(0, 20).toString('hex');

    if (res.status >= 400) {
      throw new Error(`URL hasil HD gagal diunduh. HTTP ${res.status}`);
    }

    if (!type.includes('image') && !/ffd8ff|89504e47|52494646|47494638/.test(headHex)) {
      const maybeJson = tryJsonFromBuffer(res.data);
      throw new Error(maybeJson?.message || maybeJson?.error || 'URL hasil HD bukan gambar.');
    }

    return Buffer.from(res.data);
  }

  const base64 = str.replace(/^data:image\/\w+;base64,/i, '');
  return Buffer.from(base64, 'base64');
}

async function callBotcahxHd(imageUrl) {
  const endpoints = [
    '/api/tools/remini',
    '/api/tools/hd',
    '/api/tools/upscale',
    '/api/maker/remini',
    '/api/image/remini'
  ];

  const errors = [];

  for (const endpoint of endpoints) {
    try {
      const res = await axios.get(getBotcahxUrl(endpoint, { url: imageUrl }), {
        responseType: 'arraybuffer',
        timeout: REQUEST_TIMEOUT,
        validateStatus: () => true,
        headers: { 'User-Agent': 'Mozilla/5.0' }
      });

      const buffer = Buffer.from(res.data);
      const type = String(res.headers['content-type'] || '').toLowerCase();

      if (res.status >= 500) {
        errors.push(`${endpoint}: server error ${res.status}`);
        continue;
      }

      if (type.includes('image')) return buffer;

      const json = tryJsonFromBuffer(buffer);
      if (!json) {
        errors.push(`${endpoint}: response bukan JSON/gambar`);
        continue;
      }

      if (json.status === false || json.success === false) {
        errors.push(`${endpoint}: ${json.message || json.error || 'request gagal'}`);
        continue;
      }

      const value = findResultValue(json);
      if (!value) {
        errors.push(`${endpoint}: tidak ada field hasil gambar`);
        continue;
      }

      return await valueToImageBuffer(value);
    } catch (err) {
      errors.push(`${endpoint}: ${err.message}`);
    }
  }

  throw new Error(errors.join(' | '));
}

async function localEnhance(buffer) {
  const image = await Jimp.read(buffer);
  const maxSide = Math.max(image.bitmap.width, image.bitmap.height);
  const scale = maxSide < 900 ? 2 : maxSide < 1400 ? 1.5 : 1.15;
  const targetWidth = Math.min(Math.round(image.bitmap.width * scale), 2200);

  image
    .resize(targetWidth, Jimp.AUTO)
    .normalize()
    .contrast(0.08)
    .quality(95)
    .convolute([
      [0, -1, 0],
      [-1, 5, -1],
      [0, -1, 0]
    ]);

  return await image.getBufferAsync(Jimp.MIME_JPEG);
}

let handler = async (m, { sock, prefix, command }) => {
  const user = global.db?.users?.[m.sender];
  if (!user) return m.reply('❌ Kamu belum terdaftar di database bot.');

  const isPremium = !!(user.premium || user.premiumTime > 0 || m.isOwner);

  if (!isPremium && Number(user.limit || 0) < COST_LIMIT) {
    return m.reply(`❌ *Limit kamu tidak cukup.*

Sisa limit: ${user.limit || 0}
Butuh: ${COST_LIMIT} limit untuk fitur HD.`);
  }

  const q = m.quoted ? m.quoted : m;
  const mime = (q.msg || q).mimetype || q.mimetype || q.mediaType || '';

  if (!String(mime).includes('image')) {
    return m.reply(`Kirim atau reply foto dengan perintah *${prefix}${command}*`);
  }

  await m.react('⏳').catch(() => {});
  await sock.sendMessage(
    m.chat,
    {
      text: '⏳ *Bentar ya...*\nFotonya sedang diproses ke mode HD. Limit hanya dipotong kalau proses berhasil.'
    },
    { quoted: m }
  );

  try {
    const inputBuffer = await downloadQuotedImage(q, sock);

    if (!inputBuffer.length) {
      throw new Error('Buffer gambar kosong.');
    }

    if (inputBuffer.length > MAX_UPLOAD_BYTES) {
      throw new Error('Ukuran gambar terlalu besar. Maksimal sekitar 12 MB.');
    }

    let outputBuffer;
    let mode = 'BOTCAHX Remini';

    try {
      const imageUrl = await uploadImage(inputBuffer);
      outputBuffer = await callBotcahxHd(imageUrl);
    } catch (apiError) {
      console.error('[HD BOTCAHX ERROR]', apiError.message);
      outputBuffer = await localEnhance(inputBuffer);
      mode = 'Local fallback';
    }

    if (!Buffer.isBuffer(outputBuffer) || !outputBuffer.length) {
      throw new Error('Output gambar HD kosong.');
    }

    if (!isPremium) {
      user.limit = Math.max(0, Number(user.limit || 0) - COST_LIMIT);
    }

    let caption = '✅ *Foto berhasil dibuat HD!*\n\n';
    caption += `👤 Request: @${m.sender.split('@')[0]}\n`;
    caption += `⚙️ Mode: ${mode}\n`;
    caption += isPremium ? '💎 Limit: Premium / tidak dipotong' : `💎 Limit terpotong: ${COST_LIMIT}`;

    await sock.sendMessage(
      m.chat,
      {
        image: outputBuffer,
        caption,
        mentions: [m.sender]
      },
      { quoted: m }
    );

    await m.react('✅').catch(() => {});
  } catch (err) {
    console.error('[HD ERROR]', err);
    await m.react('❌').catch(() => {});
    return m.reply(`❌ *Gagal membuat foto HD.*

Penyebab: ${err.message || err}

Limit tidak dipotong.`);
  }
};

handler.command = ['hd', 'remini', 'jernihkan', 'hdfoto'];
handler.tags = ['tools'];
handler.help = ['hd <reply foto>'];
handler.limit = false;

module.exports = handler;