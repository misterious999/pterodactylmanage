// ==========================================
// 📸 PRO SSWEB INTERACTIVE (ANTI-BLOKIR)
// ⚙️ Ciptaan Pstar7 | BOTCAHX Screenshot Engine
// ==========================================

const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

let handler = async (m, { sock, conn, text, prefix, command }) => {
    let client = sock || conn;

    switch (command) {
        // 🟢 1. MENU UTAMA (Tombol)
        case 'ssweb':
        case 'ss': {
            if (!text) return m.reply(`❗ *Sertakan Link Website!*\nContoh: \`${prefix + command} https://google.com\``);
            
            if (!global.btc) {
                return m.reply("❌ BOTCAHX_APIKEY belum diisi di file .env.");
            }

            let url = text.trim();
            if (!/^https?:\/\//i.test(url)) url = 'https://' + url;

            await m.react("⏳").catch(() => {});

            try {
                let msg = generateWAMessageFromContent(m.chat, {
                    viewOnceMessage: {
                        message: {
                            "messageContextInfo": {
                                "deviceListMetadata": {},
                                "deviceListMetadataVersion": 2
                            },
                            interactiveMessage: proto.Message.InteractiveMessage.create({
                                body: proto.Message.InteractiveMessage.Body.create({
                                    text: `📸 *WEBSITE SCREENSHOT*\n\n🌐 *URL:* ${url}\n\nSilakan pilih mode tampilan *Desktop* (PC) atau *Mobile* (HP) melalui tombol di bawah ini:`
                                }),
                                footer: proto.Message.InteractiveMessage.Footer.create({
                                    text: "© ZeroixDark Marketplace"
                                }),
                                header: proto.Message.InteractiveMessage.Header.create({
                                    title: "", subtitle: "", hasMediaAttachment: false
                                }),
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                    buttons: [
                                        {
                                            "name": "quick_reply",
                                            "buttonParamsJson": `{"display_text":"💻 DESKTOP","id":".sspc ${url}"}`
                                        },
                                        {
                                            "name": "quick_reply",
                                            "buttonParamsJson": `{"display_text":"📱 MOBILE","id":".sshp ${url}"}`
                                        }
                                    ],
                                })
                            })
                        }
                    }
                }, { quoted: m });

                await client.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
                await m.react("✅").catch(() => {});

            } catch (e) {
                console.error("[BUTTON ERROR]", e);
                let fallbackTeks = `📸 *WEBSITE SCREENSHOT*\n\n🌐 *URL:* ${url}\n\nKetik perintah berikut:\n💻 *PC:* \`.sspc ${url}\`\n📱 *HP:* \`.sshp ${url}\``;
                m.reply(fallbackTeks);
            }
            break;
        }

        // 🟢 2. EKSEKUSI DESKTOP (PC)
        case 'sspc': {
            if (!text) return;
            await m.react("⏳").catch(() => {});
            let targetUrl = text.trim();
            if (!/^https?:\/\//i.test(targetUrl)) targetUrl = 'https://' + targetUrl;
            let apiUrl = global.botcahxUrl('/api/tools/ssweb', { url: targetUrl, device: 'desktop', width: 1920, height: 1080 });
            
            try {
                await client.sendMessage(m.chat, { image: { url: apiUrl }, caption: `💻 *DESKTOP VIEW*\n🌐 ${text.trim()}` }, { quoted: m });
                await m.react("✅").catch(() => {});
            } catch (e) {
                m.reply("❌ Gagal mengambil screenshot PC. BOTCAHX mungkin limit atau web error.");
            }
            break;
        }

        // 🟢 3. EKSEKUSI MOBILE (HP)
        case 'sshp': {
            if (!text) return;
            await m.react("⏳").catch(() => {});
            let targetUrl = text.trim();
            if (!/^https?:\/\//i.test(targetUrl)) targetUrl = 'https://' + targetUrl;
            let apiUrl = global.botcahxUrl('/api/tools/ssweb', { url: targetUrl, device: 'mobile', width: 390, height: 844 });
            
            try {
                await client.sendMessage(m.chat, { image: { url: apiUrl }, caption: `📱 *MOBILE VIEW*\n🌐 ${text.trim()}` }, { quoted: m });
                await m.react("✅").catch(() => {});
            } catch (e) {
                m.reply("❌ Gagal mengambil screenshot HP. Web mungkin memblokir total akses bot.");
            }
            break;
        }
    }
}

handler.command = ['ssweb', 'sspc', 'sshp'];
handler.tags = ['tools'];
module.exports = handler;
