const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

let handler = async (m, { sock, args, prefix, command }) => {
    let action = args[0]?.toLowerCase();
    let textData = args.slice(1).join(' ');

    if (!action || !['enc', 'dec'].includes(action) || !textData) {
        return m.reply(`✦ *Format Tidak Lengkap*\n\nGunakan format: *${prefix}${command} <enc/dec> <teks>*\n\nContoh:\n◦ *${prefix}${command} enc Xenoria*\n◦ *${prefix}${command} dec WGVub3JpYQ==*`);
    }

    await m.react('⏳').catch(() => {});
    let pesanLoading = action === 'enc' 
        ? "✦ _Menyandikan teks ke dalam dimensi Base64... Mohon tunggu._" 
        : "✦ _Membongkar sandi dimensi Base64... Mohon tunggu._";
    
    // Kirim pesan loading
    let { key } = await sock.sendMessage(m.chat, { text: pesanLoading }, { quoted: m });

    try {
        let resultText = '';

        // ⚙️ Menggunakan Internal V8 Engine Node.js (Cepat & Tanpa Limit)
        if (action === 'enc') {
            resultText = Buffer.from(textData, 'utf-8').toString('base64');
        } else if (action === 'dec') {
            resultText = Buffer.from(textData, 'base64').toString('utf-8');
        }

        let teksSukses = `✦ *B A S E 6 4   T O O L S* ✦\n\n`;
        teksSukses += `🔐 *Status:* Operasi berhasil dieksekusi!\n`;
        teksSukses += `> 🔗 _Source: Internal V8 Engine_\n\n`;
        teksSukses += `_Silakan klik tombol di bawah ini untuk menyalin hasilnya dengan cepat!_`;

        // Hapus pesan loading
        await sock.sendMessage(m.chat, { delete: key }).catch(() => {});

        // Rakit pesan tombol CTA Copy
        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text: teksSukses }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: "© Neural Core Engine 📡" }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [{
                                name: "cta_copy",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "📋 Salin Hasil",
                                    copy_code: resultText
                                })
                            }]
                        })
                    })
                }
            }
        }, { quoted: m });

        await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await m.react('✅').catch(() => {});

    } catch (e) {
        await m.react('❌').catch(() => {});
        await sock.sendMessage(m.chat, { 
            text: `✦ *Sistem Mengalami Kendala*\n\n_${e.message || "Gagal memproses permintaan."}_` 
        }, { edit: key });
    }
};

handler.help = ['base64 <enc/dec> <teks>'];
handler.tags = ['tools'];
handler.command = ['base64'];

module.exports = handler;
