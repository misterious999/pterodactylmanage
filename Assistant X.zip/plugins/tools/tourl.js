const axios = require('axios');
const FormData = require('form-data');
const { fromBuffer } = require('file-type'); 
const { generateWAMessageFromContent, proto, downloadContentFromMessage } = require('@whiskeysockets/baileys');
const crypto = require('crypto');

// 🔥 KTP VVIP: Standar User-Agent Chrome
const REAL_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36';

const API_TOKEN = "";
const randomBytes = () => crypto.randomBytes(5).toString("hex");

// ==========================================
// 📡 FUNGSI-FUNGSI UPLOADER CORE
// ==========================================

const handleErrorResponse = (error) => {
    return `Error Server`;
};

const validateInput = (input) => {
    if (Buffer.isBuffer(input)) return input;
    if (input instanceof Uint8Array || input instanceof ArrayBuffer) return Buffer.from(input);
    if (typeof input === 'object' && input.data) return Buffer.from(input.data);
    throw new TypeError(`Input tidak valid`);
};

// --- 1. YUPRA ---
const uploadYupra = async (buffer, filename) => {
    buffer = validateInput(buffer);
    const form = new FormData();
    form.append('files', buffer, { filename });
    const { data } = await axios.post('https://cdn.yupra.my.id/upload', form, {
        headers: { ...form.getHeaders(), 'User-Agent': REAL_UA },
        timeout: 120000
    });
    return data;
};

// --- 2. CATBOX ---
const catbox = async (buffer, ext) => {
    buffer = validateInput(buffer);
    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('fileToUpload', buffer, `file.${ext}`);
    const { data } = await axios.post('https://catbox.moe/user/api.php', form, {
        headers: { ...form.getHeaders(), 'User-Agent': REAL_UA }
    });
    return data;
};

// --- 3. QUAX ---
const quax = async (buffer, ext, mime) => {
    buffer = validateInput(buffer);
    const form = new FormData();
    form.append('files[]', buffer, { filename: `tmp.${ext}`, contentType: mime });
    form.append('expiry', '-1');
    const { data } = await axios.post('https://qu.ax/upload.php', form, {
        headers: { ...form.getHeaders(), 'User-Agent': REAL_UA }, 
        maxBodyLength: Infinity, maxContentLength: Infinity
    });
    return data.files[0].url;
};

// --- 4. POMF2 ---
const uploadPomf2 = async (buffer, ext) => {
    buffer = validateInput(buffer);
    const form = new FormData();
    form.append('files[]', buffer, `${randomBytes()}.${ext}`);
    const { data } = await axios.post('https://pomf2.lain.la/upload.php', form, {
        headers: { ...form.getHeaders(), 'User-Agent': REAL_UA }
    });
    if (!data.success) throw new Error('Pomf2 gagal');
    return data.files[0].url;
};

// --- 5. GOFILE ---
async function uploadGoFile(buffer, fileName) {
    buffer = validateInput(buffer);
    const form = new FormData();
    form.append('file', buffer, fileName);
    const { data: res } = await axios.post('https://upload.gofile.io/uploadFile', form, {
        headers: { ...form.getHeaders(), ...(API_TOKEN ? { Authorization: `Bearer ${API_TOKEN}` } : {}), 'User-Agent': REAL_UA }
    });
    if (res.status !== 'ok') throw new Error('GoFile gagal');
    return `https://${res.data.servers?.[0]}.gofile.io/download/web/${res.data.parentFolder}/${res.data.name}`;
}

// --- 6. FADZZZ CLOUD (FIXED DOMAIN) ---
async function uploadFadzzz(buffer, filename) {
    buffer = validateInput(buffer);
    const form = new FormData();
    
    form.append('file', buffer, filename);
    
    // 🔥 FIXED: Domain dikembalikan ke my.id sesuai instruksi Bosku!
    const { data } = await axios.post('https://fadzzzcloud.my.id/upload', form, {
        headers: { 
            ...form.getHeaders(),
            'User-Agent': REAL_UA 
        },
        maxBodyLength: Infinity,
        maxContentLength: Infinity
    });
    return data;
}

// ==========================================
// 🚀 MAIN HANDLER (EXECUTIVE DASHBOARD)
// ==========================================

let handler = async (m, { sock, prefix, command }) => {
    let q = m.quoted || m;
    let mime = (q.msg || q).mimetype || q.mediaType || '';
    
    if (!mime || mime.includes('text/plain')) {
        return m.reply(`❌ *Akses Ditolak!*\nSilakan balas (reply) ke media Foto/Video/Audio/Dokumen dengan perintah \`${prefix}${command}\``);
    }

    await m.react('⏳');
    let { key } = await sock.sendMessage(m.chat, { text: "🔄 _Menghidupkan Multi-Uploader Engine..._" }, { quoted: m });

    try {
        let mediaType = mime.split('/')[0];
        if (mediaType === 'audio') mediaType = 'audio';
        else if (mediaType === 'video') mediaType = 'video';
        else if (mediaType === 'image') mediaType = 'image';
        else mediaType = 'document';

        const stream = await downloadContentFromMessage(q.msg || q, mediaType);
        let media = Buffer.from([]);
        for await (const chunk of stream) media = Buffer.concat([media, chunk]);

        if (!media || media.length === 0) throw new Error('Gagal mengekstrak file');
        if (media.length > 100 * 1024 * 1024) throw new Error('File terlalu besar (Maks 100MB)');

        const type = await fromBuffer(media).catch(() => null);
        let fileExt = type?.ext || mime.split('/')[1]?.split(';')[0] || 'bin';
        let fileMime = type?.mime || mime;
        const fileName = `AssistantX-${crypto.randomBytes(3).toString("hex")}.${fileExt}`;

        await sock.sendMessage(m.chat, { text: "🚀 _Menembakkan file ke 6 Server Awan (Cloud)..._", edit: key });

        // --- Eksekusi Paralel ---
        let link1 = 'Error'; let status1 = '🔴 Gagal';
        try { const r = await uploadYupra(media, fileName); if (r.success) { link1 = `https://cdn.yupra.my.id${r.files[0].url}`; status1 = '🟢 Sukses'; } } catch (e) { link1 = handleErrorResponse(e); }

        let link2 = 'Error'; let status2 = '🔴 Gagal';
        try { link2 = await catbox(media, fileExt); if (link2.startsWith('http')) status2 = '🟢 Sukses'; } catch (e) { link2 = handleErrorResponse(e); }

        let link3 = 'Error'; let status3 = '🔴 Gagal';
        try { link3 = await quax(media, fileExt, fileMime); status3 = '🟢 Sukses'; } catch (e) { link3 = handleErrorResponse(e); }

        let link4 = 'Error'; let status4 = '🔴 Gagal';
        try { link4 = await uploadPomf2(media, fileExt); status4 = '🟢 Sukses'; } catch (e) { link4 = handleErrorResponse(e); }

        let link5 = 'Error'; let status5 = '🔴 Gagal';
        try { link5 = await uploadGoFile(media, fileName); status5 = '🟢 Sukses'; } catch (e) { link5 = handleErrorResponse(e); }

        let link6 = 'Error'; let status6 = '🔴 Gagal';
        try { 
            const r = await uploadFadzzz(media, fileName); 
            if (r.success) { link6 = r.url; status6 = '🟢 Sukses'; } 
        } catch (e) { link6 = handleErrorResponse(e); }

        let teks = `✨ *M U L T I - U P L O A D E R* ✨\n\n`;
        teks += `╭───「 *SERVER STATUS* 」\n`;
        teks += `│ ◦ ☁️ *Yupra:* ${status1}\n`;
        teks += `│ ◦ 📦 *Catbox:* ${status2}\n`;
        teks += `│ ◦ 🦆 *Quax:* ${status3}\n`;
        teks += `│ ◦ 🎀 *Pomf2:* ${status4}\n`;
        teks += `│ ◦ 📁 *GoFile:* ${status5}\n`;
        teks += `│ ◦ 🌩️ *Fadzzz:* ${status6}\n`;
        teks += `╰──────────────\n\n`;
        teks += `_Silakan salin tautan yang berhasil diunggah menggunakan tombol interaktif di bawah ini._ 🚀`;

        const buttons = [];
        if (status1.includes('Sukses')) buttons.push({ name: "cta_copy", buttonParamsJson: `{"display_text":"Salin Link Yupra","id":"c1","copy_code":"${link1}"}` });
        if (status2.includes('Sukses')) buttons.push({ name: "cta_copy", buttonParamsJson: `{"display_text":"Salin Link Catbox","id":"c2","copy_code":"${link2}"}` });
        if (status3.includes('Sukses')) buttons.push({ name: "cta_copy", buttonParamsJson: `{"display_text":"Salin Link Quax","id":"c3","copy_code":"${link3}"}` });
        if (status4.includes('Sukses')) buttons.push({ name: "cta_copy", buttonParamsJson: `{"display_text":"Salin Link Pomf2","id":"c4","copy_code":"${link4}"}` });
        if (status5.includes('Sukses')) buttons.push({ name: "cta_copy", buttonParamsJson: `{"display_text":"Salin Link GoFile","id":"c5","copy_code":"${link5}"}` });
        if (status6.includes('Sukses')) buttons.push({ name: "cta_copy", buttonParamsJson: `{"display_text":"Salin Link Fadzzz","id":"c6","copy_code":"${link6}"}` });

        await sock.sendMessage(m.chat, { delete: key });

        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: `© Assistant X Multi-Cloud Engine 📡` }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons: buttons }),
                        contextInfo: {
                            forwardingScore: 999, isForwarded: true,
                            forwardedNewsletterMessageInfo: { newsletterJid: global.idChannel || "1203631@newsletter", newsletterName: "Assistant X Cloud ☁️", serverId: 1 }
                        }
                    })
                }
            }
        }, { quoted: m });

        await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await m.react('✅');

    } catch (e) {
        console.error('Error Multi-Uploader:', e);
        await m.react('❌');
        await sock.sendMessage(m.chat, { text: `❌ *Sistem Gagal!*\n\n📝 _Log:_ ${e.message}`, edit: key });
    }
};

handler.help = ['tourl'];
handler.tags = ['tools'];
handler.command = ['tourl', 'upload'];

module.exports = handler;
