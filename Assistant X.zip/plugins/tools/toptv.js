// ==========================================
// 🎥 VIDEO TO PTV (VIDEO NOTE) CONVERTER
// ⚙️ Ciptaan Pstar7 | Assistant X Project
// ==========================================

let handler = async (m, { sock, prefix, command }) => {
    try {
        // Cek apakah ada pesan yang di-reply atau pesan langsung
        let q = m.quoted ? m.quoted : m;
        let mime = (q.msg || q).mimetype || '';

        // Validasi format: Harus berupa video
        if (!mime.includes('video')) {
            await m.react("⚠️");
            return m.reply(`╭──「 *⚠️ INVALID FORMAT* 」\n│ Harap balas sebuah pesan video dengan perintah:\n│ ◦ \`${prefix + command}\`\n╰────────────`);
        }

        await m.react("⏳"); // Indikator proses

        // Mengambil raw object (data mentah) dari video
        let videoObj = m.message?.extendedTextMessage?.contextInfo?.quotedMessage?.videoMessage || m.message?.videoMessage;

        if (!videoObj) {
            return m.reply("❌ Gagal membaca metadata video. Pastikan kamu me-reply video yang valid.");
        }

        // Merakit ulang sebagai PTV (Push-To-Video / Video Note bulat)
        let ptvData = { ptvMessage: videoObj };

        // Eksekusi pengiriman
        await sock.relayMessage(m.chat, ptvData, {});
        await m.react("✅"); // Indikator sukses

    } catch (error) {
        console.error("[ERROR TOPTV]", error);
        m.reply(`❌ Terjadi kesalahan internal saat mengonversi video.`);
    }
}

handler.help = ["toptv"];
handler.command = ["toptv"];
handler.tags = ["tools"];
handler.limit = true;      // Menguras 1 limit user
handler.register = true;   // Hanya untuk user terdaftar

module.exports = handler;
