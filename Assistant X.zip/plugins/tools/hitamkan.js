const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');
const os = require('os');
const path = require('path');

let JimpLib = null;
try {
    const mod = require('jimp');
    JimpLib = mod.Jimp || mod;
} catch (_) {
    JimpLib = null;
}

const REQUEST_TIMEOUT = 180000;
const MAX_UPLOAD_BYTES = 12 * 1024 * 1024;

function buildBotcahxUrl(endpoint, params = {}) {
    if (typeof global.botcahxUrl === 'function') {
        return global.botcahxUrl(endpoint, params);
    }

    const base = String(
        global.botcahxBaseUrl ||
        process.env.BOTCAHX_BASE_URL ||
        'https://api.botcahx.eu.org'
    ).replace(/\/$/, '');

    const apikey =
        global.btc ||
        global.botcahxKey ||
        process.env.BOTCAHX_APIKEY;

    if (!apikey) {
        throw new Error('BOTCAHX_APIKEY belum diatur di .env / Environment Variables panel.');
    }

    const url = new URL(`${base}${endpoint.startsWith('/') ? endpoint : `/${endpoint}`}`);

    for (const [key, value] of Object.entries(params || {})) {
        if (value !== undefined && value !== null && value !== '') {
            url.searchParams.set(key, String(value));
        }
    }

    url.searchParams.set('apikey', apikey);
    return url.toString();
}

async function downloadQuotedImage(q, sock) {
    if (typeof q.download === 'function') {
        const buffer = await q.download();
        if (Buffer.isBuffer(buffer) && buffer.length) return buffer;
    }

    if (sock && typeof sock.downloadMediaMessage === 'function') {
        try {
            const buffer = await sock.downloadMediaMessage(q, 'image');
            if (Buffer.isBuffer(buffer) && buffer.length) return buffer;
        } catch (_) {}
    }

    const msg =
        q.msg ||
        q.message?.imageMessage ||
        q.message?.viewOnceMessageV2?.message?.imageMessage ||
        q.message?.viewOnceMessage?.message?.imageMessage ||
        q;

    const stream = await downloadContentFromMessage(msg, 'image');

    let buffer = Buffer.alloc(0);
    for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
    }

    if (!buffer.length) {
        throw new Error('Gagal mengunduh gambar dari WhatsApp.');
    }

    return buffer;
}

async function uploadToCatbox(buffer) {
    const tmp = path.join(os.tmpdir(), `hitamkan_${Date.now()}_${Math.random().toString(16).slice(2)}.jpg`);
    fs.writeFileSync(tmp, buffer);

    try {
        const form = new FormData();
        form.append('reqtype', 'fileupload');
        form.append('fileToUpload', fs.createReadStream(tmp));

        const { data } = await axios.post('https://catbox.moe/user/api.php', form, {
            headers: form.getHeaders(),
            timeout: 60000,
            maxBodyLength: Infinity,
            maxContentLength: Infinity,
            validateStatus: () => true
        });

        const url = String(data || '').trim();
        if (url.startsWith('http')) return url;

        throw new Error(`Catbox gagal: ${url.slice(0, 120)}`);
    } finally {
        fs.unlink(tmp, () => {});
    }
}

async function uploadToUguu(buffer) {
    const form = new FormData();

    form.append('files[]', buffer, {
        filename: 'image.jpg',
        contentType: 'image/jpeg'
    });

    const { data } = await axios.post('https://uguu.se/upload.php', form, {
        headers: {
            ...form.getHeaders(),
            'User-Agent': 'Mozilla/5.0'
        },
        timeout: 60000,
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
        validateStatus: () => true
    });

    const url = data?.files?.[0]?.url;
    if (url && String(url).startsWith('http')) return url;

    throw new Error('Uguu tidak mengembalikan URL.');
}

async function uploadToTelegraph(buffer) {
    const form = new FormData();

    form.append('file', buffer, {
        filename: 'image.jpg',
        contentType: 'image/jpeg'
    });

    const { data } = await axios.post('https://telegra.ph/upload', form, {
        headers: {
            ...form.getHeaders(),
            'Content-Length': form.getLengthSync()
        },
        timeout: 60000,
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
        validateStatus: () => true
    });

    const src = data?.[0]?.src;
    if (src) return `https://telegra.ph${src}`;

    throw new Error('Telegraph tidak mengembalikan URL.');
}

async function getUploadUrls(buffer) {
    const uploaders = [
        uploadToCatbox,
        uploadToUguu,
        uploadToTelegraph
    ];

    const urls = [];
    const errors = [];

    for (const uploader of uploaders) {
        try {
            const url = await uploader(buffer);
            if (url && !urls.includes(url)) urls.push(url);
        } catch (error) {
            errors.push(error.message);
        }
    }

    if (!urls.length) {
        throw new Error(`Gagal upload gambar. Detail: ${errors.join(' | ')}`);
    }

    return urls;
}

function tryParseJson(buffer) {
    try {
        return JSON.parse(Buffer.from(buffer).toString('utf8'));
    } catch {
        return null;
    }
}

function findResultValue(input, depth = 0) {
    if (!input || depth > 8) return null;

    if (typeof input === 'string') {
        const value = input.trim();

        if (value.startsWith('http')) return value;
        if (/^data:image\//i.test(value)) return value;
        if (/^[A-Za-z0-9+/=]{500,}$/.test(value)) return value;

        return null;
    }

    if (Buffer.isBuffer(input)) return input;

    if (Array.isArray(input)) {
        for (const item of input) {
            const found = findResultValue(item, depth + 1);
            if (found) return found;
        }
        return null;
    }

    if (typeof input === 'object') {
        const preferredKeys = [
            'result',
            'data',
            'url',
            'image',
            'img',
            'output',
            'buffer',
            'base64',
            'media',
            'file',
            'download',
            'link',
            'response'
        ];

        for (const key of preferredKeys) {
            const found = findResultValue(input[key], depth + 1);
            if (found) return found;
        }

        for (const value of Object.values(input)) {
            const found = findResultValue(value, depth + 1);
            if (found) return found;
        }
    }

    return null;
}

async function valueToImageBuffer(value) {
    if (Buffer.isBuffer(value)) return value;

    const str = String(value || '').trim();
    if (!str) throw new Error('Hasil gambar kosong.');

    if (str.startsWith('http')) {
        const res = await axios.get(str, {
            responseType: 'arraybuffer',
            timeout: REQUEST_TIMEOUT,
            validateStatus: () => true,
            headers: {
                'User-Agent': 'Mozilla/5.0'
            }
        });

        const type = String(res.headers['content-type'] || '').toLowerCase();

        if (res.status >= 400) {
            throw new Error(`URL hasil gagal diunduh. HTTP ${res.status}`);
        }

        if (!type.includes('image')) {
            const json = tryParseJson(res.data);
            throw new Error(json?.message || json?.error || 'URL hasil bukan gambar.');
        }

        return Buffer.from(res.data);
    }

    const base64 = str.replace(/^data:image\/\w+;base64,/i, '');
    return Buffer.from(base64, 'base64');
}

async function callBotcahxJadiHitam(imageUrl) {
    const apiUrl = buildBotcahxUrl('/api/maker/jadihitam', {
        url: imageUrl
    });

    const res = await axios.get(apiUrl, {
        responseType: 'arraybuffer',
        timeout: REQUEST_TIMEOUT,
        validateStatus: () => true,
        headers: {
            'User-Agent': 'Mozilla/5.0'
        }
    });

    const buffer = Buffer.from(res.data);
    const type = String(res.headers['content-type'] || '').toLowerCase();

    if (res.status >= 500) {
        throw new Error(`Server BOTCAHX error. HTTP ${res.status}`);
    }

    if (res.status >= 400) {
        const json = tryParseJson(buffer);
        throw new Error(json?.message || json?.error || `Request gagal. HTTP ${res.status}`);
    }

    if (type.includes('image')) {
        return buffer;
    }

    const json = tryParseJson(buffer);

    if (!json) {
        throw new Error('Response BOTCAHX bukan JSON/gambar.');
    }

    if (json.status === false || json.success === false) {
        throw new Error(json.message || json.error || 'BOTCAHX gagal memproses gambar.');
    }

    const value = findResultValue(json);

    if (!value) {
        console.log('[HITAMKAN RAW RESPONSE]', JSON.stringify(json, null, 2));
        throw new Error('Field hasil gambar tidak ditemukan dari response BOTCAHX.');
    }

    return await valueToImageBuffer(value);
}

async function localDarkFallback(buffer) {
    if (!JimpLib || typeof JimpLib.read !== 'function') {
        throw new Error('BOTCAHX gagal dan fallback lokal butuh package jimp. Install: npm i jimp');
    }

    const image = await JimpLib.read(buffer);

    if (typeof image.greyscale === 'function') image.greyscale();
    else if (typeof image.grayscale === 'function') image.grayscale();

    if (typeof image.brightness === 'function') image.brightness(-0.35);
    if (typeof image.contrast === 'function') image.contrast(0.25);
    if (typeof image.quality === 'function') image.quality(92);

    const mime = JimpLib.MIME_JPEG || 'image/jpeg';

    if (typeof image.getBufferAsync === 'function') {
        return await image.getBufferAsync(mime);
    }

    return await new Promise((resolve, reject) => {
        image.getBuffer(mime, (err, out) => {
            if (err) reject(err);
            else resolve(out);
        });
    });
}

async function processHitamkan(inputBuffer) {
    const uploadUrls = await getUploadUrls(inputBuffer);
    const errors = [];

    for (const imageUrl of uploadUrls) {
        try {
            return {
                buffer: await callBotcahxJadiHitam(imageUrl),
                mode: 'BOTCAHX Jadihitam'
            };
        } catch (error) {
            errors.push(`${imageUrl}: ${error.message}`);
        }
    }

    console.log('[HITAMKAN API RETRY FAILED]', errors.join(' | '));

    return {
        buffer: await localDarkFallback(inputBuffer),
        mode: 'Local fallback'
    };
}

let handler = async (m, { sock, prefix, command }) => {
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || q.mimetype || q.mediaType || '';

    if (!String(mime).includes('image')) {
        return m.reply(`Kirim atau reply foto dengan perintah *${prefix}${command}*`);
    }

    await m.react('⏳').catch(() => {});

    try {
        await sock.sendMessage(m.chat, {
            text: '⏳ *Bentar ya...*\nFoto sedang diproses menjadi mode hitam.'
        }, {
            quoted: m
        });

        const inputBuffer = await downloadQuotedImage(q, sock);

        if (!inputBuffer.length) {
            throw new Error('Buffer gambar kosong.');
        }

        if (inputBuffer.length > MAX_UPLOAD_BYTES) {
            throw new Error('Ukuran gambar terlalu besar. Maksimal sekitar 12 MB.');
        }

        const result = await processHitamkan(inputBuffer);

        if (!Buffer.isBuffer(result.buffer) || !result.buffer.length) {
            throw new Error('Output gambar kosong.');
        }

        await sock.sendMessage(m.chat, {
            image: result.buffer,
            caption: `✅ *HITAMKAN SELESAI*

👤 Request: @${m.sender.split('@')[0]}
⚙️ Mode: ${result.mode}
🤖 Engine: BOTCAHX`,
            mentions: [m.sender]
        }, {
            quoted: m
        });

        await m.react('✅').catch(() => {});
    } catch (error) {
        console.error('[HITAMKAN ERROR]', error);
        await m.react('❌').catch(() => {});

        return m.reply(`❌ *Gagal memproses Hitamkan.*

Penyebab:
${error.message || error}

Catatan:
Endpoint BOTCAHX bisa sedang error. Plugin ini sudah memakai retry dan fallback lokal.`);
    }
};

handler.help = ['hitamkan <reply foto>'];
handler.command = ['hitamkan'];
handler.tags = ['tools'];
handler.limit = true;

module.exports = handler;