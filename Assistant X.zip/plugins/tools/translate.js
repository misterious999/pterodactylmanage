const axios = require('axios');

const COMMON_LANGS = {
    auto: 'Auto Detect',

    id: 'Indonesia',
    en: 'English',
    ja: 'Japanese',
    ko: 'Korean',
    zh: 'Chinese Simplified',
    'zh-cn': 'Chinese Simplified',
    'zh-tw': 'Chinese Traditional',
    ar: 'Arabic',
    ms: 'Malay',
    jv: 'Javanese',
    su: 'Sundanese',

    es: 'Spanish',
    fr: 'French',
    de: 'German',
    it: 'Italian',
    pt: 'Portuguese',
    ru: 'Russian',
    tr: 'Turkish',
    hi: 'Hindi',
    th: 'Thai',
    vi: 'Vietnamese',

    nl: 'Dutch',
    pl: 'Polish',
    uk: 'Ukrainian',
    fa: 'Persian',
    ur: 'Urdu',
    bn: 'Bengali',
    ta: 'Tamil',
    te: 'Telugu',
    fil: 'Filipino',
    tl: 'Filipino'
};

const LANG_ALIAS = {
    indo: 'id',
    indonesia: 'id',
    indonesian: 'id',

    inggris: 'en',
    english: 'en',
    en_us: 'en',
    enuk: 'en',

    jepang: 'ja',
    japanese: 'ja',
    japan: 'ja',

    korea: 'ko',
    korean: 'ko',

    china: 'zh-cn',
    chinese: 'zh-cn',
    mandarin: 'zh-cn',
    cina: 'zh-cn',

    arab: 'ar',
    arabic: 'ar',

    melayu: 'ms',
    malay: 'ms',

    jawa: 'jv',
    javanese: 'jv',

    sunda: 'su',
    sundanese: 'su',

    spanyol: 'es',
    spanish: 'es',

    prancis: 'fr',
    french: 'fr',

    jerman: 'de',
    german: 'de',

    itali: 'it',
    italian: 'it',

    portugis: 'pt',
    portuguese: 'pt',

    rusia: 'ru',
    russian: 'ru',

    turki: 'tr',
    turkish: 'tr',

    hindi: 'hi',
    india: 'hi',

    thailand: 'th',
    thai: 'th',

    vietnam: 'vi',
    vietnamese: 'vi',

    belanda: 'nl',
    dutch: 'nl'
};

function cleanText(text = '') {
    return String(text || '')
        .replace(/\u200e|\u200f|\u202a|\u202b|\u202c/g, '')
        .trim();
}

function normalizeLang(lang = '') {
    const clean = cleanText(lang)
        .toLowerCase()
        .replace(/[^a-z0-9-_]/g, '');

    return LANG_ALIAS[clean] || clean;
}

function getLangName(code = '') {
    const normalized = normalizeLang(code);
    return COMMON_LANGS[normalized] || normalized.toUpperCase();
}

function limitText(text = '', max = 3500) {
    const clean = cleanText(text);

    if (clean.length <= max) return clean;

    return clean.slice(0, max).trim();
}

function parseArgs(input = '', quotedText = '') {
    let raw = cleanText(input);

    if (!raw && quotedText) {
        return {
            from: 'auto',
            to: 'id',
            text: cleanText(quotedText)
        };
    }

    const first = raw.split(/\s+/)[0] || '';
    const rest = raw.split(/\s+/).slice(1).join(' ').trim();

    // Format: .tr id teks
    // Format: .tr en hello
    if (first && !first.includes('|') && !first.includes('>') && rest) {
        return {
            from: 'auto',
            to: normalizeLang(first),
            text: rest
        };
    }

    // Format: .tr en|id hello
    if (first.includes('|') && rest) {
        const [from, to] = first.split('|');

        return {
            from: normalizeLang(from || 'auto'),
            to: normalizeLang(to || 'id'),
            text: rest
        };
    }

    // Format: .tr en>id hello
    if (first.includes('>') && rest) {
        const [from, to] = first.split('>');

        return {
            from: normalizeLang(from || 'auto'),
            to: normalizeLang(to || 'id'),
            text: rest
        };
    }

    // Kalau reply teks: .tr id
    if (first && quotedText && !rest) {
        return {
            from: 'auto',
            to: normalizeLang(first),
            text: cleanText(quotedText)
        };
    }

    return {
        from: 'auto',
        to: 'id',
        text: raw
    };
}

function extractQuotedText(m) {
    const q = m.quoted;

    if (!q) return '';

    return cleanText(
        q.text ||
        q.caption ||
        q.body ||
        q.message?.conversation ||
        q.message?.extendedTextMessage?.text ||
        ''
    );
}

function isValidTargetLang(lang = '') {
    const code = normalizeLang(lang);

    if (!code) return false;
    if (code === 'auto') return false;
    if (/^[a-z]{2,3}(-[a-z]{2})?$/i.test(code)) return true;

    return false;
}

function makeLangList() {
    const rows = Object.entries(COMMON_LANGS)
        .filter(([code]) => code !== 'auto')
        .map(([code, name]) => `│ ${code.padEnd(6)} = ${name}`)
        .join('\n');

    return `╭──「 *🌐 KODE BAHASA* 」
${rows}
╰────────────

Contoh:
.tr en aku suka kamu
.tr id I love coding
.tr en|id I am hungry
.tr auto>ja selamat pagi`;
}

async function translateGoogleGTX(text, from = 'auto', to = 'id') {
    const response = await axios.get('https://translate.googleapis.com/translate_a/single', {
        timeout: 30000,
        params: {
            client: 'gtx',
            sl: from || 'auto',
            tl: to,
            dt: 't',
            q: text
        },
        headers: {
            'User-Agent': 'Mozilla/5.0'
        },
        validateStatus: () => true
    });

    if (response.status >= 400) {
        throw new Error(`Google GTX HTTP ${response.status}`);
    }

    const data = response.data;

    if (!Array.isArray(data) || !Array.isArray(data[0])) {
        throw new Error('Response Google GTX tidak valid.');
    }

    const translated = data[0]
        .map(item => Array.isArray(item) ? item[0] : '')
        .join('')
        .trim();

    const detected = data[2] || from || 'auto';

    if (!translated) {
        throw new Error('Hasil translate Google GTX kosong.');
    }

    return {
        translated,
        detected,
        source: 'Google GTX'
    };
}

async function translateMyMemory(text, from = 'auto', to = 'id') {
    if (from === 'auto') {
        throw new Error('MyMemory butuh source language, tidak mendukung auto dengan stabil.');
    }

    const response = await axios.get('https://api.mymemory.translated.net/get', {
        timeout: 30000,
        params: {
            q: text,
            langpair: `${from}|${to}`,
            de: process.env.TRANSLATE_EMAIL || undefined
        },
        headers: {
            'User-Agent': 'Mozilla/5.0'
        },
        validateStatus: () => true
    });

    if (response.status >= 400) {
        throw new Error(`MyMemory HTTP ${response.status}`);
    }

    const translated = response.data?.responseData?.translatedText;

    if (!translated) {
        throw new Error(response.data?.responseDetails || 'Hasil translate MyMemory kosong.');
    }

    return {
        translated: cleanText(translated),
        detected: from,
        source: 'MyMemory'
    };
}

async function translateLibre(text, from = 'auto', to = 'id') {
    const baseUrl = cleanText(process.env.LIBRETRANSLATE_URL || global.libreTranslateUrl || '');

    if (!baseUrl) {
        throw new Error('LIBRETRANSLATE_URL belum diatur.');
    }

    const apiKey = process.env.LIBRETRANSLATE_API_KEY || global.libreTranslateKey || '';

    const url = `${baseUrl.replace(/\/$/, '')}/translate`;

    const payload = {
        q: text,
        source: from || 'auto',
        target: to,
        format: 'text'
    };

    if (apiKey) {
        payload.api_key = apiKey;
    }

    const response = await axios.post(url, payload, {
        timeout: 30000,
        headers: {
            'Content-Type': 'application/json',
            'User-Agent': 'Mozilla/5.0'
        },
        validateStatus: () => true
    });

    if (response.status >= 400) {
        throw new Error(`LibreTranslate HTTP ${response.status}`);
    }

    const translated = response.data?.translatedText;

    if (!translated) {
        throw new Error('Hasil translate LibreTranslate kosong.');
    }

    return {
        translated: cleanText(translated),
        detected: from,
        source: 'LibreTranslate'
    };
}

async function translateText(text, from = 'auto', to = 'id') {
    const errors = [];

    // 1. Google GTX utama
    try {
        return await translateGoogleGTX(text, from, to);
    } catch (error) {
        errors.push(`Google GTX: ${error.message}`);
    }

    // 2. MyMemory fallback, hanya kalau source bukan auto
    try {
        return await translateMyMemory(text, from, to);
    } catch (error) {
        errors.push(`MyMemory: ${error.message}`);
    }

    // 3. LibreTranslate opsional
    try {
        return await translateLibre(text, from, to);
    } catch (error) {
        errors.push(`LibreTranslate: ${error.message}`);
    }

    throw new Error(errors.join('\n'));
}

function makeResultCard({ original, translated, from, to, detected, source }) {
    const fromName = from === 'auto'
        ? `Auto Detect${detected && detected !== 'auto' ? ` (${getLangName(detected)})` : ''}`
        : getLangName(from);

    const toName = getLangName(to);

    return `╭──「 *🌐 TRANSLATE* 」
│ 🔎 *Dari:* ${fromName}
│ 🎯 *Ke:* ${toName}
│ 🔌 *Source:* ${source}
├─「 *TEKS ASLI* 」
│ ${original.replace(/\n/g, '\n│ ')}
├─「 *HASIL* 」
│ ${translated.replace(/\n/g, '\n│ ')}
╰────────────`;
}

let handler = async (m, { text, args, prefix, command }) => {
    const input = cleanText(text || (args || []).join(' '));
    const quotedText = extractQuotedText(m);
    const cmd = String(command || '').toLowerCase();

    if (input.toLowerCase() === 'list' || cmd === 'listlang' || cmd === 'bahasa') {
        return m.reply(makeLangList());
    }

    const parsed = parseArgs(input, quotedText);

    if (!parsed.text) {
        return m.reply(`❌ *Masukkan teks yang mau diterjemahkan.*

Contoh:
${prefix}${command} en aku mau makan
${prefix}${command} id I want to eat
${prefix}${command} en|id I want to eat
${prefix}${command} auto>ja selamat pagi

Lihat kode bahasa:
${prefix}${command} list`);
    }

    if (!isValidTargetLang(parsed.to)) {
        return m.reply(`❌ Kode bahasa tujuan tidak valid: *${parsed.to}*

Cek kode:
${prefix}${command} list`);
    }

    const original = limitText(parsed.text, 3500);

    if (original.length < parsed.text.length) {
        await m.reply('⚠️ Teks terlalu panjang, hanya 3500 karakter pertama yang diterjemahkan.');
    }

    await m.react('⏳').catch(() => {});

    try {
        const result = await translateText(original, parsed.from, parsed.to);

        const card = makeResultCard({
            original,
            translated: result.translated,
            from: parsed.from,
            to: parsed.to,
            detected: result.detected,
            source: result.source
        });

        await m.react('✅').catch(() => {});
        return m.reply(card);
    } catch (error) {
        console.error('[TRANSLATE ERROR]', error);

        await m.react('❌').catch(() => {});

        return m.reply(`❌ *Gagal menerjemahkan teks.*

Detail:
${error.message || error}

Coba format source manual:
${prefix}${command} en|id I want to eat`);
    }
};

handler.command = ['translate', 'tr', 'terjemah', 'listlang', 'bahasa'];
handler.tags = ['tools'];
handler.help = [
    'tr <kode bahasa> <teks>',
    'tr <dari>|<ke> <teks>',
    'translate list'
];
handler.limit = true;

module.exports = handler;