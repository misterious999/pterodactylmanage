const axios = require('axios');

// ==========================================
// 🎭 VIP EMOJI MIXER (DEEP NESTING EXTRACTOR)
// ==========================================

let handler = async (m, { sock, prefix, command, text }) => {
    let apiKey = global.btc;

    if (!apiKey) {
        await m.react("⚠️").catch(() => {});
        return m.reply("❌ *Sistem Terkunci!*\nBOTCAHX_APIKEY belum diatur di file `.env`.");
    }

    if (!text) {
        await m.react("⚠️").catch(() => {});
        return m.reply(`❌ *Format Salah!*\n\nContoh Penggunaan:\n> \`${prefix + command} 😭 😁\``);
    }

    // ✂️ MESIN PEMISAH EMOJI (Anti Siluman)
    let txtBersih = text.replace(/[a-zA-Z0-9\s+&|/\\_]/g, '');
    let emojis = Array.from(txtBersih).filter(v => v !== '\uFE0F' && v !== '\uFE0E');

    if (emojis.length < 2) {
         await m.react("❌").catch(() => {});
         return m.reply(`❌ *Emoji Tidak Terbaca!*\nPastikan memasukkan minimal 2 emoji yang jelas.\nContoh: \`${prefix + command} 🥵 🥶\``);
    }

    let emoji1 = emojis[0];
    let emoji2 = emojis[1];

    await m.react("⏳").catch(() => {});

    try {
        const fetchEmojimix = async (e1, e2) => {
            return await axios.get(global.botcahxUrl('/api/emoji/emojimix', { emoji1: e1, emoji2: e2 }), {
                responseType: 'arraybuffer',
                validateStatus: () => true,
                timeout: 60000 
            });
        };

        // 🚀 Tembakan Pertama (Normal: A + B)
        let res = await fetchEmojimix(emoji1, emoji2);
        let isError = false;

        if (String(res.headers['content-type']).includes('application/json')) {
            let jsonCheck = JSON.parse(Buffer.from(res.data).toString('utf-8'));
            if (jsonCheck.status === false) isError = true;
        } else if (res.status !== 200) {
            isError = true;
        }

        // 🔄 AUTO-SWAP: Jika ditolak, putar balik posisinya (B + A)!
        if (isError) {
            console.log("🔄 [EMOJIMIX] Mencoba kombinasi terbalik...");
            res = await fetchEmojimix(emoji2, emoji1);
        }

        let contentType = String(res.headers['content-type'] || '').toLowerCase();
        let stickerBuffer;

        // 🧠 Eksekusi Hasil Akhir
        if (contentType.includes('application/json')) {
            let jsonText = Buffer.from(res.data).toString('utf-8');
            let json = JSON.parse(jsonText);
            
            let resultUrl = null;
            
            // 🔓 PEMBONGKAR BRANKAS BERLAPIS (DEEP NESTING)
            if (json.status === true) {
                // Skenario 1: Kalau BOTCAHX nyembunyiin di dalam array "results" (Seperti di screenshot)
                if (json.result && Array.isArray(json.result.results) && json.result.results.length > 0) {
                    let item = json.result.results[0];
                    // Cek url mentah, kalau ga ada baru masuk ke media_formats
                    resultUrl = item.url || item.media_formats?.png_transparent?.url;
                } 
                // Skenario 2: Kalau format standar
                else if (json.result && json.result.url) {
                    resultUrl = json.result.url;
                } 
                else if (json.url) {
                    resultUrl = json.url;
                } 
                else if (typeof json.result === 'string') {
                    resultUrl = json.result;
                }
            }

            // Jika URL ketemu dan valid, download gambarnya!
            if (resultUrl && resultUrl.startsWith('http')) {
                let fetchImg = await axios.get(resultUrl, { responseType: 'arraybuffer' });
                stickerBuffer = Buffer.from(fetchImg.data);
            } else {
                // Jika beneran error dari API
                let alasanAsli = json.message || json.error || "Kombinasi ini belum didukung atau format API BOTCAHX berubah.";
                throw new Error(`*Alasan Server:* ${alasanAsli}`);
            }
        } 
        else if (res.status === 200) {
            // Kalau API langsung lempar gambar mentah (Bonus!)
            stickerBuffer = Buffer.from(res.data);
        } else {
            throw new Error(`Server BOTCAHX gagal merespon. (Kode: ${res.status})`);
        }

        await m.react("✅").catch(() => {});

        let packnameVIP = global.packname || "Assistant X";
        let authorVIP = m.sender.split('@')[0] || "Emoji Mixer";

        await sock.sendSticker(m.chat, stickerBuffer, m, { 
            packname: packnameVIP, 
            author: authorVIP 
        });

    } catch (err) {
        console.error("🔴 [EMOJIMIX ERROR]:", err.message || err);
        await m.react("❌").catch(() => {});
        return m.reply(`❌ *GAGAL MEMBUAT EMOJI!*\n\n${err.message || err}`);
    }
}

handler.command = ["emojimix"];
handler.tags = ["tools"];
handler.help = ["emojimix <emoji1> <emoji2>"];
handler.limit = true; 

module.exports = handler;
