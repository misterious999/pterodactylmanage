// ==========================================
// 🪄 FITUR REMOVE BACKGROUND (BOTCAHX API)
// 🔄 AUTO-POLLING & CATBOX.MOE UPLOADER
// ==========================================

const { downloadContentFromMessage } = require("@whiskeysockets/baileys");
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const os = require('os');
const FormData = require('form-data');

let handler = async (m, { sock, prefix, command }) => {
    let user = global.db.users[m.sender];
    if (!user) return m.reply("❌ Kamu belum terdaftar di database bot!");

    // ==========================================
    // 🔑 PENGECEKAN LIMIT (-1 Limit)
    // ==========================================
    let costLimit = 1;
    if (user.limit < costLimit) {
        return m.reply(`💸 Limit kamu tidak cukup!\nKamu butuh *${costLimit} Limit* untuk fitur ini.`);
    }

    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';

    if (!mime.startsWith('image/')) {
        let usage = `╭───┈ *「 🪄 REMOVE BACKGROUND 」*\n`;
        usage += `│ Kirim atau balas sebuah gambar dengan perintah:\n`;
        usage += `│ *${prefix}${command}*\n`;
        usage += `╰───────────────┈ ⳹`;
        return m.reply(usage);
    }

    await m.react("⏳");

    try {
        let apikey = global.btc || global.apikey;
        if (!apikey) throw new Error("API Key BOTCAHX belum diatur di config.js");

        // 1. Download Gambar dari WA
        let mediaType = mime.split('/')[0];
        let stream = await downloadContentFromMessage(q.msg || q, mediaType);
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }

        // 2. 🚀 UPLOAD SEMENTARA KE CATBOX.MOE (SANG RAJA UPLOADER)
        let tmpFile = path.join(os.tmpdir(), `rmbg_${Date.now()}.png`);
        fs.writeFileSync(tmpFile, buffer);

        let form = new FormData();
        form.append('reqtype', 'fileupload');
        form.append('fileToUpload', fs.createReadStream(tmpFile));
        
        let upRes = await axios.post('https://catbox.moe/user/api.php', form, { headers: form.getHeaders() });
        let imageUrl = upRes.data; // Catbox mereturn langsung URL gambarnya dalam bentuk string
        
        fs.unlinkSync(tmpFile); // Bersihkan file sampah dari VPS

        // Validasi kalau upload ke Catbox gagal
        if (!imageUrl || !imageUrl.startsWith('http')) {
            throw new Error('Gagal mengupload gambar ke server Catbox.');
        }

        // ==========================================
        // 🚀 PROSES REMOVE BG LEWAT BOTCAHX
        // ==========================================
        let MediaBuffer = null;
        let processRes = await axios.get(global.botcahxUrl('/api/tools/removebg', { url: imageUrl }), {
            responseType: 'arraybuffer',
            timeout: 90000,
            validateStatus: () => true
        });

        let processType = String(processRes.headers['content-type'] || '').toLowerCase();

        if (processType.includes('image')) {
            MediaBuffer = Buffer.from(processRes.data);
        } else {
            let jsonText = Buffer.from(processRes.data).toString('utf-8');
            let data = JSON.parse(jsonText);
            let result = data?.result || data?.data || data;
            let finalValue = '';

            if (typeof result === 'string') finalValue = result;
            else if (result && typeof result === 'object') finalValue = result.url || result.image || result.base64 || result.output;

            if (!finalValue) throw new Error(data?.message || data?.error || 'BOTCAHX tidak mengembalikan hasil RemoveBG.');

            if (String(finalValue).startsWith('http')) {
                let finalRes = await axios.get(finalValue, { responseType: 'arraybuffer', timeout: 60000 });
                MediaBuffer = Buffer.from(finalRes.data);
            } else {
                finalValue = String(finalValue).replace(/^data:image\/\w+;base64,/, '');
                MediaBuffer = Buffer.from(finalValue, 'base64');
            }
        }

        let caption = `╭───┈ *「 🪄 REMOVE BACKGROUND 」*\n`;
        caption += `│ ✅ *Proses Selesai!*\n`;
        caption += `│ 💸 Limit Terpotong: ${costLimit}\n`;
        caption += `╰───────────────┈ ⳹`;

        await sock.sendMessage(m.chat, { image: MediaBuffer, caption: caption }, { quoted: m });

        // Potong Limit & Notif
        user.limit -= costLimit;
        await sock.sendMessage(m.chat, { text: `💸 Limitmu berkurang *${costLimit}*` }, { quoted: m });
        await m.react("✅");

    } catch (error) {
        console.error("[RMBG ERROR]", error.response?.data || error.message);
        await m.react("❌");
        let errMsg = error.response?.data?.message || error.response?.data?.error || error.message || "Terjadi kesalahan sistem.";
        m.reply(`❌ *GAGAL MEMPROSES GAMBAR!*\nDetail: ${errMsg}`);
    }
}

handler.command = ["rmbg", "removebg", "nobg"];
handler.tags = ["tools"];
handler.help = ["rmbg <reply image>"];

module.exports = handler;
