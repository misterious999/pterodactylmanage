// ==========================================
// BRAT GENERATOR (BOTCAHX API)
// INDEPENDENT PLUGIN + NOTIFIKASI LIMIT
// ==========================================

const axios = require('axios');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const ffmpeg = require('fluent-ffmpeg');

async function createSticker(buffer, isVideo) {
    const tmpIn = path.join(os.tmpdir(), crypto.randomBytes(5).toString('hex') + (isVideo ? '.mp4' : '.png'));
    const tmpOut = path.join(os.tmpdir(), crypto.randomBytes(5).toString('hex') + '.webp');

    fs.writeFileSync(tmpIn, buffer);

    await new Promise((resolve, reject) => {
        let ff = ffmpeg(tmpIn)
            .on('error', reject)
            .on('end', () => resolve(true))
            .addOutputOptions([
                "-vcodec", "libwebp",
                "-vf", "scale='min(512,iw)':min'(512,ih)':force_original_aspect_ratio=decrease,fps=15, pad=512:512:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse"
            ])
            .toFormat('webp');

        if (isVideo) {
            ff.addOutputOptions([
                "-loop", "0",
                "-ss", "00:00:00",
                "-t", "00:00:05",
                "-preset", "default",
                "-an",
                "-vsync", "0"
            ]);
        }
        ff.save(tmpOut);
    });

    const webpBuffer = fs.readFileSync(tmpOut);
    fs.unlinkSync(tmpIn);
    fs.unlinkSync(tmpOut);
    return webpBuffer;
}

let handler = async (m, { sock, text, prefix, command }) => {
    let user = global.db.users[m.sender];
    if (!user) return m.reply("[ SYSTEM ] Akun tidak terdaftar di database.");

    let apikey = global.btc;
    if (!apikey) return m.reply("[ SYSTEM ] BOTCAHX_APIKEY belum dikonfigurasi pada environment.");

    let finalTeks = text || (m.quoted && m.quoted.text ? m.quoted.text : null);

    let isVid = command === 'bratvid';
    let isCustom = command === 'bratcustom' || command === 'bratcostum';
    let costLimit = isVid ? 2 : 1;

    if (!finalTeks) {
        let usage = `[ BRAT GENERATOR CONFIGURATION ]\n\n`;
        usage += `◦ ${prefix}brat <teks> (Normal | -1 Limit)\n`;
        usage += `◦ ${prefix}brat2 <teks> (Versi 2 | -1 Limit)\n`;
        usage += `◦ ${prefix}bratvid <tema>|<teks> (Video | -2 Limit)\n`;
        usage += `◦ ${prefix}bratcustom <warnateks>|<warnabg>|<teks> (Custom | -1 Limit)\n\n`;
        usage += `[ AVAILABLE THEMES FOR BRATVID ]\n`;
        usage += `- green\n- white\n- black\n\n`;
        usage += `Contoh Penggunaan:\n${prefix}bratvid green|System Online`;
        return m.reply(usage);
    }

    if (user.limit < costLimit) {
        return m.reply(`[ SYSTEM ] Limit tidak mencukupi. Dibutuhkan ${costLimit} limit. (Sisa limit: ${user.limit})`);
    }

    await m.react("⏳");

    try {
        let apiUrl = '';
        let params = {};

        if (isCustom) {
            let parts = finalTeks.split("|");
            if (parts.length < 3) {
                await m.react("❌");
                return m.reply(`[ SYSTEM ] Format invalid. Contoh: ${prefix}bratcustom merah|putih|Teks Kamu`);
            }
            
            let textColorInput = parts[0].trim();
            let bgColorInput = parts[1].trim();
            let fixText = parts.slice(2).join("|").trim();

            const basicColors = {
                merah: "ff0000", biru: "0000ff", hijau: "008000", kuning: "ffff00", hitam: "000000", 
                putih: "ffffff", ungu: "800080", oranye: "ffa500", abuabu: "808080", coklat: "8b4513", 
                merahmuda: "ffc0cb", birutua: "00008b", birumuda: "87ceeb", hijautua: "006400", hijaumuda: "90ee90", 
                emas: "ffd700", perak: "c0c0c0", cyan: "00ffff", magenta: "ff00ff"
            };

            let textColor = basicColors[textColorInput.toLowerCase()] || textColorInput;
            let bgColor = basicColors[bgColorInput.toLowerCase()] || bgColorInput;

            params = { text: fixText, textColor, bgColor };
            apiUrl = global.botcahxUrl('/api/maker/brat', params);

        } else if (command === 'brat2') {
            params = { text: finalTeks.trim() };
            apiUrl = global.botcahxUrl('/api/maker/brat2', params);

        } else if (isVid) {
            let parts = finalTeks.split("|");
            if (parts.length < 2) {
                await m.react("❌");
                let usageVid = `[ SYSTEM ] Format invalid.\n\nGunakan format: ${prefix}bratvid <tema>|<teks>\n\n`;
                usageVid += `[ AVAILABLE THEMES ]\n- green\n- white\n- black\n\n`;
                usageVid += `Contoh: ${prefix}bratvid green|System Online`;
                return m.reply(usageVid);
            }

            let selectedTheme = parts[0].trim().toLowerCase();
            let actualText = parts.slice(1).join("|").trim();

            let validThemes = ['green', 'white', 'black'];
            if (!validThemes.includes(selectedTheme)) {
                await m.react("❌");
                return m.reply(`[ SYSTEM ] Tema "${selectedTheme}" tidak tersedia.\nPilih dari: green, white, black.`);
            }

            params = { text: actualText, theme: selectedTheme, format: 'mp4' };
            apiUrl = global.botcahxUrl('/api/maker/canvas-bratvid', params);

        } else {
            params = { text: finalTeks.trim() };
            apiUrl = global.botcahxUrl('/api/maker/brat', params);
        }

        let response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
        let rawBuffer = Buffer.from(response.data, 'binary');

        let stickerBuffer = await createSticker(rawBuffer, isVid);

        await sock.sendMessage(m.chat, { text: `[ SYSTEM ] Limit dikurangi: ${costLimit}` }, { quoted: m });
        await sock.sendMessage(m.chat, { sticker: stickerBuffer }, { quoted: m });

        user.limit -= costLimit;
        await m.react("✅");

    } catch (error) {
        console.error("[BRAT ERROR]", error);
        await m.react("❌");
        m.reply("[ SYSTEM ] Proses gagal. API sedang sibuk atau konfigurasi salah.");
    }
}

handler.command = ["brat", "brat2", "bratvid", "bratcustom", "bratcostum"];
handler.tags = ["tools"];
handler.help = ["brat <teks>"];

module.exports = handler;
