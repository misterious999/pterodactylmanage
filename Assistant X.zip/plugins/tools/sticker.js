const fs = require("fs");
const path = require("path");
const { tmpdir } = require("os");
const Crypto = require("crypto");
const ff = require("fluent-ffmpeg");
const webp = require("node-webpmux");

// 🛠️ Fungsi Penunda Waktu untuk Animasi
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// ==========================================
// 🚀 ENGINE SCRAPER MANDIRI (INDEPENDENT)
// ==========================================
async function convertToWebp(mediaPath, isVideo) {
    const tmpFileOut = path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`);

    await new Promise((resolve, reject) => {
        let process = ff(mediaPath)
            .on("error", reject)
            .on("end", () => resolve(true))
            .addOutputOptions([
                "-vcodec", "libwebp",
                "-vf", "scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15,pad=320:320:-1:-1:color=white@0.0,split[a][b];[a]palettegen=reserve_transparent=on:transparency_color=ffffff[p];[b][p]paletteuse"
            ]);
        
        if (isVideo) {
            process.addOutputOptions(["-loop", "0", "-ss", "00:00:00", "-t", "00:00:07", "-preset", "default", "-an", "-vsync", "0"]);
        }

        process.toFormat("webp").save(tmpFileOut);
    });

    const buff = fs.readFileSync(tmpFileOut);
    if (fs.existsSync(tmpFileOut)) fs.unlinkSync(tmpFileOut);
    return buff;
}

async function addExif(webpSticker, packname, author) {
    const img = new webp.Image();
    const json = { 'sticker-pack-id': Crypto.randomBytes(32).toString('hex'), 'sticker-pack-name': packname, 'sticker-pack-publisher': author };
    let exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00]);
    let jsonBuffer = Buffer.from(JSON.stringify(json), 'utf8');
    let exif = Buffer.concat([exifAttr, jsonBuffer]);
    exif.writeUIntLE(jsonBuffer.length, 14, 4);
    await img.load(webpSticker);
    img.exif = exif;
    return await img.save(null);
}

// ==========================================
// 🎯 MAIN HANDLER
// ==========================================
let handler = async (m, { sock }) => {
  try {
    // 🔥 VAKSIN ANTI ENOENT: Pastikan folder tmp lokal tersedia untuk Baileys
    if (!fs.existsSync('./tmp')) {
        fs.mkdirSync('./tmp', { recursive: true });
    }

    let qmsg = m.quoted ? m.quoted : m;
    let mime = (qmsg.msg || qmsg).mimetype || m.mime || "";

    if (!/image|video/.test(mime)) {
      await m.react("⚠️");
      return m.replyPremium("❌ Kirim atau balas foto/video dengan pesan `.s`");
    }

    if (/video/.test(mime) && (qmsg.msg || qmsg).seconds > 15) {
      await m.react("⚠️");
      return m.replyPremium("❌ Durasi video maksimal 15 detik untuk dijadikan stiker!");
    }

    // Animasi 1
    await m.react("⚙️");
    let { key } = await sock.sendMessage(m.chat, { text: "🔄 *Menginisialisasi Mesin...*\n\n[░░░░░░░░░░] 0%" }, { quoted: m });

    // Animasi 2
    await sleep(300);
    await sock.sendMessage(m.chat, { text: "📥 *Mengunduh Media...*\n\n[████░░░░░░] 40%", edit: key });
    
    // Download media pakai metode klasik (Aman)
    let mediaPath = await sock.downloadAndSaveMediaMessage(qmsg);

    // Animasi 3
    await sleep(300);
    await sock.sendMessage(m.chat, { text: "⚙️ *Memproses Exif & Menembakkan Stiker...*\n\n[████████░░] 80%", edit: key });

    // Eksekusi Konversi Mandiri (TANPA mengandalkan fungsi Base!)
    let isVideo = /video/.test(mime);
    let webpBuffer = await convertToWebp(mediaPath, isVideo);
    let finalSticker = await addExif(webpBuffer, "Assistant X Project", global.ownername || "PSTAR7");

    // Tembak Stiker Langsung
    await sock.sendMessage(m.chat, { sticker: finalSticker }, { quoted: m });

    // Animasi Akhir
    await sock.sendMessage(m.chat, { text: "✅ *Stiker Berhasil Dibuat!*\n\n[██████████] 100%", edit: key });
    await m.react("✅");

    // Bersihkan file mentah dari VPS
    if (fs.existsSync(mediaPath)) fs.unlinkSync(mediaPath);

  } catch (error) {
    console.error("[ERROR STICKER]", error);
    await m.react("❌");
    m.replyPremium(`❌ *Proses Gagal!*\n\n📝 _Log:_ ${error.message}`);
  }
}

handler.help = ["sticker"];
handler.command = ["s", "stiker", "sgif"];
handler.tags = ["tools"];

module.exports = handler;
