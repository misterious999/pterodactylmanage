const { generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

// ==========================================
// 🔍 GROUP ID EXTRACTOR (SMART NAME RESOLVER & UI)
// ⚙️ Ciptaan Pstar7 | Melacak Username Pembuat Grup
// ==========================================

let handler = async (m, { sock, args, prefix, command }) => {
    // 1. Validasi Input
    if (!args[0]) {
        return m.reply(`❌ *Mana link grupnya Bosku?*\n\nContoh Penggunaan:\n> \`${prefix + command} https://chat.whatsapp.com/KxYZ...123\``);
    }

    let link = args[0];

    // 2. Ekstraksi Kode Undangan
    let codeMatch = link.match(/chat\.whatsapp\.com\/([0-9A-Za-z]{10,30})/i);
    
    if (!codeMatch) {
        await m.react("❌").catch(() => {});
        return m.reply("❌ *Link Tidak Valid!*\nPastikan link yang kamu kirim adalah link undangan grup WhatsApp yang benar.");
    }

    let inviteCode = codeMatch[1];
    await m.react("⏳").catch(() => {});

    try {
        // 3. Menembak API Baileys untuk melihat metadata grup
        let res = await sock.groupGetInviteInfo(inviteCode);

        // 4. SMART NAME RESOLVER (Mencari Username Pembuat)
        let ownerJid = res.owner || res.creator;
        let pembuatTxt = "Tidak diketahui";
        let mentions = [];

        if (ownerJid) {
            mentions.push(ownerJid);
            let num = ownerJid.split('@')[0];
            let pushname = "";

            // Deteksi di Database Global Bot
            if (global.db && global.db.users && global.db.users[ownerJid] && global.db.users[ownerJid].name) {
                pushname = global.db.users[ownerJid].name;
            } 
            // Deteksi di Cache Kontak Baileys
            else if (sock.contacts && sock.contacts[ownerJid]) {
                pushname = sock.contacts[ownerJid].name || sock.contacts[ownerJid].notify;
            }

            if (pushname) {
                pembuatTxt = `*${pushname}* (@${num})`;
            } else {
                // Samarkan jika WhatsApp memblokir namanya (Privasi)
                pembuatTxt = `*User Pribadi* (@${num})`;
            }
        }

        // 5. Merakit Laporan Eksekutif
        let teksHasil = `╭──「 *🔍 RADAR GRUP* 」\n`;
        teksHasil += `│ 🏷️ *Nama Grup:* ${res.subject}\n`;
        teksHasil += `│ 🆔 *ID Grup:* \`${res.id}\`\n`;
        
        if (ownerJid) {
            teksHasil += `│ 👑 *Pembuat:* ${pembuatTxt}\n`;
        }
        
        let desc = res.desc ? res.desc.toString() : "Tidak ada deskripsi.";
        if (desc.length > 100) desc = desc.substring(0, 100) + "..."; 
        
        teksHasil += `│ 📝 *Deskripsi:* ${desc}\n`;
        teksHasil += `╰────────────\n\n`;
        teksHasil += `_Pilih aksi cepat melalui tombol interaktif di bawah ini!_ 🚀`;

        // 6. Merakit UI Interactive Buttons
        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text: teksHasil }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: "© Assistant X Project 📡" }),
                        header: proto.Message.InteractiveMessage.Header.create({ title: "", hasMediaAttachment: false }),
                        contextInfo: {
                            mentionedJid: mentions,
                            forwardingScore: 999,
                            isForwarded: true
                        },
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                {
                                    name: "cta_copy",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "📋 Salin ID Grup",
                                        id: "copy_id",
                                        copy_code: res.id
                                    })
                                },
                                {
                                    name: "cta_url",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "🔗 Join Group",
                                        url: `https://chat.whatsapp.com/${inviteCode}`
                                    })
                                }
                            ]
                        })
                    })
                }
            }
        }, { quoted: m });

        // 7. Kirim Pesan Interaktif
        await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await m.react("✅").catch(() => {});

    } catch (e) {
        console.error("[ERROR CEK ID GC]", e.message);
        await m.react("❌").catch(() => {});
        
        let errMsg = `❌ *Gagal Mendapatkan Info Grup!*\n\n`;
        errMsg += `Kemungkinan penyebab:\n`;
        errMsg += `1. Link undangan sudah **dibatalkan/di-reset** oleh admin grup.\n`;
        errMsg += `2. Nomor bot sudah di-kick/diblokir dari grup tersebut.\n\n`;
        errMsg += `_Pesan Sistem: ${e.message}_`;
        
        m.reply(errMsg);
    }
}

handler.command = ['cekidgc', 'idgc'];
handler.tags = ['tools'];
handler.help = ['cekidgc <link>'];

module.exports = handler;
