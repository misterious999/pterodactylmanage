const axios = require('axios');
const FormData = require('form-data');

// ==========================================
// 🖼️ STICKER MEME - MEMEGEN ENGINE (BEBAS API KEY)
// ==========================================

// Fungsi upload bawaan (menggantikan ../lib/uploadImage)
async function uploadToCloud(buffer) {
    try {
        const form = new FormData();
        form.append('files[]', buffer, 'image.jpg');
        const { data } = await axios.post('https://uguu.se/upload.php', form, {
            headers: form.getHeaders()
        });
        return data.files[0].url;
    } catch (err1) {
        try {
            const form2 = new FormData();
            form2.append('files[]', buffer, 'image.jpg');
            const { data } = await axios.post('https://pomf.lain.la/upload.php', form2, {
                headers: form2.getHeaders()
            });
            return data.files[0].url;
        } catch (err2) {
            throw new Error("Semua server uploader sedang mati!");
        }
    }
}

let handler = async (m, { sock, text, prefix, command }) => {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || q.mediaType || '';

    if (!mime.includes('image')) {
        await m.react("❌").catch(() => {});
        return m.reply(`❌ *Media Tidak Ditemukan!*\nKirim/reply foto dengan perintah:\n> \`${prefix + command} teks atas | teks bawah\``);
    }

    if (!text) {
        await m.react("❌").catch(() => {});
        return m.reply(`❌ *Teks Kosong!*\nContoh: \`${prefix + command} Halo | Semua\``);
    }

    await m.react("⏳").catch(() => {});

    try {
        let [atas, bawah] = text.split('|');
        
        // Memegen butuh karakter '_' jika salah satu teks dikosongkan
        let textAtas = atas && atas.trim() !== '' ? encodeURIComponent(atas.trim()) : '_';
        let textBawah = bawah && bawah.trim() !== '' ? encodeURIComponent(bawah.trim()) : '_';

        // 1. Download gambar dari WA
        let mediaBuffer = await sock.downloadMediaMessage(q, 'image');
        if (!mediaBuffer) throw new Error("Gagal mengunduh gambar dari WhatsApp.");

        // 2. Upload gambar ke Cloud
        let url = await uploadToCloud(mediaBuffer);
        console.log(`[+] SMEME: Gambar dihosting ke -> ${url}`);

        // 3. Rakit link API Memegen
        let memeUrl = `https://api.memegen.link/images/custom/${textAtas}/${textBawah}.png?background=${url}`;

        // 4. Unduh hasil gambar meme menjadi buffer
        let { data: stickerBuffer } = await axios.get(memeUrl, { responseType: 'arraybuffer' });

        // 5. Kirim sebagai stiker pakai fungsi bawaan bot bosku
        let packnameVIP = global.packname || "Assistant X";
        let authorVIP = m.sender.split('@')[0] || "Meme Gen";

        await sock.sendSticker(m.chat, Buffer.from(stickerBuffer), m, { 
            packname: packnameVIP, 
            author: authorVIP 
        });

        await m.react("✅").catch(() => {});

    } catch (err) {
        console.error("🔴 [SMEME ERROR]:", err.message || err);
        await m.react("❌").catch(() => {});
        return m.reply(`❌ *GAGAL MEMPROSES!*\n\nPesan Sistem: ${err.message || err}`);
    }
}

handler.command = ["smeme"];
handler.tags = ["tools"];
handler.help = ["smeme <teks atas>|<teks bawah>"];
handler.limit = true; 

module.exports = handler;
