const { generateWAMessageFromContent } = require("@whiskeysockets/baileys");

let handler = async (m, { sock, args, prefix, command }) => {
  let user = global.db.users[m.sender];
  
  // 1. Memastikan pengguna memang sudah terdaftar
  if (!user || !user.registered) {
    await m.react("⚠️");
    return m.reply(`❌ *Akses Ditolak!*\nBosku belum terdaftar di dalam database Assistant X Project.`);
  }

  // 2. Meminta Serial Number (SN) dengan tampilan rapi
  if (!args[0]) {
    await m.react("❓");
    return m.reply(`*Format Unreg Salah!*\n\nSilakan masukkan Serial Number (SN) Bosku sebagai verifikasi keamanan untuk menghancurkan data.\n\n*Contoh:* \`${prefix + command} ${user.sn}\`\n\n_(Lupa SN? Cek di ${prefix}profile)_`);
  }

  // 3. Memvalidasi SN
  if (args[0] !== user.sn) {
    await m.react("❌");
    return m.reply("❌ *Otorisasi Gagal!*\nSerial Number (SN) yang Bosku masukkan tidak cocok dengan database. Proses penghancuran data dibatalkan.");
  }

  await m.react("⏳");

  // Simpan data lama untuk dikirim ke Log Channel
  let oldName = user.name;
  let oldSn = user.sn;

  // ==========================================
  // 4. PROTOKOL PENGHANCURAN DATA (PURGE)
  // ==========================================
  user.registered = false;
  user.name = "Unknown";
  user.age = 0;
  user.sn = "";
  // Mereset statistik agar tidak di-abuse (dicurangi)
  user.limit = 0; 
  user.balance = 0;
  user.level = 0;
  user.xp = 0;

  await m.react("✅");

  // ==========================================
  // 5. MERAKIT TEKS UI (SYSTEM PURGE)
  // ==========================================
  let teksUser = `🗑️ *D A T A   W I P E D* 🗑️\n\n`;
  teksUser += `Sistem telah menghancurkan seluruh data identitas Anda dari server pusat Assistant X Project.\n\n`;
  
  teksUser += `╭───「 *PURGE LOG* 」\n`;
  teksUser += `│ ◦ 📛 Nama: *${oldName}*\n`;
  teksUser += `│ ◦ 🔑 S/N: \`${oldSn}\`\n`;
  teksUser += `│ ◦ 🗑️ Status: *Permanently Deleted*\n`;
  teksUser += `╰──────────────\n\n`;
  
  teksUser += `_Selamat tinggal, ${oldName}. Tekan tombol di bawah jika Anda berubah pikiran dan ingin mendaftar kembali._ 🚀`;

  // Bingkai Mewah Fmeta (Tema Security)
  const fmeta = {
      key: { participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {}) },
      message: {
          imageMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7118-24/f1/m233/up-video-nd-10... ",
              mimetype: "image/jpeg",
              caption: "System Purge Protocol",
              jpegThumbnail: null
          }
      }
  };

  // Merakit Interactive Message (Tombol Daftar Ulang)
  let msgData = {
      viewOnceMessage: {
          message: {
              messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
              interactiveMessage: {
                  body: { text: teksUser },
                  footer: { text: `© Powered by ${global.ownername || "PSTAR7"}` },
                  nativeFlowMessage: {
                      buttons: [
                          { 
                              name: "quick_reply", 
                              buttonParamsJson: JSON.stringify({ display_text: "📝 Daftar Ulang", id: `${prefix}daftar` }) 
                          }
                      ]
                  },
                  contextInfo: { mentionedJid: [m.sender] }
              }
          }
      }
  };

  // Kirim Balasan Eksekusi ke User
  let msg = generateWAMessageFromContent(m.chat, msgData, { quoted: fmeta });
  await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

  // ==========================================
  // 📢 6. LAPORAN KE SALURAN (LOG UNREG)
  // ==========================================
  if (global.idChannelDaftar) {
      let maskedSN = oldSn.substring(0, 6) + "****"; // Menyensor digit terakhir

      let teksChannel = `🗑️ *S Y S T E M   P U R G E* 🗑️\n\n`;
      teksChannel += `Seorang user telah menghapus identitasnya dari ekosistem Assistant X.\n\n`;
      teksChannel += `╭───「 *DELETED MEMBER* 」\n`;
      teksChannel += `│ ◦ 👤 Nama: *${oldName}*\n`;
      teksChannel += `│ ◦ 🔑 S/N: *${maskedSN}*\n`;
      teksChannel += `╰──────────────\n\n`;
      teksChannel += `Data tersebut telah hangus terbakar dari server. 🔥`;

      try {
          await sock.sendMessage(global.idChannelDaftar, { text: teksChannel });
      } catch (e) {
          console.error("[ERROR BROADCAST UNREG]", e);
      }
  }
}

handler.command = ["unreg"];
handler.tags = ["informasi"];
handler.help = ["unreg <sn>"];

module.exports = handler;
