const crypto = require('crypto');
const { generateWAMessageFromContent } = require("@whiskeysockets/baileys");

// ==========================================
// ⚙️ CORE ENGINE PENDAFTARAN (XENORIA RPG)
// ==========================================
async function prosesPendaftaran(m, sock, user, nama, umur, prefix) {
  await m.react("⏳");

  let sn = crypto.randomBytes(4).toString('hex').toUpperCase(); 
  user.name = nama.trim();
  user.age = umur;
  user.registered = true;
  user.limit = 50;        
  user.balance = 10000;   
  user.level = 1;
  user.xp = 0;
  user.sn = `AXP-${sn}`;  

  const roles = [
      { role: 'Warrior 🗡️', weapon: 'Rusty Sword', hp: 600, mp: 200, atk: 15, def: 20 },
      { role: 'Mage 🪄', weapon: 'Wooden Staff', hp: 400, mp: 600, atk: 25, def: 10 },
      { role: 'Assassin 🥷', weapon: 'Iron Dagger', hp: 450, mp: 300, atk: 30, def: 12 },
      { role: 'Archer 🏹', weapon: 'Hunter Bow', hp: 500, mp: 300, atk: 20, def: 15 },
      { role: 'Necromancer 💀', weapon: 'Bone Wand', hp: 450, mp: 500, atk: 22, def: 12 }
  ];
  
  let chosen = roles[Math.floor(Math.random() * roles.length)];
  
  user.rpg = {
      role: chosen.role,
      weapon: chosen.weapon,
      armor: 'Pakaian Pemula',
      hp: chosen.hp,
      max_hp: chosen.hp,
      mp: chosen.mp,
      max_mp: chosen.mp,
      attack: chosen.atk,
      defense: chosen.def,
      lantai: 1,
      inventory: { potion: 3, wood: 5 }
  };

  await m.react("✅");

  const makeBar = (current, max) => {
      let percentage = Math.min(Math.max(current / max, 0), 1);
      let filled = Math.round(percentage * 10);
      let empty = 10 - filled;
      return "▰".repeat(filled) + "▱".repeat(empty);
  };

  let hpBar = makeBar(user.rpg.hp, user.rpg.max_hp);
  let mpBar = makeBar(user.rpg.mp, user.rpg.max_mp);
  let xpBar = makeBar(user.xp, 100); 
  
  // 🔥 PERBAIKAN JUDUL: Dibuat rapat agar tidak dipotong otomatis oleh WhatsApp
  let teksUser = `✦ *XENORIA INITIATED* ✦\n\n`;
  teksUser += `Takdirmu telah terukir di gerbang dimensi.\n`;
  teksUser += `⬡ *S/N:* \`${user.sn}\`\n\n`;
  
  teksUser += `*STATUS PAHLAWAN*\n`;
  teksUser += `👤 Nama   : ${user.name} (${user.age})\n`;
  teksUser += `🔰 Kelas  : ${user.rpg.role}\n`;
  teksUser += `⚔️ Senjata: ${user.rpg.weapon}\n`;
  teksUser += `🏆 Level  : ${user.level}\n\n`;
  
  teksUser += `*ATTRIBUTES*\n`;
  teksUser += `❤️ HP  [${hpBar}] ${user.rpg.hp}/${user.rpg.max_hp}\n`;
  teksUser += `💙 MP  [${mpBar}] ${user.rpg.mp}/${user.rpg.max_mp}\n`;
  teksUser += `✨ EXP [${xpBar}] ${user.xp}/100\n\n`;
  
  teksUser += `*INVENTORY*\n`;
  teksUser += `🪙 Saldo: Rp 10.000\n`;
  teksUser += `🎒 Tas  : 3 Potion, 5 Wood\n\n`;
  
  teksUser += `_⚠️ Perburuan, Raid Boss, dan transaksi hanya sah di Grup Utama!_\n\n`;
  teksUser += `*Akses Gerbang Pertempuran:*\nhttps://chat.whatsapp.com/LE9BXOjPIEy9CebW95H4Ra`;

  const fmeta = {
      key: { participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {}) },
      message: {
          imageMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7118-24/f1/m233/up-video-nd-10",
              mimetype: "image/jpeg",
              caption: "Assistant X Security",
              jpegThumbnail: null
          }
      }
  };

  let p = prefix || "."; 

  let msgData = {
      viewOnceMessage: {
          message: {
              messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
              interactiveMessage: {
                  body: { text: teksUser },
                  footer: { text: `Powered by ${global.ownername || "PSTAR7"} | Xenoria System` },
                  nativeFlowMessage: {
                      buttons: [
                          { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🎒 Cek Ransel", id: `.inventory` }) },
                          { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "⚔️ Mulai Petualangan", id: `.adventure` }) },
                          { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "📜 Main Menu", id: `.menu` }) }
                      ]
                  },
                  contextInfo: { 
                      mentionedJid: [m.sender],
                      forwardingScore: 999,
                      isForwarded: true,
                      forwardedNewsletterMessageInfo: {
                          newsletterJid: global.idChannelDaftar || global.idChannel || "1203631@newsletter", 
                          newsletterName: "Log Pendaftaran Assistant X 📝", 
                          serverId: 1 
                      }
                  }
              }
          }
      }
  };

  let msg = generateWAMessageFromContent(m.chat, msgData, { quoted: fmeta });
  await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

  if (global.idChannelDaftar) {
      let maskedSN = user.sn.substring(0, 6) + "****"; 
      let teksChannel = `🌐 *GLOBAL BROADCAST* 🌐\n\nPahlawan baru telah mendarat!\n\n⬡ Nama: ${user.name}\n⬡ Role: ${user.rpg.role}\n⬡ S/N: ${maskedSN}\n\nMari sambut kedatangannya di medan pertempuran! 🚀`;
      try {
          await sock.sendMessage(global.idChannelDaftar, { text: teksChannel });
      } catch (e) {
          console.error("[ERROR BROADCAST DAFTAR]", e);
      }
  }
}

// ==========================================
// 🚀 MAIN HANDLER (PINTU MASUK COMMAND)
// ==========================================
let handler = async (m, { sock, text, prefix, command }) => {
  let user = global.db.users[m.sender];
  if (!user) {
    global.db.users[m.sender] = { registered: false };
    user = global.db.users[m.sender];
  }

  if (user.registered) {
    await m.react("⚠️");
    return m.reply(`❌ *Akses Ditolak!*\nTakdirmu sudah terukir sebelumnya.\n\nKetik \`${prefix || "."}profile\` untuk melihat status pahlawanmu.`);
  }

  // 🤖 1. METODE DAFTAR OTOMATIS
  if (command === 'autodaftar') {
      user.menungguUmur = true; 
      await m.react("🤖");
      return m.reply(`✦ *AUTO-REGISTRATION* ✦\n\nNama pahlawanmu akan diakuisisi otomatis dari profil WhatsApp (*${m.pushName || "Unknown"}*).\n\n👉 *Balas pesan ini dengan angka umurmu (Contoh: 18)*`);
  }

  // ✍️ 2. METODE DAFTAR MANUAL
  if (command === 'daftar') {
      let p = prefix || ".";
      if (!text) {
        await m.react("❓");
        
        let teksTolak = `✦ *REGISTRATION* ✦\n\nKamu belum melengkapi data pahlawan.\nPilih *Daftar Otomatis* di bawah agar lebih instan, atau gunakan format manual.\n\n*Format Manual:*\n\`${p + command} Nama.Umur\` (Contoh: \`${p + command} Pstar7.20\`)`;
        
        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                    interactiveMessage: {
                        body: { text: teksTolak },
                        footer: { text: "Xenoria Security System" },
                        nativeFlowMessage: {
                            buttons: [
                                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🤖 Daftar Otomatis", id: `${p}autodaftar` }) }
                            ]
                        },
                        contextInfo: { 
                            mentionedJid: [m.sender],
                            forwardingScore: 999,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: {
                                newsletterJid: global.idChannelDaftar || global.idChannel || "1203631@newsletter", 
                                newsletterName: "Assistant X Security System", 
                                serverId: 1 
                            }
                        }
                    }
                }
            }
        }, { quoted: m });

        return await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
      }

      let [namaInput, umurInput] = text.split(".");
      if (!namaInput || !umurInput) {
        await m.react("⚠️");
        return m.reply(`*Format Tidak Lengkap!*\n\nGunakan tanda titik (.) sebagai pemisah.\n*Contoh:* \`${p + command} Pstar7.20\``);
      }
      
      let umur = parseInt(umurInput);
      if (isNaN(umur) || umur < 5 || umur > 100) {
        await m.react("⚠️");
        return m.reply("❌ Anomali terdeteksi! Harap masukkan umur yang valid (5 - 100 Tahun).");
      }

      await prosesPendaftaran(m, sock, user, namaInput, umur, p);
  }
}

// ==========================================
// 🎣 HOOK PENANGKAP UMUR (UNTUK AUTO DAFTAR)
// ==========================================
handler.before = async (m, { sock, prefix }) => {
    if (!m.text) return false;
    
    let user = global.db.users[m.sender];
    if (!user || !user.menungguUmur) return false; 
    
    let umur = parseInt(m.text);
    let p = prefix || "."; 
    
    if (m.text.startsWith(p) && isNaN(umur)) {
        user.menungguUmur = false;
        return false; 
    }

    if (isNaN(umur)) {
        m.reply("⚠️ Harap kirimkan angka umur yang valid saja (Contoh: 18).");
        return true; 
    }

    if (umur < 5 || umur > 100) {
        m.reply("❌ Umur tidak valid (5 - 100 Tahun)!\nSilakan ketik ulang umur yang benar.");
        return true;
    }

    user.menungguUmur = false; 
    let nama = m.pushName || "Player" + Math.floor(Math.random() * 1000); 
    
    await prosesPendaftaran(m, sock, user, nama, umur, p);
    return true; 
}

handler.command = ["daftar", "autodaftar"];
handler.tags = ["informasi"];

module.exports = handler;
