'use strict';

const os = require('os');
const { execSync } = require('child_process');
const { generateWAMessageFromContent } = require('@whiskeysockets/baileys');

// ==========================================
// 🚀 HANDLER UTAMA BOT (MINIMALIST + KLASIK BAR)
// ==========================================
let handler = async (m, { sock }) => {
    try {
        await m.react('⏳').catch(() => {});
        const startTime = Date.now();

        // 1. System Resource Calculation
        const totalMem = os.totalmem();
        const freeMem = os.freemem();
        const usedMem = totalMem - freeMem;
        const ramPercent = Math.min(100, Math.max(0, (usedMem / totalMem) * 100));

        const cpus = os.cpus();
        const cpuCores = cpus?.length || 0;
        const load = os.loadavg()[0] || 0;
        const cpuPercent = Math.min(100, Math.max(0, (load / Math.max(cpuCores, 1)) * 100));

        const uptimeSeconds = os.uptime();
        const platform = os.platform();
        const arch = os.arch();
        
        // Membatasi panjang hostname Pterodactyl (Docker ID) agar tidak merusak layout
        let hostname = os.hostname();
        if (hostname.length > 12) hostname = hostname.substring(0, 12) + '...';

        // 2. Storage Calculation
        let diskInfo = 'N/A';
        let diskPercent = 0;
        try {
            const diskRaw = execSync('df -h / | awk \'NR==2 {print $3 " / " $2 " (" $5 ")"}\'').toString().trim();
            if (diskRaw) {
                diskInfo = diskRaw;
                const percMatch = diskRaw.match(/\((\d+)\%\)/);
                if (percMatch) diskPercent = parseInt(percMatch[1]);
            }
        } catch (e) {}

        // 3. Network Interfaces
        const networkInterfaces = os.networkInterfaces();
        const interfaces = Object.entries(networkInterfaces)
            .filter(([name, values]) => {
                return Array.isArray(values) && values.some(value => !value.internal && value.family === 'IPv4');
            })
            .map(([name]) => name);

        // Utilities Format
        function formatBytes(bytes) {
            if (!Number.isFinite(bytes) || bytes <= 0) return '0 B';
            const units = ['B', 'KB', 'MB', 'GB', 'TB'];
            const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
            const value = bytes / Math.pow(1024, index);
            return value.toFixed(index === 0 ? 0 : 2) + ' ' + units[index];
        }

        function formatUptime(seconds) {
            const days = Math.floor(seconds / 86400);
            const hours = Math.floor((seconds % 86400) / 3600);
            const minutes = Math.floor((seconds % 3600) / 60);
            const parts = [];
            if (days > 0) parts.push(days + 'd');
            if (hours > 0) parts.push(hours + 'h');
            parts.push(minutes + 'm');
            return parts.join(' ');
        }
        
        // Visual Progress Bar (Blok Klasik)
        function makeBar(percent) {
            const totalBlocks = 10;
            const filledBlocks = Math.round((percent / 100) * totalBlocks);
            const emptyBlocks = totalBlocks - filledBlocks;
            return '■'.repeat(filledBlocks) + '□'.repeat(emptyBlocks);
        }

        // Hitung Latency/Ping
        const pingTime = Date.now() - startTime;
        
        // Nama Bot
        const botName = global.botname || "Assistant X Project";

        // 4. Merakit UI Minimalis & Elegan
        const textOutput = `> 🌐 *${botName.toUpperCase()} SERVER*
> ━━━━━━━━━━━━━━━━━━━━━━
> ⚡ *Latency :* ${pingTime}ms
> 🖥️ *Node    :* ${hostname}
> ━━━━━━━━━━━━━━━━━━━━━━
> 📊 *HARDWARE USAGE*
> 🔸 *CPU:* ${cpuPercent.toFixed(1)}%
> └ [${makeBar(cpuPercent)}]
> 🔸 *RAM:* ${ramPercent.toFixed(1)}%
> └ [${makeBar(ramPercent)}]
> 🔸 *DSK:* ${diskInfo !== 'N/A' ? diskInfo.split(' (')[0] : 'N/A'}
> └ [${makeBar(diskPercent)}]
> ━━━━━━━━━━━━━━━━━━━━━━
> ⚙️ *SYSTEM SPECS*
> ◦ *Memory* : ${formatBytes(usedMem)} / ${formatBytes(totalMem)}
> ◦ *Cores*  : ${cpuCores} vCPU
> ◦ *Load*   : ${load.toFixed(2)} Avg
> ◦ *OS*     : ${platform} (${arch})
> ◦ *Net*    : ${interfaces.join(', ') || 'eth0'}
> ◦ *Uptime* : ${formatUptime(uptimeSeconds)}
> ━━━━━━━━━━━━━━━━━━━━━━
> 🟢 *STATUS: ONLINE*`;

        // 5. Eksekusi ke WA dengan Quoted Status & Button
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: { text: textOutput },
                        footer: { text: `© ${botName} v${global.versibot || '2.0'}` },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "☰ Menu Utama",
                                        id: ".menu"
                                    })
                                }
                            ]
                        },
                        contextInfo: {
                            participant: "0@s.whatsapp.net",
                            remoteJid: "status@broadcast",
                            quotedMessage: {
                                imageMessage: {
                                    caption: `Pusat Informasi Sistem | Server Ping`
                                }
                            }
                        }
                    }
                }
            }
        }, {});

        await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await m.react('✅').catch(() => {});
        
    } catch (e) {
        console.error(e);
        await m.react('❌').catch(() => {});
        m.reply(`[System Error]: Gagal memuat diagnostic.\nDetail: ${e.message}`);
    }
};


handler.command = ['ping'];
handler.tags = ['informasi'];
handler.help = ['ping'];

module.exports = handler;
