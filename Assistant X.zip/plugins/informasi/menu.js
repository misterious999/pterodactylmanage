const {
    generateWAMessageFromContent,
    prepareWAMessageMedia,
    proto
} = require("@whiskeysockets/baileys");

const moment = require("moment-timezone");

// ======================================================
// MENU CONFIG
// ======================================================
const categoryEmojis = {
    main: "🧭", owner: "👨‍💻", group: "👥", jpm: "📢", download: "📥", downloader: "📥", utility: "🛠️", premium: "⭐", panel: "🖥️", pterodactyl: "🦖", ai: "🤖", game: "🎮", store: "🛒", tools: "🧰", rpg: "⚔️", search: "🔍", fun: "🎡", mancing: "🎣", info: "ℹ️", islami: "🕌", maker: "🎨", other: "🧩"
};

const categoryNames = {
    main: "Main Menu", owner: "Owner Tools", group: "Grup Manager", jpm: "Broadcast", download: "Downloader", downloader: "Downloader", utility: "Utilitas", premium: "Premium", panel: "Server Panel", pterodactyl: "Pterodactyl", ai: "Artificial Intelligence", game: "Game & Permainan", store: "Toko Digital", tools: "Peralatan", rpg: "Petualangan RPG", search: "Pencarian", fun: "Hiburan", mancing: "Memancing", info: "Informasi", islami: "Islami", maker: "Pembuat Media", other: "Menu Lainnya"
};

const categoryDescriptions = {
    main: "Navigasi utama dan informasi bot.", owner: "Perintah khusus pengelola sistem.", group: "Fitur moderasi dan pengaturan grup.", jpm: "Kirim pesan siaran ke banyak grup.", download: "Unduh media dari berbagai platform.", downloader: "Unduh media dari berbagai platform.", utility: "Alat bantu praktis sehari-hari.", premium: "Fitur khusus untuk pengguna VIP.", panel: "Manajemen panel server.", pterodactyl: "Kontrol server Pterodactyl.", ai: "Asisten cerdas untuk menjawab pertanyaan.", game: "Kumpulan permainan seru di chat.", store: "Fitur transaksi dan toko digital.", tools: "Alat bantu tambahan WhatsApp.", rpg: "Mainkan game petualangan RPG di sini.", search: "Cari informasi, gambar, atau lirik lagu.", fun: "Fitur seru-seruan dan hiburan ringan.", mancing: "Fitur simulasi memancing virtual.", info: "Cek status dan informasi sistem bot.", islami: "Kumpulan doa, jadwal sholat, dan Islami.", maker: "Buat stiker, edit gambar, dan efek.", other: "Fitur tambahan yang tidak terkategori."
};

const customMenuNames = {
    adventure: "⚔️ Mulai Petualangan", heal: "🏥 Pulihkan Nyawa", shop: "⛺ Toko RPG", inv: "🎒 Cek Tas", inventory: "🎒 Cek Tas", upgrade: "🔨 Tingkatkan Barang", role: "📜 Pilih Peran", makan: "🍗 Makan Dulu", masak: "🔥 Masak Bahan", dapur: "🍳 Pergi ke Dapur", mancing: "🎣 Pergi Memancing", akuarium: "🐠 Lihat Akuarium", ai: "🤖 Ngobrol sama AI", toimg: "🖼️ Ubah ke Gambar", ping: "⚡ Cek Respons", owner: "👨‍💻 Kontak Owner", play: "🎵 Putar Lagu", ytmp4: "🎥 Unduh Video YT", ytmp3: "🎵 Unduh Audio YT", yt: "📥 YouTube Downloader", ytdl: "📥 YouTube Downloader", terabox: "☁️ Unduh Terabox", tiktok: "📱 Unduh TikTok", tt: "📱 Unduh TikTok", ig: "📸 Unduh Instagram", capcut: "🎬 Unduh CapCut", translate: "🌐 Terjemahkan Teks", tr: "🌐 Terjemahkan Teks", cekidch: "🔎 Cek ID Channel", upswgc: "📤 Upload SWGC", jpm: "📢 Siaran Grup"
};

// ======================================================
// BASIC HELPER
// ======================================================
function clockString(ms) {
    const h = Math.floor(ms / 3600000);
    const m = Math.floor(ms / 60000) % 60;
    const s = Math.floor(ms / 1000) % 60;
    return [h, m, s].map(v => String(v).padStart(2, "0")).join(":");
}

function cleanTag(tag = "") {
    let key = String(tag || "").toLowerCase().trim();
    if (key === "downloader") key = "download";
    return key || "other";
}

function toArray(value) {
    if (!value) return [];
    return Array.isArray(value) ? value : [value];
}

function formatMoney(value = 0) {
    const num = Number(value || 0);
    if (!Number.isFinite(num)) return "0";
    return num.toLocaleString("id-ID");
}

function getBotVersion() {
    const envVersion = process.env.BOT_VERSION || global.botVersion;
    if (envVersion) return String(envVersion).replace(/^v/i, "");
    try {
        const pkg = require(`${process.cwd()}/package.json`);
        return String(pkg.version || "1.0.0").replace(/^v/i, "");
    } catch (_) { return "1.0.0"; }
}

function truncate(text = "", max = 60) {
    const clean = String(text || "").trim();
    if (clean.length <= max) return clean;
    return clean.slice(0, max - 3).trim() + "...";
}

function getWibDateTime() {
    try {
        const parts = new Intl.DateTimeFormat("id-ID", {
            timeZone: "Asia/Jakarta", weekday: "long", day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", hour12: false
        }).formatToParts(new Date());

        const get = type => parts.find(part => part.type === type)?.value || "";
        let hour = get("hour");
        const minute = get("minute");
        if (hour === "24") hour = "00";

        return { day: get("weekday") || "-", date: `${get("day")}-${get("month")}-${get("year")}`, time: `${hour}:${minute}`, hour: Number(hour) };
    } catch (_) {
        const now = new Date();
        const hour = now.getHours();
        const minute = String(now.getMinutes()).padStart(2, "0");
        return { day: "-", date: `${String(now.getDate()).padStart(2, "0")}-${String(now.getMonth() + 1).padStart(2, "0")}-${now.getFullYear()}`, time: `${String(hour).padStart(2, "0")}:${minute}`, hour };
    }
}

function getGreeting() {
    const { hour } = getWibDateTime();
    if (hour >= 4 && hour < 11) return "pagi 🌅";
    if (hour >= 11 && hour < 15) return "siang ☀️";
    if (hour >= 15 && hour < 18) return "sore 🌇";
    if (hour >= 18 && hour < 24) return "malam 🌙";
    return "dini hari 🌌";
}

function getLimitDisplay(userDb = {}, isOwner = false) {
    if (isOwner) return "Tak Terbatas";
    if (userDb.premium) return "Tak Terbatas";
    return `${userDb.limit || 0}`;
}

function getUserStatus(userDb = {}, isOwner = false) {
    if (isOwner) return "Pemilik Sistem";
    if (userDb.premium) return "Member Premium";
    return "Member Standar";
}

function getCategoryEmoji(key = "other") { return categoryEmojis[key] || categoryEmojis.other; }
function getCategoryName(key = "other") { return categoryNames[key] || key.charAt(0).toUpperCase() + key.slice(1); }
function getCategoryDescription(key = "other") { return categoryDescriptions[key] || categoryDescriptions.other; }

function makeFakeQuoted(m) {
    return {
        key: { participant: "0@s.whatsapp.net", ...(m.chat ? { remoteJid: "status@broadcast" } : {}) },
        message: { conversation: "𝗔𝘀𝘀𝗶𝘀𝘁𝗮𝗻𝘁 𝗫 𝗜𝗻𝘁𝗲𝗿𝗮𝗰𝘁𝗶𝘃𝗲" }
    };
}

// ======================================================
// CATEGORY BUILDER
// ======================================================
function buildCategories(plugins = {}) {
    const categories = {};
    const allCommands = new Set();

    for (const file in plugins) {
        const plug = plugins[file];
        if (!plug) continue;

        const tags = toArray(plug.tags);
        const commands = plug.help ? toArray(plug.help) : toArray(plug.command);
        if (!tags.length || !commands.length) continue;

        for (const rawTag of tags) {
            const key = cleanTag(rawTag);
            const name = getCategoryName(key);

            if (!categories[key]) categories[key] = { key, name, cmds: new Set() };

            for (const cmd of commands) {
                if (!cmd) continue;
                const commandName = String(cmd).trim().replace(/^\./, "");
                if (!commandName) continue;

                categories[key].cmds.add(commandName);
                allCommands.add(commandName);
            }
        }
    }
    return { categories, totalFeatures: allCommands.size };
}

function makeRowsFromCategories(categories = {}, prefix = ".", totalFeatures = 0) {
    const rows = [];
    rows.push({ title: "📜 Tampilkan Semua Fitur", description: `Lihat keseluruhan ${totalFeatures} perintah sistem.`, id: `${prefix}allmenu` });

    for (const key of Object.keys(categories).sort()) {
        const data = categories[key];
        const emoji = getCategoryEmoji(key);
        const name = getCategoryName(key);
        const total = data.cmds.size;

        rows.push({ title: `${emoji} ${truncate(name, 35)}`, description: `Jelajahi ${total} fitur di kategori ini.`, id: `${prefix}menu ${key}` });
    }
    return rows;
}

function makeRowsFromCommands(cmds = [], prefix = ".", categoryKey = "other") {
    const emoji = getCategoryEmoji(categoryKey);
    const rows = [];
    const uniqueCmds = new Set();

    for (const cmd of cmds) {
        const mainCmd = String(cmd || "").split(/\s+/)[0].replace(/^\./, "").toLowerCase().trim();
        if (!mainCmd || uniqueCmds.has(mainCmd)) continue;

        uniqueCmds.add(mainCmd);
        let title = customMenuNames[mainCmd];
        if (!title) title = `${emoji} ${mainCmd.charAt(0).toUpperCase() + mainCmd.slice(1)}`;

        rows.push({ title: truncate(title, 60), description: `Jalankan perintah ${prefix}${mainCmd}`, id: `${prefix}${mainCmd}` });
    }
    return rows;
}

// ======================================================
// TEXT BUILDER (FUTURISTIC MINIMALIST)
// ======================================================
function buildDashboardText({ userName, greeting, timeInfo, status, limitDisplay, balance, uptime, totalFeatures, totalUsers, botVersion, botNameStr }) {
    return `✧ ━━━[ *${botNameStr.toUpperCase()}* ]━━━ ✧
Halo *${userName}*, selamat ${greeting}! ✨

❖ 𝗨𝗦𝗘𝗥 𝗣𝗥𝗢𝗙𝗜𝗟𝗘
» 𝗔𝗰𝗰𝗲𝘀𝘀 : ${status}
» 𝗦𝗮𝗹𝗱𝗼  : Rp ${formatMoney(balance)}
» 𝗟𝗶𝗺𝗶𝘁  : ${limitDisplay}

❖ 𝗦𝗬𝗦𝗧𝗘𝗠 𝗜𝗡𝗙𝗢
» 𝗧𝗶𝗺𝗲   : ${timeInfo.time} WIB
» 𝗨𝗽𝘁𝗶𝗺𝗲 : ${uptime} Detik
» 𝗠𝗼𝗱𝘂𝗹𝗲 : ${totalFeatures} Fitur
» 𝗨𝘀𝗲𝗿𝘀  : ${totalUsers} Terdaftar
» 𝗩𝗲𝗿𝘀𝗶𝗼𝗻: v${botVersion}

✧ ━━━━━━━━━━━━━━━━━━ ✧
Silakan jelajahi menu melalui tombol di bawah. 👇`;
}

function buildHelpText(userName, prefix, botNameStr) {
    return `✧ ━━━[ *PUSAT BANTUAN* ]━━━ ✧\nHalo *${userName}* 👋\n\nGunakan tombol interaktif di bawah untuk menavigasi fitur *${botNameStr}* dengan mudah.\n\nAtau gunakan perintah manual:\n» *${prefix}menu* (Membuka panel utama)\n» *${prefix}menu download* (Membuka kategori)\n» *${prefix}allmenu* (Melihat daftar semua fitur)`;
}

function buildCategoryHeader({ key, name, userName, limitDisplay, userDb, rpgDb, botNameStr }) {
    const emoji = getCategoryEmoji(key);
    const description = getCategoryDescription(key);

    let header = `✧ ━━━[ *${name.toUpperCase()}* ]━━━ ✧\n_${description}_\n\n`;

    if (key === "rpg") {
        header += `❖ 𝗦𝗧𝗔𝗧𝗜𝗦𝗧𝗜𝗞 𝗥𝗣𝗚\n» 𝗣𝗲𝗿𝗮𝗻   : ${rpgDb.role || "Pemula"}\n» 𝗟𝗲𝘃𝗲𝗹   : ${userDb.level || 0} (EXP: ${userDb.xp || 0})\n» 𝗨𝗮𝗻𝗴    : Rp ${formatMoney(userDb.balance || userDb.money || 0)}\n» 𝗡𝘆𝗮𝘄𝗮   : ${rpgDb.hp || 0}/${rpgDb.max_hp || 500}\n» 𝗘𝗻𝗲𝗿𝗴𝗶  : ${rpgDb.mp || 0}/${rpgDb.max_mp || 400}\n» 𝗦𝗲𝗻𝗷𝗮𝘁𝗮 : ${rpgDb.weapon || "Tangan Kosong"}\n» 𝗣𝗮𝗸𝗮𝗶𝗮𝗻 : ${rpgDb.armor || "Baju Biasa"}\n\n`;
    } else if (key === "mancing") {
        header += `❖ 𝗦𝗧𝗔𝗧𝗜𝗦𝗧𝗜𝗞 𝗠𝗔𝗡𝗖𝗜𝗡𝗚\n» 𝗔𝗻𝗴𝗹𝗲𝗿  : ${userName}\n» 𝗔𝗹𝗮𝘁    : Level ${userDb.pancingan || 0}\n» 𝗨𝗺𝗽𝗮𝗻   : ${userDb.umpan || 0} pcs\n» 𝗣𝗮𝘂𝘀    : ${userDb.paus || 0} ekor\n» 𝗛𝗶𝘂     : ${userDb.hiu || 0} ekor\n\n`;
    } else if (key === "store") {
        header += `❖ 𝗗𝗔𝗧𝗔 𝗣𝗘𝗟𝗔𝗡𝗚𝗚𝗔𝗡\n» 𝗡𝗮𝗺𝗮   : ${userName}\n» 𝗦𝗮𝗹𝗱𝗼  : Rp ${formatMoney(userDb.balance || userDb.money || 0)}\n» 𝗣𝗮𝘆𝗺𝗲𝗻𝘁: QRIS & Transfer Manual\n\n`;
    } else {
        header += `❖ 𝗜𝗡𝗙𝗢 𝗔𝗞𝗦𝗘𝗦\n» 𝗜𝘇𝗶𝗻   : ${limitDisplay}\n» 𝗦𝘁𝗮𝘁𝘂𝘀 : Online System\n\n`;
    }

    header += `Pilih perintah yang tersedia di bawah. 👇`;
    return header;
}

// ======================================================
// SEND HELPER (STABIL DENGAN GAMBAR HEADER)
// ======================================================
async function sendInteractive(sock, m, options = {}) {
    const {
        body,
        footer = `© ${process.env.OWNER_NAME || global.ownername || "Assistant X"} Project`,
        rows = [],
        buttonTitle = "Pilihan Menu",
        quoted,
        imageUrl,
        extraButtons = []
    } = options;

    let imageMessage = null;

    // Proses download & pasang gambar sebagai Header (Metode WA paling stabil)
    if (imageUrl) {
        try {
            const media = await prepareWAMessageMedia(
                { image: { url: imageUrl } },
                { upload: sock.waUploadToServer }
            );
            imageMessage = media.imageMessage;
        } catch (error) {
            console.log("[WARN] Gagal memuat gambar header:", error.message);
        }
    }

    const buttons = [];

    if (rows.length > 0) {
        const safeRows = rows.slice(0, 90);
        buttons.push({
            name: "single_select",
            buttonParamsJson: JSON.stringify({
                title: buttonTitle,
                sections: [{ title: "Daftar Layanan", rows: safeRows }]
            })
        });
    }
    
    buttons.push(...extraButtons);

    const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({ text: body }),
                    footer: proto.Message.InteractiveMessage.Footer.create({ text: footer }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        title: "", subtitle: "", 
                        hasMediaAttachment: !!imageMessage,
                        ...(imageMessage ? { imageMessage } : {})
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons }),
                    contextInfo: {
                        mentionedJid: [m.sender],
                        forwardingScore: 999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: global.idChannelDaftar || global.idChannel || "1203631@newsletter",
                            newsletterName: "Pusat Informasi Sistem",
                            serverId: 1
                        }
                    }
                })
            }
        }
    }, { quoted });

    try {
        return await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    } catch (error) {
        console.log("[MENU BUTTON ERROR]", error.message);
        return sock.sendMessage(m.chat, { text: body }, { quoted });
    }
}

// ======================================================
// HANDLER UTAMA
// ======================================================
let handler = async (m, { sock, args, isOwner, command, prefix }) => {
    const usedPrefix = prefix || global.prefix || ".";
    const plugins = global.plugins || {};
    const { categories, totalFeatures } = buildCategories(plugins);

    const userDb = global.db?.users?.[m.sender] || {};
    const rpgDb = userDb.rpg || {};
    const userName = userDb.name || m.pushName || "Pengguna";
    const tagUser = `@${m.sender.split("@")[0]}`;

    const timeInfo = getWibDateTime();
    const greeting = getGreeting();
    const limitDisplay = getLimitDisplay(userDb, isOwner);
    const status = getUserStatus(userDb, isOwner);
    const totalUsers = Object.keys(global.db?.users || {}).length;
    const uptime = clockString(process.uptime() * 1000);
    
    // MENGAMBIL DATA DARI .ENV
    const botVersion = process.env.BOT_VERSION || getBotVersion();
    const botNameStr = process.env.BOT_NAME || global.botname || "Assistant X";
    const thumbUrl = process.env.THUMBNAIL_URL || global.thumb || "https://files.catbox.moe/xevp3k.jpg";

    const fakeQuoted = makeFakeQuoted(m);

    let categoryInput = args[0] ? String(args[0]).toLowerCase().trim() : null;
    if (categoryInput === "downloader") categoryInput = "download";

    const isAllMenu = command === "allmenu" || categoryInput === "all" || (m.text && String(m.text).toLowerCase().includes("allmenu"));

    await m.react("✅").catch(() => {});

    // ==================================================
    // A. ALL MENU — TEXT LAYOUT (Clean Minimalist)
    // ==================================================
    if (isAllMenu) {
        const keys = Object.keys(categories).sort();
        if (!keys.length) return sock.sendMessage(m.chat, { text: "Mohon maaf, belum ada menu yang tersedia saat ini." }, { quoted: fakeQuoted });

        let text = `✧ ━━━[ *ALL MENU* ]━━━ ✧\nHalo ${tagUser} 👋\nBerikut adalah daftar seluruh layanan yang tersedia.\n\n`;
        text += `❖ 𝗦𝗧𝗔𝗧𝗜𝗦𝗧𝗜𝗞 𝗦𝗜𝗦𝗧𝗘𝗠\n» Kategori: ${keys.length} Modul\n» Fitur: ${totalFeatures} Perintah\n\n`;
        text += `💡 *Panduan:* Ketik *${usedPrefix}menu <kategori>* untuk membuka menu spesifik. Contoh: *${usedPrefix}menu download*\n\n`;

        for (const key of keys) {
            const data = categories[key];
            const cmds = Array.from(data.cmds).sort();
            text += `❖ *${getCategoryEmoji(key)} ${getCategoryName(key).toUpperCase()}*\n`;
            cmds.forEach(cmd => { text += ` » ${usedPrefix}${cmd}\n`; });
            text += `\n`;
        }

        return await sock.sendMessage(m.chat, {
            text: text.trim(),
            mentions: [m.sender]
        }, { quoted: fakeQuoted });
    }

    // ==================================================
    // B. SUB MENU KATEGORI
    // ==================================================
    if (categoryInput && categoryInput !== "all") {
        const data = categories[categoryInput];

        if (!data) {
            return sock.sendMessage(m.chat, {
                text: `Mohon maaf, kategori *${categoryInput}* tidak ditemukan.\nSilakan ketik *${usedPrefix}menu* untuk melihat daftar kategori yang benar.`
            }, { quoted: m });
        }

        const cmds = Array.from(data.cmds).sort();
        const rows = makeRowsFromCommands(cmds, usedPrefix, categoryInput);
        const body = buildCategoryHeader({ key: categoryInput, name: getCategoryName(categoryInput), userName, limitDisplay, userDb, rpgDb, botNameStr });

        return sendInteractive(sock, m, {
            body,
            rows,
            buttonTitle: "Pilih Fitur",
            quoted: fakeQuoted,
            imageUrl: thumbUrl // Gunakan kembali Upload Image stabil
        });
    }

    // ==================================================
    // C. HELP
    // ==================================================
    if (command === "help") {
        const body = buildHelpText(userName, usedPrefix, botNameStr);

        return sendInteractive(sock, m, {
            body,
            rows: [],
            quoted: fakeQuoted,
            imageUrl: thumbUrl, // Gunakan kembali Upload Image stabil
            extraButtons: [
                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🗂️ Buka Menu Utama", id: `${usedPrefix}menu` }) }
            ]
        });
    }

    // ==================================================
    // D. MAIN MENU DASHBOARD
    // ==================================================
    if (command === "menu") {
        const body = buildDashboardText({
            userName, greeting, timeInfo, status, limitDisplay, balance: userDb.balance || userDb.money || 0, uptime, totalFeatures, totalUsers, botVersion, botNameStr
        });

        const rows = makeRowsFromCategories(categories, usedPrefix, totalFeatures);

        await sendInteractive(sock, m, {
            body,
            rows,
            buttonTitle: "Pilih Kategori",
            quoted: fakeQuoted,
            imageUrl: thumbUrl, // Gambar di-upload ke server Meta, 100% lolos
            extraButtons: [
                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "⚡ Cek Ping", id: `${usedPrefix}ping` }) },
                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "👨‍💻 Kontak Owner", id: `${usedPrefix}owner` }) }
            ]
        });

        // Eksekusi VN Menu jika disetel
        if (global.vnMenu) {
            try {
                await sock.sendMessage(m.chat, {
                    audio: { url: global.vnMenu },
                    mimetype: "audio/mp4",
                    ptt: true
                }, { quoted: fakeQuoted });
            } catch (_) {}
        }
    }
};

handler.tags = ["main"];
handler.command = ["menu", "help", "allmenu"];

module.exports = handler;
