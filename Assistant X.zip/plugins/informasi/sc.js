// ==========================================
// 📦 SCRIPT PROMOTION ENGINE - ASSISTANT X
// ⚙️ Ciptaan Pstar7 | Modern & Elegant UI
// ==========================================

const { generateWAMessageFromContent, proto } = require("@whiskeysockets/baileys");

let handler = async (m, { sock, prefix, command }) => {
    let ownerNumber = global.owner?.[0] || "628xxxxxxxxxx"; // Mengambil nomor owner dari global config
    let botName = global.botname || "Assistant X";
    let ownerName = global.ownername || "Pstar7";

    // ==========================================
    // 🎨 MERAKIT TEKS PROMOSI
    // ==========================================
    let teksPromo = `┏━━━ *⚡ Script ${botName}* ━━━┓\n\n`;
    teksPromo += `Bot WhatsApp generasi mutakhir yang dirancang untuk performa tinggi, ringan, dan siap mendominasi kebutuhan digitalmu—mulai dari personal, komunitas, hingga bisnis sewa bot.\n\n`;
    
    teksPromo += `💎 *KEUNGGULAN UTAMA*\n`;
    teksPromo += `- ✨ UI/UX Menu Interaktif & Estetik\n`;
    teksPromo += `- 📥 High-Speed Multi-Platform Downloader\n`;
    teksPromo += `- 🧠 Integrasi AI Kreatif & Responsif\n`;
    teksPromo += `- 🏢 Sistem Manajemen Grup Terstruktur\n`;
    teksPromo += `- 📢 Kontrol Broadcast/JPM Lebih Aman\n`;
    teksPromo += `- 🤝 Optimal untuk Bisnis Sewa Bot\n`;
    teksPromo += `- 🛠️ Clean Architecture (Mudah Dikembangkan)\n\n`;
    
    teksPromo += `🏷️ *LISENSI & INVESTASI HARGA*\n\n`;
    
    teksPromo += `📦 *Script Base (Tanpa Update)*\n`;
    teksPromo += `   └ Harga: *Rp 35.000*\n\n`;
    
    teksPromo += `🚀 *Script Full Update (Lifetime)*\n`;
    teksPromo += `   └ Harga: *Rp 50.000*\n\n`;
    
    teksPromo += `🧾 *Add-on: Tambah Nomor Database*\n`;
    teksPromo += `   └ Harga: *Rp 20.000 / nomor*\n\n`;
    
    teksPromo += `📌 *CATATAN PENTING*\n`;
    teksPromo += `Add-on tambah nomor database bersifat eksklusif dan hanya berlaku bagi pembeli script atau *reseller* resmi.\n\n`;
    
    teksPromo += `_Bangun ekosistem bot WhatsApp-mu tanpa ribet. Deploy, jalankan, dan taklukkan pasar!_ 🚀\n\n`;
    teksPromo += `┗━━━━━━━━━━━━━━━━━━━━━━┛\n`;
    teksPromo += `© Scripts by ${ownerName}`;

    // Bingkai Mewah Fmeta (Keamanan & Estetika Pesan)
    const fmeta = {
        key: { participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {}) },
        message: {
            imageMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7118-24/f1/m233/up-video-nd-10... ",
                mimetype: "image/jpeg",
                caption: `${botName} Marketplace`,
                jpegThumbnail: null
            }
        }
    };

    // Merakit Pesan Interaktif dengan Tombol Aksi Cepat & URL Owner
    let msgData = {
        viewOnceMessage: {
            message: {
                messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                interactiveMessage: {
                    body: { text: teksPromo },
                    footer: { text: `© Ecosystem by ${ownerName}` },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: "cta_url",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "💬 Konsultasi & Order",
                                    url: `https://wa.me/${ownerNumber}?text=Halo%20kak,%20saya%20tertarik%20untuk%20membeli%20Script%20${botName}.`
                                })
                            },
                            {
                                name: "quick_reply",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "📜 Menu Utama",
                                    id: `${prefix}menu`
                                })
                            }
                        ]
                    },
                    contextInfo: { 
                        mentionedJid: [m.sender],
                        forwardingScore: 999,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: global.idChannel || "1203631@newsletter", 
                            newsletterName: `${botName} Marketplace 🛒`, 
                            serverId: 1 
                        }
                    }
                }
            }
        }
    };

    await m.react("🛒");
    let msg = generateWAMessageFromContent(m.chat, msgData, { quoted: fmeta });
    return sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}

handler.command = ["sc"];
handler.tags = ["informasi"];
handler.help = ["sc"];

module.exports = handler;
