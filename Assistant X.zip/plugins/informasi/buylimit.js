// ==========================================
// 🛒 FITUR BELI LIMIT (SISTEM EKONOMI RPG)
// ==========================================

let handler = async (m, { sock, args, prefix, command }) => {
    let user = global.db.users[m.sender];
    if (!user) return m.reply("❌ Kamu belum terdaftar di database bot!");

    // 🔥 PENGATURAN HARGA: 1 Limit = Rp 5.000 Saldo
    let hargaPerLimit = 5000;

    // 1️⃣ JIKA MEMBER CUMA NGETIK COMMAND TANPA ANGKA
    if (!args[0]) {
        let saldoRapi = typeof global.toRupiah === 'function' ? global.toRupiah(user.balance || 0) : `Rp ${(user.balance || 0).toLocaleString('id-ID')}`;
        let hargaRapi = typeof global.toRupiah === 'function' ? global.toRupiah(hargaPerLimit) : `Rp ${hargaPerLimit.toLocaleString('id-ID')}`;

        let teks = `╭───┈ *「 🛒 TOKO LIMIT 」*\n`;
        teks += `│ 🏷️ *Harga:* ${hargaRapi} / 1 Limit\n`;
        teks += `│ 💳 *Saldomu:* ${saldoRapi}\n`;
        teks += `│ 🎟️ *Limitmu:* ${user.limit || 0}\n`;
        teks += `╰───────────────┈ ⳹\n\n`;
        teks += `*Cara Beli:* \`${prefix}${command} 10\` (Untuk membeli 10 limit)`;
        return m.reply(teks);
    }

    // 2️⃣ VALIDASI ANGKA INPUTAN
    let jumlah = parseInt(args[0]);
    if (isNaN(jumlah) || jumlah <= 0) {
        return m.reply(`⚠️ Masukkan jumlah angka yang valid!\n*Contoh:* \`${prefix}${command} 5\``);
    }

    // 3️⃣ CEK KECUKUPAN SALDO MEMBER
    let totalHarga = jumlah * hargaPerLimit;
    
    if ((user.balance || 0) < totalHarga) {
        let totalRapi = typeof global.toRupiah === 'function' ? global.toRupiah(totalHarga) : `Rp ${totalHarga.toLocaleString('id-ID')}`;
        return m.reply(`❌ Saldomu tidak cukup Bosku!\nKamu butuh *${totalRapi}* untuk membeli ${jumlah} Limit.\n\n_Silakan main mini games untuk cari cuan dulu!_`);
    }

    // 4️⃣ PROSES TRANSAKSI (POTONG SALDO, TAMBAH LIMIT)
    user.balance -= totalHarga;
    user.limit = (user.limit || 0) + jumlah;

    // 5️⃣ STRUK PEMBELIAN
    let bayarRapi = typeof global.toRupiah === 'function' ? global.toRupiah(totalHarga) : `Rp ${totalHarga.toLocaleString('id-ID')}`;
    let sisaSaldo = typeof global.toRupiah === 'function' ? global.toRupiah(user.balance) : `Rp ${user.balance.toLocaleString('id-ID')}`;

    let teksSukses = `╭───┈ *「 🎉 PEMBELIAN SUKSES 」*\n`;
    teksSukses += `│ 🛍️ *Item:* +${jumlah} Limit\n`;
    teksSukses += `│ 💸 *Total Bayar:* -${bayarRapi}\n`;
    teksSukses += `│ \n`;
    teksSukses += `│ 🎟️ *Limit Sekarang:* ${user.limit}\n`;
    teksSukses += `│ 💳 *Sisa Saldo:* ${sisaSaldo}\n`;
    teksSukses += `╰───────────────┈ ⳹`;

    await sock.sendMessage(m.chat, { text: teksSukses }, { quoted: m });
}

handler.help = ['buylimit <jumlah>'];
handler.tags = ['informasi'];
// 🔥 Dijamin pakai Array biar nggak nyangkut kayak fitur dompet tadi!
handler.command = ['buylimit', 'belilimit'];

module.exports = handler;
