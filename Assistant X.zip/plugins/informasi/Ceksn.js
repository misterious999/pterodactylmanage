const { generateWAMessageFromContent, proto } = require("@whiskeysockets/baileys");

// ==========================================
// 🛡️ CEK SERIAL NUMBER (VIP SECURITY DASHBOARD)
// ==========================================

let handler = async (m, { sock, prefix, command }) => {
  let user = global.db.users[m.sender]

  // 1. VALIDASI KEAMANAN (ANTI-CRASH FIX)
  // Mengganti m.replyPremium yang sudah dihapus dengan format Channel VIP murni
  if (!user || !user.registered) {
    await m.react("⚠️")
    return sock.sendMessage(m.chat, { 
        text: `❌ *Akses Ditolak!*\n\nData kamu tidak ditemukan di server Assistant X Project!\nSilakan registrasi dengan mengetik \`${prefix}daftar nama.umur\` terlebih dahulu.`,
        contextInfo: {
            forwardingScore: 999, isForwarded: true,
            forwardedNewsletterMessageInfo: { 
                newsletterJid: global.idChannel || "1203631@newsletter", 
                newsletterName: "🛡️ Assistant X Security", 
                serverId: 1 
            }
        }
    }, { quoted: m });
  }

  await m.react("⏳")

  // Mengambil data Serial Number dari database
  let sn = user.sn || "SN-TIDAK-VALID"

  // 2. MERAKIT PAPAN PENGUMUMAN (EXECUTIVE UI)
  let teks = `✨ *S E C U R I T Y   C E N T E R* ✨\n\n`
  teks += `╭───「 *USER IDENTITY* 」\n`
  teks += `│ ◦ 👤 Nama: *${user.name}*\n`
  teks += `│ ◦ 🔑 S N: *${sn}*\n`
  teks += `╰──────────────\n\n`
  teks += `_⚠️ Serial Number adalah kunci mutlak untuk identitasmu. Jangan berikan kode ini kepada siapapun!_ 🛡️`

  // 3. MERAKIT PESAN INTERAKTIF NATIVE FLOW + LABEL CHANNEL
  let msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
          footer: proto.Message.InteractiveMessage.Footer.create({ text: "© Assistant X Security System 📡" }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [{
              name: "cta_copy", 
              buttonParamsJson: JSON.stringify({
                display_text: "📋 Salin Serial Number",
                id: "copy_sn",
                copy_code: sn 
              })
            }]
          }),
          // Menyelipkan Label Saluran ke dalam Pesan Tombol
          contextInfo: {
              forwardingScore: 999,
              isForwarded: true,
              forwardedNewsletterMessageInfo: {
                  newsletterJid: global.idChannel || "1203631@newsletter",
                  newsletterName: "🛡️ Assistant X Security",
                  serverId: 1
              }
          }
        })
      }
    }
  }, { quoted: m });

  // Eksekusi penembakan pesan
  await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
  await m.react("✅")
}

handler.command = ["ceksn", "sn"]
handler.tags = ["informasi"]
handler.help = ["ceksn"]

module.exports = handler;
