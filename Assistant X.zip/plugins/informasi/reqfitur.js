const crypto = require("crypto")

let handler = async (m, { sock, args, text, command, prefix, isOwner }) => {
  // 1. Inisialisasi kerangka database jika belum ada
  if (!global.db.settings.reqfitur) global.db.settings.reqfitur = {}

  let dbReq = global.db.settings.reqfitur
  const ownerRaw = Array.isArray(global.owner) ? String(global.owner[0] || "") : String(global.owner || "").split(/[,\s]+/)[0]
  let ownerNum = ownerRaw ? (ownerRaw.includes("@") ? ownerRaw : `${ownerRaw}@s.whatsapp.net`) : "" // Nomor tujuan notifikasi persetujuan
  if (!ownerNum) return m.replyPremium("❌ OWNER_NUMBER belum diisi di file .env.")

  switch (command) {
    // ==========================================
    // BAGIAN PENGGUNA: MEMBUAT REQUEST
    // ==========================================
    case "reqfitur":
    case "requestfitur": {
      if (!text) {
        await m.react("⚠️")
        return m.replyPremium(`❌ Masukkan deskripsi fitur yang ingin di-request!\nContoh: \`${prefix + command}\` buatin game RPG yang seru`)
      }
      
      await m.react("⏳")
      // Membuat ID Unik 6 Karakter (Kombinasi huruf & angka)
      let id = crypto.randomBytes(3).toString("hex").toUpperCase() 
      
      dbReq[id] = { 
        text: text, 
        sender: m.sender, 
        status: "pending", 
        date: new Date().toLocaleDateString("id-ID")
      }

      // Format pesan yang dikirim ke Owner
      let ownerMsg = `╭───┈ *「 REQUEST FITUR BARU 」*\n`
      ownerMsg += `│ 🆔 *ID:* ${id}\n`
      ownerMsg += `│ 👤 *Dari:* @${m.sender.split("@")[0]}\n`
      ownerMsg += `│ 📝 *Request:* ${text}\n`
      ownerMsg += `╰───────────────┈ ⳹\n\n`
      ownerMsg += `Ketik \`.acc ${id}\` untuk menerima, atau \`.reject ${id}\` untuk menolak.`
      
      // Mengirim langsung ke nomor Owner
      await sock.sendMessage(ownerNum, { text: ownerMsg, mentions: [m.sender] })
      
      await m.react("✅")
      m.replyPremium(`✅ Request berhasil dikirim ke Owner!\n\n🆔 *ID Request:* ${id}\nMohon tunggu persetujuan agar masuk ke dalam list sistem.`)
      break
    }

    // ==========================================
    // BAGIAN OWNER: MENERIMA REQUEST
    // ==========================================
    case "acc":
    case "terima": {
      // Pastikan hanya Owner yang bisa mengeksekusi ini
      if (!isOwner && m.sender !== ownerNum) return
      
      if (!args[0]) {
        await m.react("⚠️")
        return m.replyPremium(`❌ Masukkan ID request yang ingin diterima!\nContoh: \`${prefix + command}\` A1B2C3`)
      }
      
      let id = args[0].toUpperCase()
      if (!dbReq[id]) {
        await m.react("❌")
        return m.replyPremium("❌ ID Request tersebut tidak ditemukan di database!")
      }
      if (dbReq[id].status === "accepted") {
        await m.react("⚠️")
        return m.replyPremium("⚠️ Request ini sudah kamu terima sebelumnya!")
      }

      // Ubah status dan simpan permanen
      dbReq[id].status = "accepted"
      
      await m.react("✅")
      m.replyPremium(`✅ Request fitur ID *${id}* berhasil diterima dan resmi dimasukkan ke dalam list.`)
      
      // Memberi notifikasi kejutan ke user pembuat request
      await sock.sendMessage(dbReq[id].sender, { text: `✅ *Selamat!*\nRequest fitur kamu (ID: ${id}) bertema:\n_"${dbReq[id].text}"_\n\nTelah *DITERIMA* oleh Owner dan masuk ke dalam daftar antrean pengerjaan!` })
      break
    }

    // ==========================================
    // BAGIAN OWNER: MENOLAK REQUEST
    // ==========================================
    case "reject":
    case "tolak": {
      if (!isOwner && m.sender !== ownerNum) return
      
      if (!args[0]) {
        await m.react("⚠️")
        return m.replyPremium(`❌ Masukkan ID request yang ingin ditolak!\nContoh: \`${prefix + command}\` A1B2C3`)
      }
      
      let id = args[0].toUpperCase()
      if (!dbReq[id]) {
        await m.react("❌")
        return m.replyPremium("❌ ID Request tersebut tidak ditemukan di database!")
      }

      let userSender = dbReq[id].sender
      let userText = dbReq[id].text
      
      // Membuang data ke tempat sampah
      delete dbReq[id]
      
      await m.react("✅")
      m.replyPremium(`✅ Request fitur ID *${id}* berhasil ditolak dan dihapus sepenuhnya dari sistem.`)
      
      // Memberi notifikasi ke user bahwa idenya ditolak
      await sock.sendMessage(userSender, { text: `❌ *Mohon Maaf!*\nRequest fitur kamu (ID: ${id}) bertema:\n_"${userText}"_\n\nTelah *DITOLAK* oleh Owner. Jangan menyerah, silakan request ide cemerlang lainnya nanti!` })
      break
    }

    // ==========================================
    // BAGIAN UMUM: MELIHAT DAFTAR REQUEST
    // ==========================================
    case "listreqfitur":
    case "listreq": {
      await m.react("⏳")
      // Hanya mengambil data yang statusnya 'accepted'
      let list = Object.entries(dbReq).filter(([id, data]) => data.status === "accepted")
      
      if (list.length === 0) {
        await m.react("⚠️")
        return m.replyPremium("📉 Belum ada request fitur yang disetujui saat ini. Jadilah yang pertama dengan mengetik `.reqfitur`!")
      }

      let teks = `╭───┈ *「 LIST REQUEST FITUR 」*\n`
      teks += `│ 📊 *Total:* ${list.length} Fitur Menunggu\n╰───────────────┈ ⳹\n\n`
      
      let mentions = []
      list.forEach(([id, data], index) => {
        teks += `▧ *${index + 1}. ${data.text}*\n`
        teks += `> 🆔 ID: ${id}\n`
        teks += `> 👤 Pengusul: @${data.sender.split("@")[0]}\n`
        teks += `> 📅 Tanggal: ${data.date}\n\n`
        mentions.push(data.sender) // Menyimpan kontak untuk fitur Tag
      })

      await m.react("✅")
      
      // Merakit layout premium manual agar fitur "mentions" (Tag) bisa menyala
      await sock.sendMessage(m.chat, { 
        text: teks, 
        mentions: mentions,
        contextInfo: {
          isForwarded: true,
          forwardingScore: 999,
          forwardedNewsletterMessageInfo: { newsletterJid: global.idChannel, newsletterName: `💖 Assistant X Information || WhatsApp Bot 💖`, serverId: 1 },
          externalAdReply: { title: `💢 — ${global.botname} v${global.versibot}`, body: `© Powered by ${global.ownername}`, thumbnailUrl: global.thumbnail, sourceUrl: global.linkGrup, mediaType: 1, renderLargerThumbnail: false }
        }
      }, { quoted: m })
      break
    }

    // ==========================================
    // BAGIAN OWNER: MENGHAPUS DARI LIST
    // ==========================================
    case "delreqfitur":
    case "delreq": {
      if (!isOwner) return
      
      if (!args[0]) {
        await m.react("⚠️")
        return m.replyPremium(`❌ Masukkan ID request yang sudah selesai/ingin dihapus!\nContoh: \`${prefix + command}\` A1B2C3`)
      }
      
      let id = args[0].toUpperCase()
      if (!dbReq[id]) {
        await m.react("❌")
        return m.replyPremium("❌ ID Request tersebut tidak ada di dalam list!")
      }

      delete dbReq[id]
      await m.react("✅")
      m.replyPremium(`✅ Request fitur ID *${id}* telah berhasil dihapus secara permanen dari daftar List Request Fitur.`)
      break
    }
  }
}

// Mendaftarkan semua command dari switch case di atas
handler.command = ["reqfitur", "requestfitur", "acc", "terima", "reject", "tolak", "listreqfitur", "listreq", "delreqfitur", "delreq"]
handler.tags = ["informasi"]
handler.help = ["reqfitur <teks>", "listreqfitur"]

module.exports = handler
