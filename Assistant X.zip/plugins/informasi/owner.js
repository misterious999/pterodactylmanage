const { generateWAMessageFromContent } = require("@whiskeysockets/baileys");

let handler = async (m, { sock, prefix, command }) => {
    // 1. 🔬 DETEKTOR TIPE DATA DINAMIS (Anti-Potong)
    let rawOwner = global.owner;
    let ownerNumber = typeof rawOwner === 'string' ? rawOwner : (Array.isArray(rawOwner) ? rawOwner[0] : "628xxxxxxxxx");
    
    // Membersihkan karakter non-angka (berjaga-jaga jika ada tanda + atau spasi di config)
    ownerNumber = ownerNumber.replace(/[^0-9]/g, '');

    const ownerName = global.ownername || "Pstar7";
    const botName = global.botname || "Assistant X Project";

    await sock.sendMessage(m.chat, { react: { text: '👑', key: m.key } }).catch(() => {});

    // ==========================================
    // 2. INJEKSI VCARD (Kartu Kontak Otomatis)
    // ==========================================
    const vcard = 'BEGIN:VCARD\n' +
        'VERSION:3.0\n' +
        `FN:${ownerName}\n` +
        `ORG:${botName} Ecosystem;\n` +
        `TITLE:System Architect & Lead Developer\n` +
        `TEL;type=CELL;type=VOICE;waid=${ownerNumber}:+${ownerNumber}\n` +
        'END:VCARD';

    // Mesin mengirimkan file kontak agar user bisa langsung "Save"
    await sock.sendMessage(m.chat, { 
        contacts: { displayName: ownerName, contacts: [{ vcard }] }
    }, { quoted: m });

    // ==========================================
    // 3. RENDER KARTU IDENTITAS INTERAKTIF (UI/UX)
    // ==========================================
    let profileTeks = `╭─── [ *👑 EXCLUSIVE ACCESS* ] ───⳹\n`;
    profileTeks += `│ 👤 *Developer:* ${ownerName}\n`;
    profileTeks += `│ 📱 *WhatsApp:* wa.me/${ownerNumber}\n`;
    profileTeks += `│ 🏢 *Ecosystem:* ${botName}\n`;
    profileTeks += `│ ☁️ *Server:* Pterodactyl Node\n`;
    profileTeks += `╰────────────────────────┈ ⳹\n\n`;
    profileTeks += `_Infrastruktur kecerdasan buatan ini sepenuhnya dirancang, diprogram, dan dikelola secara eksklusif oleh ${ownerName}._\n\n_Silakan gunakan tombol di bawah ini untuk negosiasi bisnis, penyewaan peladen (Panel Store), atau pelaporan anomali sistem._`;

    // Metadata palsu agar pesan terlihat dikirim dari sistem pusat
    let fmeta = {
        key: { participant: '0@s.whatsapp.net', remoteJid: 'status@broadcast' },
        message: { conversation: '✧ Developer Credentials Authenticated ✧' }
    };

    // ==========================================
    // 4. PEMBANGKITAN TOMBOL NATIVE FLOW
    // ==========================================
    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                interactiveMessage: {
                    body: { text: profileTeks },
                    footer: { text: `Authorized by ${ownerName} 👑` }, 
                    nativeFlowMessage: { 
                        buttons: [
                            // Tombol 1: URL Hyperlink langsung ke PC Anda
                            {
                                name: "cta_url",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "💬 Chat Developer",
                                    url: `https://wa.me/${ownerNumber}?text=Halo+${ownerName},+saya+pengguna+${encodeURIComponent(botName)}...`,
                                    merchant_url: `https://wa.me/${ownerNumber}?text=Halo+${ownerName},+saya+pengguna+${encodeURIComponent(botName)}...`
                                })
                            },
                            // Tombol 2: Pintasan pemantauan jaringan
                            {
                                name: "quick_reply",
                                buttonParamsJson: JSON.stringify({ display_text: "📡 Status Jaringan", id: `${prefix}ping` })
                            }
                        ] 
                    },
                    contextInfo: { mentionedJid: [m.sender], isForwarded: true, forwardingScore: 9999, participant: "0@s.whatsapp.net", remoteJid: "status@broadcast" }
                }
            }
        }
    }, { userJid: m.chat, quoted: fmeta });

    // Eksekusi pengiriman antarmuka
    await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}

handler.tags = ["informasi"];
handler.command = ["owner"];
handler.help = ['owner'];

module.exports = handler;
