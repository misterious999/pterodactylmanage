const axios = require('axios');

let handler = m => m;

handler.before = async function (m, { sock }) {
    // 🔥 PERBAIKAN FATAL: Dilarang keras memakai 'return true', cukup 'return;' agar tidak membunuh command lain!
    if (m.isBaileys || !m.text) return;
    if (/^[./#!]/.test(m.text)) return;

    let txt = m.text;
    if (!global.btc) return;
    
    let urlRegex = /https?:\/\/[^\s]+/i;
    let match = txt.match(urlRegex);
    if (!match) return;
    
    let url = match[0];
    let endpoint = "";
    let platform = "";

    if (txt.includes('instagram.com')) {
        endpoint = global.botcahxUrl('/api/dowloader/igdowloader', { url });
        platform = "Instagram";
    } else if (txt.includes('tiktok.com') || txt.includes('vt.tiktok.com')) {
        endpoint = global.botcahxUrl('/api/dowloader/tiktok', { url });
        platform = "TikTok";
    } else if (txt.includes('capcut.com')) {
        endpoint = global.botcahxUrl('/api/dowloader/capcut', { url });
        platform = "CapCut";
    } else if (txt.includes('pin.it') || txt.includes('pinterest.com')) {
        endpoint = global.botcahxUrl('/api/dowloader/pinterest', { url });
        platform = "Pinterest";
    } else if (txt.includes('v.douyin.com')) {
        endpoint = global.botcahxUrl('/api/dowloader/douyin', { url });
        platform = "Douyin";
    }

    if (!platform) return;

    await m.react("⏳");

    try {
        let { data } = await axios.get(endpoint);
        let mediaUrl = "";
        let captionText = `╭───┈ *「 AUTO DOWNLOAD 」*\n│ 🎯 *Platform:* ${platform}\n│ ✅ *Status:* Berhasil Diunduh!\n╰───────────────┈ ⳹`;

        let res = data.result || data.message; 

        if (platform === "Instagram") {
            mediaUrl = Array.isArray(res) ? (res[0]?._url || res[0]?.url) : (res?._url || res?.url);
        } else if (platform === "TikTok") {
            mediaUrl = res?.video?.[0] || res?.video || res?.nowatermark;
        } else if (platform === "CapCut") {
            mediaUrl = res?.video_ori || res?.video;
        } else if (platform === "Pinterest") {
            mediaUrl = res?.data?.image || res?.image || (Array.isArray(res) ? res[0] : res);
        } else if (platform === "Douyin") {
            mediaUrl = Array.isArray(res) ? res[0]?.video : res?.video;
        }

        if (!mediaUrl || typeof mediaUrl !== 'string' || !mediaUrl.startsWith('http')) {
            throw new Error(`BOTCAHX memberikan respons kosong/error: ${mediaUrl}`);
        }

        if (platform === "Pinterest") {
            await sock.sendMessage(m.chat, { image: { url: mediaUrl }, caption: captionText }, { quoted: m });
        } else {
            await sock.sendMessage(m.chat, { video: { url: mediaUrl }, caption: captionText }, { quoted: m });
        }

        await m.react("✅");

    } catch (e) {
        console.error(`[AUTO DOWNLOAD ERROR - ${platform}]`, e.message);
        await m.react("❌");
    }

    return; // 🔥 PERBAIKAN: Akhiri dengan aman tanpa membunuh perintah lain.
}

module.exports = handler;
