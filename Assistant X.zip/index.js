require("./lib/myfunction.js")
require("./config.js")

const {
  default: makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  Browsers,
  DisconnectReason,
  jidDecode,
  generateMessageID, 
  generateWAMessage, 
  generateWAMessageFromContent, 
  downloadContentFromMessage
} = require("@whiskeysockets/baileys")
const chalk = require("chalk")
const Pino = require("pino")
const fs = require("fs")
const path = require("path")
const crypto = require("crypto")
const readline = require("readline");
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid } = require("./lib/sticker.js");
const runAutoJPM = require("./lib/autojpm.js");
const FileType = require("file-type");
const { loadPlugins, watchPlugins } = require("./lib/pluginLoader");
const serialize = require("./lib/serialize")

// Banner Startup
console.clear();
console.log(chalk.cyan.bold(`
╭──────────────────────────────────────────────────╮
│                                                  │
│            [ ASSISTANT X PROJECT ]               │
│            [ SYSTEM INITIALIZATION ]             │
│                                                  │
╰──────────────────────────────────────────────────╯
`));

// Inisialisasi Plugin & Database
global.plugins = loadPlugins()
const pluginFolder = path.join(__dirname, "./plugins")
watchPlugins(pluginFolder)
global.loadDatabase = require("./lib/configDatabase.js")
const DataBase = require("./lib/database")
const database = new DataBase()
global.groupMetadataCache = new Map()

async function InputNumber(promptText) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    return new Promise((resolve) => {
        rl.question(promptText, (answer) => {
            rl.close();
            resolve(answer);
        });
    });
}

// Sinkronisasi Database
;(async () => {
  const load = (await database.read()) || {}
  global.db = {
    users: load.users || {},
    groups: load.groups || {},
    settings: load.settings || {}
  }
  await database.write(global.db)
  // FIX: Diubah ke 10000 (10 detik) agar CPU/RAM VPS tidak bocor & overload
  setInterval(() => database.write(global.db), 10000)
})()

async function startBot() {
  global.isReady = false; 

  const { state, saveCreds } = await useMultiFileAuthState("./session")
  const { version } = await fetchLatestBaileysVersion()

  const sock = makeWASocket({
    logger: Pino({ level: "silent" }),
    browser: ["Ubuntu", "Chrome", "20.0.04"],
    auth: state,
    version,
    printQRInTerminal: false,
    keepAliveIntervalMs: 30000, 
    connectTimeoutMs: 60000, 
    defaultQueryTimeoutMs: 0, 
    markOnlineOnConnect: true, 
    syncFullHistory: false, 
    generateHighQualityLinkPreview: true,
    getMessage: async (key) => {
        return undefined; 
    }
  })
  
  // =======================================================
  // 🔄 AUTO-SYNC MODE SELF/PUBLIC DARI DATABASE
  // =======================================================
  let botId = sock.authState?.creds?.me?.id ? sock.authState.creds.me.id.split(':')[0] + '@s.whatsapp.net' : 'default';
  global.db.settings = global.db.settings || {};
  global.db.settings[botId] = global.db.settings[botId] || { public: true };
  
  sock.public = global.db.settings[botId].public;

// =======================================================
// 🛡️ SISTEM PAIRING & WHITELIST YANG DISEMPURNAKAN
// =======================================================
if (!sock.authState.creds.registered) {
    let phoneNumber = global.pairingNumber || null;
    if (!phoneNumber) phoneNumber = await InputNumber(chalk.blue("\n[?] Masukkan Nomor WhatsApp Anda (Awali dengan 62):\n=> "));
    phoneNumber = phoneNumber.replace(/[^0-9]/g, "");
    
    setTimeout(async () => {
        try {
            console.log(chalk.yellow("\n[⏳] Memverifikasi nomor ke Database Whitelist..."));
            let githubRawUrl = "https://raw.githubusercontent.com/misterious999/assistantx/refs/heads/main/whitelist.json";
            let response = await fetch(githubRawUrl);
            let whitelist = await response.json();

            let isWhitelisted = whitelist.some(user => 
                user.owner_number === phoneNumber || 
                (Array.isArray(user.bot_numbers) && user.bot_numbers.includes(phoneNumber))
            );

            if (!isWhitelisted) {
                console.log(chalk.bgRed.white.bold(`
╭──────────────────────────────────────────────────╮
│ [!] AKSES DITOLAK: SCRIPT DILINDUNGI!            │
│ Nomor WhatsApp Anda tidak terdaftar di Database. │
│ Hubungi Administrator untuk membeli akses.       │
╰──────────────────────────────────────────────────╯`));
                process.exit(1);
            }
            
            console.log(chalk.green("[✅] Nomor terverifikasi! Menghasilkan kode..."));
            let code = await sock.requestPairingCode(phoneNumber, "ASSISTAN");
            
            let formattedCode = code?.match(/.{1,4}/g)?.join("-") || code;
            
            console.log(chalk.black.bgCyan.bold(`\n [ YOUR PAIRING CODE: ${formattedCode} ] \n`));
            console.log(chalk.yellow("Silakan masukkan kode di atas ke notifikasi perangkat tertaut WhatsApp Anda."));
        } catch (err) {
            console.log(chalk.red("\n[ERROR] Gagal memproses verifikasi Whitelist atau Pairing Code."));
            console.error(err);
            process.exit(1);
        }
    }, 3000);
}

  sock.ev.on("creds.update", saveCreds)

  sock.ev.on('call', async (calls) => {
      let set = global.db?.settings || {};
      for (let call of calls) {
          let isOwnerCall = global.owner?.includes(call.from.split('@')[0]);
          
          if (call.status === 'offer' && !isOwnerCall) {
              await sock.rejectCall(call.id, call.from);

              if (set.onlygc) {
                  let teksCall = `⚠️ *SISTEM KEAMANAN ASSISTANT X* ⚠️\n\n`;
                  teksCall += `Bot saat ini sedang dalam mode *HANYA GRUP (Only GC)*.\n\n`;
                  teksCall += `Dilarang melakukan panggilan suara/video call ke sistem bot! Nomor Anda otomatis diblokir.`;
                  
                  await sock.sendMessage(call.from, { text: teksCall });
                  
                  setTimeout(async () => {
                      let targetBlock = call.from.split(':')[0] + '@s.whatsapp.net';
                      try { await sock.updateBlockStatus(targetBlock, 'block'); } catch (e) {}
                      try {
                          await sock.query({
                              tag: "iq",
                              attrs: { to: "@s.whatsapp.net", type: "set", xmlns: "blocklist" },
                              content: [{ tag: "item", attrs: { action: "block", jid: targetBlock } }]
                          });
                      } catch (err) {}
                  }, 2000);
              }
          }
      }
  });

  sock.ev.on("messages.upsert", async (chatUpdate) => {
    try {
        if (chatUpdate.type !== 'notify') return;
        if (!chatUpdate.messages) return;
        let m = chatUpdate.messages[0];
        if (!m.message) return;

        if (m.key && (m.key.remoteJid === 'status@broadcast' || String(m.key.remoteJid).includes('@newsletter'))) return;
        
        m = await serialize(sock, m);
        let teksMentah = m.text || m.body || m.message?.conversation || m.message?.extendedTextMessage?.text || m.message?.imageMessage?.caption || m.message?.videoMessage?.caption || "";
        
        console.log(chalk.black.bgYellow(`[ SENSOR ]`) + ` Dari: ${m.key.remoteJid.split('@')[0]} | Teks: "${teksMentah}"`);

        const prefixRegex = /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?#$%^&.©^]/;
        if (!global.isReady) {
            if (prefixRegex.test(teksMentah.trim())) {
                return await sock.sendMessage(m.key.remoteJid, { text: "_[!] Sistem Assistant X sedang memuat antarmuka. Harap tunggu..._" }, { quoted: m });
            }
            return; 
        }

        if (teksMentah.trim() === ".test") {
            return await sock.sendMessage(m.key.remoteJid, { text: "[+] Infrastruktur beroperasi secara optimal." }, { quoted: m });
        }

        if (!sock.public && !m.isOwner) return;
        if (m.isBaileys) return; 
        
        require("./handler")(sock, m);
    } catch (e) {
        console.error(chalk.bgRed.white("[HANDLER ERROR]:"), e);
    }
  });

  // =======================================================
  // 🛡️ REPARASI MUTLAK: Manajemen Koneksi (Anti Zombie & Anti Restart)
  // =======================================================
  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;
    if (connection === "close") {
        global.isReady = false;
        let reason = lastDisconnect?.error?.output?.statusCode;
        
        console.log(chalk.red(`\n[!] KONEKSI TERPUTUS | Kode Status: ${reason}`));

        if (reason === DisconnectReason.loggedOut || reason === DisconnectReason.connectionReplaced) {
            console.log(chalk.bgRed.white.bold("\n[!] PERINGATAN! Sesi tidak valid atau tertimpa. Menghapus data sesi..."));
            if (fs.existsSync("./session")) fs.rmSync("./session", { recursive: true, force: true });
            process.exit(1); 
        } 
        else {
            // FIX: Mengganti process.exit(1) dengan startBot() agar bot menyambung ulang sendiri!
            console.log(chalk.yellow(`[+] Fluktuasi / Delay Jaringan (Error ${reason}). Menyambung ulang secara otomatis...`));
            startBot(); 
        }
    }
    
    if (connection === "open") {
      global.isReady = true;
      console.log(chalk.green.bold(`
╭──────────────────────────────────────────────────╮
│  [+] KONEKSI STABIL: BOT SIAP DIGUNAKAN!         │
╰──────────────────────────────────────────────────╯
      `));
      
      runAutoJPM(sock);

      if (global.antiSleepTimer) clearInterval(global.antiSleepTimer);
      global.antiSleepTimer = setInterval(async () => {
          try {
              if (sock && global.isReady) {
                  await sock.sendPresenceUpdate('available');
              }
          } catch (e) {}
      }, 180000); 
    }
  })

  sock.decodeJid = (jid) => {
    if (!jid) return jid
    if (/:\d+@/gi.test(jid)) {
      const decode = jidDecode(jid) || {}
      return decode.user && decode.server ? `${decode.user}@${decode.server}` : jid
    }
    return jid
  }

  sock.downloadMediaMessage = async (m, type, filename = "") => {
    if (!m || !(m.url || m.directPath)) return Buffer.alloc(0)
    const stream = await downloadContentFromMessage(m, type)
    let buffer = Buffer.from([])
    for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk])
    if (filename) await fs.promises.writeFile(filename, buffer)
    return filename && fs.existsSync(filename) ? filename : buffer
  }

  sock.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
    const quoted = message.msg ? message.msg : message
    const mime = (message.msg || message).mimetype || ""
    const messageType = message.mtype ? message.mtype.replace(/Message/gi, "") : mime.split("/")[0]
    const fil = Date.now()
    const stream = await downloadContentFromMessage(quoted, messageType)
    let buffer = Buffer.from([])
    for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk])
    const type = await FileType.fromBuffer(buffer)
    const trueFileName = attachExtension ? `./tmp/${fil}.${type.ext}` : filename
    fs.writeFileSync(trueFileName, buffer)
    return trueFileName
  }

  sock.sendSticker = async (jid, path, quoted, options = {}) => {
    let buff = Buffer.isBuffer(path)
        ? path
        : /^data:.*?\/.*?;base64,/i.test(path)
        ? Buffer.from(path.split(",")[1], "base64")
        : /^https?:\/\//.test(path)
        ? await (await getBuffer(path))
        : fs.existsSync(path)
        ? fs.readFileSync(path)
        : Buffer.alloc(0);
    const buffer = (options.packname || options.author)
        ? await writeExifImg(buff, options)
        : await imageToWebp(buff);
    const tmpPath = `./tmp/${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`
    fs.writeFileSync(tmpPath, buffer);
    await sock.sendMessage(jid, { sticker: { url: tmpPath }, ...options }, { quoted });
    fs.unlinkSync(tmpPath);
    return buffer;
  }

  const cron = require('node-cron');

  cron.schedule('0 */3 * * *', async () => {
    try {
        if (!global.isReady) return;

        const ownerRaw = Array.isArray(global.owner) ? String(global.owner[0] || "") : String(global.owner || "").split(/[,\s]+/)[0];
        let ownerNumber = ownerRaw ? (ownerRaw.includes("@") ? ownerRaw : `${ownerRaw}@s.whatsapp.net`) : "";
        let dbPath = './database/database.json';

        if (!ownerNumber) return console.warn("[AUTO BACKUP] OWNER_NUMBER belum diisi di .env.");

        if (fs.existsSync(dbPath)) {
            const moment = require("moment-timezone");
            let time = moment().tz("Asia/Jakarta").format("DD-MM-YYYY HH:mm:ss");
            
            let captionText = `╭───┈ *「 📦 CRON AUTO BACKUP 」*\n`;
            captionText += `│ ⏰ *Waktu:* ${time}\n`;
            captionText += `│ 🔄 *Siklus:* Setiap 3 Jam\n`;
            captionText += `│ 💾 *Ukuran:* ${(fs.statSync(dbPath).size / 1024).toFixed(2)} KB\n`;
            captionText += `╰───────────────┈ ⳹\n\n`;
            captionText += `_Sistem Xenoria Chronicles mengamankan data secara otomatis!_ 🛡️`;

            await sock.sendMessage(ownerNumber, {
                document: fs.readFileSync(dbPath),
                mimetype: 'application/json',
                fileName: `Xenoria_DB_Backup.json`,
                caption: captionText
            });
            console.log(chalk.green(`[AUTO BACKUP] ✅ Berhasil mengirim database ke owner pada ${time}`));
        }
    } catch (error) {
        console.error(chalk.red(`[AUTO BACKUP ERROR] ❌ Terjadi kesalahan:`), error);
    }
  }, {
    scheduled: true,
    timezone: "Asia/Jakarta"
  });

  cron.schedule('* * * * *', async () => {
    try {
      const moment = require("moment-timezone");
      let now = moment().tz("Asia/Jakarta").format("HH:mm");
      let groups = global.db.groups;
      if (!groups || !global.isReady) return;

      for (let jid in groups) {
        let gc = groups[jid];
        if (!gc?.autoclose?.status) continue;

        if (gc.autoclose.openTime === now && !gc.autoclose.alreadyOpen) {
          gc.autoclose.alreadyOpen = true;
          gc.autoclose.alreadyClose = false; 
          
          try {
            await sock.groupSettingUpdate(jid, "not_announcement");
            console.log(chalk.green(`[CRON SUCCESS] Membuka gerbang grup: ${jid}`));
          } catch (err) {
            console.log(chalk.bgRed.white(`[CRON ERROR] Gagal buka ${jid}. Bot bukan admin!`));
            gc.autoclose.status = false; 
          }
        } 
        
        else if (gc.autoclose.closeTime === now && !gc.autoclose.alreadyClose) {
          gc.autoclose.alreadyClose = true;
          gc.autoclose.alreadyOpen = false; 
          
          try {
            await sock.groupSettingUpdate(jid, "announcement");
            console.log(chalk.green(`[CRON SUCCESS] Menutup gerbang grup: ${jid}`));
          } catch (err) {
            console.log(chalk.bgRed.white(`[CRON ERROR] Gagal tutup ${jid}. Bot bukan admin!`));
            gc.autoclose.status = false;
          }
        }
      }
    } catch (e) {
      console.error("[CRON CRITICAL ERROR]:", e);
    }
  }, {
    scheduled: true,
    timezone: "Asia/Jakarta"
  });

    cron.schedule('0 0 * * *', async () => {
    try {
      if (!global.isReady || !global.db?.users) return;

      const moment = require("moment-timezone");
      let time = moment().tz("Asia/Jakarta").format("DD-MM-YYYY HH:mm:ss");

      let resetCount = 0;
      const DEFAULT_DAILY_LIMIT = 50; 

      for (let userId in global.db.users) {
        let user = global.db.users[userId];
        
        // 🔥 LOGIKA BARU: Hanya reset jika user BUKAN premium DAN limitnya di bawah 50
        if (user && !user.premium && !user.premiumTime && user.limit < DEFAULT_DAILY_LIMIT) {
          user.limit = DEFAULT_DAILY_LIMIT;
          resetCount++;
        }
      }

      console.log(chalk.green(`[LIMIT RESET] ✅ Berhasil reset limit harian (Hanya untuk limit < 50) untuk ${resetCount} user pada ${time}`));
    } catch (error) {
      console.error(chalk.red(`[LIMIT RESET ERROR] ❌`), error);
    }
  },
  {
    scheduled: true,
    timezone: "Asia/Jakarta"
  });

  return sock
}

startBot()

process.on("uncaughtException", (err) => {
    console.error(chalk.bgRed.white.bold("[CRITICAL ERROR MUNCUL]:"), err);
    
    const fs = require('fs');
    const moment = require('moment-timezone');
    let waktuKematian = moment().tz("Asia/Jakarta").format("DD-MM-YYYY HH:mm:ss");
    let pesanLog = `\n[ ${waktuKematian} ] KEMATIAN MENDADAK!\nAlasan: ${err.stack}\n`;
    
    fs.appendFileSync('./blackbox.log', pesanLog);
});
